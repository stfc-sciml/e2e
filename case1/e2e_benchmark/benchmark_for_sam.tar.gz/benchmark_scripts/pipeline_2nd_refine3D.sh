#!/bin/bash

# Set this environment variable to something unique for each
# run of this benchmark
export RELION_BENCHMARK='benchmark1'
mkdir -p benchmark_scripts/${RELION_BENCHMARK}

# disabled for the moment, as long job
##jid1=$(sbatch --parsable --output=benchmark_scripts/${RELION_BENCHMARK}/refine3D.out --error=benchmark_scripts/${RELION_BENCHMARK}/refine3D.err benchmark_scripts/Refine3D043_slurm.sh)

##echo "Refine3D submitted, job $jid1"

# first job - no dependencies
jid2=$(sbatch --parsable --output=benchmark_scripts/${RELION_BENCHMARK}/mask_post.out --error=benchmark_scripts/${RELION_BENCHMARK}/mask_post.err benchmark_scripts/MaskCreate048_PostProcess049_slurm.sh)

echo "MaskCreate + PostProcess submitted, job $jid2"

# depends on previous job
jid3=$(sbatch --parsable  --dependency=afterany:${jid2} --output=benchmark_scripts/${RELION_BENCHMARK}/ctfrefine.out --error=benchmark_scripts/${RELION_BENCHMARK}/ctfrefine.err benchmark_scripts/CtfRefine050_slurm.sh)

echo "CtfRefine submitted, job $jid3"
