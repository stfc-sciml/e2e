#!/bin/bash

#SBATCH --ntasks=1
#SBATCH --partition=scarf
#SBATCH --cpus-per-task=12

mkdir -p benchmark_scripts/${RELION_BENCHMARK}/CtfRefine

mpirun time `which relion_ctf_refine` --i Refine3D/job043/run_data.star --f benchmark_scripts/${RELION_BENCHMARK}/PostProcess/postprocess.star --o benchmark_scripts/${RELION_BENCHMARK}/CtfRefine/ --fit_defocus --kmin_defocus 30 --fit_mode fpmff --fit_beamtilt --kmin_tilt 30 --j 12

