#!/bin/bash

#SBATCH --ntasks=5
#SBATCH --partition=gpu
#SBATCH --cpus-per-task=1
#SBATCH --nodes=1
#SBATCH --gres=gpu:4

mkdir -p benchmark_scripts/${RELION_BENCHMARK}/Refine3D

mpirun time `which relion_refine_mpi` --o benchmark_scripts/${RELION_BENCHMARK}/Refine3D/run --auto_refine --split_random_halves --i Select/job042/particles.star --ref Class3D/job039/run_it025_class002.mrc --ini_high 30 --dont_combine_weights_via_disc --pool 30 --pad 1  --skip_gridding  --ctf --ctf_corrected_ref --particle_diameter 120 --flatten_solvent --zero_mask --oversampling 1 --healpix_order 2 --auto_local_healpix_order 4 --offset_range 5 --offset_step 2 --sym D2 --low_resol_join_halves 40 --norm --scale  --j 1 --gpu ""

