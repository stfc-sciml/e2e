#!/bin/bash

#SBATCH --partition=scarf
#SBATCH --nodes=1

mkdir -p benchmark_scripts/${RELION_BENCHMARK}/MaskCreate

time `which relion_mask_create` --i Refine3D/job043/run_class001.mrc --o benchmark_scripts/${RELION_BENCHMARK}/MaskCreate/mask.mrc --lowpass 15 --ini_threshold 0.007 --extend_inimask 0 --width_soft_edge 5 --j 1

if [[ ! -e benchmark_scripts/${RELION_BENCHMARK}/MaskCreate/mask.mrc ]]; then
    echo "relion_mask_create failed to output mask"
    exit 1
fi

mkdir -p benchmark_scripts/${RELION_BENCHMARK}/PostProcess

time `which relion_postprocess` --mask benchmark_scripts/${RELION_BENCHMARK}/MaskCreate/mask.mrc --i Refine3D/job043/run_half1_class001_unfil.mrc --o benchmark_scripts/${RELION_BENCHMARK}/PostProcess/postprocess  --angpix -1 --mtf benchmark_scripts/mtf_k2_200kV.star --mtf_angpix 0.56 --auto_bfac  --autob_lowres 10

if [[ ! -e benchmark_scripts/${RELION_BENCHMARK}/PostProcess/postprocess.star ]]; then
    echo "relion_ctf_refine failed to output postprocess.star"
    exit 1
fi
