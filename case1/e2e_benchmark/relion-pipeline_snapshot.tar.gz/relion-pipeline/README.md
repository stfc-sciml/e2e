# pipeliner

Python pipeliner for RELION and CCP-EM

### Getting started

It's a good idea to work in a virtual environment for this project. Set one up as
follows:

```
python3 -m venv venv/
source venv/bin/activate
pip install -r requirements.txt
pip install -r requirements-dev.txt
pre-commit install
```

This project uses [pre-commit](https://pre-commit.com/) to run
[Black](https://black.readthedocs.io/) for code formatting,
[flake8](https://flake8.pycqa.org/) for linting and some other simple checks.

You might want to install Black separately yourself too, so you can run it from your
IDE.

According to the flake8 documentation, flake8 should not stop a git commit from going
ahead unless `flake8.strict` is set in the git config. That doesn't actually seem to
work: with the current configuration, commits fail if flake8 finds any problems. There
are some flake8 warnings that have not been fixed yet, so to get round this, flake8
checks can be disabled: `SKIP=flake8 git commit ...`

Run the test suite with `python -m unittest`.
For the plugins tests paths for cryoEF, crYOLO and the pipeliner modified version of ThreeDFSC
need to be set in the `$RELION_CRYOEF_PATH`, `RELION_CRYOLO_PATH`, and `RELION_THREEDFSC_PATH` env variables respectivly.

Some of the tests are quite slow or require some interaction; so this just runs a subset of essential tests.
Set the environment variable `$UNITTEST_FULL` to `True` to run the slower tests as well.
Set the environment variable `$UNITTEST_INTERACTIVE` to `True` to also run the tests that require interaction.
