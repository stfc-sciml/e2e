import sys
from pipeliner.data_structure import NODES
from pipeliner.utils import raise_error


class RelionPlugIn:
    def __init__(self, fn_in):
        self.plugin_file = fn_in
        self.python_code = None
        self.name = None
        self.id = None
        self.version = None
        self.process_name = None
        self.inputs_types = None
        self.outputs_types = None
        self.exe_list = list()
        self.read_plugin_file()

    def read_plugin_file(self):
        python_code_lines = []
        plugin_header_lines = []
        in_python_code = False

        # read the plugin file and get the header and code
        with open(self.plugin_file, "r") as plugin_file:
            plugin_lines = plugin_file.readlines()

        code_section = any(
            "#relion_plugin_code" in string.rstrip() for string in plugin_lines
        )

        if not code_section:
            raise_error(
                "ERROR: Plugin does not contain the code block labelled"
                " '#relion_plugin_code'"
            )

        for line in plugin_lines:
            if "#relion_plugin_code" in line:
                in_python_code = True
            if not in_python_code:
                plugin_header_lines.append(line)
            else:
                python_code_lines.append(line)

        self.python_code = "".join(python_code_lines)

        plugin_header = "".join(plugin_header_lines)
        global plugin_exes
        global plugin_input_types
        global plugin_output_types
        global pluginName
        global pluginID
        global pluginProcessName
        global pluginVersion

        plugin_input_types = None
        plugin_output_types = None

        header_code = (
            "global plugin_exes\nglobal plugin_input_types\n"
            "global plugin_output_types\nglobal pluginName\n"
            "global pluginID\nglobal pluginProcessName\n"
            "global pluginVersion\n" + plugin_header
        )

        try:
            exec(header_code, globals(), {"NODES": NODES})

        except Exception:
            e_type, e_object, e_traceback = sys.exc_info()
            self.is_bad = (
                "\nERROR: Encountered an error reading the header of plugin "
                "file:\n {}\n The error was:\n {}: {} when it was run by {}".format(
                    self.plugin_file, e_type, e_object, e_traceback
                )
            )

        # make sure the appropriate input and output types have been
        # defined by the plugin
        if plugin_input_types is None:
            bad_message = (
                "ERROR: The plugin {} did not define a dictionary of allowed inputs"
                " in its header.\nIf no inputs are needed use an empty dict".format(
                    pluginName
                )
            )

        elif plugin_output_types is None:
            bad_message = (
                "ERROR: The plugin {} did not define a dictionary of allowed outputs"
                " in its header.\nIf no outputs are needed use an empty dict".format(
                    pluginName
                )
            )
        else:
            bad_message = False

        self.exe_list = plugin_exes
        self.inputs_types = plugin_input_types
        self.outputs_types = plugin_output_types
        self.name = pluginName
        self.id = pluginID
        self.process_name = pluginProcessName
        self.version = pluginVersion
        self.is_bad = bad_message
