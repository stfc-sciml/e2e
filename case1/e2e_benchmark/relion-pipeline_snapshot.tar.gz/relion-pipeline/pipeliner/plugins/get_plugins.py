import os
import subprocess
from glob import glob
from .plugins_data import RelionPlugIn
from pipeliner.utils import get_project_root, raise_error


def gather_plugins():
    """Check the plugin's dir and make a dict of all plugins"""
    plugins_dir = os.path.join(get_project_root(), "plugins/active")
    plugin_files = glob(plugins_dir + "/*.rln")
    plugins_dict = {}
    plugin_errors = []
    for plug_file in plugin_files:
        try:
            plugin = RelionPlugIn(plug_file)

            if plugin.id in plugins_dict:
                raise_error(
                    "ERROR: Two different plugins are attempting to use the"
                    " plugin ID {}:\n{}\n{}\nAll plugins need unique IDs".format(
                        plugin.id, plug_file, plugins_dict[plugin.id].plugin_file
                    )
                )
            if plugin.is_bad:
                print(plugin.is_bad, plugin.id)
                plugin_errors.append(
                    [
                        "WARNING: Plugin {} cannot be used because it raised the "
                        "following error:\n{}".format(plugin.name, plugin.is_bad),
                        plugin.id,
                    ]
                )
            else:
                plugins_dict[plugin.id] = plugin

        except (SyntaxError, AttributeError, ValueError) as e:
            plugin_errors.append(
                [
                    "WARNING: Error reading plugin at {}\nThis plug in will not"
                    " be available because is raised the following error:\n".format(
                        plug_file
                    )
                    + str(e),
                    plugin.id,
                ]
            )
    return (plugins_dict, plugin_errors)


def get_plugin(plugin_type):
    plugins_dict = gather_plugins()
    if plugin_type in plugins_dict:
        return plugins_dict[plugin_type]
    else:
        raise_error(
            "ERROR: Cannot find Process or plugin for process type " + plugin_type
        )


def validate_plugin(the_plugin):
    """Make sure that any external programs called by the plugin actually exist"""
    for exe_file in the_plugin.exe_list:
        if exe_file != "None":
            # check if the exe_file is not an absolute path
            if os.path.isfile(exe_file):
                exe_path = exe_file
            # if it's not find it with which
            else:
                exe_which = subprocess.run(["which", exe_file], stdout=subprocess.PIPE)
                exe_path = os.path.abspath(exe_which.stdout.decode().rstrip())
            if not os.path.isfile(exe_path):
                raise_error(
                    "ERROR: External executable {} in plugin {}({}) is not a valid "
                    "file".format(exe_file, the_plugin.process_name, the_plugin.id)
                )
    return True
