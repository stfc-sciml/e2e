"""
jobstar_reader

Reads the job.star files that relion 3.1 uses to replace run.out
writes a run.out from a job.star
"""
import subprocess
import os
import re
import time
from itertools import islice
from gemmi import cif
from pipeliner.job_options import JobOption
from pipeliner.utils import get_env_var

datalabels = [
    "data_",
    "data_pipeline_general",
    "data_pipeline_processes",
    "data_pipeline_nodes",
    "data_pipeline_input_edges",
    "data_pipeline_output_edges",
    "data_job",
    "data_joboptions_values",
    "data_joboptions_full_definition",
    "data_guinier",
    "data_fsc",
    "data_general",
    "data_optics",
    "data_micrographs",
    "data_particles",
    "data_movies",
    "data_model_class_",
    "data_model_group_",
    "data_model_general",
    "data_model_classes",
    "data_model_groups",
    "data_model_pdf_orient_class_",
]
reserved_words = [
    "stop_",
    "data_",
    "save_",
    "global_",
    "loop_",
]


class JobStar:
    def __init__(self, fn_in):
        """Read a job.star file """
        # Check that the file does not have any reserved work errors
        infile = StarfileCheck(fn_in)
        infile.check_reserved_words()
        itime = 0
        if infile.been_corrected:
            # the file might take some time to write... wait for it
            while not os.path.isfile(infile.tmp_name):
                time.sleep(1)
                itime += 1
                if itime > 30:
                    raise ValueError(
                        "ERROR: Waitied 30 sec for the file {} to write but it hasn't."
                        "  Are there disk access issues?"
                    )

            fn_in = infile.tmp_name

        # read the starfile
        self.data = cif.read_file(fn_in)

        # remove the temp file if it was corrected
        if infile.been_corrected and infile.remove_temp:
            subprocess.run(["rm", infile.tmp_name])

        # get the dat blocks
        self.pipeline_info = self.data.find_block("job")
        self.options = self.data.find_block("joboptions_values").find_loop(
            "_rlnJobOptionVariable"
        )
        self.values = self.data.find_block("joboptions_values").find_loop(
            "_rlnJobOptionValue"
        )

    def count_blocks(self):
        return len(self.data)

    def count_pipeline(self):
        return len(list(self.pipeline_info))

    def count_jobopt(self):
        return len(list(self.options))

    def get_all_options(self):
        joboptions = {}
        job_options = list(zip(list(self.options), list(self.values)))
        for item in self.pipeline_info:
            if item.pair is not None:
                job_options.append((item.pair[0], item.pair[1]))
        for item in job_options:
            joboptions[item[0].replace("'", "").replace('"', "")] = (
                item[1].replace("'", "").replace('"', "")
            )
        return joboptions

    def get_plugin_options(self):
        """Returns a dict of JobOption objects all of which are
        .as_textbox() type except a few which need to be other types"""
        joboptions = {}
        job_options = list(zip(list(self.options), list(self.values)))
        for item in self.pipeline_info:
            if item.pair is not None:
                job_options.append((item.pair[0], item.pair[1]))
        for item in job_options:
            # all job options here are returned as strings except some which
            # need to be joboption classes for plugins
            jo = item[0].replace("'", "").replace('"', "")
            if jo == "do_queue":
                do_queue_default = get_env_var("RELION_QUEUE_USE", False)
                joboptions[jo] = JobOption.as_boolean(
                    "Submit to queue?",
                    do_queue_default,
                    "If set to Yes, the job will be submit to a queue,"
                    " otherwise the job will be executed locally. Note "
                    "that only MPI jobs may be sent to a queue. The default "
                    "can be set through the environment variable RELION_QUEUE_USE.",
                )
                joboptions[jo].value = item[1]

            elif jo == "min_dedicated":
                min_cores_default = get_env_var("RELION_MINIMUM_DEDICATED", 1)
                joboptions[jo] = JobOption.as_slider(
                    "Minimum dedicated cores per node: ",
                    min_cores_default,
                    1,
                    64,
                    1,
                    "Minimum number of dedicated cores that need to be requested "
                    "on each node. This is useful to force the queue to fill up entire "
                    "nodes of a given size. The default can be set through the"
                    " environment variable RELION_MINIMUM_DEDICATED.",
                )
                joboptions[jo].value = int(item[1])

            elif jo == "nr_mpi":
                joboptions[jo] = JobOption.as_slider(
                    "Number of MPI procs:",
                    1,
                    1,
                    64,
                    1,
                    "Number of MPI nodes to use in parallel. When set to 1"
                    ", MPI will not be used. The maximum can be set through the"
                    " environment variable RELION_MPI_MAX.",
                )
                joboptions[jo].value = int(item[1])

            else:
                joboptions[jo] = JobOption.as_textbox(
                    "Plugin string variable: " + jo,
                    None,
                    "This is a general string variable for a plugin",
                )
                if item[1] in ["''", '""']:
                    joval = ""
                else:
                    joval = item[1].replace("'", "").replace('"', "")
                joboptions[jo].value = joval

        return joboptions


class BodyFile:
    """A star file that lists the bodies in a multibody refinement"""

    def __init__(self, fn_in):
        bodyfile = StarfileCheck(fn_in)
        if bodyfile.been_corrected:
            fn_in = bodyfile.tmp_name

        self.data = cif.read_file(fn_in)

        if bodyfile.been_corrected and bodyfile.remove_temp:
            subprocess.run(["rm", bodyfile.tmp_name])

        self.bodies = self.data.sole_block()

    def count_bodies(self):
        bodycount = len(self.bodies.find_loop("_rlnBodyMaskName"))
        return bodycount


class ExportStar:
    """Read a star file that lists exported jobs"""

    def __init__(self, fn_in):
        exportfile = StarfileCheck(fn_in)
        if exportfile.been_corrected:
            fn_in = exportfile.tmp_name

        self.data = cif.read_file(fn_in)

        if exportfile.been_corrected and exportfile.remove_temp:
            subprocess.run(["rm", exportfile.tmp_name])

        self.jobs = self.data.sole_block()


class OutputNodeStar:
    def __init__(self, fn_in):
        on_file = StarfileCheck(fn_in)
        if on_file.been_corrected:
            fn_in = on_file.tmp_name

        self.data = cif.read_file(fn_in)

        if on_file.been_corrected and on_file.remove_temp:
            subprocess.run(["rm", on_file.tmp_name])

    def get_output_nodes(self):
        on_block = self.data.find_block("output_nodes")
        nodes_table = on_block.find(["_rlnPipeLineNodeName", "_rlnPipeLineNodeType"])
        return nodes_table


class JobstarLine:
    """ composes the lines for the joboptions_full_description block"""

    JOBTYPES = {
        "TEXTBOX": 1,
        "FILENAME": 2,
        "INPUTNODE": 3,
        "RADIO": 4,
        "BOOLEAN": 5,
        "SLIDER": 6,
    }

    RADIO_OPTIONS = {
        "SAMPLING": JobOption.SAMPLING,
        "NODETYPE": JobOption.NODETYPE,
        "NODETYPE_OPTIONS": JobOption.NODETYPE_OPTIONS,
        "GAIN_ROTATION": JobOption.GAIN_ROTATION,
        "GAIN_FLIP": JobOption.GAIN_FLIP,
        "CTF_FIT": JobOption.CTF_FIT,
    }

    def star_format(self, in_val):
        """Format text for a longform text in a starfile.  Replace
        spaces with __"""
        if in_val != "":
            format_val = in_val.replace(" ", "__").replace("\n", "__")
        else:
            format_val = '""'
        return format_val

    def __init__(self, option, joboptions):
        self.opt = joboptions[option]
        self.option_type = self.opt.joboption_type
        self.option = option

    def boolean_opt(self):
        line = [
            self.option,
            self.star_format(self.opt.label),
            self.JOBTYPES[self.option_type],
            self.opt.defaultvalue,
            "0",
            "0",
            "0",
            "undefined",
            "undefined",
            self.star_format(self.opt.helptext),
            "++undefined++",
        ]
        return line

    def slider_opt(self):
        line = [
            self.option,
            self.star_format(self.opt.label),
            self.JOBTYPES[self.option_type],
            self.opt.defaultvalue,
            self.opt.minvalue,
            self.opt.maxvalue,
            self.opt.stepvalue,
            "undefined",
            "undefined",
            self.star_format(self.opt.helptext),
            "++undefined++",
        ]
        return line

    def textbox_opt(self):
        line = [
            self.option,
            self.star_format(self.opt.label),
            self.JOBTYPES[self.option_type],
            self.star_format(self.opt.defaultvalue),
            "0",
            "0",
            "0",
            "undefined",
            "undefined",
            self.star_format(self.opt.helptext),
            "++undefined++",
        ]
        return line

    def filename_opt(self):
        line = [
            self.option,
            self.star_format(self.opt.label),
            self.JOBTYPES[self.option_type],
            self.star_format(self.opt.defaultvalue),
            "0",
            "0",
            "0",
            self.star_format(self.opt.pattern),
            self.star_format(self.opt.directory),
            self.star_format(self.opt.helptext),
            "++undefined++",
        ]
        return line

    def inputnode_opt(self):
        line = [
            self.option,
            self.star_format(self.opt.label),
            self.JOBTYPES[self.option_type],
            self.star_format(self.opt.defaultvalue),
            "0",
            "0",
            "0",
            self.star_format(self.opt.pattern),
            "undefined",
            self.star_format(self.opt.helptext),
            "++undefined++",
        ]
        return line

    def radio_opt(self):
        line = [
            self.option,
            self.star_format(self.opt.label),
            self.JOBTYPES[self.option_type],
            self.star_format(self.opt.defaultvalue),
            "0",
            "0",
            "0",
            "undefined",
            "undefined",
            self.star_format(self.opt.helptext),
            "++" + "++".join(self.RADIO_OPTIONS[self.opt.radiomenu]) + "++",
        ]
        return line

    def get_jobstar_line(self):
        option_type = self.option_type
        if option_type == "TEXTBOX":
            line = self.textbox_opt()
        if option_type == "FILENAME":
            line = self.filename_opt()
        if option_type == "INPUTNODE":
            line = self.inputnode_opt()
        if option_type == "RADIO":
            line = self.radio_opt()
        if option_type == "SLIDER":
            line = self.slider_opt()
        if option_type == "BOOLEAN":
            line = self.boolean_opt()
        return [str(x) for x in line]


class StarfileCheck:
    def __init__(self, fn_in, remove_tmp=True):
        self.version = "undefined"
        self.fn_in = fn_in
        with open(fn_in) as f:
            head = islice(f, 0, 3)
            for line in head:
                if "# version" in line:
                    self.version = line.replace("#", "")
        self.been_corrected = False
        self.tmp_name = None
        self.remove_temp = remove_tmp

    def check_reserved_words(self):

        with open(self.fn_in) as thefile:
            f = thefile.readlines()

        nline = 0
        for line in f:
            if (
                line.rstrip() != "loop_"
                and re.sub(r"\d+", "", line.strip()) not in datalabels
                and line[0] != "#"
            ):
                line_split = line.split()
                for entry in line_split:
                    for word in reserved_words:
                        if entry.startswith(word):
                            f[nline] = f[nline].replace(entry, '"' + entry + '"')
                            self.been_corrected = True
            nline += 1
            if self.been_corrected:
                self.tmp_name = "tmp_" + os.path.basename(self.fn_in)
                with open(self.tmp_name, "w") as out_tmpfile:
                    for line in f:
                        out_tmpfile.write(line)
