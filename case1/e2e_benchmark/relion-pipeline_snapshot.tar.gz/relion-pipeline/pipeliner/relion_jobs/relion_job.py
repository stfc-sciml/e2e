import os
import subprocess
import math
from pipeliner.utils import truncate_number, get_env_var, raise_error
from gemmi import cif
from pipeliner.jobstar_reader import JobstarLine, JobStar
from pipeliner.star_writer import write
from pipeliner.data_structure import Node, NODES
from pipeliner.job_options import JobOption
from pipeliner.data_structure import PROCS


class RelionJob(object):
    """
    Super-class for RELION job objects.

    Each job type has its own sub-class.

    WARNING: do not instantiate this class directly, use the factory functions in this
    module.
    """

    PROCESS_TYPE_NUM = -1

    def __init__(self):
        if type(self) == RelionJob:
            raise NotImplementedError(
                "Cannot create RelionJob objects directly - use a sub-class"
            )

        self.output_name = ""
        self.alias = None
        self.hidden_name = None
        self.type = -1
        self.is_continue = False
        self.input_nodes = list()
        self.output_nodes = list()
        self.joboptions = {}
        self.final_command = ""
        self.is_plugin = False
        self.plugin_use_queue = False

    def clear(self):
        self.output_name = ""
        self.alias = None
        self.type = -1
        self.input_nodes.clear()
        self.output_nodes.clear()
        self.is_continue = False

    def set_option(self, line):
        if len(line) == 0:
            return
        if "==" not in line:
            raise RuntimeError("No '==' entry on JobOption line: {}".format(line))
        key, val = line.split(" == ")
        found = None
        for k, v in self.joboptions.items():
            if v.label == key:
                found = k
                break
        if found is None:
            raise RuntimeError("Job does not contain label: {}".format(key))
        self.joboptions[found].set_string(val)

    def read(self, filename, do_initialise=False):
        read_all = True
        if filename.endswith(".job"):
            with open(filename) as job_file:
                # check job type
                job_type = int(job_file.readline().split("==")[1].strip(" \n"))
                if job_type != self.PROCESS_TYPE_NUM:
                    raise RuntimeError(
                        "Trying to read job file {} with type {} in class {}".format(
                            filename, job_type, type(self)
                        )
                    )

                # find if continue
                line = job_file.readline()
                if "is_continue == true" in line:
                    self.is_continue = True
                else:
                    self.is_continue = False
                # TODO: return value of is_continue to caller?

                # initialise
                if do_initialise:
                    self.initialise()

                # reading all stored options
                for joboption in self.joboptions.values():
                    # if doesn't have label, not initialised?
                    if joboption.label is not None:
                        job_file.seek(0)
                        for line in job_file:
                            if joboption.label in line:
                                joboption.value = line.split("==")[1].strip(" \n")
                                break
                    else:
                        read_all = False

        elif filename.endswith("job.star"):
            job_options = JobStar(filename).get_all_options()
            job_type = int(job_options["_rlnJobType"])
            if job_type != self.PROCESS_TYPE_NUM:
                raise RuntimeError(
                    "Trying to read job file {} with type {} in class {}".format(
                        filename, job_type, type(self)
                    )
                )
            self.is_continue = bool(int(job_options["_rlnJobIsContinue"]))
            del job_options["_rlnJobType"]
            del job_options["_rlnJobIsContinue"]
            for joboption in self.joboptions:
                try:
                    if type(job_options[joboption]) is str:
                        job_options[joboption] = (
                            job_options[joboption].replace("'", "").replace('"', "")
                        )
                    self.joboptions[joboption].value = job_options[joboption]
                except KeyError:
                    raise_error(
                        "ERROR: job option {} missing from job.star file".format(
                            joboption
                        )
                    )
        return read_all

    def write(self, fn=""):
        filename = self.hidden_name if fn == "" else fn

        with open(filename + "run.job", "w+") as f:
            f.write("job_type == {}\n".format(self.type))
            if self.is_continue:
                f.write("is_continue == true\n")
            else:
                f.write("is_continue == false\n")
            for key, val in self.joboptions.items():
                f.write(val.label + " == " + str(val.value) + "\n")

    def write_jobstar(self, fn, full_definitions=False, is_continue=False):
        """Write a job.star file.  If is_continue writes a continuation file
        with just the joboptions that are able to be changed in continuations.
        if full_definitions writes the depreciated style with full definitions
        of the defaults, input type, min, max, and help text"""

        filename = fn + "job.star"
        jobstar = cif.Document()

        job_block = jobstar.add_new_block("job")
        job_block.set_pair("_rlnJobType", str(self.PROCESS_TYPE_NUM))
        if not is_continue:
            job_block.set_pair("_rlnJobIsContinue", str(int(self.is_continue)))
        else:
            job_block.set_pair("_rlnJobIsContinue", "1")

        jobop_block = jobstar.add_new_block("joboptions_values")
        jobop_loop = jobop_block.init_loop(
            "_", ["rlnJobOptionVariable", "rlnJobOptionValue"]
        )

        for option in self.joboptions:
            if not is_continue:
                jobop_loop.add_row(
                    [
                        str(cif.quote(option)),
                        cif.quote(str(self.joboptions[option].value)),
                    ]
                )
                full_opts_line = JobstarLine(option, self.joboptions)
            else:
                if self.joboptions[option].in_continue:
                    jobop_loop.add_row(
                        [
                            str(cif.quote(option)),
                            cif.quote(str(self.joboptions[option].value)),
                        ]
                    )
                    full_opts_line = JobstarLine(option, self.joboptions)
        if full_definitions:
            fulldef_block = jobstar.add_new_block("joboptions_full_definition")
            fulldef_loop = fulldef_block.init_loop(
                "_",
                [
                    "rlnJobOptionVariable",
                    "rlnJobOptionGUILabel",
                    "rlnJoboptionType",
                    "rlnJobOptionDefaultValue",
                    "rlnJobOptionSliderMin",
                    "rlnJobOptionSliderMax",
                    "rlnJobOptionSliderStep",
                    "rlnJobOptionFilePattern",
                    "rlnJobOptionDirectoryDefault",
                    "rlnJobOptionHelpText",
                    "rlnJobOptionMenuOptions",
                    "rlnJobOptionInContinue",
                ],
            )

            for option in self.joboptions:
                if not is_continue:
                    fulldef_loop.add_row(full_opts_line.get_jobstar_line())
                else:
                    if self.joboptions[option].in_continue:
                        fulldef_loop.add_row(full_opts_line.get_jobstar_line())

        write(jobstar, filename)

    def initialise_pipeline(
        self, outputname, defaultname, job_counter,
    ):
        self.output_nodes = []
        self.input_nodes = []

        if outputname == "":  # for continue jobs, use the same output name
            outputname = "{}/job{:03}/".format(defaultname, job_counter)
        self.output_name = outputname
        return outputname

    def save_job_submission_script(self, output_script, outputname, commands, nmpi):
        ## error checking
        fn_qsub = self.joboptions["qsubscript"].get_string(
            True, "ERROR: no submission script template specified"
        )
        if not os.path.isfile(fn_qsub):
            raise_error("Error reading template submission script in: " + fn_qsub)
        subprocess.run(["touch", output_script])
        if not os.path.isfile(output_script):
            raise_error("Error writing to job submission script in: " + outputname)

        nthr = self.joboptions.get("nr_threads")
        if nthr is None:
            nthr = 1
        else:
            nthr = nthr.get_number()

        ncores = nmpi * nthr
        ndedi = self.joboptions["min_dedicated"].get_number()
        fnodes = ncores / ndedi
        nnodes = math.ceil(fnodes)
        # should this be written to the run.err as well?
        # should we set ndedi to ncores if ncores < ndedi?
        if fnodes % 1 != 0:
            print(
                " Warning! You're using {} MPI processes with {} threads each "
                "(i.e. {} cores), while asking for {} nodes with {} cores.\n"
                "It is more efficient to make the number of cores (i.e. mpi*threads)"
                " a multiple of the minimum number of dedicated cores per"
                " node ".format(
                    truncate_number(nmpi, 0),
                    truncate_number(nthr, 0),
                    truncate_number(ncores, 0),
                    truncate_number(nnodes, 0),
                    truncate_number(ndedi, 0),
                )
            )

        queuename = self.joboptions["queuename"].get_string()
        qsub_extra_1 = self.joboptions.get("qsub_extra_1")
        qsub_extra_2 = self.joboptions.get("qsub_extra_2")
        qsub_extra_3 = self.joboptions.get("qsub_extra_3")
        qsub_extra_4 = self.joboptions.get("qsub_extra_4")
        extras = {}
        n = 1
        for extra in (qsub_extra_1, qsub_extra_2, qsub_extra_3, qsub_extra_4):
            qsubvar = "qsub_extra_" + str(n)
            if extra is not None:
                extras[qsubvar] = extra.get_string()
            else:
                extras[qsubvar] = None
            n += 1

        replacements = {
            "XXXmpinodesXXX": str(int(nmpi)),
            "XXXthreadsXXX": str(int(nthr)),
            "XXXcoresXXX": str(int(ncores)),
            "XXXdedicatedXXX": str(int(ndedi)),
            "XXXnameXXX": outputname,
            "XXXerrfileXXX": outputname + "run.err",
            "XXXoutfileXXX": outputname + "run.out",
            "XXXqueueXXX": queuename,
            "XXXextra1XXX": extras["qsub_extra_1"],
            "XXXextra2XXX": extras["qsub_extra_2"],
            "XXXextra3XXX": extras["qsub_extra_3"],
            "XXXextra4XXX": extras["qsub_extra_4"],
        }

        with open(fn_qsub) as template_data:
            template = template_data.readlines()

        non_rel_com = False  # has a non-relion command been written?
        # if so then all subsequent commands need a carriage return

        with open(output_script, "w") as outscript:
            for line in template:
                for sub in replacements:
                    if sub in line:
                        line = line.replace(sub, replacements[sub])
                if "XXXcommandXXX" in line:
                    for com in commands:
                        # relion_mpi commands are subbed in for XXXcommandXXX
                        # other commands (and non mpi relion commands) are put
                        # in as is replacing the line with XXXcommandXX.
                        if com.find("relion_") > 0 and (
                            com.find("_mpi") > 0 or nmpi == 1
                        ):
                            outscript.write(line.replace("XXXcommandXXX", com))
                        elif not non_rel_com:
                            non_rel_com = True
                            outscript.write(com)
                        else:
                            outscript.write("\n" + com)
                else:
                    outscript.write(line)

    def prepare_final_command(self, outputname, commands, do_makedir):
        # Create output directory if the outname contains a "/"
        if do_makedir:
            job_dir = os.path.dirname(outputname)
            if not os.path.isdir(job_dir) and len(job_dir) > 0:
                os.makedirs(job_dir)
        #  add pipeline_control to all relion commands
        for icom in commands:
            if "which relion_" in icom:
                commands[commands.index(icom)] += " --pipeline_control " + outputname

        # check for MPI
        nr_mpi = self.joboptions.get("nr_mpi")

        if nr_mpi is not None:
            nr_mpi = int(nr_mpi.get_number())
        else:
            nr_mpi = 1

        # run the job locally or submit to queue
        do_queue = self.joboptions.get("do_queue")
        if do_queue is not None:
            do_queue = do_queue.get_boolean()
        else:
            do_queue = False

        # if job type is plugin add a command to the end
        # to touch a status file that says the job has finished.
        if self.PROCESS_TYPE_NUM == PROCS["PlugIn"] and do_queue:
            commands.append("touch {}PLUGIN_QUEUED_FINISHED".format(outputname))

        if do_queue:
            output_script = outputname + "run_submit.script"

            RelionJob.save_job_submission_script(
                self, output_script, outputname, commands, nr_mpi
            )

            qsub = self.joboptions["qsub"].get_string()
            self.final_command = qsub + " " + output_script + " &"

            return self.final_command

        else:
            # check for allowed number of mpis
            try:
                warn = int(os.environ["RELION_ERROR_LOCAL_MPI"])
                if nr_mpi > warn:
                    os.system(
                        "echo 'ERROR: you're submitting a local job with "
                        "{} parallel MPI processes. It's more than allowed by the"
                        " RELION_ERROR_LOCAL_MPI environment variable.\nSwitching"
                        " to {} MPI processes' >> {}run.err".format(
                            nr_mpi, warn, outputname
                        )
                    )
                    nr_mpi = warn
            except KeyError:
                pass

            one_command = ""
            self.final_command = ""
            for i, com in enumerate(commands):
                if nr_mpi > 1 and ("_mpi" in com.split()[0] or "mpi" in com.split()[1]):
                    one_command = "mpirun -n {} {}".format(nr_mpi, com)
                else:
                    one_command = com

                if ">" not in com:
                    one_command += (
                        " >> " + outputname + "run.out 2>> " + outputname + "run.err"
                    )
                self.final_command += one_command
                if i == len(commands) - 1:
                    self.final_command += " & "
                else:
                    self.final_command += " && "

        return self.final_command

    def initialise(self):
        raise NotImplementedError(
            "initialise() should be implemented in sub-classes of RelionJob"
        )

    def get_commands(self, outputname, do_makedir, job_counter):
        raise NotImplementedError(
            "get_commands() should be implemented in sub-classes of RelionJob"
        )

    def get_runtab_options(self, mpi=True, threads=True):
        """Get the options found in the Run tab of the GIU,
        which are common to for all jobtypes"""

        if mpi:
            self.joboptions["nr_mpi"] = JobOption.as_slider(
                "Number of MPI procs:",
                1,
                1,
                64,
                1,
                "Number of MPI nodes to use in parallel. When set to 1"
                ", MPI will not be used. The maximum can be set through the environment"
                " variable RELION_MPI_MAX.",
                True,
            )

        if threads:
            self.joboptions["nr_threads"] = JobOption.as_slider(
                "Number of threads:",
                1,
                1,
                16,
                1,
                "Number of shared-memory (POSIX) threads to use in"
                " parallel. When set to 1, no multi-threading will "
                "be used. The maximum can be set through the environment"
                " variable RELION_THREAD_MAX.",
                True,
            )

        self.get_queue_options()
        self.get_additional_args()

    def get_additional_args(self):
        """Get the additional arguments job option"""
        self.joboptions["other_args"] = JobOption.as_textbox(
            "Additional arguments: ", "", "", True
        )

    def get_queue_options(self):
        """Get options related to queueing and queue submission,
        which are common to for all jobtypes"""

        do_queue_default = get_env_var("RELION_QUEUE_USE", False)
        self.joboptions["do_queue"] = JobOption.as_boolean(
            "Submit to queue?",
            do_queue_default,
            "If set to Yes, the job will be submit to a queue,"
            " otherwise the job will be executed locally. Note "
            "that only MPI jobs may be sent to a queue. The default "
            "can be set through the environment variable RELION_QUEUE_USE.",
            True,
        )

        queue_name_default = get_env_var("RELION_QUEUE_NAME", "openmpi")
        self.joboptions["queuename"] = JobOption.as_textbox(
            "Queue name: ",
            queue_name_default,
            "Name of the queue to which to submit the job. The"
            " default name can be set through the environment"
            " variable RELION_QUEUE_NAME.",
            True,
        )

        qsub_default = get_env_var("RELION_QSUB_COMMAND", "qsub")
        self.joboptions["qsub"] = JobOption.as_textbox(
            "Queue submit command: ",
            qsub_default,
            "Name of the command used to submit scripts to the queue,"
            " e.g. qsub or bsub. Note that the person who installed RELION"
            " should have made a custom script for your cluster/queue setup."
            " Check this is the case (or create your own script following the"
            " RELION Wiki) if you have trouble submitting jobs. The default "
            "command can be set through the environment variable RELION_QSUB_COMMAND.",
            True,
        )
        qsub_template_default = get_env_var(
            "RELION_QSUB_TEMPLATE", "Enter submission template here",
        )

        self.joboptions["qsubscript"] = JobOption.as_fn(
            "Standard submission script: ",
            qsub_template_default,
            "*",
            ".",
            "The template for your standard queue job submission script."
            " Its default location may be changed by setting the environment"
            " variable RELION_QSUB_TEMPLATE. In the template script a number"
            " of variables will be replaced: \nXXXcommandXXX = relion command"
            " + arguments; \nXXXqueueXXX = The queue name;"
            "\nXXXmpinodesXXX = The number of MPI nodes;"
            "\nXXXthreadsXXX = The number of threads;"
            "\nXXXcoresXXX = XXXmpinodesXXX * XXXthreadsXXX;"
            "\nXXXdedicatedXXX = The minimum number of dedicated cores on each node;"
            "\nXXXnodesXXX = The number of requested nodes"
            " = CEIL(XXXcoresXXX / XXXdedicatedXXX);"
            "\nIf these options are not enough for your standard jobs,"
            " you may define a user-specified number of extra variables"
            ": XXXextra1XXX, XXXextra2XXX, etc. The number of extra variables"
            " is controlled through the environment variable RELION_QSUB_EXTRA_COUNT."
            " Their help text is set by the environment variables "
            "RELION_QSUB_EXTRA1, RELION_QSUB_EXTRA2, etc For example, "
            "setenv RELION_QSUB_EXTRA_COUNT 1, together with "
            "setenv RELION_QSUB_EXTRA1 'Max number of hours in queue' "
            "will result in an additional (text) ein the GUI Any "
            "variables XXXextra1XXX in the template script will be "
            "replaced by the corresponding value.Likewise, default values"
            " for the extra entries can be set through environment variables "
            "RELION_QSUB_EXTRA1_DEFAULT, RELION_QSUB_EXTRA2_DEFAULT, etc. "
            "But note that (unlike all other entries in the GUI) the extra "
            "values are not remembered from one run to the other.",
            True,
        )

        min_cores_default = get_env_var("RELION_MINIMUM_DEDICATED", 1)
        self.joboptions["min_dedicated"] = JobOption.as_slider(
            "Minimum dedicated cores per node: ",
            min_cores_default,
            1,
            64,
            1,
            "Minimum number of dedicated cores that need to be requested "
            "on each node. This is useful to force the queue to fill up entire "
            "nodes of a given size. The default can be set through the environment"
            " variable RELION_MINIMUM_DEDICATED.",
            True,
        )

        self.get_extra_options()

    def get_extra_options(self):
        if "RELION_QSUB_EXTRA_COUNT" in os.environ:
            n_extra = int(os.environ["RELION_QSUB_EXTRA_COUNT"])
        else:
            n_extra = 0
        if n_extra > 0:
            for extranum in range(1, n_extra + 1):
                if "RELION_QSUB_EXTRA{}".format(str(extranum)) in os.environ:
                    extra_id = "RELION_QSUB_EXTRA{}".format(extranum)
                    extra_name = os.environ[extra_id]
                else:
                    raise_error(
                        "environment variable RELION_QSUB_EXTRA{} missing".format(
                            str(extranum)
                        )
                    )

                extra_default = get_env_var("{}_DEFAULT".format(extra_id), "")
                extra_help = get_env_var("{}_HELP".format(extra_id), "")

                self.joboptions[
                    "qsub_extra_{}".format(extranum)
                ] = JobOption.as_textbox(extra_name, extra_default, extra_help, True)

    def get_comp_options(self):
        """Get computational options, which are common to for all jobtypes"""

        self.joboptions["do_parallel_discio"] = JobOption.as_boolean(
            "Use parallel disc I/O?",
            True,
            "If set to Yes, all MPI slaves will read their own images from disc. "
            "Otherwise, only the master will read images and send them through the"
            " network to the slaves. Parallel file systems like gluster of fhgfs are"
            " good at parallel disc I/O. NFS may break with many slaves reading in"
            " parallel. If your datasets contain particles with different box sizes, "
            "you have to say Yes.",
            True,
        )

        self.joboptions["nr_pool"] = JobOption.as_slider(
            "Number of pooled particles:",
            3,
            1,
            16,
            1,
            "Particles are processed in individual batches by MPI slaves. During"
            " each batch, a stack of particle images is only opened and closed once"
            " to improve disk access times. All particle images of a single batch are"
            " read into memory together. The size of these batches is at least one"
            " particle per thread used. The nr_pooled_particles parameter controls"
            " how many particles are read together for each thread. If it is set to"
            " 3 and one uses 8 threads, batches of 3x8=24 particles will be read"
            " together. This may improve performance on systems where disk access,"
            " and particularly metadata handling of disk access, is a problem. It has"
            " a modest cost of increased RAM usage.",
            True,
        )

        self.joboptions["do_pad1"] = JobOption.as_boolean(
            "Skip padding?",
            False,
            "If set to Yes, the calculations will not use padding in Fourier space"
            " for better interpolation in the references. Otherwise, references are "
            "padded 2x before Fourier transforms are calculated. Skipping padding "
            "(i.e. use --pad 1) gives nearly as good results as using --pad 2, but"
            " some artifacts may appear in the corners from signal that is folded"
            " back.",
            True,
        )

        self.joboptions["skip_gridding"] = JobOption.as_boolean(
            "Skip gridding?",
            True,
            "If set to Yes, the calculations will skip gridding in the M step"
            " to save time, typically with just as good results.",
            True,
        )

        self.joboptions["do_preread_images"] = JobOption.as_boolean(
            "Pre-read all particles into RAM?",
            False,
            "If set to Yes, all particle images will be read into computer memory,"
            " which will greatly speed up calculations on systems with slow disk"
            " access. However, one should of course be careful with the amount of"
            " RAM available. Because particles are read in float-precision, it will"
            " take ( N * box_size * box_size * 4 / (1024 * 1024 * 1024) ) Giga-bytes"
            " to read N particles into RAM. For 100 thousand 200x200 images, that"
            " becomes 15Gb, or 60 Gb for the same number of 400x400 particles. "
            "Remember that running a single MPI slave on each node that runs as "
            "many threads as available cores will have access to all available RAM."
            "\n\nIf parallel disc I/O is set to No, then only the master reads all"
            " particles into RAM and sends those particles through the network to"
            " the MPI slaves during the refinement iterations.",
            True,
        )

        default_scratch = get_env_var("RELION_SCRATCH_DIR")
        self.joboptions["scratch_dir"] = JobOption.as_textbox(
            "Copy particles to scratch directory:",
            default_scratch,
            "If a directory is provided here, then the job will create a "
            "sub-directory in it called relion_volatile. If that relion_volatile"
            " directory already exists, it will be wiped. Then, the program will"
            " copy all input particles into a large stack inside the relion_volatile"
            " subdirectory. Provided this directory is on a fast local drive (e.g."
            " an SSD drive), processing in all the iterations will be faster. If the"
            " job finishes correctly, the relion_volatile directory will be wiped."
            " If the job crashes, you may want to remove it yourself.",
            True,
        )

        self.joboptions["do_combine_thru_disc"] = JobOption.as_boolean(
            "Combine iterations through disc?",
            False,
            "If set to Yes, at the end of every iteration all MPI slaves will write"
            " out a large file with their accumulated results. The MPI master will"
            " read in all these files, combine them all, and write out a new file"
            " with the combined results. All MPI salves will then read in the"
            " combined results. This reduces heavy load on the network, but "
            "increases load on the disc I/O. This will affect the time it takes"
            " between the progress-bar in the expectation step reaching its end "
            "(the mouse gets to the cheese) and the start of the ensuing maximisation"
            " step. It will depend on your system setup which is most efficient.",
            True,
        )

        self.joboptions["use_gpu"] = JobOption.as_boolean(
            "Use GPU acceleration?",
            False,
            "If set to Yes, the job will try to use GPU acceleration.",
            True,
        )

        self.joboptions["gpu_ids"] = JobOption.as_textbox(
            "Which GPUs to use:",
            "",
            "This argument is not necessary. If left empty, the job itself will"
            " try to allocate available GPU resources. You can override the "
            "default allocation by providing a list of which GPUs (0,1,2,3, etc)"
            " to use. MPI-processes are separated by ':', threads by ','.  "
            "For example: '0,0:1,1:0,0:1,1'",
            True,
        )

    def add_comp_options(self):
        """Prepare the computational options section of the command;
        common to all job types"""
        command = ""
        if not self.joboptions["do_combine_thru_disc"].get_boolean():
            command += " --dont_combine_weights_via_disc"

        if not self.joboptions["do_parallel_discio"].get_boolean():
            command += " --no_parallel_disc_io"

        scratch_dir = self.joboptions["scratch_dir"].get_string()
        if self.joboptions["do_preread_images"].get_boolean():
            command += " --preread_images"
        elif len(scratch_dir) > 0:
            command += " --scratch_dir " + scratch_dir

        command += " --pool " + self.joboptions["nr_pool"].get_string()

        if self.joboptions["do_pad1"].get_boolean():
            command += " --pad 1"
        else:
            command += " --pad 2"

        if self.joboptions["skip_gridding"].get_boolean():
            command += " --skip_gridding"
        return command

    def create_refine_nodes(self, runname, it, K, dim, nr_bodies):
        if dim not in [2, 3]:
            raise_error("ERROR: invalid dim value")
        if it < 0:
            # for 3D autorefine
            fn_out = runname
        else:
            # for classifications
            fn_out = runname + "_it" + "{:03d}".format(it)

        # for multibody
        if nr_bodies > 1:
            for ibody in range(nr_bodies):
                halfname = "{}_half1_body{:03d}_unfil.mrc".format(fn_out, ibody + 1)
                self.output_nodes.append(Node(halfname, NODES["Halfmap"]))
        # for normal classifications/refinements
        else:
            self.output_nodes.append(Node(fn_out + "_data.star", NODES["Part data"]))
            if it > 0:  # for classifications
                self.output_nodes.append(Node(fn_out + "_model.star", NODES["Model"]))
            else:  # for refinements
                self.output_nodes.append(
                    Node(fn_out + "_half1_class001_unfil.mrc", NODES["Halfmap"])
                )
            if dim == 3:
                for iclass in range(K):
                    fn_class = "{}_class{:03d}.mrc".format(fn_out, iclass + 1)
                    self.output_nodes.append(Node(fn_class, NODES["3D refs"]))

    def refinement_IO(self, outputname, dim, n_bodies, do_continue):
        """Prepare the input and output nodes for jobs based on 3DRefine"""
        fn_run = os.path.join(outputname, "run")
        if do_continue:
            fn_cont = self.joboptions["fn_cont"].get_string(
                True, "ERROR: empty field for continuation STAR file...",
            )
            pos_it = int(fn_cont.partition("it")[2].partition("_")[0])
            if pos_it < 0 or "_optimiser" not in fn_cont:
                raise_error(
                    "Warning: invalid optimiser.star filename provided for "
                    "continuation run!",
                )
            fn_run += "_ct" + str(pos_it)
            command = " --continue " + fn_cont

        elif not do_continue:
            fn_img = self.joboptions["fn_img"].get_string(
                True, "ERROR: empty field for input STAR file..."
            )
            command = " --i " + fn_img
            self.input_nodes.append(Node(fn_img, self.joboptions["fn_img"].nodetype))

        command += " --o " + fn_run

        try:
            my_iter = int(self.joboptions["nr_iter"].get_number())

        #  different was of calculating for SGD
        except KeyError:
            try:
                sgd_ini_iter = self.joboptions["sgd_ini_iter"].get_number()
                sgd_inbetween_iter = self.joboptions["sgd_inbetween_iter"].get_number()
                sgd_fin_iter = self.joboptions["sgd_fin_iter"].get_number()
                my_iter = int(sgd_fin_iter + sgd_inbetween_iter + sgd_ini_iter)
            except KeyError:
                my_iter = -1

        try:
            my_classes = int(self.joboptions["nr_classes"].get_number())
        except KeyError:
            my_classes = 1

        self.create_refine_nodes(fn_run, my_iter, my_classes, dim, n_bodies)
        return command

    def solvmask2_node(self):
        """Add the input node for a secondary solvent mask if one is used"""
        splitargs = self.joboptions["other_args"].get_string().split()
        if "--solvent_mask2" in splitargs:
            solvmask2 = splitargs[splitargs.index("--solvent_mask2") + 1]
            self.input_nodes.append(Node(solvmask2, NODES["Mask"]))

    """
    COMPLETED MARKED BY "*"

    * containsLabel(label, option)
    * setOption(setOptionLine)

    * read(filename, is_continue, do_initialize)
    write(filename)

    * saveJobSubmissionScript(newFn, outFn, commands, errorMsg)

    * initialisePipeline(outFn, default_name, job_counter)  # ?

    * prepareFinalCommand(outFn, commands, finalCommand, do_makedir, warningMsg)

    * initialise(job_type)    # general e.g. mpi etc. (envs)

    * getCommands(outFn, commands, finalCommand, do_makedir, job_counter, errorMsg)

    * inititaliseImportJob()  # specificfor job
    * getCommandImportJob(outFn, commands, finalCommand, do_makedir, job_counter,
                          errorMsg)
        # TODO this should be implemented with method overloading rather than listing
        #  every single option
    ...
    """
