from .relion_job import RelionJob
from ..data_structure import Node, NODES, MASKCREATE_TYPE_NUM
from ..job_options import JobOption


class MaskCreateJob(RelionJob):
    # TODO: need to think how to define constants a bit more - consider overriding,
    #  polymorphism etc
    PROCESS_NAME = "MaskCreate"
    PROCESS_TYPE_NUM = MASKCREATE_TYPE_NUM

    def __init__(self):
        super(self.__class__, self).__init__()
        # TODO: remove this and use class-level constant if possible
        self.type = MASKCREATE_TYPE_NUM
        self.hidden_name = ".gui_maskcreate"
        self.joboptions["fn_in"] = JobOption.as_inputnode(
            "Input 3D map",
            NODES["3D refs"],
            "",
            "MRC map files (*.mrc)",
            "Provide an input MRC map from which to start binarizing the map.",
        )
        self.joboptions["lowpass_filter"] = JobOption.as_slider(
            "Lowpass filter map (A)",
            10,
            10,
            100,
            5,
            "Lowpass filter that will be applied to the input map, prior to"
            " binarization. To calculate solvent masks, a lowpass filter of 15-20A"
            " may work well.",
            True,
        )

        self.joboptions["angpix"] = JobOption.as_slider(
            "Pixel size (A)",
            -1,
            0.3,
            5,
            0.1,
            "Provide the pixel size of the input map in Angstroms to calculate the"
            "low-pass filter. This value is also used in the output image header.",
            True,
        )

        self.joboptions["inimask_threshold"] = JobOption.as_slider(
            "Initial binarisation threshold",
            0.02,
            0,
            0.5,
            0.01,
            "This threshold is used to make an initial binary mask from the"
            "average of the two unfiltered half-reconstructions. If you don't"
            " know what value to use, display one of the unfiltered half-maps in"
            " a 3D surface rendering viewer and find the lowest threshold that gives"
            " no noise peaks outside the reconstruction.",
            True,
        )

        self.joboptions["extend_inimask"] = JobOption.as_slider(
            "Extend binary map this many pixels:",
            3,
            0,
            20,
            1,
            "The initial binary mask is extended this number of pixels in all"
            " directions.",
            True,
        )

        self.joboptions["width_mask_edge"] = JobOption.as_slider(
            "Add a soft-edge of this many pixels:",
            3,
            0,
            20,
            1,
            "The extended binary mask is further extended with a raised-cosine"
            " soft edge of the specified width.",
            True,
        )

        self.joboptions["do_helix"] = JobOption.as_boolean(
            "Mask a 3D helix?",
            False,
            "Generate a mask for 3D helix which spans across Z axis of the box.",
            True,
        )

        self.joboptions["helical_z_percentage"] = JobOption.as_slider(
            "Central Z length (%):",
            30.0,
            5.0,
            80.0,
            1.0,
            "Reconstructed helix suffers from inaccuracies of orientation searches."
            " The central part of the box contains more reliable information compared "
            "to the top and bottom parts along Z axis. Set this value (%) to the"
            " central part length along Z axis divided by the box size. Values around"
            " 30% are commonly used but you may want to try different lengths.",
            True,
        )

        self.get_runtab_options(False, True)

    def initialise(self):
        # Initialisation already done in __init__. TODO: do we need this method too?
        pass

    def get_commands(self, outputname, do_makedir, job_counter):

        outputname = self.initialise_pipeline(
            outputname, self.PROCESS_NAME, job_counter
        )
        fn_out = outputname + "mask.mrc"

        command = ""

        map_in = self.joboptions["fn_in"].get_string(
            True, "ERROR: Empty field for input map"
        )

        lowpass_filter = self.joboptions["lowpass_filter"].get_string()
        command += "--lowpass " + lowpass_filter

        angpix = self.joboptions["angpix"].get_string()
        command += " --angpix " + angpix

        inimask_threshold = self.joboptions["inimask_threshold"].get_string()
        command += " --ini_threshold " + inimask_threshold

        extend_inimask = self.joboptions["extend_inimask"].get_string()
        command += " --extend_inimask " + extend_inimask

        width_mask_edge = self.joboptions["width_mask_edge"].get_string()
        command += " --width_soft_edge " + width_mask_edge

        do_helix = self.joboptions["do_helix"].get_boolean()
        if do_helix:
            helical_z_percentage = (
                self.joboptions["helical_z_percentage"].get_number() / 100
            )
            command += " --helix --z_percentage " + str(helical_z_percentage)

        other_args = self.joboptions["other_args"].get_string()
        if len(other_args) != 0:
            command += " " + other_args

        nr_threads = self.joboptions["nr_threads"].get_string()
        command += " --j " + nr_threads

        self.input_nodes.append(Node(map_in, self.joboptions["fn_in"].nodetype))
        self.output_nodes.append(Node(fn_out, NODES["Mask"]))

        commands = [
            "`which relion_mask_create` --i {} --o {} {}".format(
                map_in, fn_out, command
            )
        ]
        return self.prepare_final_command(outputname, commands, do_makedir)
