from .relion_job import RelionJob
from ..data_structure import Node, NODES, LOCALRES_TYPE_NUM
from ..job_options import JobOption
from pipeliner.utils import raise_error

import os


class LocalResJob(RelionJob):
    PROCESS_NAME = "LocalRes"
    PROCESS_TYPE_NUM = LOCALRES_TYPE_NUM

    def __init__(self):
        super(self.__class__, self).__init__()
        self.type = LOCALRES_TYPE_NUM
        self.hidden_name = ".gui_localres"

        self.joboptions["fn_in"] = JobOption.as_inputnode(
            "One of the 2 unfiltered half-maps:",
            NODES["Halfmap"],
            "",
            "MRC map files (*_unfil.mrc)",
            "Provide one of the two unfiltered half-reconstructions that were output"
            " upon convergence of a 3D auto-refine run.",
        )

        self.joboptions["angpix"] = JobOption.as_slider(
            "Calibrated pixel size (A)",
            1,
            0.3,
            5,
            0.1,
            "Provide the final, calibrated pixel size in Angstroms. This value may be"
            " different from the pixel-size used thus far, e.g. when you have "
            "recalibrated the pixel size using the fit to a PDB model. The X-axis"
            " of the output FSC plot will use this calibrated value.",
        )

        try:
            default_resmap_location = os.getenv("RELION_RESMAP_EXECUTABLE")
        except KeyError:
            default_resmap_location = "Enter an .exe for resmap"

        self.joboptions["do_resmap_locres"] = JobOption.as_boolean(
            "Use ResMap?",
            True,
            "If set to Yes, then ResMap will be used for local resolution "
            "estimation.",
        )

        self.joboptions["fn_resmap"] = JobOption.as_fn(
            "ResMap executable:",
            default_resmap_location,
            "ResMap*",
            ".",
            "Location of the ResMap executable. You can control the default of"
            " this field by setting environment variable RELION_RESMAP_EXECUTABLE"
            ", or by editing the first few lines in src/gui_jobwindow.h and "
            "recompile the code. \n \n Note that the ResMap wrapper cannot "
            "use MPI.",
        )

        self.joboptions["fn_mask"] = JobOption.as_inputnode(
            "User-provided solvent mask:",
            NODES["Mask"],
            "",
            "Image Files (*.{spi,vol,msk,mrc})",
            "Provide a mask with values between 0 and 1 around all domains of the"
            " complex. ResMap uses this mask for local resolution calculation. "
            "RELION does NOT use this mask for calculation, but makes a histogram"
            " of local resolution within this mask.",
            True,
        )

        self.joboptions["pval"] = JobOption.as_slider(
            "P-value:",
            0.05,
            0.0,
            1.0,
            0.01,
            "This value is typically left at 0.05. If you change it, report the"
            " modified value in your paper!",
        )

        self.joboptions["minres"] = JobOption.as_slider(
            "Highest resolution (A): ",
            0.0,
            0.0,
            10.0,
            0.1,
            "ResMaps minRes parameter. By default (0), the program will start at"
            " just above 2x the pixel size",
        )

        self.joboptions["maxres"] = JobOption.as_slider(
            "Lowest resolution (A): ",
            0.0,
            0.0,
            10.0,
            0.1,
            "ResMaps maxRes parameter. By default (0), the program will stop at 4x"
            " the pixel size",
        )

        self.joboptions["stepres"] = JobOption.as_slider(
            "Resolution step size (A)", 1.0, 0.1, 3, 0.1, "ResMaps stepSize parameter.",
        )

        self.joboptions["do_relion_locres"] = JobOption.as_boolean(
            "Use Relion?",
            False,
            "If set to Yes, then relion_postprocess will be used for "
            "local-resolution estimation. This program basically performs a series"
            " of post-processing operations with a small soft, spherical mask that"
            " is moved over the entire map, while using phase-randomisation to "
            "estimate the convolution effects of that mask.\n\nThe output "
            "relion_locres.mrc map can be used to color the surface of a map in "
            "UCSF Chimera according to its local resolution. The output "
            "relion_locres_filtered.mrc is a composite map that is locally "
            "filtered to the estimated resolution. This is a developmental feature"
            " in need of further testing, but initial results indicate it may be"
            " useful.\n\nNote that only this program can use MPI, the ResMap "
            "wrapper cannot use MPI.",
        )

        # self.joboptions["locres_sampling"] = JobOption.as_slider(
        # "Sampling rate (A):",
        # 25, 5, 50, 5,
        # "The local-resolution map will be calculated every so many Angstroms"
        # ", by placing soft spherical masks on a cubic grid with this spacing"
        # ". Very fine samplings (e.g. < 15A?) may take a long time to compute"
        # " and give spurious estimates!",
        # )
        #
        # self.joboptions["randomize_at"] = JobOption.as_slider(
        # "Frequency for phase-randomisation (A): ",
        # 10., 5, 20., 1,
        # "From this frequency onwards, the phases for the mask-corrected "
        # "FSC-calculation will be randomized. Make sure this is a lower "
        # "resolution (i.e. a higher number) than the local resolutions you"
        # " are after in your map.",
        # )

        self.joboptions["adhoc_bfac"] = JobOption.as_slider(
            "User-provided B-factor:",
            -100,
            -500,
            0,
            -25,
            "Probably, the overall B-factor as was estimated in the postprocess"
            " is a useful value for here. Use negative values for sharpening. "
            "Be careful: if you over-sharpen your map, you may end up interpreting"
            " noise for signal!",
        )

        self.joboptions["fn_mtf"] = JobOption.as_fn(
            "MTF of the detector (STAR file)",
            "",
            "STAR Files (*.star)",
            ".",
            "The MTF of the detector is used to complement the user-provided "
            "B-factor in the sharpening. If you don't have this curve, you can "
            "leave this field empty.",
        )

        self.get_runtab_options()

    def initialise(self):
        pass

    def get_commands(self, outputname, do_makedir, job_counter):

        outputname = self.initialise_pipeline(
            outputname, self.PROCESS_NAME, job_counter
        )

        do_resmap_localres = self.joboptions["do_resmap_locres"].get_boolean()
        do_relion_localres = self.joboptions["do_relion_locres"].get_boolean()
        if do_resmap_localres and do_relion_localres:
            raise_error(
                "ERROR: choose either ResMap or Relion for local"
                " resolution estimation"
            )

        if do_resmap_localres and do_relion_localres:
            raise_error("ERROR: empty field for input half-map...")

        fn_half1 = self.joboptions["fn_in"].get_string(
            True, "Empty field for input half-map"
        )
        if "half1" not in os.path.basename(fn_half1):
            raise_error("Cannot find 'half' substring in the input filename")

        fn_half2 = fn_half1.replace("half1", "half2")

        self.input_nodes.append(Node(fn_half1, self.joboptions["fn_in"].nodetype))
        nr_mpi = self.joboptions["nr_mpi"].get_number()

        if do_resmap_localres:
            fn_resmap = self.joboptions["fn_resmap"].get_string(
                True, "ERROR: please provide an executable for the ResMap program.",
            )
            fn_mask = self.joboptions["fn_mask"].get_string(
                True,
                "ERROR: Please provide an input mask for ResMap "
                "local-resolution estimation.",
            )
            if self.joboptions["do_queue"].get_boolean():
                raise_error(
                    "ERROR: You cannot submit a ResMap job to the queue, "
                    "as it needs user interaction."
                )
            if nr_mpi > 1:
                os.system(
                    "echo "
                    "'You cannot use more than 1 MPI processor"
                    " for the ResMap wrapper..."
                    " Changing number of mpis to 1\n' >> {}run.err".format(outputname)
                )
                nr_mpi = 1

            # make symbolic links to the halfmaps in the output dir
            os.symlink(os.path.abspath(fn_half1), outputname + "half1.mrc")
            os.symlink(os.path.abspath(fn_half2), outputname + "half2.mrc")
            self.input_nodes.append(Node(fn_mask, self.joboptions["fn_mask"].nodetype))

            self.output_nodes.append(
                Node(outputname + "half1_resmap.mrc", NODES["Resmap"])
            )

            command = fn_resmap
            command += " --maskVol=" + self.joboptions["fn_mask"].get_string()
            command += " --noguiSplit "
            command += outputname + "half1.mrc " + outputname + "half2.mrc"
            command += " --vxSize=" + self.joboptions["angpix"].get_string()
            command += " --pVal=" + self.joboptions["pval"].get_string()
            command += " --minRes=" + self.joboptions["minres"].get_string()
            command += " --maxRes=" + self.joboptions["maxres"].get_string()
            command += " --stepRes=" + self.joboptions["stepres"].get_string()

        elif do_relion_localres:
            # Relion postprocessing

            if nr_mpi > 1:
                command = "`which relion_postprocess_mpi`"
            else:
                command = "`which relion_postprocess`"

            command += " --locres --i " + fn_half1
            command += " --o " + outputname + "relion"
            command += " --angpix " + self.joboptions["angpix"].get_string()
            # locres_sampling = self.joboptions["locres_sampling"].get_string()
            # command += " --locres_sampling " + locres_sampling
            # randomize_at = self.joboptions["randomize_at"].get_string()
            # command += " --locres_randomize_at " + randomize_at

            command += " --adhoc_bfac " + self.joboptions["adhoc_bfac"].get_string()

            fn_mtf = self.joboptions["fn_mtf"].get_string()
            if len(fn_mtf) > 0:
                command += " --mtf " + fn_mtf

            fn_mask = self.joboptions["fn_mask"].get_string()
            if len(fn_mask) > 0:
                command += " --mask " + fn_mask

                # relion doesn't make an inut node for the mask here, but it should
                # the resmap version does
                self.input_nodes.append(
                    Node(fn_mask, self.joboptions["fn_mask"].nodetype)
                )

            self.output_nodes.append(
                Node(outputname + "histogram.pdf", NODES["PdfLogfile"])
            )

            self.output_nodes.append(
                Node(outputname + "relion_locres_filtered.mrc", NODES["Finalmap"],)
            )

            self.output_nodes.append(
                Node(outputname + "relion_locres.mrc", NODES["Resmap"],)
            )

        other_args = self.joboptions["other_args"].get_string()
        if len(other_args) > 0:
            command += " " + other_args

        commands = [command]
        return self.prepare_final_command(outputname, commands, do_makedir)
