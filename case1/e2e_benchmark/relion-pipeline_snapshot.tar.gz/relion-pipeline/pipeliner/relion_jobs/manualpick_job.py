from .relion_job import RelionJob
from ..data_structure import Node, NODES, MANUALPICK_TYPE_NUM
from ..job_options import JobOption
from pipeliner.utils import raise_error


class ManualPickJob(RelionJob):
    PROCESS_NAME = "ManualPick"
    PROCESS_TYPE_NUM = MANUALPICK_TYPE_NUM

    def __init__(self):
        super(self.__class__, self).__init__()
        # TODO: remove this and use class-level constant if possible
        self.type = MANUALPICK_TYPE_NUM
        self.hidden_name = ".gui_manualpick"

        self.joboptions["fn_in"] = JobOption.as_inputnode(
            "Input micrographs:",
            NODES["Mics"],
            "",
            "Input Micrographs (*.{star,mrc})",
            "Input STAR file (with or without CTF information), "
            "OR a unix-type wildcard with all micrographs in MRC format"
            " (in this case no CTFs can be used).",
        )

        self.joboptions["diameter"] = JobOption.as_slider(
            "Particle diameter (A):",
            100,
            0,
            500,
            50,
            "The diameter of the circle used around picked particles (in Angstroms)."
            " Only used for display.",
            True,
        )

        self.joboptions["micscale"] = JobOption.as_slider(
            "Scale for micrographs:",
            0.2,
            0.1,
            1,
            0.05,
            "The micrographs will be displayed at this relative scale,"
            " i.e. a value of 0.5 means that only every second pixel"
            " will be displayed.",
            True,
        )

        self.joboptions["sigma_contrast"] = JobOption.as_slider(
            "Sigma contrast:",
            3,
            0,
            10,
            0.5,
            "The micrographs will be displayed with the black value set "
            "to the average of all values MINUS this values times the standard"
            " deviation of all values in the micrograph, and the white value"
            " will be set to the average PLUS this value times the standard "
            "deviation. Use zero to set the minimum value in the micrograph "
            "to black, and the maximum value to white ",
            True,
        )

        self.joboptions["white_val"] = JobOption.as_slider(
            "White value:",
            0,
            0,
            512,
            16,
            "Use non-zero values to set the value of the whitest "
            "pixel in the micrograph.",
            True,
        )

        self.joboptions["black_val"] = JobOption.as_slider(
            "Black value:",
            0,
            0,
            512,
            16,
            "Use non-zero values to set the value of the blackest"
            " pixel in the micrograph.",
            True,
        )

        self.joboptions["lowpass"] = JobOption.as_slider(
            "Lowpass filter (A)",
            20,
            10,
            100,
            5,
            "Lowpass filter that will be applied to the micrographs."
            " Give a negative value to skip the lowpass filter.",
            True,
        )

        self.joboptions["highpass"] = JobOption.as_slider(
            "Highpass filter (A)",
            -1,
            100,
            1000,
            100,
            "Highpass filter that will be applied to the micrographs. "
            "This may be useful to get rid of background ramps due to uneven"
            " ice distributions. Give a negative value to skip the highpass "
            "filter. Useful values are often in the range of 200-400 Angstroms.",
            True,
        )

        self.joboptions["angpix"] = JobOption.as_slider(
            "Pixel size (A)",
            -1,
            0.3,
            5,
            0.1,
            "Pixel size in Angstroms. This will be used to calculate"
            " the filters and the particle diameter in pixels. If a "
            "CTF-containing STAR file is input, then the value given here"
            " will be ignored, and the pixel size will be calculated from the"
            " values in the STAR file. A negative value can then be given here.",
            True,
        )

        self.joboptions["do_startend"] = JobOption.as_boolean(
            "Pick start-end coordinates helices?",
            False,
            "If set to true, start and end coordinates are picked subsequently"
            " and a line will be drawn between each pair",
            True,
        )

        self.joboptions["ctfscale"] = JobOption.as_slider(
            "Scale for CTF image:",
            1,
            0.1,
            2,
            0.1,
            "CTFFINDs CTF image (with the Thonrings) will be displayed"
            " at this relative scale, i.e. a value of 0.5 means that only"
            " every second pixel will be displayed.",
            True,
        )

        self.joboptions["do_color"] = JobOption.as_boolean(
            "Blue<>red color particles?",
            False,
            "If set to true, then the circles for each particles are coloured"
            " from red to blue (or the other way around) for a given metadatalabel."
            " If this metadatalabel is not in the picked coordinates STAR file"
            "(basically only the rlnAutopickFigureOfMerit or rlnClassNumber) would"
            " be useful values there, then you may provide an additional STAR file"
            " (e.g. after classification/refinement below. Particles with values"
            " -999, or that are not in the additional STAR file will be coloured"
            " the default color: green",
            True,
        )

        self.joboptions["color_label"] = JobOption.as_textbox(
            "MetaDataLabel for color:",
            "rlnParticleSelectZScore",
            "The Metadata label of the value to plot from red<>blue."
            " Useful examples might be: \nrlnParticleSelectZScore \n rlnClassNumber"
            " \n rlnAutopickFigureOfMerit \n rlnAngleTilt \n rlnLogLikeliContribution"
            " \n rlnMaxValueProbDistribution \n rlnNrOfSignificantSamples\n",
            True,
        )

        self.joboptions["fn_color"] = JobOption.as_fn(
            "STAR file with color label: ",
            "",
            "STAR file (*.star)",
            ".",
            "The program will figure out which particles in this STAR file"
            " are on the current micrograph and color their circles according "
            "to the value in the corresponding column. Particles that are not in"
            " this STAR file, but present in the picked coordinates file will be "
            "colored green. If this field is left empty, then the color label "
            "(e.g. rlnAutopickFigureOfMerit) should be present in the"
            " coordinates STAR file.",
            True,
        )

        self.joboptions["blue_value"] = JobOption.as_slider(
            "Blue value: ",
            0.0,
            0.0,
            4.0,
            0.1,
            "The value of this entry will be blue. There will be a "
            "linear scale from blue to red, according to this value and the"
            " one given below.",
            True,
        )

        self.joboptions["red_value"] = JobOption.as_slider(
            "Red value: ",
            2.0,
            0.0,
            4.0,
            0.1,
            "The value of this entry will be red. There will be a"
            " linear scale from blue to red, according to this value"
            " and the one given above.",
            True,
        )

        self.get_runtab_options(False, False)

    def initialise(self):
        # Initialisation already done in __init__. TODO: do we need this method too?
        pass

    def get_commands(self, outputname, do_makedir, job_counter):

        outputname = self.initialise_pipeline(
            outputname, self.PROCESS_NAME, job_counter
        )

        command = "`which relion_manualpick` "

        input_star_mics = self.joboptions["fn_in"].get_string()
        if len(input_star_mics) < 1:
            raise_error("ERROR: empty field for input STAR file...")

        self.input_nodes.append(
            Node(input_star_mics, self.joboptions["fn_in"].nodetype)
        )
        command += "--i " + input_star_mics

        command += " --odir " + outputname
        command += " --pickname manualpick"

        fn_suffix = outputname + "coords_suffix_manualpick.star"
        self.output_nodes.append(Node(fn_suffix, NODES["Mic coords"]))

        fn_outstar = outputname + "micrographs_selected.star"
        self.output_nodes.append(Node(fn_outstar, NODES["Mics"]))

        command += " --allow_save --fast_save --selection " + fn_outstar

        command += " --scale " + self.joboptions["micscale"].get_string()
        command += " --sigma_contrast " + self.joboptions["sigma_contrast"].get_string()
        command += " --black " + self.joboptions["black_val"].get_string()
        command += " --white " + self.joboptions["white_val"].get_string()

        lowpass = int(self.joboptions["lowpass"].get_number())
        if lowpass > 0:
            command += " --lowpass " + str(lowpass)

        highpass = int(self.joboptions["highpass"].get_number())
        if highpass > 0:
            command += " --highpass " + str(highpass)

        angpix = self.joboptions["angpix"].get_number()
        if angpix > 0:
            command += " --angpix " + str(angpix)

        command += " --ctf_scale " + self.joboptions["ctfscale"].get_string()
        command += " --particle_diameter " + self.joboptions["diameter"].get_string()

        do_startend = self.joboptions["do_startend"].get_boolean()
        if do_startend:
            command += " --do_startend "

        do_color = self.joboptions["do_color"].get_boolean()
        if do_color:
            command += " --color_label " + self.joboptions["color_label"].get_string()
            command += " --blue " + self.joboptions["blue_value"].get_string()
            command += " --red " + self.joboptions["red_value"].get_string()
            fn_color = self.joboptions["fn_color"].get_string()
            if len(fn_color) > 0:
                command += " --color_star " + fn_color

        other_args = self.joboptions["other_args"].get_string()
        if len(other_args) > 0:
            command += " " + other_args

        suffixfile_com = "echo {} > {}".format(input_star_mics, fn_suffix)
        command = [command, suffixfile_com]
        return self.prepare_final_command(outputname, command, do_makedir)
