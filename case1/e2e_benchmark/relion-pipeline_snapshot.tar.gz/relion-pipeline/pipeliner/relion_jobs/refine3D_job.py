from .relion_job import RelionJob
from ..data_structure import Node, NODES, REFINE3D_TYPE_NUM
from ..job_options import JobOption
from ..utils import truncate_number


class Refine3DJob(RelionJob):
    PROCESS_NAME = "Refine3D"
    PROCESS_TYPE_NUM = REFINE3D_TYPE_NUM

    def __init__(self):
        super(self.__class__, self).__init__()
        self.type = REFINE3D_TYPE_NUM
        self.hidden_name = ".gui_auto3d"

        self.joboptions["fn_img"] = JobOption.as_inputnode(
            "Input images STAR file:",
            NODES["Part data"],
            "",
            "STAR files (*.star) \t Image stacks "
            "(not recommended, read help!) (*.{spi,mrcs})",
            "A STAR file with all images (and their metadata). \n \n Alternatively, "
            "you may give a Spider/MRC stack of 2D images, but in that case NO "
            "metadata can be included and thus NO CTF correction can be performed, "
            "nor will it be possible to perform noise spectra estimation or intensity"
            " scale corrections in image groups. Therefore, running RELION with an "
            "input stack will in general provide sub-optimal results and is therefore"
            " not recommended!! Use the Preprocessing procedure to get the input STAR"
            " file in a semi-automated manner. Read the RELION wiki for more"
            " information.",
        )

        self.joboptions["fn_cont"] = JobOption.as_fn(
            "Continue from here: ",
            "",
            "STAR Files (*_optimiser.star)",
            "CURRENT_ODIR",
            "Select the *_optimiser.star file for the iteration from which"
            " you want to continue a previous run. Note that the Output "
            "rootname of the continued run and the rootname of the previous"
            " run cannot be the same. If they are the same, the program will"
            " automatically add a '_ctX' to the output rootname, with X being the"
            " iteration from which one continues the previous run.",
            True,
        )

        self.joboptions["fn_ref"] = JobOption.as_inputnode(
            "Reference map:",
            NODES["3D refs"],
            "",
            "Image Files (*.{spi,vol,mrc})",
            "A 3D map in MRC/Spider format. Make sure this map has the same dimensions"
            " and the same pixel size as your input images.",
        )

        self.joboptions["fn_mask"] = JobOption.as_inputnode(
            "Reference mask (optional):",
            NODES["Mask"],
            "",
            "Image Files (*.{spi,vol,msk,mrc})",
            "If no mask is provided, a soft spherical mask based on the particle"
            "diameter will be used.\n\nOtherwise, provide a Spider/mrc map containing"
            " a (soft) mask with the same dimensions as the reference(s), and values"
            " between 0 and 1, with 1 being 100% protein and 0 being 100% solvent. "
            "The reconstructed reference map will be multiplied by this mask.\n\n "
            "In some cases, for example for non-empty icosahedral viruses, it is "
            "also useful to use a second mask. For all white (value 1) pixels in "
            "this second mask the corresponding pixels in the reconstructed map are"
            " set to the average value of these pixels. Thereby, for example, the"
            " higher density inside the virion may be set to a constant. Note that "
            "this second mask should have one-values inside the virion and zero-values"
            " in the capsid and the solvent areas. To use a second mask, use the "
            "additional option --solvent_mask2, which may given in the Additional "
            "arguments line (in the Running tab).",
            True,
        )

        self.joboptions["ref_correct_greyscale"] = JobOption.as_boolean(
            "Ref. map is on absolute greyscale?",
            False,
            "Probabilities are calculated based on a Gaussian noise model, which "
            "contains a squared difference term between the reference and the "
            "experimental image. This has a consequence that the reference needs"
            " to be on the same absolute intensity grey-scale as the experimental"
            " images. RELION and XMIPP reconstruct maps at their absolute intensity"
            " grey-scale. Other packages may perform internal normalisations of the"
            " reference density, which will result in incorrect grey-scales. "
            "Therefore: if the map was reconstructed in RELION or in XMIPP, set this "
            "option to Yes, otherwise set it to No. If set to No, RELION will use a"
            " (grey-scale invariant) cross-correlation criterion in the first "
            "iteration, and prior to the second iteration the map will be filtered"
            " again using the initial low-pass filter. This procedure is relatively"
            " quick and typically does not negatively affect the outcome of the"
            "subsequent MAP refinement. Therefore, if in doubt it is recommended"
            " to set this option to No.",
        )

        self.joboptions["ini_high"] = JobOption.as_slider(
            "Initial low-pass filter (A):",
            60,
            0,
            200,
            5,
            "It is recommended to strongly low-pass filter your initial reference map."
            "If it has not yet been low-pass filtered, it may be done internally using"
            "this option. If set to 0, no low-pass filter will be applied to the "
            "initial reference(s).",
        )

        self.joboptions["sym_name"] = JobOption.as_textbox(
            "Symmetry:",
            "C1",
            "If the molecule is asymmetric, set Symmetry group to C1. "
            "Note their are multiple possibilities for icosahedral symmetry: \n"
            "* I1: No-Crowther 222 (standard in Heymann, Chagoyen & Belnap, JSB,"
            " 151 (2005) 196–207) \n * I2: Crowther 222 \n * I3: 52-setting (as "
            "used in SPIDER?)\n * I4: A different 52 setting \n The command"
            " 'relion_refine --sym D2 --print_symmetry_ops' prints a list of all"
            " symmetry operators for symmetry group D2. RELION uses XMIPP's libraries"
            " for symmetry operations. Therefore, look at the XMIPP Wiki for more "
            "details: "
            "http://xmipp.cnb.csic.es/twiki/bin/view/Xmipp/WebHome?topic=Symmetry",
        )

        self.joboptions["do_ctf_correction"] = JobOption.as_boolean(
            "Do CTF-correction?",
            True,
            "If set to Yes, CTFs will be corrected inside the MAP refinement. "
            "The resulting algorithm intrinsically implements the optimal linear,"
            " or Wiener filter. Note that CTF parameters for all images need to "
            "be given in the input STAR file. The command 'relion_refine"
            " --print_metadata_labels' will print a list of all possible metadata"
            " labels for that STAR file. See the RELION Wiki for more details.\n\n"
            " Also make sure that the correct pixel size (in Angstrom)"
            " is given above!)",
        )

        self.joboptions["ctf_corrected_ref"] = JobOption.as_boolean(
            "Has reference been CTF-corrected?",
            False,
            "Set this option to Yes if the reference map represents density that is"
            " unaffected by CTF phases and amplitudes, e.g. it was created using CTF"
            " correction (Wiener filtering) inside RELION or from a PDB. \n\n"
            "If set to No, then in the first iteration, the Fourier transforms of "
            "the reference projections are not multiplied by the CTFs.",
        )

        self.joboptions["ctf_intact_first_peak"] = JobOption.as_boolean(
            "Ignore CTFs until first peak?",
            False,
            "If set to Yes, then CTF-amplitude correction will only be performed"
            " from the first peak of each CTF onward. This can be useful if the CTF"
            " model is inadequate at the lowest resolution. Still, in general using"
            " higher amplitude contrast on the CTFs (e.g. 10-20%) often yields better"
            " results. Therefore, this option is not generally recommended: try"
            " increasing amplitude contrast (in your input STAR file) first!",
        )

        self.joboptions["particle_diameter"] = JobOption.as_slider(
            "Mask diameter (A):",
            200,
            0,
            1000,
            10,
            "The experimental images will be masked with a soft circular mask with "
            "this diameter. Make sure this radius is not set too small because that"
            " may mask away part of the signal! If set to a value larger than the "
            "image size no masking will be performed.\n\n The same diameter will also"
            " be used for a spherical mask of the reference structures if no"
            " user-provided mask is specified.",
            True,
        )

        self.joboptions["do_zero_mask"] = JobOption.as_boolean(
            "Mask individual particles with zeros?",
            True,
            "If set to Yes, then in the individual particles, the area outside a"
            " circle with the radius of the particle will be set to zeros prior "
            "to taking the Fourier transform. This will remove noise and therefore"
            " increase sensitivity in the alignment and classification. However,"
            " it will also introduce correlations between the Fourier components"
            " that are not modelled. When set to No, then the solvent area is filled"
            " with random noise, which prevents introducing correlations. "
            "High-resolution refinements (e.g. ribosomes or other large complexes"
            " in 3D auto-refine) tend to work better when filling the solvent area"
            " with random noise (i.e. setting this option to No), refinements of"
            " smaller complexes and most classifications go better when using zeros"
            " (i.e. setting this option to Yes).",
        )

        self.joboptions["do_solvent_fsc"] = JobOption.as_boolean(
            "Use solvent-flattened FSCs?",
            False,
            "If set to Yes, then instead of using unmasked maps to calculate the"
            " gold-standard FSCs during refinement, masked half-maps are used and"
            " a post-processing-like correction of the FSC curves "
            "(with phase-randomisation) is performed every iteration. This only "
            "works when a reference mask is provided on the I/O tab. This may yield "
            "higher-resolution maps, especially when the mask contains only a "
            "relatively small volume inside the box.",
            True,
        )

        self.joboptions["sampling"] = JobOption.as_radio(
            "Angular sampling interval:",
            "SAMPLING",
            2,
            "There are only a few discrete angular samplings possible because we use"
            " the HealPix library to generate the sampling of the first two Euler "
            "angles on the sphere. The samplings are approximate numbers and vary"
            " slightly over the sphere.\n\n If auto-sampling is used, this will be"
            " the value for the first iteration(s) only, and the sampling rate will"
            " be increased automatically after that.",
        )

        self.joboptions["offset_range"] = JobOption.as_slider(
            "Offset search range (pix):",
            5,
            0,
            30,
            1,
            "Probabilities will be calculated only for translations in a circle with"
            " this radius (in pixels). The center of this circle changes at every"
            " iteration and is placed at the optimal translation for each image in "
            "the previous iteration.\n\n If auto-sampling is used, this will be the"
            " value for the first iteration(s) only, and the sampling rate will be"
            " increased automatically after that.",
        )

        self.joboptions["offset_step"] = JobOption.as_slider(
            "Offset search step (pix):",
            1,
            0.1,
            5,
            0.1,
            "Translations will be sampled with this step-size (in pixels)."
            "Translational sampling is also done using the adaptive approach."
            " Therefore, if adaptive=1, the translations will first be evaluated"
            " on a 2x coarser grid.\n\n If auto-sampling is used, this will be the"
            " value for the first iteration(s) only, and the sampling rate will be "
            "increased automatically after that.",
        )

        self.joboptions["auto_local_sampling"] = JobOption.as_radio(
            "Local searches from auto-sampling:",
            "SAMPLING",
            4,
            "In the automated procedure to increase the angular samplings, local "
            "angular searches of -6/+6 times the sampling rate will be used from"
            " this angular sampling rate onwards. For most lower-symmetric "
            "particles a value of 1.8 degrees will be sufficient. Perhaps"
            " icosahedral symmetries may benefit from a smaller value such as "
            "0.9 degrees.",
        )

        self.joboptions["auto_faster"] = JobOption.as_boolean(
            "Use finer angular sampling faster?",
            False,
            "If set to Yes, then let auto-refinement proceed faster with finer angular"
            " samplings. Two additional command-line options will be passed to the "
            "refine program: \n --auto_ignore_angles lets angular sampling go down "
            "despite changes still happening in the angles \n \n --auto_resol_angles "
            "lets angular sampling go down if the current resolution already requires "
            "that sampling at the edge of the particle.  \n\n This option will make "
            "the computation faster, but hasn't been tested for many cases for "
            "potential loss in reconstruction quality upon convergence.",
            True,
        )

        self.joboptions["do_helix"] = JobOption.as_boolean(
            "Do helical reconstruction?",
            False,
            "If set to Yes, then perform 3D helical reconstruction.",
        )

        self.joboptions["helical_tube_inner_diameter"] = JobOption.as_textbox(
            "Tube diameter - inner (A):",
            "-1",
            "Inner and outer diameter (in Angstroms) of the reconstructed helix "
            "spanning across Z axis. Set the inner diameter to negative value if"
            " the helix is not hollow in the center. The outer diameter should be "
            "slightly larger than the actual width of helical tubes because it also "
            "decides the shape of 2D particle mask for each segment. If the psi"
            " priors of the extracted segments are not accurate enough due to high"
            " noise level or flexibility of the structure, then set the outer diameter"
            " to a large value.",
        )

        self.joboptions["helical_tube_outer_diameter"] = JobOption.as_textbox(
            "Tube diameter - outer (A):",
            "-1",
            "Inner and outer diameter (in Angstroms) of the reconstructed helix "
            "spanning across Z axis. Set the inner diameter to negative value if"
            " the helix is not hollow in the center. The outer diameter should be "
            "slightly larger than the actual width of helical tubes because it also "
            "decides the shape of 2D particle mask for each segment. If the psi"
            " priors of the extracted segments are not accurate enough due to high"
            " noise level or flexibility of the structure, then set the outer diameter"
            " to a large value.",
        )

        self.joboptions["range_rot"] = JobOption.as_textbox(
            "Angular search range - rot (deg):",
            "-1",
            "Local angular searches will be performed within +/- of the given amount"
            " (in degrees) from the optimal orientation in the previous iteration. The"
            " default negative value means that no local searches will be performed. "
            "A Gaussian prior will be applied, so that orientations closer to the "
            "optimal orientation in the previous iteration will get higher weights "
            "than those further away.\n\nThese ranges will only be applied to the "
            "rot, tilt and psi angles in the first few iterations (global searches"
            " for orientations) in 3D helical reconstruction. Values of 9 or 15 "
            "degrees are commonly used. Higher values are recommended for more "
            "flexible structures and more memory and computation time will be used. "
            "A range of 15 degrees means sigma = 5 degrees.\n\nThese options will be"
            " invalid if you choose to perform local angular searches or not to "
            "perform image alignment on 'Sampling' tab.",
        )

        self.joboptions["range_tilt"] = JobOption.as_textbox(
            "Angular search range - tilt (deg):",
            "15",
            "Local angular searches will be performed within +/- the given amount (in"
            " degrees) from the optimal orientation in the previous iteration. "
            "A Gaussian prior (also see previous option) will be applied, so that"
            " orientations closer to the optimal orientation in the previous iteration"
            " will get higher weights than those further away.\n\nThese ranges will "
            "only be applied to the rot, tilt and psi angles in the first few "
            "iterations (global searches for orientations) in 3D helical "
            "reconstruction. Values of 9 or 15 degrees are commonly used. Higher "
            "values are recommended for more flexible structures and more memory"
            " and computation time will be used. A range of 15 degrees means sigma"
            " = 5 degrees.\n\nThese options will be invalid if you choose to perform"
            " local angular searches or not to perform image alignment"
            " on 'Sampling' tab.",
        )

        self.joboptions["range_psi"] = JobOption.as_textbox(
            "Angular search range - psi (deg):",
            "10",
            "Local angular searches will be performed within +/- the given amount "
            "(in degrees) from the optimal orientation in the previous iteration. "
            "A Gaussian prior (also see previous option) will be applied, so that"
            " orientations closer to the optimal orientation in the previous"
            " iteration will get higher weights than those further away.\n\nThese"
            " ranges will only be applied to the rot, tilt and psi angles in the"
            " first few iterations (global searches for orientations) in 3D"
            " helical reconstruction. Values of 9 or 15 degrees are commonly used."
            " Higher values are recommended for more flexible structures and more"
            " memory and computation time will be used. A range of 15 degrees means"
            " sigma = 5 degrees.\n\nThese options will be invalid if you choose to"
            " perform local angular searches or not to perform image alignment on"
            " 'Sampling' tab.",
        )

        self.joboptions["do_apply_helical_symmetry"] = JobOption.as_boolean(
            "Apply helical symmetry?",
            True,
            "If set to Yes, helical symmetry will be applied in every iteration. "
            "Set to No if you have just started a project, helical symmetry is "
            "unknown or not yet estimated.",
        )

        self.joboptions["helical_nr_asu"] = JobOption.as_slider(
            "Number of unique asymmetrical units:",
            1,
            1,
            100,
            1,
            "Number of unique helical asymmetrical units in each segment box."
            " If the inter-box distance (set in segment picking step) "
            "is 100 Angstroms and the estimated helical rise is ~20 Angstroms,"
            " then set this value to 100 / 20 = 5 (nearest integer). This integer"
            " should not be less than 1. The correct value is essential in"
            " measuring the signal to noise ratio in helical reconstruction.",
        )

        self.joboptions["helical_twist_initial"] = JobOption.as_textbox(
            "Initial helical twist (deg):",
            "0",
            "Initial helical symmetry. Set helical twist (in degrees) to positive"
            " value if it is a right-handed helix. Helical rise is a positive value"
            " in Angstroms. If local searches of helical symmetry are planned,"
            " initial values of helical twist and rise should be within their "
            "respective ranges.",
        )

        self.joboptions["helical_rise_initial"] = JobOption.as_textbox(
            "Initial helical rise (A):",
            "0",
            "Initial helical symmetry. Set helical twist (in degrees) to positive"
            " value if it is a right-handed helix. Helical rise is a positive value"
            " in Angstroms. If local searches of helical symmetry are planned, "
            "initial values of helical twist and rise should be within their "
            "respective ranges.",
        )

        self.joboptions["helical_z_percentage"] = JobOption.as_slider(
            "Central Z length (%):",
            30.0,
            5.0,
            80.0,
            1.0,
            "Reconstructed helix suffers from inaccuracies of orientation searches. "
            "The central part of the box contains more reliable information compared"
            " to the top and bottom parts along Z axis, where Fourier artefacts are "
            "also present if the number of helical asymmetrical units is larger than"
            " 1. Therefore, information from the central part of the box is used for"
            " searching and imposing helical symmetry in real space. Set this value"
            " (%) to the central part length along Z axis divided by the box size."
            " Values around 30% are commonly used.",
        )

        self.joboptions["do_local_search_helical_symmetry"] = JobOption.as_boolean(
            "Do local searches of symmetry?",
            False,
            "If set to Yes, then perform local searches of helical twist and rise"
            " within given ranges.",
        )

        self.joboptions["helical_twist_min"] = JobOption.as_textbox(
            "Helical twist search (deg) - Min:",
            "0",
            "Minimum, maximum and initial step for helical twist search. "
            "Set helical twist (in degrees) to positive value if it is a right-handed"
            " helix. Generally it is not necessary for the user to provide an initial"
            " step (less than 1 degree, 5~1000 samplings as default). But it needs to"
            " be set manually if the default value does not guarantee convergence. The"
            " program cannot find a reasonable symmetry if the true helical parameters"
            " fall out of the given ranges. Note that the final reconstruction can"
            " still converge if wrong helical and point group symmetry are provided.",
        )

        self.joboptions["helical_twist_max"] = JobOption.as_textbox(
            "Helical twist search (deg) - Max:",
            "0",
            "Minimum, maximum and initial step for helical twist search. Set helical "
            "twist (in degrees) to positive value if it is a right-handed helix. "
            "Generally it is not necessary for the user to provide an initial step "
            "(less than 1 degree, 5~1000 samplings as default). But it needs to be set"
            " manually if the default value does not guarantee convergence. The program"
            " cannot find a reasonable symmetry if the true helical parameters fall "
            "out of the given ranges. Note that the final reconstruction can still "
            "converge if wrong helical and point group symmetry are provided.",
        )

        self.joboptions["helical_twist_inistep"] = JobOption.as_textbox(
            "Helical twist search (deg) - Step:",
            "0",
            "Minimum, maximum and initial step for helical twist search. Set helical"
            " twist (in degrees) to positive value if it is a right-handed helix."
            " Generally it is not necessary for the user to provide an initial step"
            " (less than 1 degree, 5~1000 samplings as default). But it needs to be "
            "set manually if the default value does not guarantee convergence. The"
            " program cannot find a reasonable symmetry if the true helical parameters"
            " fall out of the given ranges. Note that the final reconstruction can"
            " still converge if wrong helical and point group symmetry are provided.",
        )

        self.joboptions["helical_rise_min"] = JobOption.as_textbox(
            "Helical rise search (A) - Min:",
            "0",
            "Minimum, maximum and initial step for helical rise search. Helical rise "
            "is a positive value in Angstroms. Generally it is not necessary for "
            "the user to provide an initial step (less than 1% the initial helical"
            " rise, 5~1000 samplings as default). But it needs to be set manually if"
            " the default value does not guarantee convergence. The program cannot "
            "find a reasonable symmetry if the true helical parameters fall out of the"
            " given ranges. Note that the final reconstruction can still converge if "
            "wrong helical and point group symmetry are provided.",
        )

        self.joboptions["helical_rise_max"] = JobOption.as_textbox(
            "Helical rise search (A) - Max:",
            "0",
            "Minimum, maximum and initial step for helical rise search. Helical rise"
            " is a positive value in Angstroms. Generally it is not necessary for the"
            " user to provide an initial step (less than 1% the initial helical rise,"
            " 5~1000 samplings as default). But it needs to be set manually if the "
            "default value does not guarantee convergence. The program cannot find a"
            " reasonable symmetry if the true helical parameters fall out of the given"
            " ranges. Note that the final reconstruction can still converge if wrong "
            "helical and point group symmetry are provided.",
        )

        self.joboptions["helical_rise_inistep"] = JobOption.as_textbox(
            "Helical rise search (A) - Step:",
            "0",
            "Minimum, maximum and initial step for helical rise search. Helical rise "
            "is a positive value in Angstroms. Generally it is not necessary for"
            " the user to provide an initial step (less than 1% the initial helical "
            "rise, 5~1000 samplings as default). But it needs to be set manually if "
            "the default value does not guarantee convergence. The program cannot "
            "find a reasonable symmetry if the true helical parameters fall out of "
            "the given ranges. Note that the final reconstruction can still converge"
            " if wrong helical and point group symmetry are provided.",
        )

        self.joboptions["helical_range_distance"] = JobOption.as_slider(
            "Range factor of local averaging:",
            -1.0,
            1.0,
            5.0,
            0.1,
            "Local averaging of orientations and translations will be performed"
            " within a range of +/- this value * the box size. Polarities are also"
            " set to be the same for segments coming from the same tube during local"
            " refinement. Values of ~ 2.0 are recommended for flexible structures"
            " such as MAVS-CARD filaments, ParM, MamK, etc. This option might not "
            "improve the reconstructions of helices formed from curled 2D lattices "
            "(TMV and VipA/VipB). Set to negative to disable this option.",
        )

        self.joboptions["keep_tilt_prior_fixed"] = JobOption.as_boolean(
            "Keep tilt-prior fixed:",
            True,
            "If set to yes, the tilt prior will not change during the optimisation."
            " If set to No, at each iteration the tilt prior will move to the optimal"
            " tilt value for that segment from the previous iteration.",
        )

        self.get_comp_options()

        self.get_runtab_options()

    def initialise(self):
        # Initialisation already done in __init__. TODO: do we need this method too?
        pass

    def get_commands(self, outputname, do_makedir, job_counter):
        # split up the helical options into subfunctions because they got too nested
        def helical_symmetry_options():
            helical_nr_asu = self.joboptions["helical_nr_asu"].get_string()
            command = " --helical_nr_asu " + helical_nr_asu
            ini_twist = self.joboptions["helical_twist_initial"].get_string()
            command += " --helical_twist_initial " + ini_twist
            ini_rise = self.joboptions["helical_rise_initial"].get_string()
            command += " --helical_rise_initial " + ini_rise
            myz = self.joboptions["helical_z_percentage"].get_number() / 100.0
            command += " --helical_z_percentage " + truncate_number(myz, 2)
            return command

        def helical_symsearch_options():
            command = " --helical_symmetry_search"
            twist_min = self.joboptions["helical_twist_min"].get_string()
            command += " --helical_twist_min " + twist_min
            twist_max = self.joboptions["helical_twist_max"].get_string()
            command += " --helical_twist_max " + twist_max
            twist_inistep = self.joboptions["helical_twist_inistep"].get_number()
            if twist_inistep > 0:
                command += " --helical_twist_inistep " + truncate_number(
                    twist_inistep, 2
                )
            rise_min = self.joboptions["helical_rise_min"].get_string()
            command += " --helical_rise_min " + rise_min
            rise_max = self.joboptions["helical_rise_max"].get_string()
            command += " --helical_rise_max " + rise_max
            rise_inistep = self.joboptions["helical_rise_inistep"].get_number()
            if rise_inistep > 0:
                command += " --helical_rise_inistep " + truncate_number(rise_inistep, 2)
            return command

        def range_options():
            val = self.joboptions["range_tilt"].get_number()
            val = float(min(max(val, 0), 90))
            command = " --sigma_tilt " + truncate_number((val / 3.0), 5)

            val = self.joboptions["range_psi"].get_number()
            val = float(min(max(val, 0), 90))
            command += " --sigma_psi " + truncate_number((val / 3.0), 5)

            val = self.joboptions["range_rot"].get_number()
            val = float(min(max(val, 0), 90))
            command += " --sigma_rot " + truncate_number((val / 3.0), 5)

            val = self.joboptions["helical_range_distance"].get_number()
            if val > 0:
                command += " --helical_sigma_distance " + truncate_number(val / 3.0, 5)

            if self.joboptions["keep_tilt_prior_fixed"].get_boolean():
                command += " --helical_keep_tilt_prior_fixed"

            return command

        outputname = self.initialise_pipeline(
            outputname, self.PROCESS_NAME, job_counter
        )

        if self.joboptions["nr_mpi"].get_number() > 1:
            command = "`which relion_refine_mpi`"
        else:
            command = "`which relion_refine`"

        command += self.refinement_IO(outputname, 3, 1, self.is_continue)

        command += " --auto_refine --split_random_halves"

        fn_ref = self.joboptions["fn_ref"].get_string(
            True,
            "ERROR: empty field for reference. Type None for de-novo subtomogram"
            " averaging, provide reference for single-particle analysis.",
        )

        if fn_ref not in ["None", "none"]:
            command += " --ref " + fn_ref
            self.input_nodes.append(Node(fn_ref, self.joboptions["fn_ref"].nodetype))

            ref_correct_greyscale = self.joboptions[
                "ref_correct_greyscale"
            ].get_boolean()

            if not ref_correct_greyscale:  # dont do firstiter_cc when giving None
                command += " --firstiter_cc"

        ini_high = self.joboptions["ini_high"].get_number()
        if ini_high > 0:
            command += " --ini_high " + truncate_number(ini_high, 2)

        # do compute options
        command += self.add_comp_options()
        if self.joboptions["auto_faster"].get_boolean():
            command += " --auto_ignore_angles --auto_resol_angles"

        # ctf stuff
        if not self.is_continue:
            if self.joboptions["do_ctf_correction"].get_boolean():
                command += " --ctf"
                if self.joboptions["ctf_corrected_ref"].get_boolean():
                    command += " --ctf_corrected_ref"
                if self.joboptions["ctf_intact_first_peak"].get_boolean():
                    command += " --ctf_intact_first_peak"
            particle_diameter = self.joboptions["particle_diameter"].get_string()
            command += " --particle_diameter " + particle_diameter
            ## always flatten solvent
            command += " --flatten_solvent"
            if self.joboptions["do_zero_mask"].get_boolean():
                command += " --zero_mask"

        ## mask
        fn_mask = self.joboptions["fn_mask"].get_string()
        if len(fn_mask) > 0:
            command += " --solvent_mask " + fn_mask
            self.input_nodes.append(Node(fn_mask, self.joboptions["fn_mask"].nodetype))
            if self.joboptions["do_solvent_fsc"].get_boolean():
                command += " --solvent_correct_fsc"

        if not self.is_continue:
            iover = 1
            command += " --oversampling " + str(iover)
            sampling_opts = JobOption.SAMPLING
            sampling_opt = self.joboptions["sampling"].get_string()
            sampling = sampling_opts.index(sampling_opt) + 1
            ## The sampling given in the GUI will be the oversampled one!
            command += " --healpix_order " + str(sampling - iover)

            autolocal_opt = self.joboptions["auto_local_sampling"].get_string()
            # check this
            autolocal = sampling_opts.index(autolocal_opt)
            command += " --auto_local_healpix_order " + str(autolocal)

            ## Offset range
            offset_range = self.joboptions["offset_range"].get_string()
            command += " --offset_range " + offset_range

            ## The sampling given in the GUI will be the oversampled one!
            offset_step = self.joboptions["offset_step"].get_number()
            offset_step = offset_step * (2 ** iover)
            command += " --offset_step " + truncate_number(offset_step, 2)

            ## Provide symmetry, and always do norm and scale correction
            command += " --sym " + self.joboptions["sym_name"].get_string()
            command += " --low_resol_join_halves 40"
            command += " --norm --scale"

            if self.joboptions["do_helix"].get_boolean():
                command += " --helix"
                inner_diam = self.joboptions["helical_tube_inner_diameter"].get_number()
                if inner_diam > 0:
                    command += " --helical_inner_diameter " + truncate_number(
                        inner_diam, 2
                    )
                outer_diam = self.joboptions["helical_tube_outer_diameter"].get_string()
                command += " --helical_outer_diameter " + outer_diam

                if self.joboptions["do_apply_helical_symmetry"].get_boolean():
                    command += helical_symmetry_options()
                    if self.joboptions[
                        "do_local_search_helical_symmetry"
                    ].get_boolean():
                        command += helical_symsearch_options()
                    command += range_options()

                else:
                    command += " --ignore_helical_symmetry"
                    command += range_options()

        ## Running stuff
        command += " --j " + self.joboptions["nr_threads"].get_string()

        ## GPU-stuff
        if self.joboptions["use_gpu"].get_boolean():
            gpu_ids = self.joboptions["gpu_ids"].get_string()
            command += ' --gpu "' + gpu_ids + '"'

        ## Other arguments
        other_args = self.joboptions["other_args"].get_string()
        if len(other_args) > 0:
            self.solvmask2_node()
            command += " " + other_args

        commands = [command]
        return self.prepare_final_command(outputname, commands, do_makedir)
