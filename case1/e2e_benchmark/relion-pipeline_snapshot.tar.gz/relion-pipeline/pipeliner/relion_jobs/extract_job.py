import os
from ..utils import truncate_number, raise_error
from .relion_job import RelionJob
from ..data_structure import Node, NODES, EXTRACT_TYPE_NUM
from ..job_options import JobOption


class ExtractJob(RelionJob):
    PROCESS_NAME = "Extract"
    PROCESS_TYPE_NUM = EXTRACT_TYPE_NUM

    def __init__(self):
        super(self.__class__, self).__init__()
        # TODO: remove this and use class-level constant if possible
        self.type = EXTRACT_TYPE_NUM
        self.hidden_name = ".gui_extract"

        self.joboptions["star_mics"] = JobOption.as_inputnode(
            "micrograph STAR file: ",
            NODES["Mics"],
            "",
            "Input STAR file (*.star)",
            "Filename of the STAR file that contains all micrographs from which "
            "to extract particles.",
        )

        self.joboptions["coords_suffix"] = JobOption.as_inputnode(
            "Input coordinates: ",
            NODES["Mic coords"],
            "",
            "Input coords_suffix file (coords_suffix*)",
            "Filename of the coords_suffix file with the directory structure and"
            " the suffix of all coordinate files.",
        )

        self.joboptions["do_reextract"] = JobOption.as_boolean(
            "OR re-extract refined particles? ",
            False,
            "If set to Yes, the input Coordinates above will be ignored. "
            "Instead, one uses a _data.star file from a previous 2D or 3D"
            "refinement to re-extract the particles in that refinement, possibly"
            " re-centered with their refined origin offsets. This is particularly "
            "useful when going from binned to unbinned particles.",
        )

        self.joboptions["fndata_reextract"] = JobOption.as_inputnode(
            "Refined particles STAR file: ",
            NODES["Part data"],
            "",
            "Input STAR file (*.star)",
            "Filename of the STAR file with the refined particle coordinates,"
            " e.g. from a previous 2D or 3D classification or auto-refine run.",
        )

        self.joboptions["do_reset_offsets"] = JobOption.as_boolean(
            "Reset the refined offsets to zero? ",
            False,
            "If set to Yes, the input origin offsets will be reset to zero. This"
            " may be useful after 2D classification of helical segments, where one "
            "does not want neighbouring segments to be translated on top of each other"
            " for a subsequent 3D refinement or classification.",
        )

        self.joboptions["do_recenter"] = JobOption.as_boolean(
            "OR: re-center refined coordinates? ",
            False,
            "If set to Yes, the input coordinates will be re-centered according"
            " to the refined origin offsets in the provided _data.star file. "
            "The unit is pixel, not angstrom. The origin is at the center of the "
            "box, not at the corner.",
        )

        self.joboptions["recenter_x"] = JobOption.as_textbox(
            "Re-center on X-coordinate (in pix): ",
            "0",
            "Re-extract particles centered on this X-coordinate (in pixels "
            "in the reference)",
        )

        self.joboptions["recenter_y"] = JobOption.as_textbox(
            "Re-center on Y-coordinate (in pix): ",
            "0",
            "Re-extract particles centered on this Y-coordinate (in pixels in the "
            "reference)",
        )

        self.joboptions["recenter_z"] = JobOption.as_textbox(
            "Re-center on Z-coordinate (in pix): ",
            "0",
            "Re-extract particles centered on this Z-coordinate (in pixels in the"
            " reference)",
        )

        self.joboptions["extract_size"] = JobOption.as_slider(
            "Particle box size (pix):",
            128,
            64,
            512,
            8,
            "Size of the extracted particles (in pixels). This should be an even "
            "number!",
        )

        self.joboptions["do_invert"] = JobOption.as_boolean(
            "Invert contrast?",
            True,
            "If set to Yes, the contrast in the particles will be inverted.",
        )

        self.joboptions["do_norm"] = JobOption.as_boolean(
            "Normalize particles?",
            True,
            "If set to Yes, particles will be normalized in the "
            "way RELION prefers it.",
        )

        self.joboptions["bg_diameter"] = JobOption.as_slider(
            "Diameter background circle (pix): ",
            -1,
            -1,
            600,
            10,
            "Particles will be normalized to a mean value of zero and a "
            "standard-deviation of one for all pixels in the background area."
            "The background area is defined as all pixels outside a circle with"
            " this given diameter in pixels (before rescaling). When specifying"
            " a negative value, a default value of 75% of the Particle box size will"
            " be used.",
        )

        self.joboptions["white_dust"] = JobOption.as_slider(
            "Stddev for white dust removal: ",
            -1,
            -1,
            10,
            0.1,
            "Remove very white pixels from the extracted particles. Pixels values "
            "higher than this many times the image stddev will be replaced with "
            "values from a Gaussian distribution. \n \n Use negative value to switch"
            " off dust removal.",
        )

        self.joboptions["black_dust"] = JobOption.as_slider(
            "Stddev for black dust removal: ",
            -1,
            -1,
            10,
            0.1,
            "Remove very black pixels from the extracted particles.Pixels values"
            " higher than this many times the image stddev will be replaced with "
            "values from a Gaussian distribution. \n \n Use negative value to switch"
            " off dust removal.",
        )

        self.joboptions["do_rescale"] = JobOption.as_boolean(
            "Rescale particles?",
            False,
            "If set to Yes, particles will be re-scaled. Note that the particle "
            "diameter below will be in the down-scaled images.",
        )

        self.joboptions["rescale"] = JobOption.as_slider(
            "Re-scaled size (pixels): ",
            128,
            64,
            512,
            8,
            "The re-scaled value needs to be an even number",
        )

        self.joboptions["do_extract_helix"] = JobOption.as_boolean(
            "Extract helical segments?",
            False,
            "Set to Yes if you want to extract helical segments. RELION "
            "(.star), EMAN2 (.box) and XIMDISP (.coords) formats of tube or "
            "segment coordinates are supported.",
        )

        self.joboptions["helical_tube_outer_diameter"] = JobOption.as_slider(
            "Tube diameter (A): ",
            200,
            100,
            1000,
            10,
            "Outer diameter (in Angstroms) of helical tubes. This value should"
            " be slightly larger than the actual width of helical tubes.",
        )

        self.joboptions["helical_bimodal_angular_priors"] = JobOption.as_boolean(
            "Use bimodal angular priors?",
            True,
            "Normally it should be set to Yes and bimodal angular priors will be "
            "applied in the following classification and refinement jobs. Set to"
            " No if the 3D helix looks the same when rotated upside down.",
        )

        self.joboptions["do_extract_helical_tubes"] = JobOption.as_boolean(
            "Coordinates are start-end only?",
            True,
            "Set to Yes if you want to extract helical segments from manually"
            " picked tube coordinates (starting and end points of helical tubes"
            " in RELION, EMAN or XIMDISP format). Set to No if segment coordinates"
            " (RELION auto-picked results or EMAN / XIMDISP segments) are provided.",
        )

        self.joboptions["do_cut_into_segments"] = JobOption.as_boolean(
            "Cut helical tubes into segments?",
            True,
            "Set to Yes if you want to extract multiple helical segments with a"
            " fixed inter-box distance. If it is set to No, only one box at the"
            " center of each helical tube will be extracted.",
        )

        self.joboptions["helical_nr_asu"] = JobOption.as_slider(
            "Number of unique asymmetrical units:",
            1,
            1,
            100,
            1,
            "Number of unique helical asymmetrical units in each segment box. "
            "This integer should not be less than 1. The inter-box distance (pixels)"
            " = helical rise (Angstroms) * number of asymmetrical units / pixel size"
            " (Angstroms). The optimal inter-box distance might also depend on the box"
            " size, the helical rise"
            " and the flexibility of the structure. In "
            "general, an inter-box distance of ~10% * the box size seems appropriate.",
        )
        # put a more informative help message here
        self.joboptions["helical_rise"] = JobOption.as_slider(
            "Helical rise (A):",
            1,
            0,
            100,
            0.01,
            "Helical rise in Angstroms. (Please click '?' next to the"
            " option above for details about how the inter-box distance"
            " is calculated.)",
        )

        self.get_runtab_options(True, False)

    def initialise(self):
        # Initialisation already done in __init__. TODO: do we need this method too?
        pass

    def do_reextract_options(self, command):

        fndata_reextract = self.joboptions["fndata_reextract"].get_string(
            True, "ERROR: empty field for refined particles STAR file...",
        )

        do_reset_offsets = self.joboptions["do_reset_offsets"].get_boolean()
        do_recenter = self.joboptions["do_recenter"].get_boolean()
        if do_reset_offsets and do_recenter:
            raise_error(
                "ERROR: you cannot both reset refined offsets and recenter"
                " on refined coordinates, choose one..."
            )
        command += " --reextract_data_star " + fndata_reextract
        self.input_nodes.append(
            Node(fndata_reextract, self.joboptions["fndata_reextract"].nodetype)
        )
        if do_reset_offsets:
            command += " --reset_offsets"
        elif do_recenter:
            recenter_x = self.joboptions["recenter_x"].get_number()
            recenter_y = self.joboptions["recenter_y"].get_number()
            recenter_z = self.joboptions["recenter_z"].get_number()
            command += " --recenter"
            command += " --recenter_x " + truncate_number(recenter_x, 1)
            command += " --recenter_y " + truncate_number(recenter_y, 1)
            command += " --recenter_z " + truncate_number(recenter_z, 1)
        return command

    def do_regular_options(self, command):
        coords_suffix = self.joboptions["coords_suffix"]
        fn_coords_suffix = coords_suffix.get_string(
            True, "ERROR: empty field for coordinate STAR file...",
        )
        coord_dir = os.path.dirname(fn_coords_suffix) + "/"
        command += " --coord_dir " + coord_dir
        coord_suffix = os.path.basename(fn_coords_suffix).replace("coords_suffix", "")
        command += " --coord_suffix " + coord_suffix
        self.input_nodes.append(Node(fn_coords_suffix, coords_suffix.nodetype))
        return command

    def norm_scale_invert(self, command):
        do_rescale = self.joboptions["do_rescale"].get_boolean()
        do_norm = self.joboptions["do_norm"].get_boolean()
        do_invert = self.joboptions["do_invert"].get_boolean()
        extract_size = self.joboptions["extract_size"].get_number()

        bg_diameter = self.joboptions["bg_diameter"].get_number()
        if bg_diameter < 0:
            bg_diameter = 0.75 * extract_size
        bg_radius = int(bg_diameter / 2)

        if do_rescale:
            rescale = self.joboptions["rescale"].get_number()
            command += " --scale " + str(int(rescale))
            bg_radius = int((rescale * bg_radius) / extract_size)

        if do_norm:
            bg_radius = int(bg_radius)
            command += " --norm --bg_radius " + str(bg_radius)
            command += " --white_dust " + self.joboptions["white_dust"].get_string()
            command += " --black_dust " + self.joboptions["black_dust"].get_string()
        if do_invert:
            command += " --invert_contrast"
        return command

    def helical_options(self, command):
        command += " --helix"
        helical_tube_outer_diameter = self.joboptions[
            "helical_tube_outer_diameter"
        ].get_string()
        command += " --helical_outer_diameter " + helical_tube_outer_diameter

        if self.joboptions["helical_bimodal_angular_priors"].get_boolean():
            command += " --helical_bimodal_angular_priors"
        if self.joboptions["do_extract_helical_tubes"].get_boolean():
            command += " --helical_tubes"
            if self.joboptions["do_cut_into_segments"].get_boolean():
                command += " --helical_cut_into_segments"
                helical_nr_asu = self.joboptions["helical_nr_asu"].get_string()
                command += " --helical_nr_asu " + helical_nr_asu
                helical_rise = self.joboptions["helical_rise"].get_string()
                command += " --helical_rise " + helical_rise
            else:
                command += " --helical_nr_asu 1 --helical_rise 1"
        return command

    def get_commands(self, outputname, do_makedir, job_counter):

        outputname = self.initialise_pipeline(
            outputname, self.PROCESS_NAME, job_counter
        )

        nr_mpi = self.joboptions["nr_mpi"].get_number()
        if nr_mpi > 1:
            command = "`which relion_preprocess_mpi`"
        else:
            command = "`which relion_preprocess`"

        star_mics = self.joboptions["star_mics"].get_string()
        if len(star_mics) == 0:
            raise_error("Empty field for input STAR file")
        self.input_nodes.append(Node(star_mics, self.joboptions["star_mics"].nodetype))
        command += " --i " + star_mics

        do_reextract = self.joboptions["do_reextract"].get_boolean()

        if do_reextract:
            command = self.do_reextract_options(command)
        else:
            command = self.do_regular_options(command)

        fn_ostar = outputname + "particles.star"
        self.output_nodes.append(Node(fn_ostar, NODES["Part data"]))
        command += " --part_star " + fn_ostar
        command += " --part_dir " + outputname
        command += " --extract"
        extract_size = self.joboptions["extract_size"].get_number()
        command += " --extract_size " + str(int(extract_size))

        command = self.norm_scale_invert(command)

        do_extract_helix = self.joboptions["do_extract_helix"].get_boolean()
        if do_extract_helix:
            command = self.helical_options(command)

        if self.is_continue:
            command += " --only_do_unfinished"

        other_args = self.joboptions["other_args"].get_string()
        if len(other_args) > 0:
            command += " " + other_args

        commands = [command]

        do_extract_helical_tubes = self.joboptions[
            "do_extract_helical_tubes"
        ].get_boolean()
        if do_reextract or (do_extract_helix and do_extract_helical_tubes):
            fn_out = outputname + "coords_suffix_extract.star"
            com = "echo " + star_mics + " > " + fn_out
            commands.append(com)
            self.output_nodes.append(Node(fn_out, NODES["Mic coords"]))

        return self.prepare_final_command(outputname, commands, do_makedir)
