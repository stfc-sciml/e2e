import os
import sys

from .relion_job import RelionJob
from pipeliner.data_structure import Node, NODES
from pipeliner.plugins.get_plugins import validate_plugin
from pipeliner.api.api_utils import make_pretty_header
from pipeliner.utils import raise_error


class PlugInJob(RelionJob):
    def __init__(self, the_plugin):
        super(self.__class__, self).__init__()
        self.hidden_name = ".gui_plugin"
        self.plugin = the_plugin
        self.type = self.plugin.id

        self.PROCESS_NAME = self.plugin.process_name
        self.PROCESS_TYPE_NUM = 101

        # make sure the plug in's external exes exist
        validate_plugin(the_plugin)

    def initialise(self):
        pass

    def get_commands(self, outputname, do_makedir, job_counter):

        outputname = self.initialise_pipeline(
            outputname, self.PROCESS_NAME, job_counter
        )

        # determine if the job is a plugin being submitted to the queue
        self.is_plugin = True
        if self.joboptions.get("do_queue") == "Yes":
            self.plugin_use_queue = True

        # information about the plugin
        plugin_name = self.plugin.name
        plugin_process = self.plugin.process_name
        plugin_file = self.plugin.plugin_file
        plugin_exes = self.plugin.exe_list
        #         plugin_id = self.plugin.id
        plugin_version = self.plugin.version

        print(
            "\n"
            + make_pretty_header(
                "Pipeliner is executing a plugin for process type: " + plugin_process
            )
        )
        print("Plugin name:\n\t" + plugin_name + "  Vers " + str(plugin_version))
        print("Plugin file:\n\t" + plugin_file)

        print("The following external programs are required:")
        for extexe in plugin_exes:
            print("\t" + extexe)

        # Variables the plugin code will use:
        joboptions = {}
        print("Job options read:")

        # make the job options into a simple dict
        for jo in self.joboptions:
            joboptions[jo] = self.joboptions[jo].value
            print("\t" + jo + ": ", joboptions[jo])

        print("Output dir:\n\t" + outputname)

        # variables the plugin will return
        global commands
        global inputs
        global outputs
        commands = ""
        inputs = {}
        outputs = {}

        # execute the plugin's code
        plugin_code = self.plugin.python_code
        plugin_code = "global commands\nglobal inputs\nglobal outputs\n" + plugin_code
        try:
            exec(
                plugin_code,
                globals(),
                {
                    "plugin_exes": plugin_exes,
                    "joboptions": joboptions,
                    "output_dir": outputname,
                    "NODES": NODES,
                },
            )
        # if there is an error in the plugin code give a detailed error message
        except Exception:
            e_type, e_object, e_traceback = sys.exc_info()
            filename = e_traceback.tb_frame.f_code.co_filename
            raise RuntimeError(
                "\nERROR: Encountered an error executing the code in plugin "
                "file:\n {}\n The error was:\n {}: {}".format(
                    filename, e_type, e_object,
                )
            )

        # check the required variables have been filled
        if len(commands) > 0:
            if type(commands) is not list:
                raise_error(
                    "ERROR: The plugin {} failed to return the "
                    "command in list format.\nThe command returned was:"
                    "{}".format(self.plugin.process_name, commands)
                )
        else:
            raise_error(
                "ERROR: The plugin {} failed to return a "
                "command".format(self.plugin.process_name)
            )

        # make the input nodes
        if len(inputs) == 0:
            print(
                "WARNING: The plugin {} did not use any inputs".format(plugin_process)
            )
        else:
            for input_file in inputs:
                exts = self.plugin.inputs_types.get(inputs[input_file])
                if type(exts) is not list:
                    exts = [exts]

                if exts is None:
                    raise_error(
                        "ERROR: Input node: {} is specified as type: "
                        "{} in the plugin code,\nbut this node type is not in "
                        "the list of permitted outputs in the plugin header\n"
                        "Specified node types and allowed extensions are:\n{}".format(
                            input_file, inputs[input_file], self.plugin.inputs_types
                        )
                    )
                else:
                    inext = os.path.splitext(input_file)[1]
                if inext not in exts:
                    raise_error(
                        "ERROR: Input node: {} is specified as type: "
                        "{}(*{}) in the plugin code,\nbut the "
                        "the list of permitted outputs in the plugin header\n"
                        "Specified node types and allowed extensions are:\n{}".format(
                            input_file,
                            inputs[input_file],
                            exts,
                            self.plugin.inputs_types,
                        )
                    )
                self.input_nodes.append(Node(input_file, inputs[input_file]))

        # make the output nodes
        if len(outputs) == 0:
            print(
                "WARNING: The plugin {} did not produce any output nodes".format(
                    plugin_process
                )
            )
        else:
            dir_fixed_outputs = {}
            for output_file in outputs:
                # make sure the output nodes have the right directory
                if os.path.dirname(output_file) != outputname[:-1]:
                    fullname = os.path.join(outputname, output_file)
                    dir_fixed_outputs[fullname] = outputs[output_file]
                else:
                    dir_fixed_outputs[output_file] = outputs[output_file]

            for output_file in outputs:
                exts = self.plugin.outputs_types.get(outputs[output_file])
                if type(exts) is not list:
                    exts = [exts]

                if exts is None:
                    raise_error(
                        "ERROR: Output node: {} is specified as type: "
                        "{} in the plugin code,\nbut this node type is not in "
                        "the list of permitted outputs in the plugin header\n"
                        "Specified node types and allowed extensions are:\n{}".format(
                            output_file, outputs[output_file], self.plugin.outputs_types
                        )
                    )
                else:
                    inext = os.path.splitext(output_file)[1]
                if inext not in exts:
                    raise_error(
                        "ERROR: Output node: {} is specified as type: "
                        "{}(*{}) in the plugin code,\nbut the file has  "
                        "the list of permitted outputs in the plugin header\n"
                        "Specified node types and allowed extensions are:\n{}".format(
                            output_file,
                            outputs[output_file],
                            exts,
                            self.plugin.outputs_types,
                        )
                    )
                # also make sure the output nodes are in the output dir
                if os.path.dirname(output_file) != outputname[:-1]:
                    output_file_path = os.path.join(outputname, output_file)
                else:
                    output_file_path = output_file

                # make the output node
                self.output_nodes.append(Node(output_file_path, outputs[output_file]))

        return self.prepare_final_command(outputname, commands, do_makedir)
