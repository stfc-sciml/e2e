import json

from .relion_job import RelionJob
from ..data_structure import Node, NODES


class BuccaneerJob(RelionJob):
    PROCESS_NAME = "Buccaneer"
    PROCESS_TYPE_NUM = 100

    def __init__(self, args_file, input_map=None):
        super(self.__class__, self).__init__()
        self.type = self.PROCESS_TYPE_NUM
        self.args_file = args_file
        self.input_map = input_map

    def initialise(self):
        # Initialisation already done in __init__
        pass

    def write(self, fn=""):
        # Don't want to write a run.job file for jobs that can't be loaded by RELION GUI
        pass

    def get_commands(self, outputname, do_makedir, job_counter):

        outputname = self.initialise_pipeline(outputname, "Buccaneer", job_counter)

        commands = [
            "ccpem-buccaneer --no-gui --args "
            + self.args_file
            + " --job_location "
            + outputname
        ]

        if self.input_map is not None:
            with open(self.args_file, "r+") as f:
                json_str = f.read()
                args = json.loads(json_str)
                args["input_map"] = self.input_map
                f.seek(0)
                f.truncate()
                json.dump(args, f)

        self.input_nodes.append(Node(self.input_map, NODES["Finalmap"]))
        self.output_nodes.append(Node(outputname + "refined1.pdb", 101))

        return self.prepare_final_command(outputname, commands, do_makedir)
