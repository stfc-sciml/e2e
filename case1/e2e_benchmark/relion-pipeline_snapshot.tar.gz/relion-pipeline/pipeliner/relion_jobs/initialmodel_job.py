from .relion_job import RelionJob
from ..data_structure import NODES, INIMODEL_TYPE_NUM
from ..job_options import JobOption


class InimodelJob(RelionJob):
    PROCESS_NAME = "InitialModel"
    PROCESS_TYPE_NUM = INIMODEL_TYPE_NUM

    def __init__(self):
        super(self.__class__, self).__init__()
        # TODO: remove this and use class-level constant if possible
        self.type = INIMODEL_TYPE_NUM
        self.hidden_name = ".gui_inimodel"

        self.joboptions["fn_img"] = JobOption.as_inputnode(
            "Input images STAR file:",
            NODES["Part data"],
            "",
            "STAR files (*.star) \t Image stacks (not recommended, read help!)"
            " (*.{spi,mrcs})",
            "A STAR file with all images (and their metadata)."
            "In SGD, it is very important that there are particles"
            " from enough different orientations. One only needs a "
            "few thousand to 10k particles. When selecting good 2D classes"
            " in the Subset Selection jobtype, use the option to select a"
            " maximum number of particles from each class to generate more"
            " even angular distributions for SGD.\n \n Alternatively, you may"
            " give a Spider/MRC stack of 2D images, but in that case NO metadata"
            " can be included and thus NO CTF correction can be performed, nor"
            " will it be possible to perform noise spectra estimation or intensity"
            " scale corrections in image groups. Therefore, running RELION with "
            "an input stack will in general provide sub-optimal results and is "
            "therefore not recommended!! Use the Preprocessing procedure to get"
            " the input STAR file in a semi-automated manner. Read the RELION wiki"
            " for more information.",
        )

        self.joboptions["fn_cont"] = JobOption.as_inputnode(
            "Continue from here: ",
            "",
            "STAR Files (*_optimiser.star)",
            "CURRENT_ODIR",  # need to figure out how to set this correctly
            "Select the *_optimiser.star file for the iteration "
            "from which you want to continue a previous run. "
            "Note that the Output rootname of the continued run and the "
            "rootname of the previous run cannot be the same. "
            "If they are the same, the program will automatically add a '_ctX' "
            "to the output rootname, with X being the iteration from which"
            " one continues the previous run.",
            True,
        )

        self.joboptions["sgd_ini_iter"] = JobOption.as_slider(
            "Number of initial iterations:",
            50,
            10,
            300,
            10,
            "Number of initial SGD iterations, at which the initial"
            " resolution cutoff and the initial subset size will be used,"
            " and multiple references are kept the same. 50 seems to work"
            " well in many cases. Increase if the correct solution is not found.",
            True,
        )

        self.joboptions["sgd_inbetween_iter"] = JobOption.as_slider(
            "Number of in-between iterations:",
            200,
            50,
            500,
            50,
            "Number of SGD iterations between the initial and final ones. During"
            " these in-between iterations, the resolution is linearly increased,"
            "together with the mini-batch or subset size. In case of a multi-class"
            " refinement, the different references are also increasingly left "
            "to become dissimilar. 200 seems to work well in many cases. Increase "
            "if multiple references have trouble separating, or the correct solution"
            " is not found.",
            True,
        )

        self.joboptions["sgd_fin_iter"] = JobOption.as_slider(
            "Number of final iterations:",
            50,
            10,
            300,
            10,
            "Number of final SGD iterations, at which the final resolution cutoff"
            " and the final subset size will be used, and multiple references are"
            " left dissimilar. 50 seems to work well in many cases. Perhaps increase"
            " when multiple reference have trouble separating.",
            True,
        )

        self.joboptions["sgd_ini_resol"] = JobOption.as_slider(
            "Initial resolution (A):",
            35,
            10,
            60,
            5,
            "This is the resolution cutoff (in A) that will be applied"
            "during the initial SGD iterations. 35A seems to work well"
            " in many cases.",
            True,
        )

        self.joboptions["sgd_fin_resol"] = JobOption.as_slider(
            "Final resolution (A):",
            15,
            5,
            30,
            5,
            "This is the resolution cutoff (in A) that will be applied during "
            "the final SGD iterations. 15A seems to work well in many cases.",
            True,
        )

        self.joboptions["sgd_ini_subset_size"] = JobOption.as_slider(
            "Initial mini-batch size:",
            100,
            30,
            300,
            10,
            "The number of particles that will be processed during the initial"
            " iterations. 100 seems to work well in many cases. Lower values may"
            " result in wider searches of the energy landscape, but possibly at"
            " reduced resolutions.",
            True,
        )

        self.joboptions["sgd_fin_subset_size"] = JobOption.as_slider(
            "Final mini-batch size:",
            500,
            100,
            2000,
            100,
            "The number of particles that will be processed during the final"
            " iterations. 300-500 seems to work well in many cases. Higher values"
            " may result in increased resolutions, but at increased computational"
            " costs and possibly reduced searches of the energy landscape, but "
            "possibly at reduced resolutions.",
            True,
        )

        self.joboptions["sgd_write_iter"] = JobOption.as_slider(
            "Write-out frequency (iter):",
            10,
            1,
            50,
            1,
            "Every how many iterations do you want to write the model to disk?",
            True,
        )

        self.joboptions["sgd_sigma2fudge_halflife"] = JobOption.as_slider(
            "Increased noise variance half-life:",
            -1,
            -100,
            10000,
            100,
            "When set to a positive value, the initial estimates of the noise variance"
            " will internally be multiplied by 8, and then be gradually reduced,"
            " having 50% after this many particles have been processed. By default,"
            " this option is switched off by setting this value to a negative number."
            " In some difficult cases, switching this option on helps. In such "
            "cases, values around 1000 have been found to be useful. Change the "
            "factor of eight with the additional argument --sgd_sigma2fudge_ini",
        )

        self.joboptions["nr_classes"] = JobOption.as_slider(
            "Number of classes:",
            1,
            1,
            50,
            1,
            "The number of classes (K) for a multi-reference ab initio SGD refinement"
            ". These classes will be made in an unsupervised manner, starting from"
            " a single reference in the initial iterations of the SGD, and the "
            "references will become increasingly dissimilar during the"
            " inbetween iterations.",
        )

        self.joboptions["sym_name"] = JobOption.as_textbox(
            "Symmetry:",
            "C1",
            "SGD sometimes works better in C1. If you make an initial"
            " model in C1 but want to run Class3D/Refine3D with a higher point"
            " group symmetry, the reference model must be rotated to conform"
            " the symmetry convention. You can do this by the "
            "relion_align_symmetry command.",
        )

        self.joboptions["particle_diameter"] = JobOption.as_slider(
            "Mask diameter (A):",
            200,
            0,
            1000,
            10,
            "The experimental images will be masked with a soft "
            "circular mask with this diameter. Make sure this radius is not set"
            " too small because that may mask away part of the signal! "
            "If set to a value larger than the image size no masking will be"
            " performed.\n\n The same diameter will also be used for a spherical"
            "mask of the reference structures if no user-provided mask is specified.",
            True,
        )

        self.joboptions["do_solvent"] = JobOption.as_boolean(
            "Flatten and enforce non-negative solvent?",
            True,
            "If set to Yes, the job will apply a spherical mask and enforce all "
            "values in the reference to be non-negative.",
        )
        #  this option currently not used in relion source code
        #         self.joboptions["do_zero_mask"] = JobOption.as_boolean(
        #         "Mask individual particles with zeros?",
        #         True,
        #         "If set to Yes, then in the individual particles, the area"
        #         " outside a circle with the radius of the particle will be" "
        #         "set to zeros prior to taking the Fourier transform. This"
        #         " will remove noise and therefore increase sensitivity in"
        #         " the alignment and classification. However, it will also"
        #         " introduce correlations between the Fourier components that"
        #         " are not modelled. When set to No, then the solvent area "
        #         "is filled with random noise, which prevents introducing "
        #         "correlations. High-resolution refinements (e.g. ribosomes "
        #         "or other large complexes in 3D auto-refine) tend to work "
        #         "better when filling the solvent area with random noise "
        #         "(i.e. setting this option to No), refinements of smaller "
        #         "complexes and most classifications go better when using zeros "
        #         "(i.e. setting this option to Yes).",
        #         )

        self.joboptions["do_ctf_correction"] = JobOption.as_boolean(
            "Do CTF-correction?",
            True,
            "If set to Yes, CTFs will be corrected inside the MAP refinement. "
            "The resulting algorithm intrinsically implements the optimal linear,"
            " or Wiener filter. Note that CTF parameters for all images need to be"
            " given in the input STAR file. The command 'relion_refine"
            " --print_metadata_labels' will print a list of all possible metadata "
            "labels for that STAR file. See the RELION Wiki for more details.\n\n "
            "Also make sure that the correct pixel size (in Angstrom)"
            " is given above!)",
        )

        self.joboptions["ctf_intact_first_peak"] = JobOption.as_boolean(
            "Ignore CTFs until first peak?",
            False,
            "If set to Yes, then CTF-amplitude correction will only be performed from"
            " the first peak of each CTF onward. This can be useful if the CTF model "
            "is inadequate at the lowest resolution. Still, in general using higher"
            " amplitude contrast on the CTFs (e.g. 10-20%) often yields better"
            " results. Therefore, this option is not generally recommended: "
            "try increasing amplitude contrast (in your input STAR file) first!",
        )

        self.joboptions["sampling"] = JobOption.as_radio(
            "Initial angular sampling:",
            "SAMPLING",
            1,
            "There are only a few discrete angular samplings possible because we"
            " use the HealPix library to generate the sampling of the first two"
            " Euler angles on the sphere. The samplings are approximate numbers"
            " and vary slightly over the sphere.\n\n For initial model generation"
            " at low resolutions, coarser angular samplings can often be used than"
            " in normal 3D classifications/refinements, e.g. 15 degrees. During the"
            " inbetween and final SGD iterations, the sampling will be adjusted to "
            "the resolution, given the particle size.",
            True,
        )

        self.joboptions["offset_range"] = JobOption.as_slider(
            "Offset search range (pix):",
            6,
            0,
            30,
            1,
            "Probabilities will be calculated only for translations in a circle with"
            " this radius (in pixels). The center of this circle changes at every "
            "iteration and is placed at the optimal translation for each image in "
            "the previous iteration.",
            True,
        )

        self.joboptions["offset_step"] = JobOption.as_slider(
            "Offset search step (pix):",
            2,
            0.1,
            5,
            0.1,
            "Translations will be sampled with this step-size (in pixels). "
            "Translational sampling is also done using the adaptive approach. "
            "Therefore, if adaptive=1, the translations will first be evaluated"
            " on a 2x coarser grid.",
            True,
        )

        self.get_comp_options()
        self.get_runtab_options()

    def initialise(self):
        pass

    def get_commands(self, outputname, do_makedir, job_counter):

        outputname = self.initialise_pipeline(
            outputname, self.PROCESS_NAME, job_counter
        )

        if self.joboptions["nr_mpi"].get_number() > 1:
            command = "`which relion_refine_mpi`"
        else:
            command = "`which relion_refine`"

        if not self.is_continue:
            command += " --sgd --denovo_3dref"

        command += self.refinement_IO(outputname, 3, 1, self.is_continue)

        sgd_ini_iter = self.joboptions["sgd_ini_iter"].get_string()
        command += " --sgd_ini_iter " + sgd_ini_iter
        sgd_inbetween_iter = self.joboptions["sgd_inbetween_iter"].get_string()
        command += " --sgd_inbetween_iter " + sgd_inbetween_iter
        sgd_fin_iter = self.joboptions["sgd_fin_iter"].get_string()
        command += " --sgd_fin_iter " + sgd_fin_iter
        sgd_write_iter = self.joboptions["sgd_write_iter"].get_string()
        command += " --sgd_write_iter " + sgd_write_iter
        sgd_ini_resol = self.joboptions["sgd_ini_resol"].get_string()
        command += " --sgd_ini_resol " + sgd_ini_resol
        sgd_fin_resol = self.joboptions["sgd_fin_resol"].get_string()
        command += " --sgd_fin_resol " + sgd_fin_resol
        sgd_ini_subset_size = self.joboptions["sgd_ini_subset_size"].get_string()
        command += " --sgd_ini_subset " + sgd_ini_subset_size
        sgd_fin_subset_size = self.joboptions["sgd_fin_subset_size"].get_string()
        command += " --sgd_fin_subset " + sgd_fin_subset_size

        ## ctf
        if self.joboptions["do_ctf_correction"].get_boolean():
            command += " --ctf"
            if self.joboptions["ctf_intact_first_peak"].get_boolean():
                command += " --ctf_intact_first_peak"

        command += " --K " + self.joboptions["nr_classes"].get_string()
        command += " --sym " + self.joboptions["sym_name"].get_string()

        if self.joboptions["do_solvent"].get_boolean():
            command += " --flatten_solvent"
        # zero mask is currently not optional
        command += " --zero_mask"

        ## compute options
        command += self.add_comp_options()

        ## compute options
        particle_diameter = self.joboptions["particle_diameter"].get_string()
        command += " --particle_diameter " + particle_diameter

        ## sampling
        iover = 1
        command += " --oversampling " + str(iover)
        sampling_opts = JobOption.SAMPLING
        sampling_opt = self.joboptions["sampling"].get_string()
        sampling = sampling_opts.index(sampling_opt) + 1
        # The sampling given in the GUI will be the oversampled one!
        command += " --healpix_order " + str(sampling - iover)

        ## Offset range
        offset_range = self.joboptions["offset_range"].get_string()
        command += " --offset_range " + offset_range

        ## The sampling given in the GUI will be the oversampled one!
        offset_step = self.joboptions["offset_step"].get_number() * (2 ** iover)
        command += " --offset_step " + str(offset_step)

        ## Running stuff
        command += " --j " + self.joboptions["nr_threads"].get_string()

        ## GPU-stuff
        if self.joboptions["use_gpu"].get_boolean():
            gpu_ids = self.joboptions["gpu_ids"].get_string()
            command += ' --gpu "' + gpu_ids + '"'

        ## Other arguments
        other_arguments = self.joboptions["other_args"].get_string()
        if len(other_arguments) > 0:
            command += " " + other_arguments

        commands = [command]
        return self.prepare_final_command(outputname, commands, do_makedir)
