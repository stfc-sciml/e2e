from .relion_job import RelionJob
from ..data_structure import Node, NODES, MULTIBODY_TYPE_NUM
from ..job_options import JobOption
from ..utils import truncate_number, raise_error
from ..jobstar_reader import BodyFile
from glob import glob


class MultibodyJob(RelionJob):
    PROCESS_NAME = "MultiBody"
    PROCESS_TYPE_NUM = MULTIBODY_TYPE_NUM

    def __init__(self):
        super(self.__class__, self).__init__()
        self.type = MULTIBODY_TYPE_NUM
        self.hidden_name = ".gui_multibody"

        # none of these inputs are treated like an input node, should they be?
        self.joboptions["fn_in"] = JobOption.as_inputnode(
            "Consensus refinement optimiser.star: ",
            NODES["Optimiser"],
            "",
            "STAR Files (*_optimiser.star)",
            "Select the *_optimiser.star file for the iteration of the consensus"
            " refinement from which you want to start multi-body refinement.",
        )

        self.joboptions["fn_cont"] = JobOption.as_fn(
            "Continue from here: ",
            "",
            "STAR Files (*_optimiser.star)",
            "CURRENT_ODIR",
            "Select the *_optimiser.star file for the iteration from which you want to"
            " continue this multi-body refinement. Note that the Output rootname of"
            " the continued run and the rootname of the previous run cannot be the "
            "same. If they are the same, the program will automatically add a '_ctX'"
            "to the output rootname, with X being the iteration from which one "
            "continues the previous run.",
            True,
        )

        self.joboptions["fn_bodies"] = JobOption.as_fn(
            "Body STAR file: ",
            "",
            "STAR Files (*.{star})",
            ".",
            "Provide the STAR file with all information about the bodies to be"
            " used in multi-body refinement. An example for a three-body refinement"
            " would look like this: \n\n"
            "data_\n"
            "loop_\n"
            "_rlnBodyMaskName\n"
            "_rlnBodyRotateRelativeTo\n"
            "_rlnBodySigmaAngles\n"
            "_rlnBodySigmaOffset\n"
            "large_body_mask.mrc 2 10 2\n"
            "small_body_mask.mrc 1 10 2\n"
            "head_body_mask.mrc 2 10 2\n"
            "\n Where each data line represents a different body, and: \n"
            "- rlnBodyMaskName contains the name of a soft-edged mask with values in"
            " [0,1] that define the body; \n - rlnBodyRotateRelativeTo defines "
            "relative to which other body this body rotates (first body is number"
            " 1); \n- rlnBodySigmaAngles and _rlnBodySigmaOffset are the standard"
            " deviations (widths) of Gaussian priors on the consensus rotations and"
            " translations; \n\n Optionally, there can be a fifth column with "
            "_rlnBodyReferenceName. Entries can be 'None' (without the ''s) or the "
            "name of a MRC map with an initial reference for that body. In case the"
            " entry is None, the reference will be taken from the density in the "
            "consensus refinement.\n\n Also note that larger bodies should be above"
            " smaller bodies in the STAR file. For more information, see the "
            "multi-body paper.",
        )

        self.joboptions["do_subtracted_bodies"] = JobOption.as_boolean(
            "Reconstruct subtracted bodies?",
            True,
            "If set to Yes, then the reconstruction of each of the bodies will"
            "use the subtracted images. This may give useful insights about how"
            " well the subtraction worked. If set to No, the original particles"
            " are used for reconstruction (while the subtracted ones are still"
            " used for alignment). This will result in fuzzy densities for bodies"
            " outside the one used for refinement.",
        )

        self.joboptions["sampling"] = JobOption.as_radio(
            "Initial angular sampling:",
            "SAMPLING",
            4,
            "There are only a few discrete angular samplings possible because"
            " we use the HealPix library to generate the sampling of the first"
            " two Euler angles on the sphere. The samplings are approximate numbers"
            " and vary slightly over the sphere.\n\n Note that this will only be"
            " the value for the first few iteration(s): the sampling rate will be"
            " increased automatically after that.",
        )

        self.joboptions["offset_range"] = JobOption.as_slider(
            "Initial offset range (pix):",
            3,
            0,
            30,
            1,
            "Probabilities will be calculated only for translations in a circle with"
            " this radius (in pixels). The center of this circle changes at every"
            "iteration and is placed at the optimal translation for each image in "
            "the previous iteration.\n\n Note that this will only be the value for"
            " the first few iteration(s): the sampling rate will be increased"
            " automatically after that.",
        )

        self.joboptions["offset_step"] = JobOption.as_slider(
            "Initial offset step (pix):",
            0.75,
            0.1,
            5,
            0.1,
            "Translations will be sampled with this step-size (in pixels)."
            " Translational sampling is also done using the adaptive approach."
            " Therefore, if adaptive=1, the translations will first be evaluated"
            " on a 2x coarser grid.\n\n Note that this will only be the value for"
            " the first few iteration(s): the sampling rate will be increased"
            " automatically after that.",
        )

        self.joboptions["do_analyse"] = JobOption.as_boolean(
            "Run flexibility analysis?",
            True,
            "If set to Yes, after the multi-body refinement has completed,"
            " a PCA analysis will be run on the orientations all all bodies"
            " in the data set. This can be set to No initially, and then the"
            " job can be continued afterwards to only perform this analysis.",
            True,
        )

        self.joboptions["nr_movies"] = JobOption.as_slider(
            "Number of eigenvector movies:",
            3,
            0,
            16,
            1,
            "Series of ten output maps will be generated along this many "
            "eigenvectors. These maps can be opened as a 'Volume Series'"
            " in UCSF Chimera, and then displayed as a movie. They represent"
            " the principal motions in the particles.",
            True,
        )

        self.joboptions["do_select"] = JobOption.as_boolean(
            "Select particles based on eigenvalues?",
            False,
            "If set to Yes, a particles.star file is written out with all particles"
            " that have the below indicated eigenvalue in the selected range.",
            True,
        )

        self.joboptions["select_eigenval"] = JobOption.as_slider(
            "Select on eigenvalue:",
            1,
            1,
            20,
            1,
            "This is the number of the eigenvalue to be used in the particle subset"
            " selection (start counting at 1).",
            True,
        )

        self.joboptions["eigenval_min"] = JobOption.as_slider(
            "Minimum eigenvalue:",
            -999.0,
            -50,
            50,
            1,
            "This is the minimum value for the selected eigenvalue; only particles"
            "with the selected eigenvalue larger than this value will be included"
            " in the output particles.star file",
            True,
        )

        self.joboptions["eigenval_max"] = JobOption.as_slider(
            "Maximum eigenvalue:",
            999.0,
            -50,
            50,
            1,
            "This is the maximum value for the selected eigenvalue; only particles "
            "with the selected eigenvalue less than this value will be included in "
            "the output particles.star file",
            True,
        )

        self.get_comp_options()
        self.get_runtab_options()

    def initialise(self):
        pass

    def get_commands(self, outputname, do_makedir, job_counter):
        def multibody(self, fn_cont, fn_bodies, fn_run, outputname, do_analyse):
            if self.joboptions["nr_mpi"].get_number() > 1:
                command = "`which relion_refine_mpi`"
            else:
                command = "`which relion_refine`"
            bodyfile = BodyFile(fn_bodies)
            nr_bodies = bodyfile.count_bodies()

            if self.is_continue:
                pos_it = int(fn_cont.partition("it")[2].partition("_")[0])
                if pos_it < 0 or "_optimiser" not in fn_cont:
                    raise_error(
                        "Warning: invalid optimiser.star filename provided for "
                        "continuation run!",
                    )

                it = int("fn_cont".partition("it")[1].partition("_")[0])
                fn_run = "run_ct" + str(it)
                command += " --continue " + fn_cont
                command += " --o " + outputname + fn_run
                self.create_refine_nodes(outputname + fn_run, -1, 1, 3, nr_bodies)
            else:
                fn_run = "run"
                fn_in = self.joboptions["fn_in"].get_string()
                command += " --continue " + fn_in
                command += " --o " + outputname + fn_run
                self.create_refine_nodes(outputname + fn_run, -1, 1, 3, nr_bodies)
                command += " --solvent_correct_fsc --multibody_masks " + fn_bodies

                self.input_nodes.append(Node(fn_in, self.joboptions["fn_in"].nodetype))

                iover = 1
                command += " --oversampling " + str(iover)
                sampling_opts = JobOption.SAMPLING
                sampling_opt = self.joboptions["sampling"].get_string()
                sampling = sampling_opts.index(sampling_opt) + 1
                command += " --healpix_order " + str(sampling - iover)
                # always perform local searches!
                command += " --auto_local_healpix_order " + str(sampling - iover)
                offset_range = self.joboptions["offset_range"].get_string()
                command += " --offset_range " + offset_range
                offset_step = self.joboptions["offset_step"].get_number()
                offset_step = offset_step * (2 ** iover)
                command += " --offset_step " + truncate_number(offset_step, 2)

                if self.joboptions["do_subtracted_bodies"].get_boolean():
                    command += " --reconstruct_subtracted_bodies"

                ## Running stuff
                command += " --j " + self.joboptions["nr_threads"].get_string()

                ## GPU-stuff
                if self.joboptions["use_gpu"].get_boolean():
                    ngpus = self.joboptions["gpu_ids"].get_string()
                    command += ' --gpu "' + ngpus + '"'

                command += self.add_comp_options()
                ## Other arguments
                other_args = self.joboptions["other_args"].get_string()
                if len(other_args) > 0:
                    command += " " + other_args
                if do_analyse:
                    return (command, fn_run)
                else:
                    return (command, "")

        def flex_analysis(self, fn_bodies, fn_run, outputname):
            command = "`which relion_flex_analyse`"
            # if the refinement wasn't done before we need to find a model.star
            #  file which does not have a _it specifier
            fn_wildcard = outputname + "run*_model.star"
            modelfiles = glob(fn_wildcard)
            if fn_run == "":
                for i in modelfiles:
                    if "it_" not in i:
                        modelfiles.append(i)
                if len(modelfiles) == 0:
                    raise_error(
                        "ERROR: cannot find appropriate model.star file in the output"
                        " directory"
                    )
                elif len(modelfiles) > 1:
                    raise_error(
                        "ERROR: there are more than one model.star files (without '_it'"
                        " specifiers) in the output directory. Move all but one out of"
                        " the way."
                    )
                fn_run = modelfiles[0].replace("_model.star", "")
            else:
                fn_run = outputname + fn_run

            command += " --PCA_orient"
            command += " --model " + fn_run + "_model.star"
            command += " --data " + fn_run + "_data.star"
            command += " --bodies " + fn_bodies
            command += " --o " + outputname + "analyse"

            if self.joboptions["nr_movies"].get_number() > 0:
                command += " --do_maps"
                command += " --k " + self.joboptions["nr_movies"].get_string()

            if self.joboptions["do_select"].get_boolean():
                minval = self.joboptions["eigenval_min"].get_number()
                maxval = self.joboptions["eigenval_max"].get_number()

                if minval >= maxval:
                    raise_error(
                        "ERROR: the maximum eigenvalue should be "
                        "larger than the minimum one!"
                    )
                select_eigenval = self.joboptions["select_eigenval"].get_string()
                command += " --select_eigenvalue " + select_eigenval
                eigenval_min = self.joboptions["eigenval_min"].get_number()
                command += " --select_eigenvalue_min " + str(eigenval_min)
                eigenval_max = self.joboptions["eigenval_max"].get_number()
                command += " --select_eigenvalue_max " + str(eigenval_max)
                ## Add output node: selected particles star file
                fnt = outputname + "analyse_eval" + select_eigenval + "_select"
                # added a catch if min/and or max are between 1 and -1
                if 1 > eigenval_min > -1:
                    evmin = str(round(eigenval_min, 2)).replace(".", "p")
                else:
                    evmin = int(round(eigenval_min, 0))

                if 1 > eigenval_max > -1:
                    evmax = str(round(eigenval_max, 2)).replace(".", "p")
                else:
                    evmax = int(round(eigenval_max, 0))
                # should it throw an error if the values are outside of this range?
                if evmin == evmax:
                    evmin = str(round(eigenval_min, 2)).replace(".", "p")
                    evmax = str(round(eigenval_max, 2)).replace(".", "p")

                if eigenval_min > -99998:
                    fnt += "_min" + str(evmin)
                else:
                    raise_error(
                        "ERROR: Eigenval minimum of {} outside of acceptable range\n"
                        "Smallest allowed is -99998".format(eigenval_min)
                    )
                if eigenval_max < 99998:
                    fnt += "_max" + str(evmax)
                else:
                    raise_error(
                        "ERROR: Eigenval maximum of {} outside of acceptable range\n"
                        "Largest allowed is 99998".format(eigenval_max)
                    )
                fnt += ".star"

                self.output_nodes.append(Node(fnt, NODES["Part data"]))
            self.output_nodes.append(
                Node(outputname + "analyse_logfile.pdf", NODES["PdfLogfile"])
            )

            return command

        outputname = self.initialise_pipeline(
            outputname, self.PROCESS_NAME, job_counter
        )

        fn_bodies = self.joboptions["fn_bodies"].get_string(
            True, "ERROR: you have to specify an existing body STAR file."
        )
        fn_cont = self.joboptions["fn_cont"].get_string()
        do_analyse = self.joboptions["do_analyse"].get_boolean()
        fn_run = ""
        command = ""
        if self.is_continue and len(fn_cont) < 1 and not do_analyse:
            return ValueError("ERROR: you have to specify an existing body STAR file.")

        if not self.is_continue or self.is_continue and len(fn_cont) > 0:
            com, fn_run = multibody(
                self, fn_cont, fn_bodies, fn_run, outputname, do_analyse
            )
            command += com
            commands = [command]
        if do_analyse:
            command2 = flex_analysis(self, fn_bodies, fn_run, outputname)
            commands.append(command2)
        return self.prepare_final_command(outputname, commands, do_makedir)
