import os

from .relion_job import RelionJob
from ..data_structure import Node, NODES, POSTPROCESS_TYPE_NUM
from ..job_options import JobOption
from pipeliner.utils import raise_error


class PostprocessJob(RelionJob):
    # TODO: need to think how to define constants a bit more - consider overriding,
    #  polymorphism etc
    PROCESS_NAME = "PostProcess"
    PROCESS_TYPE_NUM = POSTPROCESS_TYPE_NUM

    def __init__(self):
        super(self.__class__, self).__init__()
        # TODO: remove this and use class-level constant if possible
        self.type = POSTPROCESS_TYPE_NUM
        self.hidden_name = ".gui_post"
        self.joboptions["fn_in"] = JobOption.as_inputnode(
            "One of the 2 unfiltered half-maps:",
            NODES["Halfmap"],
            "",
            "MRC map files (*half1_*_unfil.mrc)",
            "",
        )
        self.joboptions["fn_mask"] = JobOption.as_inputnode(
            "Solvent mask:", NODES["Mask"], "", "Image Files (*.{spi,vol,msk,mrc})", ""
        )
        self.joboptions["angpix"] = JobOption.as_slider(
            "Calibrated pixel size (A)",
            1,
            0.3,
            5,
            0.1,
            "Provide the final, calibrated pixel size in Angstroms. This value may"
            " be different from the pixel-size used thus far, e.g. when "
            "you have recalibrated the pixel size using the fit to a PDB model. "
            "The X-axis of the output FSC plot will use this calibrated value.",
            True,
        )
        self.joboptions["do_auto_bfac"] = JobOption.as_boolean(
            "Estimate B-factor automatically?",
            True,
            "If set to Yes, then the program will use the automated "
            "procedure described by Rosenthal and Henderson (2003, JMB) "
            "to estimate an overall B-factor for your map, and sharpen"
            " it accordingly. Note that your map must extend well beyond "
            "the lowest resolution included in the procedure below, which"
            " should not be set to resolutions much lower than 10 Angstroms.",
            True,
        )
        self.joboptions["autob_lowres"] = JobOption.as_slider(
            "Lowest resolution for auto-B fit (A):",
            10,
            8,
            15,
            0.5,
            "This is the lowest frequency (in Angstroms) that will"
            " be included in the linear fit of the Guinier plot as "
            "described in Rosenthal and Henderson (2003, JMB). Dont use values"
            " much lower or higher than 10 Angstroms. If your map does not "
            "extend beyond 10 Angstroms, then instead of the automated procedure"
            " use your own B-factor.",
            True,
        )
        # user is allowed option to select to conflicting options here could simplify
        self.joboptions["do_adhoc_bfac"] = JobOption.as_boolean(
            "Use your own B-factor?",
            False,
            "Instead of using the automated B-factor estimation, provide"
            " your own value. Use negative values for sharpening the map."
            "This option is useful if your map does not extend beyond the "
            "10A needed for the automated procedure, or when the automated "
            "procedure does not give a suitable value (e.g. in more disordered"
            " parts of the map).",
            True,
        )
        self.joboptions["adhoc_bfac"] = JobOption.as_slider(
            "User-provided B-factor:",
            -1000,
            -2000,
            0,
            -50,
            "Use negative values for sharpening. Be careful: if you"
            " over-sharpen your map, you may end up interpreting noise"
            " for signal!",
            True,
        )

        # MTF file has no input node type  - can't be included in structure
        self.joboptions["fn_mtf"] = JobOption.as_fn(
            "MTF of the detector (STAR file)",
            "",
            "STAR Files (*.star)",
            ".",
            "If you know the MTF of your detector, provide it here."
            " Curves for some well-known detectors may be downloaded "
            "from the RELION Wiki. Also see there for the exact format"
            "If you do not know the MTF of your detector and do not want"
            " to measure it, then by leaving this entry empty, you include"
            " the MTF of your detector in your overall estimated B-factor"
            " upon sharpening the map. Although that is probably slightly "
            "less accurate, the overall quality of your map will probably"
            " not suffer very much.",
            True,
        )
        self.joboptions["mtf_angpix"] = JobOption.as_slider(
            "Original detector pixel size:",
            1.0,
            0.3,
            2.0,
            0.1,
            "This is the original pixel size (in Angstroms) in "
            "the raw (non-super-resolution!) micrographs.",
            True,
        )
        self.joboptions["do_skip_fsc_weighting"] = JobOption.as_boolean(
            "Skip FSC-weighting?",
            False,
            "If set to No (the default), then the output map will be"
            " low-pass filtered according to the mask-corrected, "
            "gold-standard FSC-curve. Sometimes, it is also useful"
            " to provide an ad-hoc low-pass filter (option below), "
            "as due to local resolution variations some parts of the "
            "map may be better and other parts may be worse than the overall"
            " resolution as measured by the FSC. In such cases, set "
            "this option to Yes and provide an ad-hoc filter "
            "as described below.",
            True,
        )
        self.joboptions["low_pass"] = JobOption.as_slider(
            "Ad-hoc low-pass filter (A):",
            5,
            1,
            40,
            1,
            "This option allows one to low-pass filter the map"
            " at a user-provided frequency (in Angstroms). When using"
            " a resolution that is higher than the gold-standard "
            "FSC-reported resolution, take care not to interpret noise"
            " in the map for signal...",
            True,
        )

        self.get_runtab_options(False, False)

    def initialise(self):
        # Initialisation already done in __init__. TODO: do we need this method too?
        pass

    def get_commands(self, outputname, do_makedir, job_counter):

        outputname = self.initialise_pipeline(
            outputname, self.PROCESS_NAME, job_counter
        )

        command = ""
        mask = self.joboptions["fn_mask"].get_string(
            True, "ERROR: Empty field for input mask"
        )

        command += "--mask " + mask
        self.input_nodes.append(Node(mask, self.joboptions["fn_mask"].nodetype))

        fn_half1 = self.joboptions["fn_in"].get_string(
            True, "Empty field for input half-map"
        )
        if "half1" not in os.path.basename(fn_half1):
            raise_error("Cannot find 'half' substring in the input filename")

        self.input_nodes.append(Node(fn_half1, self.joboptions["fn_in"].nodetype))
        command += " --i " + fn_half1

        output_prefix = outputname + "postprocess"
        command += " --o " + output_prefix

        angpix = self.joboptions["angpix"].get_string()
        command += " --angpix " + angpix

        do_auto_bfac = self.joboptions["do_auto_bfac"].get_boolean()
        do_adhoc_bfac = self.joboptions["do_adhoc_bfac"].get_boolean()
        if do_auto_bfac and do_adhoc_bfac:
            raise_error("Select either auto or ad hoc not both")
        if not do_auto_bfac and not do_adhoc_bfac:
            raise_error("Must select one either auto or ad hoc bfactor")
        if do_auto_bfac:
            autob_lowres = self.joboptions["autob_lowres"].get_string()
            command += " --auto_bfac --autob_lowres " + autob_lowres

        elif do_adhoc_bfac:
            adhoc_bfac = self.joboptions["adhoc_bfac"].get_string()
            command += " --adhoc_bfac " + adhoc_bfac

        fn_mtf = self.joboptions["fn_mtf"].get_string()
        mtf_angpix = self.joboptions["mtf_angpix"].get_string()
        if len(fn_mtf) != 0:
            command += " --mtf " + fn_mtf + " --mtf_angpix " + mtf_angpix

        do_skip_fsc_weighting = self.joboptions["do_skip_fsc_weighting"].get_boolean()
        low_pass = self.joboptions["low_pass"].get_string()
        if do_skip_fsc_weighting:
            command += " --skip_fsc_weighting --low_pass " + low_pass

        commands = ["`which relion_postprocess` {}".format(command)]

        self.output_nodes.append(Node(output_prefix + ".mrc", NODES["Finalmap"]))
        self.output_nodes.append(Node(output_prefix + "_masked.mrc", NODES["Finalmap"]))
        self.output_nodes.append(Node(output_prefix + ".star", NODES["Post"]))
        self.output_nodes.append(Node(outputname + "logfile.pdf", NODES["PdfLogfile"]))
        return self.prepare_final_command(outputname, commands, do_makedir)
