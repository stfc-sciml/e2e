import os

from .relion_job import RelionJob
from ..data_structure import Node, NODES, IMPORT_TYPE_NUM
from ..job_options import JobOption
from pipeliner.utils import raise_error


class ImportJob(RelionJob):
    # TODO: need to think how to define constants a bit more - consider overriding,
    #  polymorphism etc
    PROCESS_NAME = "Import"
    PROCESS_TYPE_NUM = IMPORT_TYPE_NUM

    NODE_TYPES = [
        "Particle coordinates (*.box, *_pick.star)",
        "Particles STAR file (.star)",
        "Movie-particles STAR file (.star)",
        "2D references (.star or .mrcs)",
        "Micrographs STAR file (.star)",
        "3D reference (.mrc)",
        "3D mask (.mrc)",
        "Unfiltered half-map (unfil.mrc)",
    ]

    def __init__(self):
        super(self.__class__, self).__init__()
        # TODO: remove this and use class-level constant if possible
        self.type = IMPORT_TYPE_NUM
        self.hidden_name = ".gui_import"
        self.joboptions["do_raw"] = JobOption.as_boolean(
            "Import raw movies/micrographs?",
            True,
            "Set this to Yes if you plan to import raw movies or micrographs",
        )
        self.joboptions["fn_in_raw"] = JobOption.as_fn(
            "Raw input files:",
            "Micrographs/*.tif",
            "Movie or Image (*.{mrc,mrcs,tif,tiff})",
            ".",
            "Provide a Linux wildcard that selects all raw movies or micrographs to be "
            "imported.",
            True,
        )
        self.joboptions["is_multiframe"] = JobOption.as_boolean(
            "Are these multi-frame movies?",
            True,
            "Set to Yes for multi-frame movies, set to No for single-frame "
            "micrographs.",
            True,
        )
        self.joboptions["optics_group_name"] = JobOption.as_textbox(
            "Optics group name:",
            "opticsGroup1",
            "Name of this optics group. Each group of movies/micrographs with "
            "different optics characteristics for CTF refinement should have a unique "
            "name.",
            True,
        )
        self.joboptions["fn_mtf"] = JobOption.as_fn(
            "MTF of the detector:",
            "",
            "STAR Files (*.star)",
            ".",
            "As of release-3.1, the MTF of the detector is used in the refinement "
            "stages of refinement. If you know the MTF of your detector, provide it "
            "here. Curves for some well-known detectors may be downloaded from the "
            "RELION Wiki. Also see there for the exact format \n If you do not know "
            "the MTF of your detector and do not want to measure it, then by leaving "
            "this entry empty, you include the MTF of your detector in your overall "
            "estimated B-factor upon sharpening the map. Although that is probably "
            "slightly less accurate, the overall quality of your map will probably not "
            "suffer very much. \n \n Note that when combining data from different "
            "detectors, the differences between their MTFs can no longer be absorbed "
            "in a single B-factor, and providing the MTF here is important!",
            True,
        )
        self.joboptions["angpix"] = JobOption.as_slider(
            "Pixel size (Angstrom):",
            1.4,
            0.5,
            3,
            0.1,
            "Pixel size in Angstroms. ",
            True,
        )
        self.joboptions["kV"] = JobOption.as_slider(
            "Voltage (kV):",
            300,
            50,
            500,
            10,
            "Voltage the microscope was operated on (in kV)",
            True,
        )
        self.joboptions["Cs"] = JobOption.as_slider(
            "Spherical aberration (mm):",
            2.7,
            0,
            8,
            0.1,
            "Spherical aberration of the microscope used to collect these images "
            "(in mm). Typical values are 2.7 (FEI Titan & Talos, most JEOL CRYO-ARM), "
            "2.0 (FEI Polara), 1.4 (some JEOL CRYO-ARM) and 0.01 (microscopes with a "
            "Cs corrector).",
            True,
        )
        self.joboptions["Q0"] = JobOption.as_slider(
            "Amplitude contrast:",
            0.1,
            0,
            0.3,
            0.01,
            "Fraction of amplitude contrast. Often values around 10% work better than "
            "theoretically more accurate lower values...",
            True,
        )
        self.joboptions["beamtilt_x"] = JobOption.as_slider(
            "Beamtilt in X (mrad):",
            0.0,
            -1.0,
            1.0,
            0.1,
            "Known beamtilt in the X-direction (in mrad). Set to zero if unknown.",
            True,
        )
        self.joboptions["beamtilt_y"] = JobOption.as_slider(
            "Beamtilt in Y (mrad):",
            0.0,
            -1.0,
            1.0,
            0.1,
            "Known beamtilt in the Y-direction (in mrad). Set to zero if unknown.",
            True,
        )
        self.joboptions["do_other"] = JobOption.as_boolean(
            "Import other node types?",
            False,
            "Set this to Yes  if you plan to import anything else than movies or "
            "micrographs",
        )
        self.joboptions["fn_in_other"] = JobOption.as_fn(
            "Input file:",
            "ref.mrc",
            "Input file (*.*)",
            ".",
            "Select any file(s) to import. \n \n Note that for importing coordinate "
            "files, one has to give a Linux wildcard, where the *-symbol is before the "
            "coordinate-file suffix, e.g. if the micrographs are called mic1.mrc and "
            "the coordinate files mic1.box or mic1_autopick.star, one HAS to give "
            "'*.box' or '*_autopick.star', respectively.\n \n Also note that "
            "micrographs, movies and coordinate files all need to be in the same "
            "directory (with the same rootnames, e.g.mic1 in the example above) in "
            "order to be imported correctly. 3D masks or references can be imported "
            "from anywhere. \n \n Note that movie-particle STAR files cannot be "
            "imported from a previous version of RELION, as the way movies are handled "
            "has changed in RELION-2.0. \n \n For the import of a particle, 2D "
            "references or micrograph STAR file or of a 3D reference or mask, only a "
            "single file can be imported at a time. \n \n Note that due to a bug in a "
            "fltk library, you cannot import from directories that contain a "
            "substring  of the current directory, e.g. dont important from "
            "/home/betagal if your current directory is called /home/betagal_r2. In "
            "this case, just change one of the directory names.",
        )
        self.joboptions["node_type"] = JobOption.as_radio(
            "Node type:", "NODETYPE", 0, "Select the type of Node this is."
        )
        self.joboptions["optics_group_particles"] = JobOption.as_textbox(
            "Rename optics group for particles:",
            "",
            "Only for the import of a particles STAR file with a single, or no, optics "
            "groups defined: rename the optics group for the imported particles to "
            "this string.",
        )

    def initialise(self):
        # Initialisation already done in __init__. TODO: do we need this method too?
        pass

    def get_commands(self, outputname, do_makedir, job_counter):

        commands = []

        outputname = self.initialise_pipeline(
            outputname, self.PROCESS_NAME, job_counter
        )

        command = "`which relion_import` "

        do_raw = self.joboptions["do_raw"].get_boolean()
        do_other = self.joboptions["do_other"].get_boolean()

        if do_raw and do_other:
            raise_error(
                "ERROR: you cannot import BOTH raw movies/micrographs AND other node "
                "types at the same time..."
            )
        elif not do_raw and not do_other:
            raise_error("ERROR: nothing to do...")

        if do_raw:

            fn_in = self.joboptions["fn_in_raw"].get_string()
            if self.joboptions["is_multiframe"].get_boolean():

                fn_out = "movies.star"
                node = Node(outputname + fn_out, NODES["Movies"])
                self.output_nodes.append(node)
                command += " --do_movies "
            else:
                fn_out = "micrographs.star"
                node = Node(outputname + fn_out, NODES["Mics"])
                self.output_nodes.append(node)
                command += "--do_micrographs "

            optics_group = self.joboptions["optics_group_name"].get_string()
            if optics_group == "":
                raise_error("ERROR: please specify an optics group name.")
            og = optics_group.replace("$$", "")
            og = og.replace("-", "")
            if not og.isalnum():
                raise_error(
                    "ERROR: an optics group name may contain only numbers, alphabets "
                    "and hyphen(-)."
                )
            command += ' --optics_group_name "' + optics_group + '"'

            fn_mtf = self.joboptions["fn_mtf"].get_string()
            if len(fn_mtf) > 0:
                command += " --optics_group_mtf " + fn_mtf
            command += " --angpix " + self.joboptions["angpix"].get_string()
            command += " --kV " + self.joboptions["kV"].get_string()
            command += " --Cs " + self.joboptions["Cs"].get_string()
            command += " --Q0 " + self.joboptions["Q0"].get_string()
            command += " --beamtilt_x " + self.joboptions["beamtilt_x"].get_string()
            command += " --beamtilt_y " + self.joboptions["beamtilt_y"].get_string()

        elif do_other:

            fn_in = self.joboptions["fn_in_other"].get_string()
            node_type = self.joboptions["node_type"].get_string()
            if node_type == "Particle coordinates (*.box, *_pick.star)":
                fn_out = "coords_suffix" + fn_in.split("*")[-1]
                node = Node(outputname + fn_out, NODES["Mic coords"])
                self.output_nodes.append(node)
                command += " --do_coordinates "
            elif (
                node_type == "Particles STAR file (.star)"
                or node_type == "2D references (.star or .mrcs)"
                or node_type == "3D reference (.mrc)"
                or node_type == "3D mask (.mrc)"
                or node_type == "Micrographs STAR file (.star)"
                or node_type == "Unfiltered half-map (unfil.mrc)"
            ):
                fn_out = os.path.basename("/" + fn_in)

                if node_type == "Particles STAR file (.star)":
                    mynodetype = NODES["Part data"]
                elif node_type == "2D references (.star or .mrcs)":
                    mynodetype = NODES["2D refs"]
                elif node_type == "3D reference (.mrc)":
                    mynodetype = NODES["3D refs"]
                elif node_type == "3D mask (.mrc)":
                    mynodetype = NODES["Mask"]
                elif node_type == "Micrographs STAR file (.star)":
                    mynodetype = NODES["Mics"]
                elif node_type == "Unfiltered half-map (unfil.mrc)":
                    mynodetype = NODES["Halfmap"]
                else:
                    raise_error(
                        "ImportJobWindow::getCommands ERROR: Unrecognized menu option "
                        "for node_type= " + node_type
                    )

                node = Node(outputname + fn_out, mynodetype)
                self.output_nodes.append(node)

                if mynodetype == NODES["Halfmap"]:
                    command += " --do_halfmaps"
                elif mynodetype == NODES["Part data"]:
                    command += " --do_particles"
                    optics_group = self.joboptions[
                        "optics_group_particles"
                    ].get_string()
                    if optics_group != "":
                        op = optics_group.replace("-", "")
                        if not op.isalnum():
                            raise_error(
                                "ERROR: an optics group name may contain only numbers, "
                                "alphabets and hyphen(-)."
                            )
                        command += (
                            ' --particles_optics_group_name "' + optics_group + '"'
                        )
                else:
                    command += " --do_other"

        command += ' --i "' + fn_in + '"'
        command += " --odir " + outputname
        command += " --ofile " + fn_out

        if self.is_continue:
            command += " --continue"

        commands.append(command)

        return self.prepare_final_command(outputname, commands, do_makedir)
