from .relion_job import RelionJob
from ..data_structure import NODES, CLASS2D_TYPE_NUM
from ..job_options import JobOption
from pipeliner.utils import get_env_var


class Class2DJob(RelionJob):
    PROCESS_NAME = "Class2D"
    PROCESS_TYPE_NUM = CLASS2D_TYPE_NUM

    def __init__(self):
        super(self.__class__, self).__init__()
        # TODO: remove this and use class-level constant if possible
        self.type = CLASS2D_TYPE_NUM
        self.hidden_name = ".gui_class2d"

        self.joboptions["fn_img"] = JobOption.as_inputnode(
            "Input images STAR file:",
            NODES["Part data"],
            "",
            "STAR files (*.star) \t Image stacks (not recommended, read help!)"
            " (*.{spi,mrcs})",
            "A STAR file with all images (and their metadata)."
            " \n \n Alternatively, you may give a Spider/MRC stack of 2D images,"
            " but in that case NO metadata can be included and thus NO CTF correction"
            " can be performed, nor will it be possible to perform noise spectra"
            " estimation or intensity scale corrections in image groups. Therefore,"
            " running RELION with an input stack will in general provide sub-optimal"
            " results and is therefore not recommended!! Use the Preprocessing"
            " procedure to get the input STAR file in a semi-automated manner."
            " Read the RELION wiki for more information.",
        )

        self.joboptions["fn_cont"] = JobOption.as_inputnode(
            "Continue from here: ",
            "",
            "STAR Files (*_optimiser.star)",
            # how to set this correctly
            "CURRENT_ODIR",
            "Select the *_optimiser.star file for the iteration from which you want"
            " to continue a previous run. Note that the Output rootname of the "
            "continued run and the rootname of the previous run cannot be the same."
            "If they are the same, the program will automatically add a '_ctX'"
            "to the output rootname, with X being the iteration from which one "
            "continues the previous run.",
            True,
        )

        self.joboptions["do_ctf_correction"] = JobOption.as_boolean(
            "Do CTF-correction?",
            True,
            "If set to Yes, CTFs will be corrected inside the MAP refinement. The"
            " resulting algorithm intrinsically implements the optimal linear, or "
            "Wiener filter. Note that CTF parameters for all images need to be given"
            " in the input STAR file. The command 'relion_refine "
            "--print_metadata_labels' will print a list of all possible metadata "
            "labels for that STAR file. See the RELION Wiki for more details.\n\n "
            "Also make sure that the correct pixel size (in Angstrom)"
            " is given above!)",
        )

        self.joboptions["ctf_intact_first_peak"] = JobOption.as_boolean(
            "Ignore CTFs until first peak?",
            False,
            "If set to Yes, then CTF-amplitude correction will only be performed"
            " from the first peak of each CTF onward. This can be useful if the CTF"
            " model is inadequate at the lowest resolution. Still, in general using"
            " higher amplitude contrast on the CTFs (e.g. 10-20%) often yields better"
            " results. Therefore, this option is not generally recommended: try "
            "increasing amplitude contrast (in your input STAR file) first!",
        )

        self.joboptions["nr_classes"] = JobOption.as_slider(
            "Number of classes:",
            1,
            1,
            50,
            1,
            "The number of classes (K) for a multi-reference refinement. These classes"
            " will be made in an unsupervised manner from a single reference by "
            "division of the data into random subsets during the first iteration.",
        )

        self.joboptions["tau_fudge"] = JobOption.as_slider(
            "Regularisation parameter T:",
            2,
            0.1,
            10,
            0.1,
            "Bayes law strictly determines the relative weight between "
            "the contribution of the experimental data and the prior. However,"
            " in practice one may need to adjust this weight to put slightly more"
            " weight on the experimental data to allow optimal results. Values "
            "greater than 1 for this regularisation parameter (T in the JMB2011 paper)"
            " put more weight on the experimental data. Values around 2-4 have been"
            " observed to be useful for 3D refinements, values of 1-2 for 2D "
            "refinements. Too small values yield too-low resolution structures;"
            " too high values result in over-estimated resolutions, mostly notable"
            " by the apparition of high-frequency noise in the references.",
            True,
        )

        self.joboptions["nr_iter"] = JobOption.as_slider(
            "Number of iterations:",
            25,
            1,
            50,
            1,
            "Number of iterations to be performed. Note that the current "
            "implementation of 2D class averaging and 3D classification does NOT"
            " comprise a convergence criterium. Therefore, the calculations will"
            " need to be stopped by the user if further iterations do not yield "
            "improvements in resolution or classes. \n\n  Also note that upon"
            " restarting, the  iteration number continues to be increased, starting"
            " from the final iteration in the previous run. The number given here"
            " is the TOTAL number of iterations. For example, if 10 iterations have"
            " been performed previously and one restarts to perform an additional 5 "
            "iterations (for example with a finer angular sampling), then the number"
            " given here should be 10+5=15.",
            True,
        )

        self.joboptions["do_fast_subsets"] = JobOption.as_boolean(
            "Use fast subsets (for large data sets)?",
            False,
            "If set to Yes, the first 5 iterations will be done with random"
            " subsets of only K*100 particles (K being the number of classes); "
            "the next 5 with K*300 particles, the next 5 with 30% of the data set; "
            "and the final ones with all data. This was inspired by a cisTEM "
            "implementation by Niko Grigorieff et al.",
        )

        self.joboptions["particle_diameter"] = JobOption.as_slider(
            "Mask diameter (A):",
            200,
            0,
            1000,
            10,
            "The experimental images will be masked with a soft circular mask with"
            " this diameter. Make sure this radius is not set too small because that"
            " may mask away part of the signal! If set to a value larger than the"
            " image size no masking will be performed.\n\nThe same diameter will also"
            " be used for a spherical mask of the reference structures if no "
            "user-provided mask is specified.",
            True,
        )

        self.joboptions["do_zero_mask"] = JobOption.as_boolean(
            "Mask individual particles with zeros?",
            True,
            "If set to Yes, then in the individual particles, the area outside a"
            " circle with the radius of the particle will be set to zeros prior"
            " to taking the Fourier transform. This will remove noise and therefore"
            " increase sensitivity in the alignment and classification. However,"
            " it will also introduce correlations between the Fourier components"
            " that are not modelled. When set to No, then the solvent area is filled"
            " with random noise, which prevents introducing correlations. "
            "High-resolution refinements (e.g. ribosomes or other large complexes "
            "in 3D auto-refine) tend to work better when filling the solvent area "
            "with random noise (i.e. setting this option to No), refinements of "
            "smaller complexes and most classifications go better when using zeros"
            " (i.e. setting this option to Yes).",
        )

        self.joboptions["highres_limit"] = JobOption.as_slider(
            "Limit resolution E-step to (A): ",
            -1,
            -1,
            20,
            1,
            "If set to a positive number, then the expectation step (i.e. "
            "the alignment) will be done only including the Fourier components"
            " up to this resolution (in Angstroms). This is useful to prevent"
            " overfitting, as the classification runs in RELION are not to be "
            "guaranteed to be 100% overfitting-free (unlike the 3D auto-refine"
            " with its gold-standard FSC). In particular for very difficult data"
            " sets, e.g. of very small or featureless particles, this has been "
            "shown to give much better class averages. In such cases, values in "
            "the range of 7-12 Angstroms have proven useful.",
        )

        self.joboptions["dont_skip_align"] = JobOption.as_boolean(
            "Perform image alignment?",
            True,
            "If set to No, then rather than performing both alignment and"
            " classification, only classification will be performed. This"
            " allows the use of very focused masks. This requires that the"
            " optimal orientations of all particles are already stored in "
            "the input STAR file. ",
            True,
        )

        self.joboptions["psi_sampling"] = JobOption.as_slider(
            "In-plane angular sampling:",
            6.0,
            0.5,
            20,
            0.5,
            "The sampling rate for the in-plane rotation angle (psi) in degrees."
            " Using fine values will slow down the program. Recommended value for"
            " most 2D refinements: 5 degrees.\n\nIf auto-sampling is used, this will"
            " be the value for the first iteration(s) only, and the sampling rate "
            "will be increased automatically after that.",
            True,
        )

        self.joboptions["offset_range"] = JobOption.as_slider(
            "Offset search range (pix):",
            5,
            0,
            30,
            1,
            "Probabilities will be calculated only for translations in a circle with"
            " this radius (in pixels). The center of this circle changes at every "
            "iteration and is placed at the optimal translation for each image in"
            " the previous iteration.\n\nIf auto-sampling is used, this will be the"
            " value for the first iteration(s) only, and the sampling rate will be "
            "increased automatically after that.",
            True,
        )

        self.joboptions["offset_step"] = JobOption.as_slider(
            "Offset search step (pix):",
            1,
            0.1,
            5,
            0.1,
            "Translations will be sampled with this step-size (in pixels)."
            " Translational sampling is also done using the adaptive approach. "
            "Therefore, if adaptive=1, the translations will first be "
            "evaluated on a 2x coarser grid.\n\nIf auto-sampling is used, this"
            " will be the value for the first iteration(s) only, and the sampling"
            " rate will be increased automatically after that.",
            True,
        )

        self.joboptions["allow_coarser"] = JobOption.as_boolean(
            "Allow coarser sampling?",
            False,
            "If set to Yes, the program will use coarser angular and translational"
            " samplings if the estimated accuracies of the assignments is still low"
            " in the earlier iterations. This may speed up the calculations.",
            True,
        )

        self.joboptions["do_helix"] = JobOption.as_boolean(
            "Classify 2D helical segments?",
            False,
            "Set to Yes if you want to classify 2D helical segments. "
            "Note that the helical segments should come with priors of psi angles",
        )

        self.joboptions["helical_tube_outer_diameter"] = JobOption.as_slider(
            "Tube diameter (A): ",
            200,
            100,
            1000,
            10,
            "Outer diameter (in Angstroms) of helical tubes. This value should be"
            " slightly larger than the actual width of the tubes. You may want to"
            " copy the value from previous particle extraction job. If negative value"
            " is provided, this option is disabled and ordinary circular masks will "
            "be applied. Sometimes '--dont_check_norm' option is useful to prevent "
            "errors in normalisation of helical segments.",
            True,
        )

        self.joboptions["do_bimodal_psi"] = JobOption.as_boolean(
            "Do bimodal angular searches?",
            True,
            "Do bimodal search for psi angles? Set to Yes if you want to classify"
            " 2D helical segments with priors of psi angles. The priors should be "
            "bimodal due to unknown polarities of the segments. Set to No if the"
            " 3D helix looks the same when rotated upside down. If it is set to No,"
            " ordinary angular searches will be performed.\n\nThis option will be"
            " invalid if you choose not to perform image alignment on 'Sampling' tab.",
            True,
        )

        self.joboptions["range_psi"] = JobOption.as_slider(
            "Angular search range - psi (deg):",
            6,
            3,
            30,
            1,
            "Local angular searches will be performed within +/- the given amount "
            "(in degrees) from the psi priors estimated through helical segment"
            " picking. A range of 15 degrees is the same as sigma = 5 degrees."
            " Note that the ranges of angular searches should be much larger than"
            " the sampling.\n\nThis option will be invalid if you choose not to"
            " perform image alignment on 'Sampling' tab.",
            True,
        )

        self.joboptions["do_restrict_xoff"] = JobOption.as_boolean(
            "Restrict helical offsets to rise:",
            True,
            "Set to Yes if you want to restrict the translational offsets "
            "along the helices to the rise of the helix given below. Set to No"
            " to allow free (conventional) translational offsets.",
            True,
        )

        self.joboptions["helical_rise"] = JobOption.as_slider(
            "Helical rise (A):",
            4.75,
            -1,
            100,
            1,
            "The helical rise (in Angstroms). Translational offsets along the helical"
            " axis will be limited from -rise/2 to +rise/2, with a flat prior.",
            True,
        )

        self.joboptions["nr_pool"] = JobOption.as_slider(
            "Number of pooled particles:",
            3,
            1,
            16,
            1,
            "Particles are processed in individual batches by MPI slaves."
            " During each batch, a stack of particle images is only opened and"
            " closed once to improve disk access times. All particle images of "
            "a single batch are read into memory together. The size of these batches"
            " is at least one particle per thread used. The nr_pooled_particles "
            "parameter controls how many particles are read together for each thread."
            " If it is set to 3 and one uses 8 threads, batches of 3x8=24 particles "
            "will be read together. This may improve performance on systems where"
            " disk access, and particularly metadata handling of disk access, is a"
            " problem. It has a modest cost of increased RAM usage.",
            True,
        )

        self.joboptions["do_parallel_discio"] = JobOption.as_boolean(
            "Use parallel disc I/O?",
            True,
            "If set to Yes, all MPI slaves will read images from disc. "
            "Otherwise, only the master will read images and send them "
            "through the network to the slaves. Parallel file systems like "
            "gluster of fhgfs are good at parallel disc I/O. NFS may break "
            "with many slaves reading in parallel. If your datasets contain "
            "particles with different box sizes, you have to say Yes.",
            True,
        )

        self.joboptions["do_preread_images"] = JobOption.as_boolean(
            "Pre-read all particles into RAM?",
            False,
            "If set to Yes, all particle images will be read into computer"
            " memory, which will greatly speed up calculations on systems with"
            " slow disk access. However, one should of course be careful with the"
            " amount of RAM available. Because particles are read in float-precision,"
            " it will take ( N * box_size * box_size * 4 / (1024 * 1024 * 1024) ) "
            "Giga-bytes to read N particles into RAM. For 100 thousand 200x200 images,"
            " that becomes 15Gb, or 60 Gb for the same number of 400x400 particles. "
            "Remember that running a single MPI slave on each node that runs as many"
            " threads as available cores will have access to all available RAM. \n \n"
            " If parallel disc I/O is set to No, then only the master reads all"
            " particles into RAM and sends those particles through the network "
            "to the MPI slaves during the refinement iterations.",
            True,
        )

        self.joboptions["scratch_dir"] = JobOption.as_textbox(
            "Copy particles to scratch directory:",
            get_env_var("RELION_SCRATCH_DIR"),
            "If a directory is provided here, then the job will create a "
            "sub-directory in it called relion_volatile. If that relion_volatile"
            " directory already exists, it will be wiped. Then, the program will"
            " copy all input particles into a large stack inside the relion_volatile"
            " subdirectory. Provided this directory is on a fast local drive (e.g."
            " an SSD drive), processing in all the iterations will be faster. If the"
            " job finishes correctly, the relion_volatile directory will be wiped. If"
            " the job crashes, you may want to remove it yourself.",
        )

        self.joboptions["do_combine_thru_disc"] = JobOption.as_boolean(
            "Combine iterations through disc?",
            False,
            "If set to Yes, at the end of every iteration all MPI slaves will "
            "write out a large file with their accumulated results. The MPI master"
            " will read in all these files, combine them all, and write out a new"
            " file with the combined results. All MPI salves will then read in the"
            " combined results. This reduces heavy load on the network, but increases"
            " load on the disc I/O. This will affect the time it takes between the"
            " progress-bar in the expectation step reaching its end (the mouse gets"
            " to the cheese) and the start of the ensuing maximisation step. It will"
            " depend on your system setup which is most efficient.",
            True,
        )

        self.joboptions["use_gpu"] = JobOption.as_boolean(
            "Use GPU acceleration?",
            False,
            "If set to Yes, the job will try to use GPU acceleration.",
            True,
        )

        self.joboptions["gpu_ids"] = JobOption.as_textbox(
            "Which GPUs to use:",
            "",
            "This argument is not necessary. If left empty, the job "
            "itself will try to allocate available GPU resources. You can"
            " override the default allocation by providing a list of which "
            "GPUs (0,1,2,3, etc) to use. MPI-processes are separated by ':',"
            " threads by ','. For example: '0,0:1,1:0,0:1,1'",
            True,
        )
        self.get_runtab_options()

    def initialise(self):

        # Initialisation already done in __init__. TODO: do we need this method too?
        pass

    def get_commands(self, outputname, do_makedir, job_counter):  # noqa: C901

        outputname = self.initialise_pipeline(
            outputname, self.PROCESS_NAME, job_counter
        )

        if self.joboptions["nr_mpi"].get_number() > 1:
            command = "`which relion_refine_mpi`"
        else:
            command = "`which relion_refine`"

        command += self.refinement_IO(outputname, 2, 1, self.is_continue)

        ## compute options
        if not self.joboptions["do_combine_thru_disc"].get_boolean():
            command += " --dont_combine_weights_via_disc"
        if not self.joboptions["do_parallel_discio"].get_boolean():
            command += " --no_parallel_disc_io"

        scratch_dir = self.joboptions["scratch_dir"].get_string()
        if self.joboptions["do_preread_images"].get_boolean():
            command += " --preread_images"
        elif scratch_dir != "":
            command += " --scratch_dir " + scratch_dir
        command += " --pool " + self.joboptions["nr_pool"].get_string()
        ## Takanori observed bad 2D classifications with pad1, so use pad2 always.
        ## Memory isn't a problem here anyway.
        command += " --pad 2"

        ## ctf
        if not self.is_continue and self.joboptions["do_ctf_correction"].get_boolean():
            command += " --ctf"
            if self.joboptions["ctf_intact_first_peak"].get_boolean():
                command += " --ctf_intact_first_peak"

        ## optimisation
        command += " --iter " + self.joboptions["nr_iter"].get_string()
        command += " --tau2_fudge " + self.joboptions["tau_fudge"].get_string()
        command += (
            " --particle_diameter " + self.joboptions["particle_diameter"].get_string()
        )

        if not self.is_continue:
            if self.joboptions["do_fast_subsets"].get_boolean():
                command += " --fast_subsets"

            command += " --K " + self.joboptions["nr_classes"].get_string()
            ## Always flatten the solvent
            command += " --flatten_solvent"
            if self.joboptions["do_zero_mask"].get_boolean():
                command += " --zero_mask"
            highres_limit = self.joboptions["highres_limit"].get_number()
            if highres_limit > 0:
                command += " --strict_highres_exp " + str(highres_limit)

        iover = 1
        command += " --oversampling " + str(iover)

        if not self.joboptions["dont_skip_align"].get_boolean():
            command += " --skip_align"

        else:
            ## The sampling given in the GUI will be the oversampled one!
            psi_step = self.joboptions["psi_sampling"].get_number() * (2 ** iover)
            command += " --psi_step " + str(psi_step)

            ## Offset range
            offset_range = self.joboptions["offset_range"].get_string()
            command += " --offset_range " + offset_range

            ## The sampling given in the GUI will be the oversampled one!
            offset_step = self.joboptions["offset_step"].get_number() * (2 ** iover)
            command += " --offset_step " + str(offset_step)

            if self.joboptions["allow_coarser"].get_boolean():
                command += " --allow_coarser_sampling"

        if self.joboptions["do_helix"].get_boolean():
            htd = self.joboptions["helical_tube_outer_diameter"].get_string()
            command += " --helical_outer_diameter " + htd

            dont_skip_align = self.joboptions["dont_skip_align"].get_boolean()
            do_bimodal_psi = self.joboptions["do_bimodal_psi"].get_boolean()
            if dont_skip_align and do_bimodal_psi:
                command += " --bimodal_psi"

            val = self.joboptions["range_psi"].get_number()
            val = max(min(90, val), 0)
            command += " --sigma_psi " + str(val / 3.0)

            if self.joboptions["do_restrict_xoff"].get_boolean():
                helical_rise = self.joboptions["helical_rise"].get_string()
                command += " --helix --helical_rise_initial " + helical_rise

        ## always do norm and scale correction
        if not self.is_continue:
            command += " --norm --scale"

        command += " --j " + self.joboptions["nr_threads"].get_string()
        if self.joboptions["use_gpu"].get_boolean():
            gpu_ids = self.joboptions["gpu_ids"].get_string()
            command += ' --gpu "' + gpu_ids + '"'

        other_args = self.joboptions["other_args"].get_string()
        if len(other_args) > 0:
            command += " " + other_args

        commands = [command]
        return self.prepare_final_command(outputname, commands, do_makedir)
