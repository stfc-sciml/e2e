from .relion_job import RelionJob
from ..data_structure import Node, NODES, JOINSTAR_TYPE_NUM
from ..job_options import JobOption
from pipeliner.utils import raise_error

# simplified this a bit, buy this job is the first candidate for a full remake,
# could make it able to handle any number of files, eliminate clunkyness of
# being able to select multiple types of files causing errors.
# also give the ability to rectify headers, for example if autpick and
# manualpick files are joined

# also fails if there is nothing in the 1st or second slot, when it doesn't
# really need to


class JoinStarJob(RelionJob):
    PROCESS_NAME = "JoinStar"
    PROCESS_TYPE_NUM = JOINSTAR_TYPE_NUM

    def __init__(self):
        super(self.__class__, self).__init__()
        self.type = JOINSTAR_TYPE_NUM
        self.hidden_name = ".gui_joinstar"

        self.joboptions["do_part"] = JobOption.as_boolean(
            "Combine particle STAR files?", False, "",
        )

        self.joboptions["fn_part1"] = JobOption.as_inputnode(
            "Particle STAR file 1: ",
            NODES["Part data"],
            "",
            "particle STAR file (*.star)",
            "The first of the particle STAR files to be combined.",
        )

        self.joboptions["fn_part2"] = JobOption.as_inputnode(
            "Particle STAR file 2: ",
            NODES["Part data"],
            "",
            "particle STAR file (*.star)",
            "The second of the particle STAR files to be combined.",
        )

        self.joboptions["fn_part3"] = JobOption.as_inputnode(
            "Particle STAR file 3: ",
            NODES["Part data"],
            "",
            "particle STAR file (*.star)",
            "The Third of the particle STAR files to be combined.",
        )

        self.joboptions["fn_part4"] = JobOption.as_inputnode(
            "Particle STAR file 4: ",
            NODES["Part data"],
            "",
            "particle STAR file (*.star)",
            "The fourth of the particle STAR files to be combined.",
        )

        self.joboptions["do_mic"] = JobOption.as_boolean(
            "Combine micrograph STAR files?", False, "",
        )

        self.joboptions["fn_mic1"] = JobOption.as_inputnode(
            "Micrograph STAR file 1: ",
            NODES["Mics"],
            "",
            "micrograph STAR file (*.star)",
            "The first of the micrograph STAR files to be combined.",
        )
        self.joboptions["fn_mic2"] = JobOption.as_inputnode(
            "Micrograph STAR file 2: ",
            NODES["Mics"],
            "",
            "micrograph STAR file (*.star)",
            "The second of the micrograph STAR files to be combined.",
        )
        self.joboptions["fn_mic3"] = JobOption.as_inputnode(
            "Micrograph STAR file 3: ",
            NODES["Mics"],
            "",
            "micrograph STAR file (*.star)",
            "The third of the micrograph STAR files to be combined.",
        )
        self.joboptions["fn_mic4"] = JobOption.as_inputnode(
            "Micrograph STAR file 4: ",
            NODES["Mics"],
            "",
            "micrograph STAR file (*.star)",
            "The fourth of the micrograph STAR files to be combined.",
        )

        self.joboptions["do_mov"] = JobOption.as_boolean(
            "Combine movie STAR files?", False, "",
        )

        self.joboptions["fn_mov1"] = JobOption.as_inputnode(
            "Movie STAR file 1: ",
            NODES["Movies"],
            "",
            "movie STAR file (*.star)",
            "The first of the micrograph movie STAR files to be combined.",
        )

        self.joboptions["fn_mov2"] = JobOption.as_inputnode(
            "Movie STAR file 2: ",
            NODES["Movies"],
            "",
            "movie STAR file (*.star)",
            "The second of the micrograph movie STAR files to be combined.",
        )

        self.joboptions["fn_mov3"] = JobOption.as_inputnode(
            "Movie STAR file 3: ",
            NODES["Movies"],
            "",
            "movie STAR file (*.star)",
            "The third of the micrograph movie STAR files to be combined.",
        )

        self.joboptions["fn_mov4"] = JobOption.as_inputnode(
            "Movie STAR file 4: ",
            NODES["Movies"],
            "",
            "movie STAR file (*.star)",
            "The fourth of the micrograph movie STAR files to be combined.",
        )
        self.get_runtab_options(False, False)

    def initialise(self):
        pass

    def get_commands(self, outputname, do_makedir, job_counter):
        outputname = self.initialise_pipeline(
            outputname, self.PROCESS_NAME, job_counter
        )

        ii = 0
        do_part = self.joboptions["do_part"].get_boolean()
        do_mov = self.joboptions["do_mov"].get_boolean()
        do_mic = self.joboptions["do_mic"].get_boolean()

        for option in [do_part, do_mov, do_mic]:
            if option:
                ii += 1
        if ii < 1:
            raise_error(
                "You've selected no type of files for joining. Select a single type!",
            )
        if ii > 1:
            raise_error(
                "You've selected more than one type of files for joining. Only select"
                " a single type!"
            )

        command = '`which relion_star_handler` --combine --i " '

        def make_join_command(files, ftype, outputname):
            filetypes = {
                "particles": ("rlnImageName", "Part data"),
                "movies": ("rlnMicrographName", "Movies"),
                "mics": ("rlnMicrographName", "Mics"),
            }
            comm = ""
            usedfiles = []
            for pfile in files:
                fname = pfile.get_string()
                if len(fname) > 0:
                    comm += fname + " "
                    usedfiles.append(pfile)
            if len(usedfiles) > 1:
                for pfile in usedfiles:
                    self.input_nodes.append(Node(pfile.get_string(), pfile.nodetype))
                comm += '" --check_duplicates ' + filetypes[ftype][0]
                outputfile = outputname + "join_{}.star".format(ftype)
                comm += " --o " + outputfile
                self.output_nodes.append(Node(outputfile, NODES[filetypes[ftype][1]]))

                return comm

            else:
                raise_error(
                    "ERROR: Not enough files selected, select at least two to join"
                )

        if do_part:
            fn_part1 = self.joboptions["fn_part1"]
            fn_part2 = self.joboptions["fn_part2"]
            fn_part3 = self.joboptions["fn_part3"]
            fn_part4 = self.joboptions["fn_part4"]
            partsfiles = [fn_part1, fn_part2, fn_part3, fn_part4]
            command += make_join_command(partsfiles, "particles", outputname)

        elif do_mov:
            fn_mov1 = self.joboptions["fn_mov1"]
            fn_mov2 = self.joboptions["fn_mov2"]
            fn_mov3 = self.joboptions["fn_mov3"]
            fn_mov4 = self.joboptions["fn_mov4"]
            partsfiles = [fn_mov1, fn_mov2, fn_mov3, fn_mov4]
            command += make_join_command(partsfiles, "movies", outputname)

        elif do_mic:
            fn_mic1 = self.joboptions["fn_mic1"]
            fn_mic2 = self.joboptions["fn_mic2"]
            fn_mic3 = self.joboptions["fn_mic3"]
            fn_mic4 = self.joboptions["fn_mic4"]
            partsfiles = [fn_mic1, fn_mic2, fn_mic3, fn_mic4]
            command += make_join_command(partsfiles, "mics", outputname)

        other_args = self.joboptions["other_args"].get_string()
        if len(other_args) > 0:
            command += " " + other_args

        commands = [command]
        return self.prepare_final_command(outputname, commands, do_makedir)
