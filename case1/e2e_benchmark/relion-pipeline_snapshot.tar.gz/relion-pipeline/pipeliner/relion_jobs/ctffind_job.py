from .relion_job import RelionJob
from ..data_structure import Node, NODES, CTFFIND_TYPE_NUM
from ..job_options import JobOption
from ..utils import get_env_var, raise_error


class CtfFindJob(RelionJob):
    # TODO: need to think how to define constants a bit more - consider overriding,
    #  polymorphism etc
    PROCESS_NAME = "CtfFind"
    PROCESS_TYPE_NUM = CTFFIND_TYPE_NUM

    def __init__(self):
        super(self.__class__, self).__init__()
        # TODO: remove this and use class-level constant if possible
        self.type = CTFFIND_TYPE_NUM
        self.hidden_name = ".gui_ctffind"

        self.joboptions["input_star_mics"] = JobOption.as_inputnode(
            "Input micrographs STAR file:",
            NODES["Mics"],
            "",
            "STAR files (*.star)",
            "A STAR file with all micrographs to run CTFFIND or Gctf on",
        )

        self.joboptions["use_noDW"] = JobOption.as_boolean(
            "Use micrograph without dose-weighting?",
            False,
            "If set to Yes, the CTF estimation will be done using "
            "the micrograph without dose-weighting as in rlnMicrographNameNoDW "
            "(_noDW.mrc from MotionCor2). If set to No, the normal rlnMicrographName"
            " will be used.",
        )

        self.joboptions["do_phaseshift"] = JobOption.as_boolean(
            "Estimate phase shifts?",
            False,
            "If set to Yes, CTFFIND4 will estimate the phase shift,"
            " e.g. as introduced by a Volta phase-plate",
        )

        self.joboptions["phase_min"] = JobOption.as_textbox(
            "Phase shift (deg) - Min:",
            "0",
            "Minimum, maximum and step size (in degrees) for the search of"
            " the phase shift",
        )

        self.joboptions["phase_max"] = JobOption.as_textbox(
            "Phase shift (deg) - Max:",
            "180",
            "Minimum, maximum and step size (in degrees) for the search"
            " of the phase shift",
        )

        self.joboptions["phase_step"] = JobOption.as_textbox(
            "Phase shift (deg) - Step:",
            "10",
            "Minimum, maximum and step size (in degrees) for the "
            "search of the phase shift",
        )

        self.joboptions["dast"] = JobOption.as_slider(
            "Amount of astigmatism (A):",
            100,
            0,
            2000,
            100,
            "CTFFIND's dAst parameter, GCTFs -astm parameter",
        )

        #  CTFFIND options
        self.joboptions["use_ctffind4"] = JobOption.as_boolean(
            "Use CTFFIND-4.1?",
            False,
            "If set to Yes, the wrapper will use CTFFIND4 (version 4.1) "
            "for CTF estimation. This includes thread-support, calculation of "
            "Thon rings from movie frames and phase-shift estimation "
            "for phase-plate data.",
        )

        self.joboptions["use_given_ps"] = JobOption.as_boolean(
            "Use power spectra from MotionCorr job?",
            False,
            "If set to Yes, the CTF estimation will be done using power"
            " spectra calculated during motion correction.",
        )

        # getting CTFFIND exe path from env variable
        default_ctffind_location = get_env_var(
            "RELION_CTFFIND_EXECUTABLE", "Enter path to CTFFIND executable"
        )
        # I put a more informative message here rather than a
        # generic path, which confuses people.
        self.joboptions["fn_ctffind_exe"] = JobOption.as_fn(
            "CTFFIND-4.1 executable:",
            default_ctffind_location,
            "*",
            ".",
            "Location of the CTFFIND (release 4.1 or later) executable."
            " You can control the default of this field by setting environment"
            " variable RELION_CTFFIND_EXECUTABLE, or by editing the first few"
            " lines in src/gui_jobwindow.h and recompile the code.",
        )

        self.joboptions["slow_search"] = JobOption.as_boolean(
            "Use exhaustive search?",
            False,
            "If set to Yes, CTFFIND4 will use slower but more exhaustive search."
            " This option is recommended for CTFFIND version 4.1.8 and earlier, "
            "but probably not necessary for 4.1.10 and later. It is also worth trying"
            " this option when astigmatism and/or phase shifts are difficult to fit.",
        )

        self.joboptions["box"] = JobOption.as_slider(
            "FFT box size (pix):", 512, 64, 1024, 8, "CTFFIND's Box parameter",
        )
        self.joboptions["resmin"] = JobOption.as_slider(
            "Minimum resolution (A):", 30, 10, 200, 10, "CTFFIND's ResMin parameter",
        )

        self.joboptions["resmax"] = JobOption.as_slider(
            "Maximum resolution (A):", 5, 1, 20, 1, "CTFFIND's ResMax parameter",
        )

        self.joboptions["dfmin"] = JobOption.as_slider(
            "Minimum defocus value (A):",
            5000,
            0,
            25000,
            1000,
            "CTFFIND's dFMin parameter",
        )

        self.joboptions["dfmax"] = JobOption.as_slider(
            "Maximum defocus value (A):",
            50000,
            20000,
            100000,
            1000,
            "CTFFIND's dFMax parameter",
        )

        self.joboptions["dfstep"] = JobOption.as_slider(
            "Defocus step size (A):", 500, 200, 2000, 100, "CTFFIND's FStep parameter",
        )

        self.joboptions["ctf_win"] = JobOption.as_slider(
            "Estimate CTF on window size (pix) ",
            -1,
            -16,
            4096,
            16,
            "If a positive value is given, a squared window of "
            "this size at the center of the micrograph will be used to"
            " estimate the CTF. This may be useful to exclude parts of "
            "the micrograph that are unsuitable for CTF estimation, e.g."
            " the labels at the edge of phtographic film. \n \n The original "
            "micrograph will be used (i.e. this option will be ignored) if a "
            "negative value is given.",
        )

        self.joboptions["use_gctf"] = JobOption.as_boolean(
            "Use Gctf instead?",
            False,
            "If set to Yes, Kai Zhang's Gctf program (which runs on NVIDIA GPUs)"
            " will be used instead of Niko Grigorieff's CTFFIND4.",
        )
        # getting GCTF exe path from env variable
        default_gctf_location = get_env_var(
            "RELION_GCTF_EXECUTABLE", "Enter path to GCTF executable",
        )

        self.joboptions["fn_gctf_exe"] = JobOption.as_fn(
            "Gctf executable:",
            default_gctf_location,
            "*",
            ".",
            "Location of the Gctf executable. You can control the default"
            " of this field by setting environment variable RELION_GCTF_EXECUTABLE,"
            " or by editing the first few lines in src/gui_jobwindow.h "
            "and recompile the code.",
        )

        self.joboptions["do_ignore_ctffind_params"] = JobOption.as_boolean(
            "Ignore 'Searches' parameters?",
            True,
            "If set to Yes, all parameters EXCEPT for phase shift search"
            " and its ranges on the 'Searches' tab will be ignored, and Gctf's"
            " default parameters will be used (box.size=1024; min.resol=50;"
            " max.resol=4; min.defocus=500; max.defocus=90000; step.defocus=500;"
            " astigm=1000) \n \nIf set to No, all parameters on the CTFFIND tab "
            "will be passed to Gctf.",
        )

        self.joboptions["do_EPA"] = JobOption.as_boolean(
            "Perform equi-phase averaging?",
            False,
            "If set to Yes, equi-phase averaging is used in the defocus refinement,"
            " otherwise basic rotational averaging will be performed.",
        )

        self.joboptions["other_gctf_args"] = JobOption.as_textbox(
            "Other Gctf options:", "", "Provide additional gctf options here.",
        )

        self.joboptions["gpu_ids"] = JobOption.as_textbox(
            "Which GPUs to use:",
            "",
            "This argument is not necessary. If left empty, "
            "the job itself will try to allocate available GPU resources."
            " You can override the default allocation by providing a list of "
            "which GPUs (0,1,2,3, etc) to use. MPI-processes are separated by "
            "':', threads by ','. ",
        )

        self.get_runtab_options(True, False)

    def initialise(self):
        # Initialisation already done in __init__. TODO: do we need this method too?
        pass

    def get_commands(self, outputname, do_makedir, job_counter):

        outputname = self.initialise_pipeline(
            outputname, self.PROCESS_NAME, job_counter
        )

        fn_outstar = outputname + "micrographs_ctf.star"
        self.output_nodes.append(Node(fn_outstar, NODES["Mics"]))

        log_out = outputname + "logfile.pdf"
        self.output_nodes.append(Node(log_out, NODES["PdfLogfile"]))

        input_star_mics = self.joboptions["input_star_mics"].get_string(
            True, "Empty field for input STAR file"
        )

        self.input_nodes.append(
            Node(input_star_mics, self.joboptions["input_star_mics"].nodetype)
        )

        command = ""

        command += " --Box " + self.joboptions["box"].get_string()
        command += " --ResMin " + self.joboptions["resmin"].get_string()
        command += " --ResMax " + self.joboptions["resmax"].get_string()
        command += " --dFMin " + self.joboptions["dfmin"].get_string()
        command += " --dFMax " + self.joboptions["dfmax"].get_string()
        command += " --FStep " + self.joboptions["dfstep"].get_string()
        command += " --dAst " + self.joboptions["dast"].get_string()

        use_noDW = self.joboptions["use_noDW"].get_boolean()
        if use_noDW:
            command += " --use_noDW"

        do_phaseshift = self.joboptions["do_phaseshift"].get_boolean()
        if do_phaseshift:
            command += " --do_phaseshift"
            command += " --phase_min " + self.joboptions["phase_min"].get_string()
            command += " --phase_max " + self.joboptions["phase_max"].get_string()
            command += " --phase_step " + self.joboptions["phase_step"].get_string()

        # using GCTF
        use_gctf = self.joboptions["use_gctf"].get_boolean()
        use_ctffind4 = self.joboptions["use_ctffind4"].get_boolean()
        if use_gctf:
            command += (
                " --use_gctf --gctf_exe " + self.joboptions["fn_gctf_exe"].get_string()
            )

            do_ignore_ctffind_params = self.joboptions[
                "do_ignore_ctffind_params"
            ].get_boolean()
            if do_ignore_ctffind_params:
                command += " --ignore_ctffind_params"

            do_epa = self.joboptions["do_EPA"].get_boolean()
            if do_epa:
                command += " --EPA"

            command += ' --gpu "' + self.joboptions["gpu_ids"].get_string() + '"'

            other_gctf_args = self.joboptions["other_gctf_args"].get_string()
            badcoms = ("--phase_shift_H", "--phase_shift_H", "--phase_shift_H")
            if any(badcom in other_gctf_args for badcom in badcoms):
                raise_error(
                    "Please don't specify --phase_shift_L, H, S "
                    "in 'Other Gctf options'. Use 'Estimate phase shifts' "
                    "and 'Phase shift - Min, Max, Step' instead."
                )
            if len(other_gctf_args) > 0:
                command += ' --extra_gctf_options " ' + other_gctf_args + ' "'
        elif use_ctffind4:
            command += (
                " --ctffind_exe " + self.joboptions["fn_ctffind_exe"].get_string()
            )
            command += " --ctfWin " + self.joboptions["ctf_win"].get_string()
            command += " --is_ctffind4"
            slow_search = self.joboptions["slow_search"].get_boolean()
            if not slow_search:
                command += " --fast_search"
            use_given_ps = self.joboptions["use_given_ps"].get_boolean()
            if use_given_ps:
                command += " --use_given_ps"
        else:
            raise_error("ERROR: Please select use of CTFFIND4.1 or Gctf...")

        if self.is_continue:
            command += " --only_do_unfinished"

        other_args = self.joboptions["other_args"].get_string()
        if len(other_args) > 0:
            command += " " + other_args

        nr_mpi = self.joboptions["nr_mpi"].get_number()
        if nr_mpi > 1:
            rln_command = "`which relion_run_ctffind_mpi`"
        else:
            rln_command = "`which relion_run_ctffind`"

        commands = [
            "{} --i {} --o {}{}".format(
                rln_command, input_star_mics, outputname, command
            )
        ]

        return self.prepare_final_command(outputname, commands, do_makedir)
