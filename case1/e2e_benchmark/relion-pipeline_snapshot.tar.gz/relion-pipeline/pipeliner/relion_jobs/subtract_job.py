from .relion_job import RelionJob
from ..data_structure import Node, NODES, SUBTRACT_TYPE_NUM
from ..job_options import JobOption
import os
from pipeliner.utils import truncate_number


class SubtractJob(RelionJob):
    PROCESS_NAME = "Subtract"
    PROCESS_TYPE_NUM = SUBTRACT_TYPE_NUM

    def __init__(self):
        super(self.__class__, self).__init__()
        self.type = SUBTRACT_TYPE_NUM
        self.hidden_name = ".gui_subtract"

        self.joboptions["fn_opt"] = JobOption.as_fn(
            "Input optimiser.star: ",
            "",
            "STAR Files (*_optimiser.star)",
            "./",
            "Select the *_optimiser.star file for the iteration of the 3D"
            " refinement/classification which you want to use for subtraction. It will"
            " use the maps from this run for the subtraction, and of no particles "
            "input STAR file is given below, it will use all of the particles from"
            " this run.",
        )

        self.joboptions["fn_mask"] = JobOption.as_inputnode(
            "Mask of the signal to keep:",
            NODES["Mask"],
            "",
            "Image Files (*.{spi,vol,msk,mrc})",
            "Provide a soft mask where the protein density you wish to subtract"
            " from the experimental particles is black (0) and the density you "
            "wish to keep is white (1).",
        )

        self.joboptions["do_data"] = JobOption.as_boolean(
            "Use different particles?",
            False,
            "If set to Yes, subtraction will be performed on the particles in"
            " the STAR file below, instead of on all the particles of the 3D "
            "refinement/classification from the optimiser.star file.",
        )

        self.joboptions["fn_data"] = JobOption.as_inputnode(
            "Input particle star file:",
            NODES["Part data"],
            "",
            "particle STAR file (*.star)",
            "The particle STAR files with particles that will be used in the"
            " subtraction. Leave this field empty if all particles from the input"
            " refinement/classification run are to be used.",
        )

        self.joboptions["do_fliplabel"] = JobOption.as_boolean(
            "OR revert to original particles?",
            False,
            "If set to Yes, no signal subtraction is performed. Instead, the labels"
            " of rlnImageName and rlnImageOriginalName are flipped in the input STAR"
            " file given in the field below. This will make the STAR file point back to"
            " the original, non-subtracted images.",
        )

        self.joboptions["fn_fliplabel"] = JobOption.as_inputnode(
            "revert this particle star file:",
            NODES["Part data"],
            "",
            "particle STAR file (*.star)",
            "The particle STAR files with particles that will be used for label"
            " reversion.",
        )

        self.joboptions["do_center_mask"] = JobOption.as_boolean(
            "Do center subtracted images on mask?",
            True,
            "If set to Yes, the subtracted particles will be centered on projections"
            " of the center-of-mass of the input mask.",
        )

        self.joboptions["do_center_xyz"] = JobOption.as_boolean(
            "Do center on my coordinates?",
            False,
            "If set to Yes, the subtracted particles will be centered on projections"
            " of the x,y,z coordinates below. The unit is pixel, not angstrom. The"
            " origin is at the center of the box, not at the corner.",
        )

        self.joboptions["center_x"] = JobOption.as_textbox(
            "Center coordinate (pix) - X:",
            "0",
            "X-coordinate of the 3D center (in pixels).",
        )

        self.joboptions["center_y"] = JobOption.as_textbox(
            "Center coordinate (pix) - Y:",
            "0",
            "Y-coordinate of the 3D center (in pixels).",
        )

        self.joboptions["center_z"] = JobOption.as_textbox(
            "Center coordinate (pix) - Z:",
            "0",
            "Z-coordinate of the 3D center (in pixels).",
        )

        self.joboptions["new_box"] = JobOption.as_slider(
            "New box size:",
            -1,
            64,
            512,
            32,
            "Provide a non-negative value to re-window the subtracted particles"
            " in a smaller box size.",
        )

        self.get_runtab_options(True, False)

    def initialise(self):
        pass

    def get_commands(self, outputname, do_makedir, job_counter):
        outputname = self.initialise_pipeline(
            outputname, self.PROCESS_NAME, job_counter
        )

        nr_mpi = self.joboptions["nr_mpi"].get_number()
        do_fliplabel = self.joboptions["do_fliplabel"].get_boolean()

        # no reason to crash whole job because mpi selection for revert is
        # invalid, just switch it...

        if nr_mpi > 1:
            command = "`which relion_particle_subtract_mpi`"
        else:
            command = "`which relion_particle_subtract`"

        if do_fliplabel:
            fliplabel = self.joboptions["fn_fliplabel"].get_string()
            if nr_mpi > 1:
                os.system(
                    "echo "
                    "'You cannot use MPI parallelization to revert particle labels."
                    " Changing number of mpis to 1\n' >> {}run.err".format(outputname)
                )
                nr_mpi = 1
                command = "`which relion_particle_subtract`"
            self.input_nodes.append(
                Node(fliplabel, self.joboptions["fn_fliplabel"].nodetype)
            )

            self.output_nodes.append(
                Node(outputname + "original.star", NODES["Part data"])
            )

            command += " --revert " + fliplabel + " --o " + outputname

        else:
            fn_opt = self.joboptions["fn_opt"].get_string(
                True, "ERROR: empty field for input optimiser.star...",
            )
            command += " --i " + fn_opt
            self.input_nodes.append(Node(fn_opt, NODES["Optimiser"]))

            fn_mask = self.joboptions["fn_mask"].get_string()
            if len(fn_mask) != 0:
                command += " --mask " + fn_mask
                self.input_nodes.append(
                    Node(fn_mask, self.joboptions["fn_mask"].nodetype)
                )
            if self.joboptions["do_data"].get_boolean():
                fn_data = self.joboptions["fn_data"].get_string(
                    True, "ERROR: empty field for the input particle STAR file..."
                )
                command += " --data " + fn_data
                self.input_nodes.append(
                    Node(fn_data, self.joboptions["fn_data"].nodetype)
                )

            command += " --o " + outputname
            self.output_nodes.append(
                Node(outputname + "particles_subtracted.star", NODES["Part data"])
            )

            if self.joboptions["do_center_mask"].get_boolean():
                command += " --recenter_on_mask"

            elif self.joboptions["do_center_xyz"].get_boolean():
                command += " --center_x " + self.joboptions["center_x"].get_string()
                command += " --center_y " + self.joboptions["center_y"].get_string()
                command += " --center_z " + self.joboptions["center_z"].get_string()

            new_box = self.joboptions["new_box"].get_number()
            command += " --new_box " + truncate_number(new_box, 0)

        other_args = self.joboptions["other_args"].get_string()
        if len(other_args) > 0:
            command += " " + other_args

        commands = [command]
        return self.prepare_final_command(outputname, commands, do_makedir)
