from .relion_job import RelionJob
from ..data_structure import Node, NODES, MOTIONCORR_TYPE_NUM
from ..job_options import JobOption
from ..utils import get_env_var, raise_error


class MotionCorrJob(RelionJob):
    PROCESS_NAME = "MotionCorr"
    PROCESS_TYPE_NUM = MOTIONCORR_TYPE_NUM

    def __init__(self):
        super(self.__class__, self).__init__()
        # TODO: remove this and use class-level constant if possible
        self.type = MOTIONCORR_TYPE_NUM
        self.hidden_name = ".gui_motioncorr"

        self.joboptions["input_star_mics"] = JobOption.as_inputnode(
            "Input movies STAR file:",
            NODES["Movies"],
            "",
            "STAR files (*.star)",
            "A STAR file with all micrographs to run MOTIONCORR on",
        )

        self.joboptions["first_frame_sum"] = JobOption.as_slider(
            "First frame for corrected sum:",
            1,
            1,
            32,
            1,
            "First frame to use in corrected average (starts counting at 1). ",
        )

        self.joboptions["last_frame_sum"] = JobOption.as_slider(
            "Last frame for corrected sum:",
            -1,
            0,
            32,
            1,
            "Last frame to use in corrected average. Values equal to or "
            "smaller than 0 mean 'use all frames'.",
        )

        #  MotionCorr 2
        # getting MOTIONCORR2 exe path from env variable
        default_motioncor2_location = get_env_var(
            "RELION_MOTIONCOR2_EXECUTABLE", "Enter path to MOTIONCOR2 executable",
        )

        self.joboptions["fn_motioncor2_exe"] = JobOption.as_fn(
            "MOTIONCOR2 executable:",
            default_motioncor2_location,
            "*.*",
            ".",
            "Location of the MOTIONCOR2 executable. You can control the"
            " default of this field by setting environment variable "
            "RELION_MOTIONCOR2_EXECUTABLE, or by editing the first few lines in"
            " src/gui_jobwindow.h and recompile the code.",
        )

        self.joboptions["bfactor"] = JobOption.as_slider(
            "Bfactor:",
            150,
            0,
            1500,
            50,
            "The B-factor that will be applied to the micrographs.",
        )

        self.joboptions["patch_x"] = JobOption.as_textbox(
            "Number of patches X:",
            "1",
            "Number of patches (in X and Y direction) to apply motioncor2.",
        )

        self.joboptions["patch_y"] = JobOption.as_textbox(
            "Number of patches Y:",
            "1",
            "Number of patches (in X and Y direction) to apply motioncor2.",
        )
        self.joboptions["group_frames"] = JobOption.as_slider(
            "Group frames:",
            1,
            1,
            5,
            1,
            "Average together this many frames before calculating the"
            " beam-induced shifts.",
        )

        self.joboptions["bin_factor"] = JobOption.as_slider(
            "Binning factor:",
            1,
            1,
            2,
            1,
            "Bin the micrographs this much by a windowing operation in"
            " the Fourier Transform. Binning at this level is hard to un-do"
            " later on, but may be useful to down-scale super-resolution images."
            " Float-values may be used. Do make sure though that the resulting"
            " micrograph size is even.",
        )

        self.joboptions["fn_gain_ref"] = JobOption.as_fn(
            "Gain-reference image:",
            "",
            "*.mrc",
            ".",
            "Location of the gain-reference file to be applied to the"
            " input micrographs. Leave this empty if the movies are"
            " already gain-corrected.",
        )

        self.joboptions["gain_rot"] = JobOption.as_radio(
            "Gain rotation:",
            "GAIN_ROTATION",
            0,
            "Rotate the gain reference by this number times 90 degrees clockwise"
            " in relion_display. This is the same as -RotGain in MotionCor2. "
            "Note that MotionCor2 uses a different convention for rotation so it says "
            "'counter-clockwise'. Valid values are 0, 1, 2 and 3.",
        )

        self.joboptions["gain_flip"] = JobOption.as_radio(
            "Gain flip:",
            "GAIN_FLIP",
            0,
            "Flip the gain reference after rotation. This is the same as "
            "-FlipGain in MotionCor2. 0 means do nothing, 1 means flip Y (upside down)"
            " and 2 means flip X (left to right).",
        )

        self.joboptions["do_own_motioncor"] = JobOption.as_boolean(
            "Use RELION's own implementation?",
            True,
            "If set to Yes, use RELION's own implementation of a "
            "MotionCor2-like algorithm by Takanori Nakane. Otherwise, wrap to the "
            "UCSF implementation. Note that Takanori's program only runs on CPUs "
            "but uses multiple threads, while the UCSF-implementation needs a GPU but"
            " uses only one CPU thread. Takanori's implementation is most efficient"
            " when the number of frames is divisible by the number of threads"
            " (e.g. 12 or 18 threads per MPI process for 36 frames). On some"
            " machines, setting the OMP_PROC_BIND environmental variable to"
            " TRUE accelerates the program. When running on 4k x 4k movies and"
            " using 6 to 12 threads, the speeds should be similar. Note that "
            "Takanori's program uses the same model as the UCSF program and "
            "gives results that are almost identical.\n Whichever program you "
            "use, 'Motion Refinement' is highly recommended to get the most of"
            " your dataset.",
        )

        self.joboptions["fn_defect"] = JobOption.as_fn(
            "Defect file:",
            "",
            "*",
            ".",
            "Location of a UCSF MotionCor2-style defect text file or a defect"
            " map that describe the defect pixels on the detector. Each line of"
            " a defect text file should contain four numbers specifying x, y, "
            "width and height of a defect region. A defect map is an image (MRC"
            " or TIFF), where 0 means good and 1 means bad pixels. The coordinate "
            "system is the same as the input movie before application of binning, "
            "rotation and/or flipping.\nNote that the format of the defect text is"
            " DIFFERENT from the defect text produced by SerialEM! One can convert a"
            " SerialEM-style defect file into a defect map using IMOD utilities e.g."
            " 'clip defect -D defect.txt -f tif movie.mrc defect_map.tif'. See "
            "explanations in the SerialEM manual.\n\nLeave empty if you don't have any "
            "defects, or don't want to correct for defects on your detector.",
        )

        self.joboptions["gpu_ids"] = JobOption.as_textbox(
            "Which GPUs to use:",
            "0",
            "Provide a list of which GPUs (0,1,2,3, etc) to use. MPI-processes"
            " are separated by ':'. For example, to place one rank on device 0 "
            "and one rank on device 1, provide '0:1'.\n Note that multiple MotionCor2"
            " processes should not share a GPU; otherwise, it can lead to crash or"
            " broken outputs (e.g. black images) .",
        )

        self.joboptions["other_motioncor2_args"] = JobOption.as_textbox(
            "Other MOTIONCOR2 arguments",
            "",
            "Additional arguments that need to be passed to MOTIONCOR2.",
        )

        # Dose-weighting

        self.joboptions["do_dose_weighting"] = JobOption.as_boolean(
            "Do dose-weighting?",
            True,
            "If set to Yes, the averaged micrographs will be dose-weighted.",
        )

        # this has been changed to do_save_noDW in dev version of relion to avoid
        # conflict from using starfile reserved words
        self.joboptions["do_save_noDW"] = JobOption.as_boolean(
            "Save non-dose weighted as well?",
            False,
            "Aligned but non-dose weighted images are sometimes useful in"
            " CTF estimation, although there is no difference in most cases. "
            "Whichever the choice, CTF refinement job is always done on"
            " dose-weighted particles.",
        )

        self.joboptions["dose_per_frame"] = JobOption.as_slider(
            "Dose per frame (e/A2):",
            1,
            0,
            5,
            0.2,
            "Dose per movie frame (in electrons per squared Angstrom).",
        )

        self.joboptions["pre_exposure"] = JobOption.as_slider(
            "Pre-exposure (e/A2):",
            0,
            0,
            5,
            0.5,
            "Pre-exposure dose (in electrons per squared Angstrom).",
        )
        # this has been changed to do_save_ps in dev version of relion to avoid
        # conflict from using starfile reserved words
        self.joboptions["do_save_ps"] = JobOption.as_boolean(
            "Save sum of power spectra?",
            False,
            "Sum of non-dose weighted power spectra provides better signal for"
            " CTF estimation. The power spectra can be used by CTFFIND4 but not"
            " by GCTF. This option is not available for UCSF MotionCor2.",
        )

        self.joboptions["group_for_ps"] = JobOption.as_slider(
            "Sum power spectra every e/A2:",
            4,
            0,
            10,
            0.5,
            "McMullan et al (Ultramicroscopy, 2015) sugggest summing power spectra"
            " every 4.0 e/A2 gives optimal Thon rings",
        )

        self.joboptions["group_frames"] = JobOption.as_slider(
            "Group frames: ",
            1,
            1,
            5,
            1,
            "Average together this many frames before calculating the "
            "beam-induced shifts.",
        )

        self.get_runtab_options()

    def initialise(self):
        # Initialisation already done in __init__. TODO: do we need this method too?
        pass

    def get_commands(self, outputname, do_makedir, job_counter):

        outputname = self.initialise_pipeline(
            outputname, self.PROCESS_NAME, job_counter
        )

        nr_mpi = self.joboptions["nr_mpi"].get_number()
        if nr_mpi > 1:
            command = "`which relion_run_motioncorr_mpi`"
        else:
            command = "`which relion_run_motioncorr`"

        input_star_mics = self.joboptions["input_star_mics"].get_string(
            True, "ERROR: Empty field for input micrographs STAR file"
        )

        self.input_nodes.append(
            Node(input_star_mics, self.joboptions["input_star_mics"].nodetype)
        )
        command += " --i " + input_star_mics

        fn_corrected_mics = outputname + "corrected_micrographs.star"
        self.output_nodes.append(Node(fn_corrected_mics, NODES["Mics"]))

        fn_logfile = outputname + "logfile.pdf"
        self.output_nodes.append(Node(fn_logfile, NODES["PdfLogfile"]))

        command += " --o " + outputname

        command += (
            " --first_frame_sum " + self.joboptions["first_frame_sum"].get_string()
        )
        command += " --last_frame_sum " + self.joboptions["last_frame_sum"].get_string()

        do_own_motioncorr = self.joboptions["do_own_motioncor"].get_boolean()
        if do_own_motioncorr:
            command += " --use_own"
            command += " --j " + self.joboptions["nr_threads"].get_string()
        else:
            command += " --use_motioncor2"
            command += (
                " --motioncor2_exe " + self.joboptions["fn_motioncor2_exe"].get_string()
            )
            other_motioncorr2_args = self.joboptions[
                "other_motioncor2_args"
            ].get_string()
            if len(other_motioncorr2_args) > 0:
                command += (
                    ' --other_motioncor2_args " '
                    + self.joboptions["other_motioncor2_args"].get_string()
                    + ' "'
                )
            command += ' --gpu "' + self.joboptions["gpu_ids"].get_string() + '"'

        fn_defect = self.joboptions["fn_defect"].get_string()
        if len(fn_defect) > 0:
            command += " --defect_file " + fn_defect

        command += " --bin_factor " + self.joboptions["bin_factor"].get_string()
        command += " --bfactor " + self.joboptions["bfactor"].get_string()
        command += " --dose_per_frame " + self.joboptions["dose_per_frame"].get_string()
        command += " --preexposure " + self.joboptions["pre_exposure"].get_string()
        command += " --patch_x " + self.joboptions["patch_x"].get_string()
        command += " --patch_y " + self.joboptions["patch_y"].get_string()

        group_frames = self.joboptions["group_frames"].get_string()
        if len(group_frames) > 0 and int(group_frames) > 1:
            command += " --group_frames " + self.joboptions["group_frames"].get_string()

        fn_gain_ref = self.joboptions["fn_gain_ref"].get_string()
        if len(fn_gain_ref) > 0:
            # make sure this is the same error check that relion is doing
            gain_rot_opts = JobOption.GAIN_ROTATION
            gain_flip_opts = JobOption.GAIN_FLIP
            gain_rot = self.joboptions["gain_rot"].get_string()
            gain_flip = self.joboptions["gain_flip"].get_string()

            if gain_rot not in gain_rot_opts or gain_flip not in gain_flip_opts:
                raise_error("Illegal gain_rot and/or gain_flip.")
            gain_rot = str(gain_rot_opts.index(gain_rot))
            gain_flip = str(gain_flip_opts.index(gain_flip))
            command += " --gainref " + fn_gain_ref
            command += " --gain_rot " + gain_rot
            command += " --gain_flip " + gain_flip

        do_dose_weighting = self.joboptions["do_dose_weighting"].get_boolean()
        if do_dose_weighting:
            command += " --dose_weighting"
            save_noDW = self.joboptions["do_save_noDW"].get_boolean()
            if save_noDW:
                command += " --save_noDW"

        save_ps = self.joboptions["do_save_ps"].get_boolean()
        if save_ps:
            if not do_own_motioncorr:
                raise_error(
                    "'Save sum of power spectra' is not available"
                    "with UCSF MotionCor2."
                )
            dose_for_ps = self.joboptions["group_for_ps"].get_number()
            if dose_for_ps <= 0:
                raise_error("Invalid dose for the grouping for power spectra.")

            dose_rate = self.joboptions["dose_per_frame"].get_number()
            if dose_rate <= 0:
                raise ValueError(
                    "Please specify the dose rate to calculate "
                    "the grouping for power spectra."
                )

            grouping_for_ps = int(round(dose_for_ps / dose_rate, 0))
            if grouping_for_ps == 0:
                grouping_for_ps = 1
            command += " --grouping_for_ps " + str(grouping_for_ps)

        if self.is_continue:
            command += " --only_do_unfinished"

        other_args = self.joboptions["other_args"].get_string()
        if len(other_args) > 0:
            command += " " + other_args

        command = [command]
        return self.prepare_final_command(outputname, command, do_makedir)
