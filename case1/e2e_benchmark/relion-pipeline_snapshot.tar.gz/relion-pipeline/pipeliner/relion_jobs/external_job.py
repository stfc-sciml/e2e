from .relion_job import RelionJob
from ..data_structure import Node, NODES, EXTERNAL_TYPE_NUM
from ..job_options import JobOption


class ExternalJob(RelionJob):
    PROCESS_NAME = "External"
    PROCESS_TYPE_NUM = EXTERNAL_TYPE_NUM

    def __init__(self):
        super(self.__class__, self).__init__()
        self.type = EXTERNAL_TYPE_NUM
        self.hidden_name = ".gui_external"

        ## I/O
        self.joboptions["fn_exe"] = JobOption.as_fn(
            "External executable:",
            "",
            "",
            ".",
            "Location of the script that will launch the external program. This"
            " script should write all its output in the directory specified with"
            " --o. Also, it should write in that same directory a file called"
            " RELION_JOB_EXIT_SUCCESS upon successful exit, and "
            "RELION_JOB_EXIT_FAILURE upon failure.",
        )

        ## Optional input nodes
        self.joboptions["in_mov"] = JobOption.as_inputnode(
            "Input movies: ",
            NODES["Movies"],
            "",
            "movie STAR file (*.star)",
            "Input movies. This will be passed with a --in_movies argument to "
            "the executable.",
        )

        self.joboptions["in_mic"] = JobOption.as_inputnode(
            "Input micrographs: ",
            NODES["Mics"],
            "",
            "micrographs STAR file (*.star)",
            "Input micrographs. This will be passed with a --in_mics argument to "
            "the executable.",
        )

        self.joboptions["in_part"] = JobOption.as_inputnode(
            "Input particles: ",
            NODES["Part data"],
            "",
            "particles STAR file (*.star)",
            "Input particles. This will be passed with a --in_parts argument to"
            " the executable.",
        )

        self.joboptions["in_coords"] = JobOption.as_inputnode(
            "Input coordinates: ",
            NODES["Mic coords"],
            "",
            "STAR files (coords_suffix*.star)",
            "Input coordinates. This will be passed with a --in_coords argument to"
            " the executable.",
        )

        self.joboptions["in_3dref"] = JobOption.as_inputnode(
            "Input 3D reference: ",
            NODES["3D refs"],
            "",
            "MRC files (*.mrc)",
            "Input 3D reference map. This will be passed with a --in_3dref argument to"
            " the executable.",
        )

        self.joboptions["in_mask"] = JobOption.as_inputnode(
            "Input 3D mask: ",
            NODES["Mask"],
            "",
            "MRC files (*.mrc)",
            "Input 3D mask. This will be passed with a --in_mask argument to the "
            "executable.",
        )

        ## Optional parameters
        self.joboptions["param1_label"] = JobOption.as_textbox(
            "Param1 - label:",
            "",
            "Define label and value for optional parameters to the script. These will"
            " be passed as an argument --label value",
            True,
        )

        self.joboptions["param1_value"] = JobOption.as_textbox(
            "Param1 - value:",
            "",
            "Define label and value for optional parameters to the script. These will"
            " be passed as an argument --label value",
            True,
        )
        self.joboptions["param2_label"] = JobOption.as_textbox(
            "Param2 - label:",
            "",
            "Define label and value for optional parameters to the script. These will"
            " be passed as an argument --label value",
            True,
        )

        self.joboptions["param2_value"] = JobOption.as_textbox(
            "Param2 - value:",
            "",
            "Define label and value for optional parameters to the script. These will"
            " be passed as an argument --label value",
            True,
        )
        self.joboptions["param3_label"] = JobOption.as_textbox(
            "Param3 - label:",
            "",
            "Define label and value for optional parameters to the script. These will"
            " be passed as an argument --label value",
            True,
        )

        self.joboptions["param3_value"] = JobOption.as_textbox(
            "Param3 - value:",
            "",
            "Define label and value for optional parameters to the script. These will"
            " be passed as an argument --label value",
            True,
        )
        self.joboptions["param4_label"] = JobOption.as_textbox(
            "Param4 - label:",
            "",
            "Define label and value for optional parameters to the script. These will"
            " be passed as an argument --label value",
            True,
        )

        self.joboptions["param4_value"] = JobOption.as_textbox(
            "Param4 - value:",
            "",
            "Define label and value for optional parameters to the script. These will"
            " be passed as an argument --label value",
            True,
        )
        self.joboptions["param5_label"] = JobOption.as_textbox(
            "Param5 - label:",
            "",
            "Define label and value for optional parameters to the script. These will"
            " be passed as an argument --label value",
            True,
        )

        self.joboptions["param5_value"] = JobOption.as_textbox(
            "Param5 - value:",
            "",
            "Define label and value for optional parameters to the script. These will"
            " be passed as an argument --label value",
            True,
        )
        self.joboptions["param6_label"] = JobOption.as_textbox(
            "Param6 - label:",
            "",
            "Define label and value for optional parameters to the script. These will"
            " be passed as an argument --label value",
            True,
        )

        self.joboptions["param6_value"] = JobOption.as_textbox(
            "Param6 - value:",
            "",
            "Define label and value for optional parameters to the script. These will"
            " be passed as an argument --label value",
            True,
        )
        self.joboptions["param7_label"] = JobOption.as_textbox(
            "Param7 - label:",
            "",
            "Define label and value for optional parameters to the script. These will"
            " be passed as an argument --label value",
            True,
        )

        self.joboptions["param7_value"] = JobOption.as_textbox(
            "Param7 - value:",
            "",
            "Define label and value for optional parameters to the script. These will"
            " be passed as an argument --label value",
            True,
        )
        self.joboptions["param8_label"] = JobOption.as_textbox(
            "Param8 - label:",
            "",
            "Define label and value for optional parameters to the script. These will"
            " be passed as an argument --label value",
            True,
        )

        self.joboptions["param8_value"] = JobOption.as_textbox(
            "Param8 - value:",
            "",
            "Define label and value for optional parameters to the script. These will"
            " be passed as an argument --label value",
            True,
        )
        self.joboptions["param9_label"] = JobOption.as_textbox(
            "Param9 - label:",
            "",
            "Define label and value for optional parameters to the script. These will"
            " be passed as an argument --label value",
            True,
        )

        self.joboptions["param9_value"] = JobOption.as_textbox(
            "Param9 - value:",
            "",
            "Define label and value for optional parameters to the script. These will"
            " be passed as an argument --label value",
            True,
        )
        self.joboptions["param10_label"] = JobOption.as_textbox(
            "Param10 - label:",
            "",
            "Define label and value for optional parameters to the script. These will"
            " be passed as an argument --label value",
            True,
        )

        self.joboptions["param10_value"] = JobOption.as_textbox(
            "Param10 - value:",
            "",
            "Define label and value for optional parameters to the script. These will"
            " be passed as an argument --label value",
            True,
        )
        self.get_runtab_options(False, True)

        ## addition for making output nodes

        self.joboptions["fn_output"] = JobOption.as_textbox(
            "Output file name (optional): ",
            "",
            "The name of the output file (if known) this will allow the creation"
            "of an output node for this job, otherwise the resulting file will "
            "have to be imported ",
        )

        self.joboptions["output_nodetype"] = JobOption.as_radio(
            "Output node type (optional): ",
            "NODETYPE",
            10,
            "The type of file that will be output.  If unknown select 'Other'"
            "This will help relion find the file for future jobs, but the file"
            "can also always be specified directly",
        )

    def initialise(self):
        pass

    def get_commands(self, outputname, do_makedir, job_counter):

        outputname = self.initialise_pipeline(
            outputname, self.PROCESS_NAME, job_counter
        )

        fn_exe = self.joboptions["fn_exe"].get_string(
            True, "ERROR: empty field for the external executable script...",
        )
        command = fn_exe

        innodes = {
            self.joboptions["in_mic"]: "--in_mics",
            self.joboptions["in_mov"]: "--in_movies",
            self.joboptions["in_coords"]: "--in_coords",
            self.joboptions["in_part"]: "--in_parts",
            self.joboptions["in_3dref"]: "--in_3Dref",
            self.joboptions["in_mask"]: "--in_mask",
        }

        for i in list(innodes):
            innode_name = i.get_string()
            if len(innode_name) > 0:
                self.input_nodes.append(Node(innode_name, i.nodetype))
                command += " {} {}".format(innodes[i], innode_name)

        # Added an output nodes section
        fn_output = self.joboptions["fn_output"].get_string()
        if len(fn_output) > 0:
            newout = outputname + fn_output
            output_nodetype = self.joboptions["output_nodetype"].get_string()
            self.output_nodes.append(
                Node(newout, JobOption.NODETYPE_OPTIONS[output_nodetype])
            )

        command += " --o " + outputname

        params = [
            "param1",
            "param2",
            "param3",
            "param4",
            "param5",
            "param6",
            "param7",
            "param8",
            "param9",
            "param10",
        ]
        for param in params:
            param_name = self.joboptions[param + "_label"].get_string()
            if len(param_name) > 0:
                command += " --" + param_name
                param_val = self.joboptions[param + "_value"].get_string()
                if len(param_val) > 0:
                    command += " " + param_val

        # don't send the thread command if no threads are specified
        if self.joboptions["nr_threads"].get_number() > 1:
            command += " --j " + self.joboptions["nr_threads"].get_string()

        other_args = self.joboptions["other_args"].get_string()
        if len(other_args) > 0:
            command += " " + other_args

        commands = [command]
        return self.prepare_final_command(outputname, commands, do_makedir)
