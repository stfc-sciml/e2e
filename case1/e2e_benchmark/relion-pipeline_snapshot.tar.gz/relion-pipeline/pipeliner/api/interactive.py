#!/usr/bin/env python

import os
import subprocess
from datetime import datetime

from pipeliner.relion_jobs import job_factory
from pipeliner.data_structure import PROCS, PROC_NAMES
from .manage_project import RelionProject
from pipeliner.jobstar_reader import JobStar
from .api_utils import make_pretty_header, wrap_text


class interactive_job_entry:
    def __init__(self, joboptions_dict, pipeline, is_continue=False):
        self.job = joboptions_dict
        self.pipeline = pipeline
        self.jobop_values = {}  # {variable_name: old vlaue}
        self.jobop_keys = {}  # {label: variable name}
        self.is_continue = is_continue

    def get_jo_vals(self, jo):
        print(make_pretty_header(jo.label.replace(":", "")))

        default_value = str(jo.defaultvalue)

        print("Default value: " + default_value)
        val = str(input(jo.label + " "))
        if val == "":
            val = default_value
        if val == "-h":
            print("\n")
            wrap_text(str(jo.helptext))
            return self.get_jo_vals(jo)
        if "$" in val:
            com = val[1:].lstrip()
            subprocess.run(com.split())
            return self.get_jo_vals(jo)
        else:
            if val == "SKIP":
                val = ""
            return str(val)

    def int_joboptions(self):
        joboptions = self.job.joboptions
        for joboption in joboptions:
            jo = joboptions[joboption]
            if "Continue from here" not in jo.label:
                pass_check = False
                while pass_check is False:
                    value = self.get_jo_vals(jo)
                    pass_check, err_msg, value = self.check_jo_value(jo, value)
                    print(err_msg)

            self.job.joboptions[joboption].value = value

    def get_cont_jo_vals(self, jo):
        jo_var = self.jobop_keys[jo.label]
        default_value = str(self.jobop_values[jo_var])
        if default_value == '""' or default_value == "''":
            default_value = ""

        if jo.in_continue:
            print(make_pretty_header(jo.label.replace(":", "")))

            print("Previous value was: " + default_value)
            val = input(jo.label + " ")
            if val == "":
                val = default_value
            if val == "-h":
                print("\n")
                wrap_text(str(jo.helptext))
                return self.get_cont_jo_vals(jo)
            if "$" in val:
                com = val[1:].lstrip()
                subprocess.run(com.split())
                return self.get_cont_jo_vals(jo)
            if jo.label == "Continue from here: " and (
                "optimiser.star" not in val or self.job.output_name not in val
            ):
                print(
                    "ERROR: An optimiser.star file from this run ({}) must be "
                    "specified!".format(self.job.output_name)
                )
                return self.get_cont_jo_vals(jo)

            else:
                if val == "SKIP":
                    val = ""
                return str(val)
        else:
            print("Job option {} cannot be altered in continue jobs".format(jo.label))
            print("Using value: " + default_value)
            return default_value

    def cont_joboptions(self):
        joboptions = self.job.joboptions
        for joboption in joboptions:
            jo = joboptions[joboption]
            pass_check = False
            while pass_check is False:
                value = self.get_cont_jo_vals(jo)
                pass_check, err_msg, value = self.check_jo_value(jo, value)
                print(err_msg)

            self.job.joboptions[joboption].value = value

    def check_jo_value(self, joboption, value):
        jo_type = joboption.joboption_type
        valtest = False
        err_msg = ""
        if jo_type in ["FILENAME", "INPUTNODE"]:
            valtest = os.path.isfile(value)
            if value in ["", "SKIP"] or value is None:
                print(
                    "WARNING: No file specified\nIf this field "
                    "is optional (EX. mask in a 3D refine) there is no"
                    " problem.\nIf it is required the job will crash"
                )
                valtest = True
            elif not valtest:
                print(
                    "ERROR: File {} does not exist. Enter 'SKIP' to skip"
                    " putting a file in this field".format(value)
                )

        if jo_type == "RADIO":
            radios = {
                "SAMPLING": joboption.SAMPLING,
                "NODETYPE": joboption.NODETYPE,
                "NODETYPE_OPTIONS": joboption.NODETYPE_OPTIONS,
                "GAIN_ROTATION": joboption.GAIN_ROTATION,
                "CTF_FIT": joboption.CTF_FIT,
                "GAIN_FLIP": joboption.GAIN_FLIP,
            }
            valtest = value in radios[joboption.radiomenu]
            choices = "\n".join(radios[joboption.radiomenu])
            err_msg = (
                "ERROR: {} is not a vaild option\n "
                "Available choices are: {}".format(value, choices)
            )

        if jo_type == "BOOLEAN":
            valtest = value in ["Yes", "No"]
            err_msg = (
                "ERROR: You must enter 'Yes' or 'No'." " The value is case sensitive"
            )

        if jo_type == "SLIDER":
            try:
                value = float(value)
                valtest = True
            except ValueError:
                valtest = False
            err_msg = "ERROR: Value must be a number"

        if jo_type == "TEXTBOX":
            valtest = True
            try:
                value = float(value)
            except ValueError:
                pass
            err_msg = "Can't do no wrong here..."
        if valtest:
            err_msg = ""
        return (valtest, err_msg, value)


def interactive_job_create():
    def test_pick(message, opt_range):
        try:
            pick = input(message)
            in_jobtype = int(pick)
            assert in_jobtype in range(1, opt_range + 1)
            return in_jobtype
        except AssertionError or ValueError:
            print("ERROR: Select a valid job type")
            return None

    proj = RelionProject()
    proj.initialize_existing_project()

    print(make_pretty_header("Interactive job creator"))

    continuation = input("Is this a continuation of a previous job (y/n): ")

    n = 1
    procdict = {}

    if continuation in ["Yes", "Y", "y", "YES"]:
        is_continue = True
        for job in proj.pipeline.process_list:
            procdict[n] = job
            print("{:>2d}) {}".format(n, job.name))
            n += 1
        the_job = None
        while not the_job:
            the_job = test_pick(
                "Which job to continue?: ", len(proj.pipeline.process_list)
            )
        old_job = procdict[the_job]
        job, is_plugin = job_factory.new_job_of_type(old_job.type)
        if is_plugin:
            raise ValueError(
                "ERROR: Cannot modify the continuation file for a plugin job\n"
                "Do it by manually editing the continue_job.star file in the job's"
                "directory"
            )
        job.output_name = old_job.name
        job.alias = old_job.alias
        job.is_continue = True
        ojob_op_vals = [job.joboptions[x].label for x in job.joboptions]
        ojob_op_vars = [x for x in job.joboptions]
        jobop_keys = dict(zip(ojob_op_vals, ojob_op_vars))
        new_cont_job = interactive_job_entry(job, proj.pipeline)
        new_cont_job.jobop_keys = jobop_keys
        job_star = JobStar(old_job.name + "job.star")

        print(
            make_pretty_header(
                "Enter the job options for the continuation of job"
                + old_job.name
                + "\nNote: Some job options cannot be altered from"
                " the values in the original run"
            )
        )
        print(
            "Leave blank to use the previous value\nType -h for help\nUse a $"
            " to run unix commands (IE '$ls {0}' to find file"
            " names\n".format(job.output_name)
        )

        new_cont_job.jobop_values = job_star.get_all_options()

        new_cont_job.cont_joboptions()

    else:
        is_continue = False
        for pt in PROCS:
            procdict[n] = pt
            print("{:>2d}) {}".format(n, pt))
            n += 1
        raw_jobtype = None
        while not raw_jobtype:
            raw_jobtype = test_pick("Select the type of job: ", 22)
        jobtype = PROCS[procdict[raw_jobtype]]
        job = job_factory.new_job_of_type(jobtype)

        print(
            make_pretty_header(
                "Enter values for the new {} " "job".format(PROC_NAMES[job.type])
            )
        )
        print(
            "Leave blank for previous value\nType -h for help\nUse a $ to run unix"
            " commands (IE '$ls Class2D/job008' to find file names) "
        )

        new_int_job = interactive_job_entry(job, proj.pipeline)
        new_int_job.int_joboptions()

    if not os.path.isdir("RunFiles"):
        subprocess.run(["mkdir", "RunFiles"])

    if not is_continue:
        now = datetime.now()
        dt_string = now.strftime("%y-%m-%d_%H%M%S")
        filename = PROC_NAMES[job.type] + "_" + dt_string
        job.write(fn="RunFiles/")
        job.write_jobstar(fn="RunFiles/")
        job_file = filename + "_run.job"
        jobstar_file = filename + "_job.star"
        subprocess.call(
            ["mv", "RunFiles/run.job", os.path.join("RunFiles/", job_file,)]
        )
        subprocess.call(
            ["mv", "RunFiles/job.star", os.path.join("RunFiles/", jobstar_file,)]
        )
        print(make_pretty_header("Finished!"))
        print(
            "Wrote job files {} and {} in RunFiles/\nEither of these files "
            "can be used to run the job using --run_job".format(job_file, jobstar_file)
        )
        return [job_file, jobstar_file]
    else:
        continue_file = os.path.join(old_job.name, "continue_")
        job.write_jobstar(continue_file)
        os.system("ls -al " + old_job.name)
        print(make_pretty_header("Finished!"))
        print(
            "Wrote {0}continue_job.star.\nThis file can be used to continue "
            "the job using --continue_job {0}".format(old_job.name)
        )
        return [continue_file + "job.star"]


"""
TO DO:
make real tests with actual files and run them
automate with sys.stdin?

Possible:
for continue jobs only ask for parameters that actually affect the continued job
- would need to define these for every job type.
"""
