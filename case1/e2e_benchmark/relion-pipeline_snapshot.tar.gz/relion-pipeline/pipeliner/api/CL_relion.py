#!/usr/bin/env python

import argparse
import sys
import os
from glob import glob

from pipeliner.api.manage_project import RelionProject
from pipeliner.api.interactive import interactive_job_create
from pipeliner.api.api_utils import make_pretty_header, parse_proclist, parse_procname
from pipeliner.plugins.plugins_data import RelionPlugIn
from pipeliner.plugins.get_plugins import gather_plugins
from pipeliner.utils import check_for_illegal_symbols, raise_error


def main(in_args=None):
    if in_args is None:
        in_args = sys.argv[1:]

    parser = argparse.ArgumentParser(
        description=make_pretty_header("Command Line Relion")
    )
    parser._optionals.title = "Arguments"

    parser.add_argument(
        "--new_project",
        help=(
            "Initialize a new Relion project in this directory."
            " Project name is optional, if none is specified the project will"
            " be called 'default' (recommended)"
        ),
        nargs="?",
        default=None,
        const="default",
        metavar="project name",
    )

    runjob = parser.add_argument_group(make_pretty_header("Running Relion jobs"))
    runjob.add_argument(
        "--run_job",
        help="Create a Relion job using a run.job or job.star file to"
        " get the parameters",
        nargs="?",
        default=None,
        metavar="run.job or job.star file",
    )

    runjob.add_argument(
        "--overwrite",
        help="Use with --run_job to overwrite a current job rather than making"
        " a new job.  Jobs can only be overwritten with the same job type",
        nargs="?",
        default=None,
        metavar="job name",
    )

    runjob.add_argument(
        "--continue_job",
        help="Continue a Relion job that has been previously run."
        "Edit the job's continue_job.star file to modify parameters "
        "for the continuation",
        nargs="?",
        default=None,
        metavar="job name",
    )

    runjob.add_argument(
        "--create_interactive_job",
        help="Create a job.star file for any job type with an interactive dialog. "
        "Useful for situations where the GUI cannot open",
        action="store_true",
    )

    runjob.add_argument(
        "--print_command",
        help="Read a job.star or run.job file and print the Relion command it"
        " would produce",
        nargs="?",
        default=None,
        metavar="run.job or job.star file",
    )

    runjob.add_argument(
        "--schedule_job",
        help="Add a Relion job to list of scheduled jobs using a run.job or job.star "
        "file to get the parameters.  If followed by a job.star file it will create a"
        " new job if followed by a job name it will schedule a continuation of that "
        "job",
        nargs="?",
        default=None,
        metavar="run.job, job.star file or job name",
    )

    schedjob = parser.add_argument_group(make_pretty_header("Executing Schedules"))

    schedjob.add_argument(
        "--run_schedule",
        help="Create a schedule choosing from the currently scheduled jobs and "
        "run it",
        action="store_true",
    )

    schedjob.add_argument(
        "--name",
        help="(required) Enter a name for the new schedule",
        nargs="?",
        default=None,
    )

    schedjob.add_argument(
        "--jobs",
        help="(required) Enter the jobs that will be run.  Make sure to list the"
        " jobs in the order which they should be run",
        nargs="*",
        default=None,
        metavar="job name",
    )

    schedjob.add_argument(
        "--min_between",
        help="(required) Wait at least this many minutes between jobs",
        nargs="?",
        default=None,
        metavar="n",
    )
    schedjob.add_argument(
        "--nr_repeats",
        help="(optional) Repeat the schedule this many times",
        nargs="?",
        default=1,
        metavar="1",
    )

    schedjob.add_argument(
        "--wait_sec_after",
        help=(
            "(optional) Wait this many seconds after finishing before starting"
            " the next job"
        ),
        nargs="?",
        default=2,
        metavar="2",
    )

    schedjob.add_argument(
        "--wait_min_before",
        help="(optional) Wait this many minutes before starting the schedule",
        nargs="?",
        default=0,
        metavar="0",
    )

    schedjob.add_argument(
        "--stop_schedule",
        help="(required) Enter a name for the schedule to be stopped",
        nargs="?",
        default=None,
    )

    delete = parser.add_argument_group(make_pretty_header("Deleting jobs"))
    delete.add_argument(
        "--delete_job",
        help="Remove job(s) and put in the trash, deletes the job and all of its child"
        " processes",
        nargs="?",
        metavar="job name",
    )

    delete.add_argument(
        "--no_recursive",
        help="Add to delete_job to only delete the specified jobs and not their child"
        " processes.  This may severely break your pipeline.  NOT RECOMMENDED!",
        action="store_true",
    )

    undelete = parser.add_argument_group(make_pretty_header("Undeleting jobs"))
    undelete.add_argument(
        "--undelete_job",
        help="Restore a deleted job and any of its deleted parent processes from the "
        "trash",
        nargs="?",
        metavar="job name",
    )

    modify = parser.add_argument_group(make_pretty_header("Modifying jobs"))
    modify.add_argument(
        "--set_alias",
        help="Set the alias of a job",
        nargs=2,
        metavar=("[job name]", "[new alias]"),
    )

    modify.add_argument(
        "--clear_alias",
        help="Clear the alias of a job",
        nargs=1,
        metavar=("[job name]"),
    )

    modify.add_argument(
        "--set_status",
        help="Set the status of a job; choose from 'finished, failed, or aborted",
        nargs=2,
        metavar=("[job name]", "{finished, failed, aborted}"),
    )

    cleanup = parser.add_argument_group(make_pretty_header("Cleaning Up Job(s)"))
    cleanup.add_argument(
        "--cleanup",
        help=(
            "Delete intermediate files from these job(s) to save disk space"
            "; enter ALL to clean up all jobs"
        ),
        nargs="*",
        metavar="job name",
    )
    cleanup.add_argument(
        "--harsh",
        help="Add this argument to --cleanup to delete even more files",
        action="store_true",
    )

    utils = parser.add_argument_group(make_pretty_header("Utilities"))
    utils.add_argument(
        "--validate_starfile",
        help=(
            "Check a star file and make sure it is written in the correct formart.  If"
            " errors are found will attempt to fix them"
        ),
        nargs="?",
        metavar="star file",
    )

    utils.add_argument(
        "--test_plugin",
        help=(
            "Test a plugin file to make sure that it can be read"
            " without errors.  It is advisable to do this before putting"
            " it in the plugins dir. To make sure the plugin is generating the"
            " expected command put it in the plugins dir and  use the --print_command"
            " function with a star file that calls that plugin"
        ),
        nargs="?",
        metavar=".rln plugin file",
    )

    utils.add_argument(
        "--empty_trash",
        help="Delete the files in the trash.  THIS CANNOT BE UNDONE!",
        action="store_true",
    )

    utils.add_argument(
        "--draw_flowchart",
        help=(
            "Draw a flowcharts for the pipeline.  If used alone; draws the entire"
            " pipeline, if followed by a job name; draws upstream and downstream"
            " flowcharts for that job"
        ),
        nargs="?",
        const="full",
        default=None,
        metavar="job name",
    )
    utils.add_argument(
        "--upstream",
        help=(
            "[optional] Add this argument to --draw_flowchart to only draw the "
            " upstream flowchart for the specified job"
        ),
        action="store_true",
    )
    utils.add_argument(
        "--downstream",
        help=(
            "[optional] Add this argument to --draw_flowchart to only draw "
            "the downstream flowchart for the specified job"
        ),
        action="store_true",
    )
    args = parser.parse_args(in_args)

    # make sure only one function is run at a time
    # args that need values
    argcount = 0
    for arg in [
        args.run_job,
        args.delete_job,
        args.undelete_job,
        args.set_status,
        args.set_alias,
        args.clear_alias,
        args.cleanup,
        args.schedule_job,
        args.print_command,
        args.validate_starfile,
        args.draw_flowchart,
        args.test_plugin,
        args.continue_job,
        args.stop_schedule,
        args.new_project,
    ]:
        if arg is not None:
            argcount += 1

    # true/false args
    for arg in [
        args.create_interactive_job,
        args.run_schedule,
        args.empty_trash,
    ]:
        if arg:
            argcount += 1
    if argcount > 1:
        raise_error("ERROR: please only select one type of function at a time")
    elif argcount == 0:
        parser.print_help()

    proj = RelionProject()

    # initialize new project function
    if args.new_project is not None:
        # look for illegal names...
        check_for_illegal_symbols(args.new_project, "pipeline name")

        if args.new_project == "mini":
            raise_error(
                "ERROR: The pipline cannot be named 'mini' this name is used"
                " internally by Relion. "
            )
        # initialize the project
        print("Initializing a new Relion project...")
        if proj.start_new_project(pipeline_name=args.new_project):
            print("Successfully created {}_pipeline.star".format(proj.pipeline_name))
            with open(".CL_relion_project", "w") as project_file:
                project_file.write(proj.pipeline_name)
            return True

    # print command validate star and test plugin don't require an initialized project
    # validate star file function
    if args.validate_starfile is not None:
        fn_in = args.validate_starfile
        return proj.validate_starfile(fn_in)

    # print command function
    if args.print_command is not None:
        job_file = args.print_command
        command = proj.print_command(job_file)
        return command

    # test plugins
    if args.test_plugin is not None:
        the_plugin = args.test_plugin

        # make sure the file exists
        if not os.path.isfile(the_plugin):
            raise_error("ERROR: The plugin file '{}' was not found".format(the_plugin))
        # make sure the plugin has a unique ID
        plugins_dict, plugin_errors = gather_plugins()
        try:
            plugin = RelionPlugIn(the_plugin)
            if plugin.id in plugins_dict:
                print(
                    "ERROR: Two different plugins are attempting to use the"
                    " plugin ID {}:\n{}\n{}\nAll plugins need unique IDs".format(
                        plugin.id, the_plugin, plugins_dict[plugin.id].plugin_file
                    )
                )
                return False
        # if it generates an error return a detailed message
        except Exception:
            e_type, e_object, e_traceback = sys.exc_info()
            print(
                "\nTEST FAILED: Encountered an error executing the code in plugin "
                "file:\n {}\n The error(s) were:\n {}: {} when it was run by {}".format(
                    the_plugin, e_type, e_object, e_traceback
                )
            )
            return False

        if len(plugin_errors) != 0:
            for errored_plugin in plugin_errors:
                if errored_plugin[1] == plugin.id:
                    print("TEST FAILED: " + errored_plugin[0])
                    return False

        print(
            "TEST PASSED: no errors found\nMake sure the plugin is producing the "
            "desired command by making a job.star \nfile for it and running "
            "'CL_relion.py --print_command <plugin_starfile>'"
        )
        return True

    # all other functions require an initialized project
    elif len(sys.argv) > 1:
        proj.check_for_existing_project()

    # cleanup functions
    if "--cleanup" in sys.argv:
        if args.cleanup not in [None, ["ALL"]]:
            procs = parse_proclist(proj.pipeline_name, args.cleanup)
            proj.run_cleanup(procs, args.harsh)
        elif args.cleanup == ["ALL"]:
            proj.cleanup_all(args.harsh)
            return True
        else:
            print("ERROR: No jobs were specified to clean up")
            return False

    # delete job function
    if args.delete_job is not None:
        proc = parse_procname(proj.pipeline_name, args.delete_job)
        proj.delete_job(proc, args.no_recursive)
        return True
    # undelete job function
    if args.undelete_job is not None:
        proc = parse_procname(proj.pipeline_name, args.undelete_job, search_trash=True)
        proj.undelete_job(proc)
        return True

    # set status function
    if args.set_status is not None:
        job, new_status = args.set_status
        job = parse_procname(proj.pipeline_name, job)
        if new_status == "finished":
            proj.update_job_status(job, False, False)
        if new_status == "failed":
            proj.update_job_status(job, True, False)
        if new_status == "aborted":
            proj.update_job_status(job, False, True)
        return True

    # set alias function
    if "--set_alias" in sys.argv:
        job, new_alias = args.set_alias
        job = parse_procname(proj.pipeline_name, job)
        proj.add_alias(job, new_alias)
        return True

    # clear alias function
    if "--clear_alias" in sys.argv:
        job = args.clear_alias[0]
        job = parse_procname(proj.pipeline_name, job)
        proj.add_alias(job, None)
        return True

    # run job function
    if "--run_job" in sys.argv:
        overwrite = False
        target = None
        if args.overwrite is not None:
            target = parse_procname(
                proj.pipeline_name, args.overwrite, search_trash=False
            )
            overwrite = target
        job_name = proj.run_job(args.run_job, overwrite)
        print("Running job as: " + job_name)
        return True

    # continue a job
    if "--continue_job" in sys.argv:
        job_name = parse_procname(proj.pipeline_name, args.continue_job)
        proj.continue_job(job_name)
        print("Continuing " + job_name)
        return True

    # schedule job function
    if "--schedule_job" in sys.argv:
        # if a starfile is given it is a new job
        if ".star" in args.schedule_job:
            job_name = proj.schedule_job(args.schedule_job)
        else:
            job_name = parse_procname(
                proj.pipeline_name, args.schedule_job, search_trash=False
            )
            proj.continue_job(job_name, is_only_schedule=True)

        print("Scheduled job as: " + job_name)
        return True

    # create and run schedule functions
    if args.run_schedule:
        for req_arg in [
            "--name",
            "--jobs",
            "--min_between",
        ]:
            if req_arg not in sys.argv:
                sys.exit("\nERROR: Required argument {} is missing".format(req_arg))
        job_ids = parse_proclist(proj.pipeline_name, args.jobs)
        proj.run_schedule(
            args.name,
            job_ids,
            int(args.nr_repeats),
            int(args.min_between),
            int(args.wait_min_before),
            int(args.wait_sec_after),
        )
        return True

    # stop schedule function
    if args.stop_schedule is not None:
        # allow for entry of the full file name too
        sched_prefix = "RUNNING_PIPELINER_{}_".format(proj.pipeline_name)
        sched_name = args.stop_schedule.replace(sched_prefix, "")
        proj.stop_schedule(sched_name)

    # create interactive job functions
    if args.create_interactive_job:
        interactive_job_create()
        return True

    # empty the trash
    if args.empty_trash:
        trash_files = glob("Trash/*/*/*")
        if len(trash_files) > 0:
            print("Do want to delete {} files in the trash?".format(len(trash_files)))
            doit = input("THIS CANNOT BE UNDONE! (Y/N): ")
            if doit in ["Y", "y", "Yes", "YES"]:
                proj.empty_trash()
                return True
            else:
                print("Exiting without emptying trash")
                return False
        else:
            print("WARNING: No files found in Trash/")
            return False

    # draw the flowcharts
    if args.draw_flowchart is not None:
        job = args.draw_flowchart
        do_upstream = args.upstream
        do_downstream = args.downstream
        if job == "full":
            if do_upstream or do_downstream:
                print(
                    "ERROR: Asked to draw upstream or downstream flowcharts but "
                    "no job was specified"
                )
                return [False, False, False]
            else:
                proj.draw_flowcharts(do_full=True)
                return [False, False, True]

        else:
            job = parse_procname(proj.pipeline_name, args.draw_flowchart)
            if not do_upstream and not do_downstream:
                do_upstream, do_downstream = True, True
            proj.draw_flowcharts(job, do_upstream, do_downstream)
            return [do_upstream, do_downstream, False]


if __name__ == "__main__":
    main()
