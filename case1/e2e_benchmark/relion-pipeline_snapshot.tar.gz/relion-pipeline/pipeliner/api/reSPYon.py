#!/usr/bin/env python

import subprocess
import sys
import os
from datetime import datetime
from glob import glob
from json import dumps

from pipeliner.api.manage_project import RelionProject
from pipeliner.api import CL_relion


def main(in_args=None):
    """
    Wrapper for CL_relion.py; collects the stderr and std out
     as well as looking in run.job and run.err to see
     of there were any errors
     """
    if in_args is None:
        in_args = sys.argv[1:]

    # check if the storage dir exists
    if not os.path.isdir("reSPYon"):
        os.mkdir("reSPYon")

    # get timestamp and name of output file
    now = datetime.now()
    timestamp = now.strftime("%y-%m-%d_%H%M%S")
    fn_outfile = "reSPYon/{}_SPYdata.json".format(timestamp)

    # commands to run
    unix_commands = {
        "user": ["whoami"],
        "os": ["uname", "-a"],
        "python_vers": ["python", "--version"],
        "relion_vers": ["relion", "--version"],
    }
    output_data = {}

    # run the commands capture the data outputs
    for com in unix_commands:
        com_run = subprocess.run(
            unix_commands[com], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
        com_out = com_run.stdout.decode().replace("\n", "")
        com_err = com_run.stderr.decode().replace("\n", "")

        outstring = ""
        for out in [com_out, com_err]:
            if len(out) > 0:
                outstring += out + " "
        output_data[com] = outstring

    # write the CL_relion commands to the output
    output_data["CL_relion_args"] = in_args
    output_data["Start_time"] = timestamp
    # run the relion command via CL_relion
    try:
        CL_output = CL_relion.main(["CL_relion.py"] + in_args)
    except Exception as e:
        output_data["CL_relion_error"] = str(e)
        print(e)
        CL_output = None

    print(
        "\nreSPYon is capturing data for analysis - Thanks for contributing!\n"
        "If you are interested in seeing what data are retained from this\n"
        "run, they can be found in the file {}".format(fn_outfile)
    )

    # check and see if a pipeline was made
    if os.path.isfile("default_pipeline.star"):
        proj = RelionProject()
        proj.initialize_existing_project()
        with open(proj.pipeline_name + "_pipeline.star") as pipe:
            pipe_data = pipe.readlines()
        output_data["pipeline"] = pipe_data

        # if a job was run capture what has been written to the outputs so far
    if ("--run_job" or "--continue_job") in in_args:
        jobid = proj.pipeline.job_counter - 1
        outdirs = glob("*/job{:03d}/".format(jobid))
        if len(outdirs) > 0:
            outdir = outdirs[0]
            output_data["relion_job"] = outdir

            fns_runout = glob("{}run.out".format(outdir))
            fns_runerr = glob("{}run.err".format(outdir))
            if len(fns_runout) > 0:
                fn_runout = fns_runout[0]
                with open(fn_runout) as run_out:
                    output_data["relion_stdout"] = run_out.readlines()
            if len(fns_runerr) > 0:
                fn_runerr = fns_runerr[0]
                with open(fn_runerr) as run_err:
                    output_data["relion_stderr"] = run_err.readlines()
        else:
            outdir = "None"
        # capture the job star that was run
        fn_jobstar = os.path.join(os.path.dirname(outdir), "job.star")
        if os.path.isfile(fn_jobstar):
            with open(fn_jobstar) as jobstar_data:
                output_data["job.star_file"] = jobstar_data.readlines()
        # if the job was submitted to a cluster capture the submission script
        fn_subscript = os.path.join(os.path.dirname(outdir), "run_submit.script")
        if os.path.isfile(fn_subscript):
            with open(fn_subscript) as subout_data:
                output_data["submission_script"] = subout_data.readlines()

        # capture the command relion ran
        fn_note = os.path.join(os.path.dirname(outdir), "note.txt")
        if os.path.isfile(fn_note):
            with open(fn_note) as note_data:
                output_data["relion_command"] = note_data.read()

    # if a job was creating a schedule get what has been written in the log
    if "--run_schedule" in in_args:
        find_scheds = glob("*.log")
        find_scheds.sort(key=os.path.getmtime)

        logfile = find_scheds[-1]
        if len(logfile) > 0:
            output_data["schedule_file"] = logfile
            with open(logfile) as logfile_data:
                output_data["schedule_log"] = logfile_data.readlines()

    # finishing timestamp
    end_timestamp = now.strftime("%y-%m-%d_%H%M%S")
    output_data["End_time"] = end_timestamp

    # write all the data to the file
    with open(fn_outfile, "w") as outfile:
        outfile.write(dumps(output_data, indent=2))

    if CL_output is not None:
        return CL_output


if __name__ == "__main__":
    main()
