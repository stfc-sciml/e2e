from glob import glob
from pipeliner.utils import decompose_pipeline_filename, raise_error
from pipeliner.project_graph import ProjectGraph


def make_pretty_header(title):
    """Make nice looking headers"""
    length = max([len(x) for x in title.split("\n")])
    border = "-=" * int(length / 2)
    if length % 2:
        border += "-"
    return border + "\n" + title + "\n" + border


def wrap_text(text_string):
    """Produces <= 55 character wide wrapped text for on-screen
    display"""
    n = 0
    printed = 0
    text_split = text_string.split()
    while printed <= len(text_split) - 1:
        line_string = ""
        length = 0
        while length < 55 and printed <= len(text_split) - 1:
            line_string += text_split[n] + " "
            length += len(text_split[n])
            printed += 1
            n += 1
        print(line_string)


def parse_procname(pipeline_name, in_proc, search_trash=False):
    """Find process name with the ability for parse ambigious
    input.  Returns full process names IE: Import/job001/
    Can look in both active processes and the Trash Can, accepts
    inputs containing only job number and process type and alias
    IE Import/my_alias"""
    # first see of the process is in the pipeline or trash
    pipeline = ProjectGraph(name=pipeline_name)
    pipeline.read()
    in_proc = in_proc.replace(" ", "")
    if in_proc[-1] != "/":
        in_proc += "/"
    found_it = pipeline.find_process(name=in_proc)

    if not found_it:
        found_it = pipeline.find_process(alias=in_proc)

    if found_it:
        return found_it.name

    trashprocs = glob("Trash/*/job*/")
    if in_proc[0:6] == "Trash/":
        in_proc = in_proc[6:]
    if "Trash/" + in_proc in trashprocs:
        found_it = in_proc
        if search_trash:
            return found_it
        elif not search_trash:
            raise_error(
                "ERROR: Job {} is in the trash. Trashed jobs cannot be used "
                "for this function.  If you wish to use this job undelete it "
                "first".format(found_it)
            )

    # if the user entered just job number IE: job005

    in_jobnr = decompose_pipeline_filename(in_proc)[1]
    if in_jobnr == "":
        raise_error(
            "ERROR: {} does not seem to be a job in this project".format(in_proc)
        )
    else:
        for pipeproc in pipeline.process_list:
            pp_jobnr = decompose_pipeline_filename(pipeproc.name)[1]
            if pp_jobnr == in_jobnr:
                return pipeproc.name
    for trashproc in trashprocs:
        tp_jobnr = decompose_pipeline_filename(trashproc)[1]
        if tp_jobnr == in_jobnr:
            if search_trash:
                return trashproc[6:]
            if not search_trash:
                raise_error(
                    "ERROR: Job {} is in the trash. Trashed jobs cannot be used"
                    "for this function.  If you wish to use this job undelete it"
                    "first".format(found_it)
                )

    raise_error("ERROR: {} does not seem to be a job in this project".format(in_proc))


def parse_proclist(pipeline_name, list_o_procs):
    """ runs parse_procname() on a list of processes """
    checked = [parse_procname(pipeline_name, proc) for proc in list_o_procs]
    return checked
