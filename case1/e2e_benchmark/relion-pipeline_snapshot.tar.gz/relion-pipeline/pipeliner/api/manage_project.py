import os
from glob import glob
import subprocess
from gemmi import cif
import time

from pipeliner.project_graph import ProjectGraph
from pipeliner.job_runner import JobRunner
from pipeliner.relion_jobs import job_factory
from pipeliner.jobstar_reader import StarfileCheck, JobStar
from pipeliner.data_structure import PROCS
from pipeliner.utils import raise_error, clean_jobname
from pipeliner.star_writer import modify_jobstar


class RelionProject(object):
    def __init__(self, pipeline_name=None):
        self.initialized = False
        self.pipeline_name = pipeline_name
        self.pipeline = None

    def start_new_project(self, pipeline_name="default"):
        """Initialze a new Relion project.  Do not allow the creation
        of a project in a directory where one already exists """

        old_pipes = glob("*_pipeline.star")
        if len(old_pipes) > 0:
            raise_error(
                "ERROR: New project cannot be initialized, this is already"
                " a Relion project dir with pipeline(s) called: "
                "{}".format(",".join(old_pipes))
            )
        self.pipeline = ProjectGraph()
        self.pipeline.set_name(pipeline_name, new_lock=False)
        self.pipeline_name = pipeline_name
        self.pipeline.create_lock()
        self.pipeline.write()

        # create the .gui_projectdir file so the gui knows it is initialized
        subprocess.run(["touch", ".gui_projectdir"])

        return True

    def check_for_existing_project(self):
        """Check if the current working dir is a Relion project by
        searching for the pipeline"""

        # look to see if CL_relion has been run run previously and specified a pipeline
        if not self.initialized:
            if os.path.isfile(".CL_relion_project"):
                with open(".CL_relion_project") as project_file:
                    self.pipeline_name = project_file.read()

            # if that doesn't work look to see if a project might have
            # been started using the GUI
            else:
                # find possible pipelines
                pipelines = glob("*_pipeline.star")
                possible_pipes = []
                for i in pipelines:
                    if i != "mini_pipeline.star":
                        possible_pipes.append(i)

                # if there us only one candidate use it
                if len(possible_pipes) == 1:
                    found_name = possible_pipes[0].replace("_pipeline.star", "")
                    with open(".CL_relion_project", "w") as pfile:
                        pfile.write(found_name)
                    self.pipeline_name = found_name

                # if multiple possible pipelines are found...
                elif len(possible_pipes) > 1:
                    raise_error(
                        "ERROR: Trying to initialize a project but there are "
                        "multiple possible pipeline files.\nMake a file called"
                        " '.CL_relion_project' and put the name of the desired "
                        "pipeline in it.\nThe following pipelines were found:\n"
                        "{}".format([x.split("_")[0] for x in possible_pipes])
                    )
                # or if no possible pipelines are found
                else:
                    raise_error(
                        "ERROR: This is currently not a Relion project directory\n"
                        "Initialize a project with --new_project or by starting the"
                        " Relion GUI"
                    )
        # find the pipline of found initialize the project
        if os.path.isfile(self.pipeline_name + "_pipeline.star"):
            self.initialized = True
        else:
            raise_error(
                "ERROR: This is currently not a Relion project directory\n"
                "Initialize a project with --new_project or by starting the"
                " Relion GUI"
            )

    def initialize_existing_project(self):
        """An existing project is expected; check the pipeline exists
        and read it """

        self.check_for_existing_project()
        self.pipeline = ProjectGraph(name=self.pipeline_name)
        self.pipeline.check_process_completion()
        self.pipeline.read()

    def run_cleanup(self, jobs=list(), harsh=False):
        self.initialize_existing_project()
        for job in jobs:
            job = clean_jobname(job)
            jobproc = self.pipeline.find_process(job)
            if jobproc is not None:
                self.pipeline.clean_up_job(jobproc, harsh)
            elif jobproc is None:
                print("WARNING: Could not find job {} to clean up".format(job))
        self.pipeline.check_process_completion()

        return True

    def cleanup_all(self, harsh=False):
        self.initialize_existing_project()
        ProjectGraph.cleanup_all_jobs(self.pipeline, harsh)
        self.pipeline.check_process_completion()
        return True

    def delete_job(self, job, no_recursive=False):
        self.initialize_existing_project()
        job = clean_jobname(job)
        if not no_recursive:
            message = "and child processes were moved to the trash"
        else:
            message = (
                "was moved to the trash any child processes were left in place"
                " - THIS IS PROBABLY A BAD IDEA"
            )
        jobproc = self.pipeline.find_process(job)
        if jobproc is None:
            print("ERROR: Could not find job {} to delete".format(job))
        else:
            self.pipeline.delete_job(jobproc, not no_recursive)
            print("Job {} {}".format(job, message))
        self.pipeline.check_process_completion()
        return True

    def undelete_job(self, job):
        self.initialize_existing_project()
        job = clean_jobname(job)
        if not os.path.isdir(os.path.join("Trash/", job)):
            print(
                "ERROR: Could not find job {} in the trash, "
                "can't undelete it.".format(job)
            )
        else:
            self.pipeline.undelete_job(job)
        self.pipeline.check_process_completion()
        return True

    def add_alias(self, job, new_alias):
        self.initialize_existing_project()
        job = clean_jobname(job)
        jobproc = self.pipeline.find_process(job)
        self.pipeline.set_job_alias(jobproc, new_alias)
        self.pipeline.check_process_completion()
        return True

    def update_job_status(self, job, is_failed, is_aborted):
        self.initialize_existing_project()
        job = clean_jobname(job)
        jobproc = self.pipeline.find_process(job)
        self.pipeline.mark_as_finished(jobproc, is_failed, is_aborted)
        self.pipeline.check_process_completion()
        return True

    def run_job(self, job_file, overwrite=False):
        self.initialize_existing_project()
        pipeline = JobRunner(project_name=self.pipeline_name)
        # if the job is overwrite get the old job
        if overwrite:
            overwrite = clean_jobname(overwrite)
            original_job = self.pipeline.find_process(overwrite)
            target_job = original_job
            overwrite = True
        # otherwise make a new job
        else:
            target_job = None

        job = job_factory.read_job(job_file, do_initialise=True)
        if job.is_continue:
            raise_error(
                "ERROR: The job file is for continuing a job "
                "Use the --continue_job <job name> function instead.\n"
                "To modify the parameters in a continued job edit the"
                "continue_job.star file in its job directory"
            )
        pipeline.run_job(job, target_job, False, job.is_continue, False, overwrite)
        time.sleep(1)
        self.pipeline.check_process_completion()
        job_name = job.output_name
        return job_name

    def continue_job(self, job_to_continue, is_only_schedule=False):
        self.initialize_existing_project()
        pipeline = JobRunner(project_name=self.pipeline_name)
        job_to_continue = clean_jobname(job_to_continue)
        # find the job_to_continue
        curr_job = pipeline.graph.find_process(job_to_continue)
        if curr_job is None:
            raise_error(
                "ERROR: Asked to continue job: {} but this job does not "
                "exist".format(job_to_continue)
            )

        # find and read the continuation file
        continue_file = os.path.join(curr_job.name, "continue_job.star")
        if not os.path.isfile(continue_file):
            print(
                "WARNING: Could not find the file {}.\nWill instead use the"
                " job options in the original job.star file.".format(continue_file)
            )
            continue_options = {}
        else:
            continue_options = JobStar(continue_file).get_all_options()

        # find and read the original job.star
        original_options_file = os.path.join(curr_job.name, "job.star")
        if not os.path.isfile(original_options_file):
            raise_error(
                "ERROR: The file {} was not found.\nThere is an error with the job"
                " and it cannot be continued.".format(original_options_file)
            )

        # make a dummy job to get a job options dict for writing the job.star
        # substitute in the continue options
        djob = job_factory.read_job(original_options_file)
        for jo in djob.joboptions:
            if jo in continue_options:
                djob.joboptions[jo].value = continue_options[jo]

        # check if an optimiser is needed; if so and missing, raise error..
        needs_optimiser = [
            PROCS["Class2D"],
            PROCS["InitialModel"],
            PROCS["Class3D"],
            PROCS["Refine3D"],
            PROCS["MultiBody"],
        ]
        if curr_job.type in needs_optimiser:
            optimiser_file = djob.joboptions["fn_cont"].get_string()
            if "_optimiser.star" not in optimiser_file:
                raise_error(
                    "ERROR: No optimiser file was specified to continue from\n"
                    "Edit {} to list an optimiser.star file in the field "
                    "'fn_cont'".format(continue_file)
                )

            # check that additional iterations have been added
            optifile = os.path.basename(optimiser_file)
            iternumber = int(optifile.split("_")[1].replace("it", ""))
            if int(djob.joboptions["nr_iter"].get_number()) == iternumber:
                raise_error(
                    "ERROR: The job has been continued from iteration {} but "
                    "the specified number of iterations is {} so no additional "
                    "iterations will be run\nUpdate the 'nr_iter' parameter in"
                    " the continue_job.star file for this job."
                )

        # rename the old job.star file
        jobstars = glob(os.path.join(curr_job.name, "job.star.*"))
        if len(jobstars) > 0:
            jobstars.sort()
            last_ct_no = int(jobstars[-1].split(".")[-1].replace("ct", ""))
            ct_no = last_ct_no + 1
            new_name = original_options_file + ".ct{:03d}".format(ct_no)
            subprocess.run(["mv", original_options_file, new_name])
        else:
            subprocess.run(
                ["mv", original_options_file, original_options_file + ".ct000"]
            )

        # make a new jobstar file and run it
        djob.write_jobstar(curr_job.name)
        job = job_factory.read_job(original_options_file, do_initialise=True)
        job.is_continue = True
        if not is_only_schedule:
            pipeline.run_job(job, curr_job, False, job.is_continue, False, False, False)
        else:
            pipeline.run_job(job, curr_job, True, job.is_continue, False, False, False)

        return job_to_continue

    def schedule_job(self, job_file):
        self.initialize_existing_project()
        pipeline = JobRunner(project_name=self.pipeline_name)
        job = job_factory.read_job(job_file, do_initialise=True)
        pipeline.run_job(job, None, True, job.is_continue, False)
        # put a copy of the job file in the output dir
        subprocess.call(["cp", job_file, job.output_name + "job.star"])
        self.pipeline.check_process_completion()
        job_name = job.output_name
        return job_name

    def run_schedule(
        self,
        fn_sched,
        job_ids,
        nr_repeat,
        minutes_wait,
        minutes_wait_before,
        seconds_wait_after,
    ):
        self.initialize_existing_project()
        pipeline = JobRunner(project_name=self.pipeline_name)
        runfile_name = "RUNNING_PIPELINER_" + self.pipeline_name + "_" + fn_sched

        if os.path.isfile(runfile_name):
            raise_error(
                "ERROR: a file called {} already exists. \n This "
                "implies another set of scheduled jobs with this name is already "
                "running. \n Cancelling job execution...".format(runfile_name)
            )

        print(
            "Created schedule: {} with {} jobs repeated {} times".format(
                fn_sched, len(job_ids), nr_repeat
            )
        )
        print("Running " + fn_sched)
        pipeline.run_scheduled_jobs(
            fn_sched,
            job_ids,
            nr_repeat,
            minutes_wait,
            minutes_wait_before,
            seconds_wait_after,
        )
        self.pipeline.check_process_completion()
        return True

    def print_command(self, job_file):
        try:
            self.initialize_existing_project()
            job = job_factory.read_job(job_file)
            jobnumber = self.pipeline.job_counter
            commands = job.get_commands("", False, jobnumber)

        except ValueError:
            print(
                "\nWARNING: No Relion Project is initialized in this directory, "
                "so the command will be displayed as job000"
            )
            job = job_factory.read_job(job_file)
            commands = job.get_commands("", False, 0)

        print("\n" + commands)
        return commands

    def validate_starfile(self, fn_in):
        """Checks for inappropriate use of reserved words in starfiles writes
        a corrected version with proper quotation if possible"""
        the_file = StarfileCheck(fn_in)
        print("Star file vers: " + the_file.version)
        try:
            cif.read_file(fn_in)
            print("No problems found")
            return True
        except RuntimeError:
            print("Error(s) were found, attempting to correct the file...")
            the_file.check_reserved_words()

        try:
            cif.read_file(the_file.tmp_name)
            file_dir, file_name = os.path.split(fn_in)
            outfile = os.path.join(file_dir, "fixed_" + file_name)
            subprocess.call(["mv", the_file.tmp_name, outfile])
            print(
                "The file has been corrected. The corrected file has been"
                " written at : " + outfile
            )
            return True

        except RuntimeError:
            print(
                "ERROR: There were error(s) reading the file and it could"
                " not be corrected"
            )
            return False

    def empty_trash(self):
        trash_files = glob("Trash/*/*/*")
        if len(trash_files) > 0:
            subprocess.call(["rm", "-rf", "Trash"])
            print(
                "Trash has been emptied. {} files were deleted".format(len(trash_files))
            )
            return True
        else:
            print("WARNING: No files were found in the trash")
            return False

    def draw_flowcharts(
        self, job="", do_upstream=False, do_downstream=False, do_full=False
    ):
        drew_up, drew_down, drew_full = False, False, False
        self.initialize_existing_project()
        if (do_upstream or do_downstream) and job is None:
            print(
                "WARNING: No job specified for flowchart, can't draw"
                " upstream/downstream charts"
            )
        jobproc = self.pipeline.find_process(name=job)
        if jobproc is not None:
            if do_upstream:
                drew_up = self.pipeline.upstream_process_graph(jobproc)
            if do_downstream:
                drew_down = self.pipeline.downstream_process_graph(jobproc)

        if do_full:
            drew_full = self.pipeline.full_process_graph()

        if not drew_up and not drew_down and not drew_full:
            print("WARNING: There was nothing to draw! Was a job name specified?")

        return [drew_up, drew_down, drew_full]

    def stop_schedule(self, schedule_name):
        # find RUNNING_PIPELINER_ file
        sched_info = []
        the_file = None
        running_files = glob("RUNNING*")
        for f in running_files:
            sname = f.replace("RUNNING_PIPELINER_", "").split("_")
            pipe = sname[0]
            name = "_".join(sname[1:])
            if name == schedule_name and pipe == self.pipeline_name:
                the_file = f
                with open(the_file) as run_file:
                    sched_info = run_file.readlines()

        # error if the schedule is not found
        if the_file is None:
            print(
                "ERROR: Cannot find file RUNNING_PIPELINER_{0}_{1}\n"
                "'{1}' does not appear to be a running schedule".format(
                    self.pipeline_name, schedule_name,
                )
            )
            return False

        # if the schedule was started by the GUI delete the file
        if len(sched_info) == 0:
            subprocess.run(["rm", the_file])
            return True

        # if the schedule was started by the ccpem_pipeliner kill it and abort the job
        else:
            running_jobs = []
            for line in sched_info:
                if "RELION_SCHEDULE:" in line:
                    # kill the schedule id it was started by CL_relion
                    sched_pid = line.split()[1].rstrip()
                    subprocess.run(["kill", "-9", sched_pid])
                else:
                    running_jobs.append(line)
            # abort the current running job
            if len(running_jobs) > 0:
                current_job = running_jobs[-1].rstrip()
                self.update_job_status(current_job, is_failed=False, is_aborted=True)

            # remove the file
            subprocess.run(["rm", the_file])
            return True

    def modify_jobstar(self, fn_template, params_to_change, out_fn):
        out_file = modify_jobstar(fn_template, params_to_change, out_fn)
        return out_file
