import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import networkx as nx
import os
import subprocess
import time
import sys
from itertools import combinations
from gemmi import cif

from . import star_keys
from . import star_writer
from .data_structure import (
    Process,
    Node,
    STATUS,
    PROCS,
    NODES,
    NODES_DIR,
    PROC_NAMES,
    NODES_COLORS,
)
from .utils import (
    decompose_pipeline_filename,
    check_for_illegal_symbols,
    raise_error,
)
from pipeliner.jobstar_reader import OutputNodeStar, ExportStar
from glob import glob


class ProjectGraph(object):
    def __init__(self, name="default", do_read_only=False):
        self.name = name
        self.node_list = []
        self.process_list = []

        # TODO correct this to 0, it's currently at 1 for compatibility reasons
        # For now, think of this as the number of the next job. But in the long run it's
        # probably less confusing to count the number of jobs already in the pipeline.
        self.job_counter = 1
        self.do_read_only = do_read_only

    def clear(self):
        self.node_list = []
        self.process_list = []
        self.job_counter = 1

    def set_name(self, name, new_lock=True, overwrite=False):
        old_name = self.name

        # write a copy of the new pipeline
        if not os.path.isfile(name + "_pipeline.star"):
            self.name = name
            self.write(lockfile_expected=False)
            # get rid of the old lock file
            old_lockfile = ".relion_lock/lock_" + old_name + "_pipeline.star"
            new_lockfile = ".relion_lock/lock_" + name + "_pipeline.star"
            if new_lock:
                if os.path.isfile(old_lockfile):
                    subprocess.run(["mv", old_lockfile, new_lockfile])
                else:
                    self.create_lock()

            if os.path.isfile(old_lockfile):
                subprocess.run(["rm", old_lockfile])

        elif not overwrite:
            self.remove_lock()
            raise_error(
                "ERROR: Can't change pipeline name because pipeline file "
                "{}_pipeline.star already exists".format(name)
            )

    def get_pipeline_filename(self):
        return self.name + "_pipeline.star"

    def is_empty(self):
        if self.job_counter <= 1:
            return True

    def find_node(self, name):
        found = None
        for node in self.node_list:
            if node.name == name:
                found = node
        return found

    def find_process(self, name=None, alias=None):

        if (name is None and alias is None) or (name is not None and alias is not None):
            print("\n\nERROR: please specify name or alias parameter to search by.")
            exit(1)

        found = None
        if name is not None:
            for process in self.process_list:
                if process.name == name:
                    found = process
        elif alias is not None:
            for process in self.process_list:
                if process.alias == alias:
                    found = process
        return found

    def add_node(self, node, touch_if_not_exists=False):
        if node.name == "":
            raise RuntimeError(
                "Pipeline::addNode: Adding an emtpy nodename. "
                "Did you fill in all Node names correctly?"
            )
        fn_node = node.name
        for proc in self.process_list:
            if proc.alias is not None and proc.alias in fn_node:
                fn_node = proc.name + fn_node.replace(proc.alias, "")
                node.name = fn_node
                break

        found = None
        for n in self.node_list:
            if n.name == node.name:
                found = n
                break
        if found is None:
            self.node_list.append(node)
            found = node
        self.touch_temp_node_file(node, touch_if_not_exists)
        return found

    def get_node_name(self, node):
        if node.output_from_process is not None:
            fn_alias = node.output_from_process.alias
        else:
            fn_alias = None

        if fn_alias is not None:
            # make sure alias ends with a slash
            if fn_alias[-1] != "/":
                fn_alias += "/"
            fn_post = decompose_pipeline_filename(node.name)[2]
            fnt = fn_alias + fn_post
        else:
            fnt = node.name
        return fnt

    def touch_temp_node_file(self, node, touch_if_not_exists):
        if self.do_read_only:
            return False
        fnt = self.get_node_name(node)
        if os.path.isfile(node.name) or touch_if_not_exists:
            fn_type = str(node.type) + "/"
            mynode = NODES_DIR + fn_type + fnt
            mydir = os.path.dirname(mynode)
            if not os.path.isdir(mydir):
                subprocess.run(["mkdir", "-p", mydir])
            subprocess.run(["touch", mynode])
            return True
        else:
            return False

    def touch_temp_node_files(self, process):
        #         not implemented yet
        #         if self.doReadOnly:
        #             return(False)
        touch_if_not_exists = False
        if process.status == STATUS["scheduled"]:
            touch_if_not_exists = True

        for node in process.output_nodes:
            self.touch_temp_node_file(node, touch_if_not_exists)

    def delete_temp_node_file(self, node):
        #         not implemented yet
        #         if self.doReadOnly:
        #             return(False)
        fnt = self.get_node_name(node)
        # remove the node
        if os.path.isfile(node.name):
            fn_type = str(node.type) + "/"
            mynode = NODES_DIR + fn_type + fnt
            if os.path.isfile(mynode):
                subprocess.run(["rm", mynode])
            # also remove the dir if empty
            mydir = os.path.dirname(mynode)
            if os.path.isdir(mydir):
                if len(os.listdir(mydir)) == 0:
                    subprocess.run(["rm", "-r", mydir])

    def delete_temp_node_files(self, process):
        #         not implemented yet
        #         if self.doReadOnly:
        #             return(False)
        for node in process.output_nodes:
            self.delete_temp_node_file(node)

    def add_new_input_edge(self, node, process):

        # 1. Check whether Node with that name already exists in the Node list
        newnode = self.add_node(node)  # if new its added to the list

        # 2. Set the input_for_process in the inputForProcessList of this Node but only
        # if it doesn't yet exist
        found = None
        for proc in newnode.input_for_processes_list:
            if proc == process:
                found = proc
                break
        if found is None:
            newnode.input_for_processes_list.append(process)
            process.input_nodes.append(newnode)
        for proc in self.process_list:
            if newnode is not node:
                # Previously unobserved node. Check whether it came from an old process.
                nodename = newnode.name
                if proc.name in nodename:
                    proc.output_nodes.append(newnode)
                    newnode.output_from_process = proc
                    break

    def add_new_output_edge(self, process, node, mini=False):

        # 1. Check whether Node with that name already exists in the node_list
        # Touch .Nodes entries even if they don't exist for scheduled jobs

        touch_if_not_exist = process.status == 1

        # 2. Set the output_from_process of this Node
        node.output_from_process = process
        newnode = self.add_node(node, touch_if_not_exist)

        # 3. Only for new Nodes, add this Node to the outputNodeList of myProcess
        if not mini:
            if newnode == node:
                process.output_nodes.append(newnode)

    def add_new_process(self, process, do_overwrite):
        found = None
        for proc in self.process_list:
            if proc.name == process.name:
                found = proc
                proc.status = process.status
                break
        if found is None:
            self.process_list.append(process)
            self.job_counter += 1
        elif not do_overwrite:
            raise RuntimeError(
                "Pipeline::addNewProcess: trying to add existing Process to the "
                "pipeline while overwriting is not allowed."
            )
        return found

    def add_job(self, job, as_status, do_overwrite):

        # Also write a mini-pipeline in the output directory
        mini_pipeline = ProjectGraph(name="mini")
        mini_pipeline.set_name(job.output_name + "job", new_lock=False, overwrite=True)

        # Add process to the processList of the pipeline
        process = Process(job.output_name, job.type, as_status)
        newprocess = self.add_new_process(process, do_overwrite)
        mini_pipeline.add_new_process(process, True)
        if newprocess is not None:
            process = newprocess
        # Add all input nodes
        for node in job.input_nodes:
            self.add_new_input_edge(node, process)
            mini_pipeline.add_new_input_edge(node, mini_pipeline.process_list[0])

        # Add all output nodes
        for node in job.output_nodes:
            self.add_new_output_edge(process, node)
            mini_pipeline.add_new_output_edge(
                mini_pipeline.process_list[0], node, mini=True
            )
        # write the mini-pipeline
        mini_pipeline.write(lockfile_expected=False)
        return process

    def create_lock(self, wait_time=2):
        dir_lock = ".relion_lock"
        fn_lock = ".relion_lock/lock_" + self.name + "_pipeline.star"

        any_error = ""
        if not os.path.isdir(dir_lock):
            dir_err = subprocess.run(["mkdir", dir_lock], stderr=subprocess.PIPE)
            any_error = str(dir_err.stderr.decode("utf-8"))

        if "Permission denied" in any_error:
            raise RuntimeError(
                "ERROR: ProjectGraph.read() cannot create a lock directory {}."
                " You don't have write permission to this project. If you want to"
                " look at other's project directory (but run nothing there), please"
                " start RELION with --readonly".format(dir_lock)
            )

        iwait = 0
        subprocess.run(["touch", fn_lock], stderr=subprocess.PIPE)
        if not os.path.isfile(fn_lock):
            print("WARNING: Having trouble writing lock file")
            sys.stdout.write("Still trying...")
            sys.stdout.flush()
        while not os.path.isfile(fn_lock):
            # If the lock exists: wait 3 seconds and try again
            # First time round, print a warning message
            time.sleep(3)
            iwait += 3
            sys.stdout.write(".")
            sys.stdout.flush()
            if iwait > wait_time * 60:  # faster for testing
                raise RuntimeError(
                    "ERROR: ProjectGraph.read() has waited for {} minutes for lock"
                    " file to appear, but it doesn't. This should not happen. Is"
                    " something wrong with the disk access?".format(wait_time)
                )

    def check_lock(self, lock_expected, wait_time=2):
        fn_lock = ".relion_lock/lock_" + self.name + "_pipeline.star"
        if not lock_expected:
            iwait = 0
            while os.path.isfile(fn_lock):
                # If the lock exists: wait 3 seconds and try again
                # First time round, print a warning message
                if iwait == 0:
                    print(
                        "\nWARNING: trying to read pipeline.star, but directory {}"
                        " exists (which protects against simultaneous writing by"
                        " multiple instances of the GUI)".format(fn_lock)
                    )
                    sys.stdout.write("Waiting...")
                time.sleep(3)
                iwait += 3
                sys.stdout.write(".")
                sys.stdout.flush()
                if iwait > wait_time * 60:  # faster for testing
                    raise RuntimeError(
                        "ERROR: ProjectGraph.read() has waited for {} minutes for lock"
                        " directory to disappear. You may want to manually remove the"
                        " file: {}".format(wait_time, fn_lock)
                    )

        if lock_expected:
            iwait = 0
            while not os.path.isfile(fn_lock):
                # If the lock exists: wait 3 seconds and try again
                # First time round, print a warning message
                if iwait == 0:
                    print(
                        "\nWARNING: was expecting a file called {} but it isn't"
                        " there. Will wait for {} minutes to see if it"
                        " appears".format(fn_lock, wait_time)
                    )
                    sys.stdout.write("Waiting...")

                time.sleep(3)
                iwait += 3
                sys.stdout.write(".")
                sys.stdout.flush()
                if iwait > wait_time * 60:
                    raise RuntimeError(
                        "\nERROR: ProjectGraph.read() has waited for {} minutes for"
                        " lock file {} to appear, but it doesn't. This should not "
                        "happen. Is something wrong with disk "
                        "access?".format(wait_time, fn_lock)
                    )

    def remove_lock(self):
        dir_lock = ".relion_lock"
        fn_lock = ".relion_lock/lock_" + self.name + "_pipeline.star"

        if not os.path.isfile(fn_lock):
            print(
                "ERROR: PipeLine::write was expecting a file called {} but it "
                "is no longer there.".format(fn_lock)
            )

        err = subprocess.run(["rm", fn_lock], stderr=subprocess.PIPE).stderr
        if len(err) > 0:
            print(
                "ERROR: PipelineGraph.write()reported error in removing file " + fn_lock
            )

        err = subprocess.run(["rm", "-r", dir_lock], stderr=subprocess.PIPE).stderr
        if len(err) > 0:
            print(
                "ERROR: PipelineGraph.write()reported error in removing directory "
                + dir_lock
            )

    def update_lock_message(self, lock_message):
        fn_lock = ".relion_lock/lock_" + self.name + "_pipeline.star"
        with open(fn_lock, "w") as lockfile:
            lockfile.write(lock_message)

    def read(self, do_lock=False, lock_wait=2):

        pipeline_fname = self.get_pipeline_filename()
        if not os.path.isfile(pipeline_fname):
            raise_error("ERROR: Pipeline file {} not found".format(pipeline_fname))

        # check for a lock - create on is it doesn't exist
        if do_lock and not self.do_read_only:
            self.check_lock(False, wait_time=lock_wait)
            self.create_lock(wait_time=lock_wait)

        #         if not self.is_empty():
        #             print(
        #                 "WARNING: re-reading the pipeline, previous data "
        #                 "will be lost.")
        #               # TODO warning logs
        # This warning is super annoying, will hide for now.
        self.clear()

        doc = cif.read_file(pipeline_fname)

        # read jobCounter
        job_count = int(
            doc.find_block(star_keys.GENERAL_BLOCK).find_value(star_keys.JOB_COUNTER)
        )
        self.job_counter = int(job_count)

        # read nodeList
        node_block = doc.find_block(star_keys.NODE_BLOCK)
        if node_block is not None:
            node_table = node_block.find(star_keys.NODE_PREFIX, star_keys.NODE_SUFFIXES)
            for node_row in node_table:
                self.node_list.append(Node(*node_row))

        # read processList
        proc_block = doc.find_block(star_keys.PROCESS_BLOCK)
        if proc_block is not None:
            process_table = proc_block.find(
                star_keys.PROCESS_PREFIX, star_keys.PROCESS_SUFFIXES
            )
            for process_row in process_table:
                name = process_row[0]
                ptype = process_row[2]
                status = process_row[3]
                alias = process_row[1]
                if alias == "None":
                    alias = None
                self.process_list.append(Process(name, ptype, status, alias))
            # TODO make alias if doesn't exist

        # read input edges
        in_edge_block = doc.find_block(star_keys.INPUT_EDGE_BLOCK)
        if in_edge_block is not None:
            input_edge_table = in_edge_block.find(
                star_keys.INPUT_EDGE_PREFIX, star_keys.INPUT_EDGE_SUFFIXES
            )
            for input_edge_row in input_edge_table:
                node = self.find_node(input_edge_row[0])
                process = self.find_process(input_edge_row[1])
                if node is None:
                    print(
                        "WARNING: creating input edge failed - cannot find "
                        "input node {} for process with name {}".format(
                            input_edge_row[0], input_edge_row[1]
                        )
                    )
                elif process is None:
                    print(
                        "WARNING: creating input edge failed - cannot find parent "
                        "process with name {} for node {}:".format(
                            input_edge_row[1], input_edge_row[0]
                        )
                    )
                else:
                    node.input_for_processes_list.append(process)
                    process.input_nodes.append(node)

        # set out edges
        out_edge_block = doc.find_block(star_keys.OUTPUT_EDGE_BLOCK)
        if out_edge_block is not None:
            output_edge_table = out_edge_block.find(
                star_keys.OUTPUT_EDGE_PREFIX, star_keys.OUTPUT_EDGE_SUFFIXES
            )
            for output_edge_row in output_edge_table:
                process = self.find_process(output_edge_row[0])
                node = self.find_node(output_edge_row[1])
                if node is None:
                    print(
                        "WARNING: creating out edge failed - cannot find child "
                        "node {} from process with name {}".format(
                            output_edge_row[1], output_edge_row[0]
                        )
                    )
                elif process is None:
                    print(
                        "WARNING: creating output edge failed - cannot find parent "
                        "process with name {} for node {}:".format(
                            output_edge_row[0], output_edge_row[1]
                        )
                    )
                else:
                    process.output_nodes.append(node)
                    node.output_from_process = process

    def write(
        self,
        delete_nodes=list(),
        delete_processes=list(),
        lockfile_expected=True,
        lock_wait=2,
    ):
        if self.do_read_only:
            raise RuntimeError("ERROR: Can't modify pipelines in read only mode")

        # make sure the lock file exists as expected
        self.check_lock(lockfile_expected, lock_wait)

        # Prepare a new Gemmi CIF document to hold the output document structure
        doc = cif.Document()

        # Add general block with job counter
        general_block = doc.add_new_block(star_keys.GENERAL_BLOCK)
        general_block.set_pair(star_keys.JOB_COUNTER, str(self.job_counter))

        # Add processes, while keeping track of input and output edges
        input_edges = []
        output_edges = []
        if len(self.process_list) > 0:
            process_block = doc.add_new_block(star_keys.PROCESS_BLOCK)
            process_loop = process_block.init_loop(
                star_keys.PROCESS_PREFIX, star_keys.PROCESS_SUFFIXES
            )
            for process in self.process_list:
                if process not in delete_processes:
                    process_loop.add_row(
                        [
                            process.name,
                            str(process.alias),
                            str(process.type),
                            str(process.status),
                        ]
                    )
                    for node in process.input_nodes:
                        # added 2nd condition to prevent duplication of nodes
                        if (
                            node not in delete_nodes
                            and (node.name, process.name) not in input_edges
                        ):
                            input_edges.append((node.name, process.name))
                    for node in process.output_nodes:
                        # added 2nd condition to prevent duplication of nodes
                        if (
                            node not in delete_nodes
                            and (process.name, node.name) not in output_edges
                        ):
                            output_edges.append((process.name, node.name))
                else:
                    for badnode in process.output_nodes:
                        if badnode not in delete_nodes:
                            delete_nodes.append(badnode)
        # Add nodes
        # TODO: check consistency of input and output edges?
        if len(self.node_list) > 0:
            node_block = doc.add_new_block(star_keys.NODE_BLOCK)
            node_loop = node_block.init_loop(
                star_keys.NODE_PREFIX, star_keys.NODE_SUFFIXES
            )
            for node in self.node_list:
                if node not in delete_nodes:
                    node_loop.add_row([node.name, str(node.type)])

        # Add input edges
        if len(input_edges) > 0:
            input_edge_block = doc.add_new_block(star_keys.INPUT_EDGE_BLOCK)
            input_edge_loop = input_edge_block.init_loop(
                star_keys.INPUT_EDGE_PREFIX, star_keys.INPUT_EDGE_SUFFIXES
            )
            for input_edge in input_edges:
                input_edge_loop.add_row(input_edge)

        # Add output edges
        if len(output_edges) > 0:
            output_edge_block = doc.add_new_block(star_keys.OUTPUT_EDGE_BLOCK)
            output_edge_loop = output_edge_block.init_loop(
                star_keys.OUTPUT_EDGE_PREFIX, star_keys.OUTPUT_EDGE_SUFFIXES
            )
            for output_edge in output_edges:
                output_edge_loop.add_row(output_edge)

        # Write the file
        pipeline_fname = self.get_pipeline_filename()
        star_writer.write(doc, pipeline_fname)

        # remove files for deleted nodes if they havn't already been removed
        for badnode in delete_nodes:
            if os.path.isfile(badnode.name):
                subprocess.run(["rm", badnode.name])
        for badproc in delete_processes:
            if os.path.isdir(badproc.name):
                subprocess.run(["rm", "-rf", badproc.name])

        # remove the lock file
        if lockfile_expected:
            self.remove_lock()
        return True

    def find_immediate_child_processes(self, process):
        """Find just the immediate child processes of process"""
        children = []
        parent_proc = process.name
        for proc in self.process_list:
            innodes = [os.path.dirname(x.name) + "/" for x in proc.input_nodes]
            if parent_proc in innodes:
                children.append(proc)
        return children

    def downstream_process_graph(self, process):
        """Find the full child processes of a job and return a dict"""
        associated_procs = [process]
        print("Drawing downstream process graph for " + process.name)
        # find the children
        edges_list = []
        for proc in self.process_list:
            for node in proc.input_nodes:
                if (
                    node.output_from_process in associated_procs
                    and proc not in associated_procs
                ):
                    associated_procs.append(proc)
                    edge = (
                        node.type,
                        node.output_from_process.name,
                        proc.name,
                        self.get_edge_label(node),
                    )
                    if edge not in edges_list:
                        edges_list.append(edge)

        # now do it again backwards to find the parents
        for proc in reversed(self.process_list):
            for node in proc.input_nodes:
                if node.output_from_process in associated_procs:
                    # get the node type from its source and assign color
                    actual = node.output_from_process.output_nodes.index(node)
                    color_node = node.output_from_process.output_nodes[actual]
                    edge = (
                        color_node.type,
                        color_node.output_from_process.name,
                        proc.name,
                        self.get_edge_label(node),
                    )
                    if edge not in edges_list:
                        edges_list.append(edge)

                    if proc not in associated_procs:
                        associated_procs.append(proc)
        return self.show_process_graph(edges_list, process.name, "child")

    def upstream_process_graph(self, process):
        """Find the parent processes of a job and return a dict"""
        associated_procs = [process]
        print("Drawing upstream process graph for " + process.name)
        # find the children
        edges_list = []
        all_nodes = []
        # get all the nodes that contributed to the job
        con_node_list = []
        cn_count2, cn_count1 = 1, 0
        while cn_count2 > cn_count1:
            cn_count1 = len(con_node_list)
            for proc in associated_procs:
                for node in proc.input_nodes:
                    if node not in con_node_list:
                        con_node_list.append(node)
                    if node.output_from_process not in associated_procs:
                        associated_procs.append(node.output_from_process)
            cn_count2 = len(con_node_list)

        # get the processes that produced them
        for node in con_node_list:
            for into_proc in node.input_for_processes_list:
                if into_proc in associated_procs:
                    edges_list.append(
                        [
                            node.type,
                            node.output_from_process.name,
                            into_proc.name,
                            self.get_edge_label(node),
                        ]
                    )
                    for a_node in [node.output_from_process.name, into_proc.name]:
                        if a_node not in all_nodes:
                            all_nodes.append(a_node)
        return self.show_process_graph(edges_list, process.name, "parent")

    def full_process_graph(self):
        """Find the parent processes of a job and return a dict"""
        print("Drawing full process graph")
        # find the children
        edges_list = []
        all_nodes = []
        # get all the nodes
        con_node_list = []
        cn_count2, cn_count1 = 1, 0
        while cn_count2 > cn_count1:
            cn_count1 = len(con_node_list)
            for proc in reversed(self.process_list):
                for node in proc.input_nodes:
                    if node not in con_node_list:
                        con_node_list.append(node)
            cn_count2 = len(con_node_list)

        # get the processes that produced them
        for node in con_node_list:
            for into_proc in node.input_for_processes_list:
                edges_list.append(
                    [
                        node.type,
                        node.output_from_process.name,
                        into_proc.name,
                        self.get_edge_label(node),
                    ]
                )
                for a_node in [node.output_from_process.name, into_proc.name]:
                    if a_node not in all_nodes:
                        all_nodes.append(a_node)

        # count the number of processes in the final graph
        return self.show_process_graph(edges_list, None, None)

    def show_process_graph(self, edges_list, procname, ntype):
        """Draw a flowchart for a single process with all its parents and children"""

        # explicitly define graph to get colors right
        g = nx.DiGraph()
        if len(edges_list) == 0:
            print(
                "ERROR: No {} processes found for this job."
                " Cannot draw graph".format(ntype)
            )
            return False
        for edge in edges_list:
            g.add_edge(edge[1], edge[2], color=NODES_COLORS[edge[0]], itemcount=edge[3])
        edges = g.edges()
        edges_labels = nx.get_edge_attributes(g, "itemcount")
        colors = [g[u][v]["color"] for u, v in edges]
        layout = nx.layout.kamada_kawai_layout(g)
        self.optimize_graph_layout(layout)

        # color and shape the nodes
        if procname is not None:
            title = "{} processes for job {}".format(ntype, procname)
            node_list = list(g.nodes)
            proc_index = node_list.index(procname)
            color_list = [(0.5, 0.5, 0.5)] * (proc_index)
            color_list.append((1, 0, 0))
            fwdlist = [(0.5, 0.5, 0.5)] * (len(node_list[proc_index:]) - 1)
            color_list.extend(fwdlist)

            nodesize_list = [50] * (proc_index)
            nodesize_list.append(250)
            fwdlist = [50] * (len(node_list[proc_index:]) - 1)
            nodesize_list.extend(fwdlist)

        else:
            title = "Full pipeline"
            color_list = [(0.5, 0.5, 0.5)]
            nodesize_list = 50

        # draw the network graph
        nx.draw(
            g,
            pos=layout,
            node_size=nodesize_list,
            node_color=color_list,
            font_size=6,
            with_labels=True,
            min_source_margin=0,
            min_target_margin=0,
            horizontalalignment="center",
            verticalalignment="top",
            font_weight="bold",
            connectionstyle="arc3,rad=0.1",
            edge_color=colors,
            arrows=True,
        )

        # draw the labels
        nx.draw_networkx_edge_labels(
            g, pos=layout, edge_labels=edges_labels, font_size=4, bbox=dict(alpha=0),
        )

        # draw the legend
        legend_lines = [
            Line2D([0], [0], color=(0.75, 0.75, 0.75), lw=2),
            Line2D([0], [0], color=(1, 0, 1), lw=2),
            Line2D([0], [0], color=(0, 0, 1), lw=2),
            Line2D([0], [0], color=(0, 1, 1), lw=2),
            Line2D([0], [0], color=(1, 0, 0), lw=2),
            Line2D([0], [0], color=(0, 1, 0), lw=2),
            Line2D([0], [0], color=(1, 1, 0), lw=2),
        ]
        plt.title(title)
        plt.legend(
            legend_lines,
            (
                "micrographs",
                "coordinates",
                "particles",
                "classes",
                "map",
                "mask",
                "halfmap",
            ),
        )

        plt.show()
        return True

    def get_edge_label(self, node):
        nodetype = node.type
        nodefile = node.name
        data_labels = {0: "movies", 1: "micrographs", 3: "particles"}
        if nodetype in data_labels:
            try:
                starfile = cif.read_file(nodefile)
                datablock = starfile.find_block(data_labels[nodetype])
                loop = datablock.find_loop("_rlnOpticsGroup")
                return str(len(loop))
            except Exception:
                return "n/a"
        else:
            return ""

    def optimize_graph_layout(self, layout):
        """Try to make the network graph look nice without overlapping nodes"""
        xrange = (
            min([layout[x][0] for x in layout]),
            max([layout[x][0] for x in layout]),
        )
        yrange = (
            min([layout[x][1] for x in layout]),
            max([layout[x][1] for x in layout]),
        )

        # get all the combinations of the points
        combs = list(combinations(layout, 2))

        # calculate horizontal and vertical distances between the points
        ydists, xdists = {}, {}
        for pair in combs:
            x1, y1 = layout[pair[0]][0], layout[pair[0]][1]
            x2, y2 = layout[pair[1]][0], layout[pair[1]][1]
            xdists[pair] = abs(x1 - x2)
            ydists[pair] = abs(y1 - y2)

        min_v_dist = 0.05 * (abs(yrange[0]) + abs(yrange[1]))
        min_h_dist = 0.05 * (abs(xrange[0]) + abs(xrange[1]))

        # check the nodes make sure none are overlapping in x and y
        # if they are move the higher one one up the min distance
        # sort the nodes by height start at the top
        layout_keys = list(layout)
        layout_keys.sort(key=lambda x: layout[x][1], reverse=True)
        done_pairs = []
        # if a node is too close move it
        for node in layout_keys:
            for comb in combs:
                if (
                    node in comb
                    and xdists[comb] < min_h_dist
                    and ydists[comb] < min_v_dist
                    and comb not in done_pairs
                ):
                    old_y = layout[node][1]
                    layout[node][1] = old_y + min_v_dist
                    done_pairs.append(comb)
                    # and move every node above it up as well
                    for other_node in layout:
                        if layout[other_node][1] > old_y:
                            layout[other_node][1] = layout[other_node][1] + min_v_dist

        return layout

    def remake_node_directory(self):
        if self.do_read_only:
            return False

        # clear existing dir
        subprocess.run(["rm", "-rf", NODES_DIR])
        subprocess.run(["mkdir", NODES_DIR])

        # remake nodes
        for node in self.node_list:
            myproc = node.output_from_process
            if myproc not in self.process_list:
                touch_if_not_exists = False
            else:
                touch_if_not_exists = bool(myproc.status == 1)

            self.touch_temp_node_file(node, touch_if_not_exists)

        # set permissions
        if len(os.listdir(NODES_DIR)) > 0:
            subprocess.run(["chmod", "-R", "777", NODES_DIR])

    def get_output_nodes_from_starfile(self, process):
        outnodes = os.path.join(process.name, "RELION_OUTPUT_NODES.star")

        if os.path.isfile(outnodes):
            on_file = OutputNodeStar(outnodes)
            nodes = on_file.get_output_nodes()
            for fnode in nodes:
                # check if node is already on the list and create if not
                if not self.find_node(fnode[0]):
                    node_to_add = Node(fnode[0], int(fnode[1]))
                    self.add_new_output_edge(process, node_to_add)

    def check_process_completion(self):
        self.read(do_lock=True)

        finished, failed, aborted = [], [], []
        for proc in self.process_list:
            if proc.status == STATUS["running"]:
                if os.path.isfile(os.path.join(proc.name, "RELION_JOB_EXIT_SUCCESS")):
                    finished.append(proc)
                if os.path.isfile(os.path.join(proc.name, "RELION_JOB_EXIT_FAILURE")):
                    failed.append(proc)
                if os.path.isfile(os.path.join(proc.name, "RELION_JOB_EXIT_ABORTED")):
                    aborted.append(proc)

        # gather the changes
        lock_message = ""
        changes = len(finished) + len(failed) + len(aborted)
        if changes:
            outcomes = {
                "successfully finished:\n": finished,
                "failed with an error:\n": failed,
                "been aborted:\n": aborted,
            }
            msg = "check_process_completion: the following jobs have "
            for outcome in outcomes:
                if len(outcomes[outcome]) > 0:
                    lock_message += msg + outcome
                    for proc in outcomes[outcome]:
                        lock_message += proc.name + "\n"

        # only do a read/write cycle if some processes' statuses have changed
        if os.path.isfile("PIPELINE_HAS_CHANGED") or changes:
            self.update_lock_message(lock_message)
        else:
            self.remove_lock()
            return False

        # set the statuses of the newly finished processes
        for proc in finished:
            proc.status = STATUS["finished_success"]
            # check if there was an output nodes starfile
            self.get_output_nodes_from_starfile(proc)

            # make any output nodes
            if len(proc.output_nodes) == 0:
                print(
                    "ERROR: The output nodes list for job"
                    " {} is empty".format(proc.name)
                )

            for node in proc.output_nodes:
                if os.path.isfile(node.name):
                    self.touch_temp_node_file(node, False)
                else:
                    print(
                        "WARNING: output node {} does not exist"
                        " while job {} should have finished "
                        "You can manually mark this job as failed"
                        " to suppress this message.".format(node.name, proc.name)
                    )
        for proc in failed:
            proc.status = STATUS["finished_failure"]

        for proc in aborted:
            proc.status = STATUS["finished_aborted"]

        # write and remove changed status
        self.write()
        if os.path.isfile("PIPELINE_HAS_CHANGED"):
            subprocess.run(["rm", "PIPELINE_HAS_CHANGED"])
        return True

    def mark_as_finished(self, the_proc, is_failed, is_aborted, is_running=False):
        # read in the existing pipeline - get the process
        self.read(do_lock=True)
        the_proc = self.find_process(the_proc.name)

        lock_message = "Marking process {} as finished".format(the_proc.name)
        self.update_lock_message(lock_message)

        # remove any existing control files
        for control_file in [
            "RELION_JOB_EXIT_FAILED",
            "RELION_JOB_EXIT_ABORTED",
            "RELION_JOB_EXIT_SUCCESS",
        ]:
            control_file_path = os.path.join(the_proc.name, control_file)
            if os.path.isfile(control_file_path):
                subprocess.run(["rm", control_file_path])

        if is_failed:
            the_proc.status = STATUS["finished_failure"]
            subprocess.run(
                ["touch", os.path.join(the_proc.name, "RELION_JOB_EXIT_FAILED")]
            )

        elif is_aborted:
            # check that the job is running.  Only set currently running jobs
            # as aborted
            if the_proc.status != STATUS["running"]:
                self.remove_lock()
                raise_error(
                    "ERROR: Only currently running job can be marked as aborted"
                )
            the_proc.status = STATUS["finished_aborted"]
            subprocess.run(
                ["touch", os.path.join(the_proc.name, "RELION_JOB_EXIT_ABORTED")]
            )

        # this isn't used by the pipeliner, just there for testing
        elif is_running:
            the_proc.status = STATUS["running"]

        else:
            the_proc.status = STATUS["finished_success"]
            subprocess.run(
                ["touch", os.path.join(the_proc.name, "RELION_JOB_EXIT_SUCCESS")]
            )

        # for refine jobs add optimiser, data.star, model.star, and class???.mrc
        # to the pipeline

        if the_proc.type in [
            PROCS["Class2D"],
            PROCS["Class3D"],
            PROCS["Refine3D"],
            PROCS["InitialModel"],
        ]:
            # get the last iteration of the optimier file
            if the_proc.alias is None:
                fn_root1 = the_proc.name
            else:
                fn_root1 = the_proc.alias

            fn = fn_root1 + "run_ct???_it???_optimiser.star"
            fn_opts = glob(fn)

            if len(fn_opts) == 0:
                fn = fn_root1 + "run_ct??_it???_optimiser.star"
                fn_opts = glob(fn)

            if len(fn_opts) == 0:
                fn = fn_root1 + "run_ct?_it???_optimiser.star"
                fn_opts = glob(fn)

            if len(fn_opts) == 0:
                fn = fn_root1 + "run_it???_optimiser.star"
                fn_opts = glob(fn)

            if len(fn_opts) != 0:
                fn_opts.sort()
                fn_opt = fn_opts[-1]

                opt_node = Node(fn_opt, NODES["Optimiser"])
                opt_node.output_from_process = the_proc
                self.add_node(opt_node)
                self.add_new_output_edge(the_proc, opt_node)

                # also add data.star
                fn_data = fn_opt.replace("optimiser", "data")
                data_node = Node(fn_data, NODES["Part data"])
                data_node.output_from_process = the_proc
                self.add_node(data_node)
                self.add_new_output_edge(the_proc, data_node)

                fn_root = fn_opt.replace("optimiser.star", "")
                if the_proc.type == PROCS["Refine3D"]:
                    fn_root += "_half1"

                fn_model = fn_root + "model.star"
                mod_node = Node(fn_model, NODES["Model"])
                mod_node.output_from_process = the_proc
                self.add_node(mod_node)
                self.add_new_output_edge(the_proc, mod_node)

                fn_map = fn_root + "class???.mrc"
                fn_maps = glob(fn_map)
                if len(fn_maps) > 0:
                    for m in fn_maps:
                        map_node = Node(m, NODES["3D refs"])
                        map_node.output_from_process = the_proc
                        self.add_node(map_node)
                        self.add_new_output_edge(the_proc, map_node)
            else:
                print(
                    "You are trying to mark a relion_refine job as finished that"
                    " hasn't even started. \n This will be ignored. Perhaps you "
                    "wanted to delete it instead?"
                )
                the_proc.status = STATUS["running"]
                self.write()
                return False

        # check for output nodes star file
        self.get_output_nodes_from_starfile(the_proc)

        # remove any of the corresponding output nodes if the files don't exist
        for outnode in the_proc.output_nodes:
            if not os.path.isfile(outnode.name):
                the_proc.output_nodes.remove(outnode)

        self.write()
        return True

    def delete_job(self, this_job, do_recursive):

        self.read(do_lock=True)
        # get the processes and nodes to delete
        this_job = self.find_process(this_job.name)

        # update the lock message
        lock_message = "Deleting process {} ".format(this_job)
        if do_recursive:
            lock_message += "and child jobs"
        self.update_lock_message(lock_message)

        # make the list of jobs to delete
        del_processes = [this_job]
        del_nodes = this_job.output_nodes
        if do_recursive:
            for proc in self.process_list:
                del_this_proc = False
                for node in proc.input_nodes:
                    if node in del_nodes and proc not in del_processes:
                        del_processes.append(proc)
                        del_this_proc = True
                if del_this_proc:
                    for onode in proc.output_nodes:
                        if onode not in del_nodes:
                            del_nodes.append(onode)

        # move the processes to the trash
        for delproc in del_processes:
            proctype = PROC_NAMES[delproc.type]
            trashdir = "Trash/" + proctype + "/"
            subprocess.run(["mkdir", "-p", trashdir])
            subprocess.run(["mv", delproc.name[:-1] + "/", trashdir])
            if delproc.alias is not None:
                subprocess.run(["unlink", delproc.alias[:-1]])
            ## remove the process from the process list..
            self.process_list.remove(delproc)

        # remove the nodes dir
        self.remake_node_directory()

        # update the pipeline file
        self.write(del_nodes, del_processes)

    def set_job_alias(self, this_job, new_alias):
        # make sure job is vaild
        self.read()
        fn_pre, fn_jobnr = decompose_pipeline_filename(this_job.name)[0:2]
        if fn_pre == "" or fn_jobnr == "":
            raise_error("ERROR: invalid pipeline process" " name: " + this_job.name)

        if new_alias is None or len(new_alias) == 0:
            new_alias = None

        if new_alias is not None:
            # replace any spaces
            if " " in new_alias:
                new_alias = new_alias.replace(" ", "_")
                print(
                    "WARNING: No spaces are permitted in aliases. New alias"
                    " changed to {}".format(new_alias)
                )

            # check the alias name rules
            if new_alias == "None":
                raise_error("ERROR: New alias cannot be 'None'")

            if len(new_alias) < 2:
                raise_error(
                    "ERROR: Alias cannot be fewer than two characters"
                    ", please provide another one"
                )

            if new_alias[:3] == "job":
                raise_error(
                    "ERROR: Alias cannot begin with 'job', please provide another one"
                )
            check_for_illegal_symbols(new_alias, "alias")

            # add the trailing slash
            new_alias = new_alias + "/"
            for proc in self.process_list:
                if proc.alias == fn_pre + "/" + new_alias:
                    raise_error("Alias is not unique, please provide another one")

        # read in the pipeline
        self.read(do_lock=True)
        this_job = self.find_process(this_job.name)

        # update the lock message
        lock_message = "Updating alias for {} to {}".format(this_job.name, new_alias)
        self.update_lock_message(lock_message)

        # remove the existing .Nodes entry
        self.delete_temp_node_files(this_job)

        # unlink the alias
        if this_job.alias is not None:
            if os.path.isdir(this_job.alias):
                subprocess.run(["unlink", this_job.alias[:-1]])

        if new_alias is None:
            this_job.alias = None
        else:
            # set alias in pipline
            this_job.alias = fn_pre + "/" + new_alias
            # make new symlink - relative the the jobdir
            if not os.path.isdir(".Nodes"):
                os.makedirs(".Nodes")
            os.symlink(
                os.path.relpath(this_job.name[:-1], ".Nodes"), this_job.alias[:-1]
            )

        # remake new nodes entry
        self.touch_temp_node_files(this_job)

        # rewrite the pipeline
        self.write()
        return True

    def undelete_job(self, del_job):
        # reread the pipeline
        self.read(do_lock=True)
        trashed_procs = [del_job]
        restore_procs = list()

        # get current aliases to make sure none are duplicated
        curr_proclist_aliases = [x.alias for x in self.process_list]

        for del_proc in trashed_procs:
            del_proc_dir = os.path.join("Trash", del_proc)

            # find other process that inputed in and may have also been deleted
            if del_proc not in self.process_list and os.path.isdir(del_proc_dir):
                del_proc_pipe = ProjectGraph(name=del_proc_dir + "job")
                del_proc_pipe.read()
                the_process = del_proc_pipe.process_list[0]
                for node in the_process.input_nodes:
                    fn_pre, fn_jobnr = decompose_pipeline_filename(node.name)[0:2]
                    inproc = fn_pre + "/" + "job{:03d}".format(fn_jobnr) + "/"
                    if inproc not in trashed_procs:
                        trashed_procs.append(inproc)

                    # restore the alias if it exists - check for duplication
                    the_alias = the_process.alias
                    if the_alias not in curr_proclist_aliases:
                        the_process.alias = the_alias
                    elif the_alias is not None:
                        print(
                            "WARNING: Cannot restore alias {} for {} because"
                            " this would create a duplicate "
                            "alias".format(the_alias, the_process.name)
                        )
                        the_process.alias = None
                restore_procs.append(the_process)

        print("The following processes will be restored:")
        lock_message = "The following processes will be restored:\n"
        # reverse so they write in the right order
        restore_procs.reverse()
        for rproc in restore_procs:
            # put the process back in the pipeline
            print(rproc.name, " alias: ", rproc.alias)
            lock_message += rproc.name + " alias: " + str(rproc.alias) + "\n"
            self.process_list.append(rproc)
            # put the nodes back in the pipeline
            for onode in rproc.output_nodes:
                if onode.name not in self.node_list:
                    self.node_list.append(onode)
            # restore the files
            proc_pre = decompose_pipeline_filename(rproc.name)[0]
            subprocess.run(["mkdir", "-p", proc_pre])
            subprocess.run(["mv", "Trash/" + rproc.name, proc_pre])
            # restore the alias if it exists
            if rproc.alias is not None:
                subprocess.run(["ln", "-s", rproc.name[:-1], rproc.alias[:-1]])

        self.update_lock_message(lock_message)
        self.write()
        self.remake_node_directory()

    def clean_up_job(self, this_job, do_harsh):
        print("Cleaning up " + this_job.name)

        if this_job.status != STATUS["finished_success"]:
            print("you can only clean up finished jobs ... ")
            return False

        # following jobs hav have no cleanup
        no_cleanup = [
            PROCS["Import"],
            PROCS["ManualPick"],
            PROCS["Select"],
            PROCS["MaskCreate"],
            PROCS["JoinStar"],
            PROCS["LocalRes"],
            PROCS["External"],
        ]
        if this_job.type in no_cleanup:
            return True

        # get all of the subdirs
        subdirs = [x[0] for x in os.walk(this_job.name, topdown=False)]
        subdirs.remove(this_job.name)
        del_files = list()
        del_dirs = list()

        # Motioncorr jobs
        if this_job.type == PROCS["MotionCorr"]:
            for sd in subdirs:
                if do_harsh:
                    # remove entire movies dir
                    del_dirs.append(sd)
                else:
                    exts = ["/*.com", "/*.err", "/*.out", "/*.log"]
                    for ext in exts:
                        del_files += glob(sd + ext)

        # CtfFind
        elif this_job.type == PROCS["CtfFind"]:
            exts = ["gctf*.out", "gctf*.err"]
            for ext in exts:
                del_files += glob(this_job.name + ext)
            for sd in subdirs:
                # remove all Micrographs dir strcture
                del_dirs.append(sd)

        # Autopick
        elif this_job.type == PROCS["AutoPick"]:
            for sd in subdirs:
                del_files += glob(sd + "/*.spi")

        # Extract
        elif this_job.type == PROCS["Extract"]:
            for sd in subdirs:
                if do_harsh:
                    # remove everything star files and particle stacks
                    del_dirs.append(sd)
                else:
                    # only remove starfiles with metadata
                    del_files += glob(sd + "/*_extract.star")

        # Refine based processes
        elif this_job.type in [
            PROCS["Refine3D"],
            PROCS["Class3D"],
            PROCS["Class2D"],
            PROCS["InitialModel"],
            PROCS["MultiBody"],
        ]:
            search_strings = [
                "/run_it*_data.star",
                "/run_ct?_it*_data.star",
                "/run_ct??_it*_data.star",
                "/run_ct???_it*_data.star",
            ]
            all_datafiles = list()
            for sstring in search_strings:
                all_datafiles += glob(this_job.name + sstring)

            # identify data files used in pipeline - keep them
            # otherwise delete all but last iteration
            used_nodes = [x.name for x in self.node_list]
            for df in all_datafiles[:-1]:
                if df not in used_nodes:
                    del_files += glob(df.replace("_data.star", "*"))

            # Also clean up maps for PCA movies when doing harsh cleaning
            if this_job.type == PROCS["MultiBody"] and do_harsh:
                del_files += glob(this_job.name + "analyse_component*_bin*.mrc")

        # CTF refine
        elif this_job.type == PROCS["CtfRefine"]:
            exts = ["/*_wAcc.mrc", "/*_xyAcc_real.mrc", "/*_xyAcc_imag.mrc"]
            for sd in subdirs:
                for ext in exts:
                    del_files += glob(sd + ext)
        # Motion Refine
        elif this_job.type == PROCS["Polish"]:
            exts = ["/*_FCC_cc.mrc", "/*_FCC_w0.mrc", "/*_FCC_w1.mrc"]
            for sd in subdirs:
                for ext in exts:
                    del_files += glob(sd + ext)
                if do_harsh:
                    del_files += glob(sd + "/*_shiny.star")
                    del_files += glob(sd + "/*_shiny.mrcs")

        # subtraction jobs
        elif this_job.type == PROCS["Subtract"]:
            if do_harsh:
                del_files += glob(this_job.name + "subtracted.*")

        # post process
        elif this_job.type == PROCS["PostProcess"]:
            del_files += glob(this_job.name + "*masked.mrc")

        else:
            print(
                "ERROR: job {} jobtype {} not found".format(
                    this_job.name, this_job.type
                )
            )

        # Then move everything to the trash:
        for ddir in del_dirs:
            trash_dir = "Trash/" + ddir
            subprocess.run(["mkdir", "-p", trash_dir])
            trash_1up = os.path.dirname(trash_dir)
            subprocess.run(["mv", ddir, trash_1up])
        for dfile in del_files:
            trash_name = "Trash/" + dfile
            trash_dir = os.path.dirname(trash_name)
            if not os.path.isdir(trash_dir):
                subprocess.run(["mkdir", "-p", trash_dir])
            subprocess.run(["mv", dfile, trash_dir])

        return True

    def cleanup_all_jobs(self, do_harsh):
        finished_jobs = list()
        for job in self.process_list:
            if job.status == STATUS["finished_success"]:
                finished_jobs.append(job)

        if do_harsh:
            for job in finished_jobs:
                if not os.path.isfile(os.path.join(job.name, "NO_HARSH_CLEAN")):
                    self.clean_up_job(job, True)
                else:
                    print(
                        "WARNING: Did not harsh clean job {} because "
                        "it has been protected.".format(job.name)
                    )
        else:
            for job in finished_jobs:
                self.clean_up_job(job, False)
        return True

    def replace_files_for_import_export_of_sched_jobs(
        self, fn_in_dir, fn_out_dir, find_pattern, replace_pattern,
    ):

        subprocess.run(["mkdir", "-p", fn_out_dir])
        my_files = ["run.job", "note.txt", "job_pipeline.star"]
        for the_file in my_files:
            fn = os.path.join(fn_in_dir, the_file)
            if os.path.isfile(fn):
                with open(fn) as f:
                    data = f.read()
                data = data.replace(find_pattern, replace_pattern)
                outfile = os.path.join(fn_out_dir, the_file)
                with open(outfile, "w") as out_file:
                    out_file.write(data)

    def export_all_scheduled_jobs(self, mydir):
        if mydir[-1] != "/":
            mydir += "/"

        export_star = cif.Document()
        export_star_name = "ExportJobs/" + mydir + "exported.star"
        block = export_star.add_new_block("")
        loop = block.init_loop("_", ["rlnPipeLineProcessName"])

        iexp = 0
        self.read(do_lock=False)
        for proc in self.process_list:
            if proc.status == STATUS["scheduled"]:
                iexp += 1
                if str(proc.alias) != "None":
                    print(
                        "WARNING: aliases are not allowed on Scheduled jobs that are"
                        " to be exported!\n- Removing the alias {} from {} for the "
                        "export".format(proc.alias, proc.name)
                    )
                    proc.alias = None
                expname = proc.name.split("/")[0] + "/exp{:03d}".format(iexp) + "/"
                find_pattern = proc.name
                proc.name = expname
                loop.add_row([proc.name])
                self.replace_files_for_import_export_of_sched_jobs(
                    find_pattern,
                    "ExportJobs/" + mydir + expname,
                    find_pattern,
                    expname,
                )
        if iexp > 0:
            subprocess.run(["mkdir", "-p", "ExportJobs/" + mydir])
            star_writer.write(export_star, export_star_name)
            return True

        else:
            print("WARNING: There were no scheduled jobs found to export.")
            return False

    def import_jobs(self, fn_export):
        self.read(do_lock=True)

        fn_export_dir = os.path.dirname(fn_export)
        imported_jobs = ExportStar(fn_export)
        ijobs = list(imported_jobs.jobs.find_loop("_rlnPipeLineProcessName"))
        for ijob in ijobs:
            ijob_pipe = ProjectGraph(name=fn_export_dir + "/" + ijob + "job")
            ijob_pipe.read(do_lock=False)
            for iproc in ijob_pipe.process_list:
                new_name = PROC_NAMES[iproc.type] + "/job{:03d}/".format(
                    self.job_counter
                )
                self.job_counter += 1
                self.replace_files_for_import_export_of_sched_jobs(
                    fn_export_dir + "/" + iproc.name, new_name, iproc.name, new_name,
                )

                for node in ijob_pipe.node_list:
                    node.name = node.name.replace(iproc.name, new_name)
                    if self.find_node(node.name) not in self.node_list:
                        self.node_list.append(node)
                for proc in ijob_pipe.process_list:
                    proc.name = new_name
                    self.process_list.append(proc)
        self.write()

    """
    COMPLETED MARKED BY "*", alternatives completed marked by "-":

    bool setAliasJob(int this_job, string alias, string &error_message)

    * void addNewInputEdge(Node &node, long int input_for_process)
    * void addNewOutputEdge(long int output_from_process, Node &node)

    * long int addNode(Node &node, bool touch_if_not_exist=false)
    * long int addNewProcess(Process &process, bool do_overwrite=false)

    - long int findNodeByName(string name)
        - replaced with findNode
    - long int findProcessByName(string name)
    - long int findProcessByAlias(string name)
        - both replaced just by findProcess

    * bool touchTemporaryNodeFile(Node &node, bool touch_even_if_not_exitst=false)
    * void touchTemporaryNodeFiles(Process &process)

    *void deleteTemporaryNodeFile(Node &node)
    *void deleteTemporaryNodeFiles(Process &process)

    * void remakeNodeDirectory()

    * bool checkProcessCompletion()
    * bool markAsFinishedJob(int this_job, string &error_message)

    * bool get CommandLineJob(RelionJob &thisjob, int current_job,
                            bool is_main_continue, bool is_scheduled, bool do_makedir,
                            vector<string> &commands, string &final_command,
                            string &error_message)

    * long int addJob(RelionJob &job, int as_status, bool do_overwrite)
    * bool runJob(RelionJob &job, int &current_job,
                bool only_schedule, bool is_main_continue, bool is_scheduled,
                string &error_message)

    * int addScheduledJob(string job_type, string fn_options)
    * int addScheduledJob(int job_type, string fn_options)
    * void runScheduledJobs(FileName fn_sched, FileName fn_jobids, int nr_repeat,
                            long int minutes_wait,
                            long int minutes_wait_before=0,
                            long int seconds_wait_afer=10)
    -void deleteJobGetNodesAndProesses(int this_job, bool do_recturive,
                                vector<bool> &deleteNodes,
                                vector<bool> &deleteProcesses)
    -void deleteNodesAndProcesses(vector<bool> &deleteNodes,
                                 vector<bool> &deleteProcesses)
    -combined these two into  a single function

    * bool SetAliasJob(int this_job, std::string alias, std::string &error_message)

    - void undeleteJob(FileName fn_undel)
    - added restoration of the alias (assuming it doesn't create a duplicate)

    * bool cleanupJob(int this_job, bool do_harsh, string &error_message)
    * bool cleanupAllJobs(bool do_hars, string &error_message)

    - makeFlowChart(long it current_job, bool do_display_pdf, string &error_message)
        - replaced by Pandas Framework visualisation for now TODO needs better graph

    -void replaceFilesForImportExportOfScheduledJobs(Filename fn_in_dir,
                FileName fn_out_dir,
                vector<string> &find_pattern,
                vector<string> &replace_pattern)
    -bool exportAllScheduledJobs(string mydir, string &error_message)
    void importJobs(FileName fn_export)
    bool importPipeline(string name)

    * void write(bool do_lock=false, Filename  fn_del="",
                vector<bool> deleteNode=vector<bool>(),
                vector<bool> deleteProcess=vector<bool>(),
    * void read(bool do_loc=false, string lock_message="Undefined lock message")

    """
