import subprocess
import time
import os
from datetime import datetime, timedelta
from glob import glob

from .data_structure import PROCS
from .project_graph import ProjectGraph
from .relion_jobs import job_factory
from .utils import date_time_tag, raise_error
from pipeliner.utils import decompose_pipeline_filename
from pipeliner.data_structure import NODES, Node


class JobRunner(object):
    def __init__(self, project_name="default"):
        self.graph = ProjectGraph(project_name)
        if os.path.isfile(project_name + "_pipeline.star"):
            self.graph.read()

    def get_commandline_job(
        self,
        thisjob,
        current_job,
        is_main_continue,
        is_scheduled,
        do_makedir,
        overwrite=False,
        subsequent_scheduled=False,
    ):

        # if it was overwrite get info on the job being overwritten
        if overwrite:
            if current_job.name is None:
                raise_error(
                    "ERROR: Trying to overwrite an existing job that does not "
                    "exist".format()
                )
            original_jobtype, target_job = decompose_pipeline_filename(
                current_job.name
            )[0:2]

        # if as job is a subsequent run of a scheduled job
        # it will have read the pipeline again so it needs to use the original
        # job number and not the latest one in the pipeline
        elif subsequent_scheduled:
            target_job = decompose_pipeline_filename(current_job.name)[1]

        # otherwise make a new incremental job number
        else:
            target_job = self.graph.job_counter

        # set the name of the job - new jobs have no name
        if (
            is_main_continue or is_scheduled or overwrite
        ) and current_job in self.graph.process_list:
            name = current_job.name
        else:
            name = ""

        # get the command for the job
        thisjob.is_continue = is_main_continue
        final_command = thisjob.get_commands(name, do_makedir, target_job)

        if overwrite:
            # check the job is the same type as the one it replaces
            thisjob_type = decompose_pipeline_filename(thisjob.output_name)[0]
            if thisjob_type != original_jobtype:
                raise_error(
                    "ERROR: A job can only be overwritten by the same job type.\n"
                    "Attempted to overwrite a {} job with a {} "
                    "job".format(original_jobtype, thisjob_type)
                )
        # make sure a command was returned
        if final_command is None:
            print("\n\nERROR: nothing to do...")
            exit(1)
        return final_command

    def check_plugin_job_has_finished(self, job):
        """if job type is plugin and submit_to_queue is False
        check the expected outputs and make sure they exist
        if the subprocess.run has finished and no files have appeared wait for
        a few sec, check again then mark the job Failed."""
        wait_time = 30
        wait_count = 0
        job_is_success = False
        expected_output_files = [x.name for x in job.output_nodes]

        while not job_is_success and wait_count < wait_time:
            files_count = 0
            for f in expected_output_files:
                if os.path.isfile(f):
                    files_count += 1
            if files_count >= len(expected_output_files):
                job_is_success = True
                subprocess.run(
                    ["touch", os.path.join(job.output_name, "RELION_JOB_EXIT_SUCCESS")]
                )
                wait_count += wait_time

            else:
                time.sleep(1)
                wait_count += 1
        if not job_is_success:
            subprocess.run(
                ["touch", os.path.join(job.output_name, "RELION_JOB_EXIT_FAILURE")]
            )

    def run_job(
        self,
        job,
        current_job,
        only_schedule,
        is_main_continue,
        is_scheduled,
        overwrite_current=False,
        subsequent_scheduled=False,
    ):

        do_makedir = True

        if overwrite_current:
            is_main_continue = False
            do_makedir = False

        final_command = self.get_commandline_job(
            job,
            current_job,
            is_main_continue,
            is_scheduled,
            do_makedir,
            overwrite_current,
            subsequent_scheduled,
        )

        # if overwriting remove the original files
        if overwrite_current:

            # check for children...
            thejob_proc = self.graph.find_process(current_job.name)
            children = self.graph.find_immediate_child_processes(thejob_proc)

            if len(children) > 0:
                # make get a place to archive the current run
                kiddies = [x.name for x in children]
                timestamp = (
                    date_time_tag().replace("-", "").replace(" ", "").replace(":", "")
                )
                archive_dir = (
                    "." + timestamp + "." + current_job.name[:-1].replace("/", ".")
                )
                print(
                    "\nWARNING: The process designated for overwriting has {} child "
                    "processes: {}\nThe original run of this process has been archived "
                    "as {}\nPARENT_OVERWRITTEN_{} markers have been written to "
                    "all child processes\n".format(
                        len(children), ", ".join(kiddies), archive_dir, timestamp
                    )
                )
                # copy the current dir contents into the archive
                os.makedirs(archive_dir)
                subprocess.run(["cp", "-r", current_job.name, archive_dir])

                # make notes on the children
                for child in children:
                    childfile = os.path.join(
                        child.name, "PARENT_OVERWRITTEN_" + timestamp
                    )
                    with open(childfile, "w") as make_note:
                        make_note.write(archive_dir)

            subprocess.run(["rm", "-rf", job.output_name + "*"])
        else:
            # remove any control files:
            control_files = [
                "RELION_JOB_ABORT_NOW",
                "RELION_JOB_EXIT_ABORTED",
                "RELION_JOB_EXIT_SUCCESS",
                "RELION_JOB_EXIT_FAILURE",
            ]
            # remove overwrite notices
            parent_overwrite_files = glob(job.output_name + "PARENT_OVERWRITTEN_*")
            control_files += parent_overwrite_files

            for cf in control_files:
                cf_name = os.path.join(job.output_name, cf)
                if os.path.isfile(cf_name):
                    subprocess.run(["rm", cf_name])

        if only_schedule:
            newstatus = 1  # scheduled
        else:
            newstatus = 0  # running
        allow_overwrite = is_main_continue or is_scheduled or overwrite_current

        # update the pipeline
        # only locking pipeliner here during writing
        self.graph.create_lock()
        current_proc = self.graph.add_job(job, newstatus, allow_overwrite)
        self.graph.touch_temp_node_files(current_proc)

        # For continuation of relion_refine jobs, remove the
        # original output nodes from the list
        if is_main_continue and not only_schedule:
            if current_proc.type in [
                PROCS["Class2D"],
                PROCS["Class3D"],
                PROCS["Refine3D"],
                PROCS["MultiBody"],
                PROCS["InitialModel"],
            ]:
                # delete the nodes from the nodes dir and pipeline...
                self.graph.delete_temp_node_files(current_proc)
                for node in current_proc.output_nodes():
                    self.graph.node_list.remove(node)

        self.graph.write()  # TODO: reduce coupling, graph should write itself
        if not only_schedule:
            print("Executing: ", final_command)
            subprocess.run(final_command, shell=True)

            # make the note, run.job and job.star files
            notefile_path = os.path.join(job.output_name, "note.txt")
            os.system("echo '{}' >> {}".format(final_command, notefile_path))
            job.write(job.output_name)
            job.write_jobstar(job.output_name)
            job.write_jobstar(job.hidden_name)
            # write the continuation file - for continuing the job later
            continue_name = os.path.join(job.output_name, "continue_")
            job.write_jobstar(continue_name, is_continue=True)

            # if the job is a plugin, and will not mae control files
            # check to see if it was finished successfully
            if job.is_plugin and not job.plugin_use_queue:
                self.check_plugin_job_has_finished(job)

        # if this was a select job which generated n output files
        # add the newly created output nodes
        if (
            "relion_star_handler`" in final_command
            and "--size_split" in final_command.split()
        ):
            # need som time for the files to finish writing
            time.sleep(10)
            self.graph.read(do_lock=True)
            output_files = glob(job.output_name + "*split*.star")
            node_types = {"micrographs": NODES["Mics"], "particles": NODES["Part data"]}
            the_proc = self.graph.find_process(job.output_name)

            for file in output_files:
                # the split1 node was already added - don't add it twice
                if file not in self.graph.node_list:
                    node_type = os.path.basename(file).split("_split")[0]
                    node = Node(file, node_types[node_type])
                    self.graph.add_node(node, False)
                    self.graph.add_new_output_edge(the_proc, node, mini=False)
            self.graph.write()

        # back up pipeline
        fn_pipe = self.graph.get_pipeline_filename()
        if os.path.isfile(fn_pipe):
            subprocess.run(["cp", fn_pipe, job.output_name])

        return current_proc

    def run_scheduled_jobs(
        self,
        fn_sched,
        job_ids=list(),
        nr_repeat=1,
        minutes_wait=0,
        minutes_wait_before=0,
        seconds_wait_after=0,
    ):
        def write_to_sched_log(message, logfile):
            """For realtime updating of the schedule log"""
            with open(logfile, "a+") as schedlog:
                schedlog.write(message)

        def schedule_fail(message):
            """If the schedule fails: write to the log and then delete
            the schedule lockfile"""
            write_to_sched_log("\n+ " + date_time_tag() + "\n", sl_name)
            write_to_sched_log(message, sl_name)
            subprocess.run(["rm", sched_lock])
            raise_error(message)

        # make sure there are jobs to run
        if len(job_ids) == 0:
            raise_error("\nERROR: run_scheduled_jobs: Nothing to do...")

        # make the schedule lock file
        sched_lock = "RUNNING_PIPELINER_{}_{}".format(self.graph.name, fn_sched)

        if os.path.isfile(sched_lock):
            raise_error(
                "ERROR: a file called {} already exists. \n This "
                "implies another set of scheduled jobs with this name is already "
                "running. \n Cancelling job execution...".format(sched_lock)
            )

        # touch the schedule lockfile
        subprocess.run(["touch", sched_lock])

        # write the PID to schedule control file
        proc_pid = os.getpid()
        with open(sched_lock, "a") as runfile:
            runfile.write("RELION_SCHEDULE: {}\n".format(proc_pid))

        # prepare the logfile
        sl_name = "pipeline_{}.log".format(fn_sched)
        write_to_sched_log("\n" + "+" * 35, sl_name)
        write_to_sched_log(
            "\nStarting a new scheduler execution called schedule1\n"
            "The scheduled jobs are:",
            sl_name,
        )

        for jobname in job_ids:
            write_to_sched_log("\n- " + jobname, sl_name)

        if nr_repeat > 1:
            write_to_sched_log(
                "\nWill execute the scheduled jobs {} times\nWill wait until at "
                "least {} minute(s) have passed between each "
                "repeat".format(nr_repeat, minutes_wait),
                sl_name,
            )
        write_to_sched_log(
            "\nRUNNING_PIPELINER_{} will be used to control the "
            "schedule\n".format(fn_sched) + "+" * 35,
            sl_name,
        )

        if minutes_wait_before > 0:
            time.sleep(minutes_wait_before * 60)

        for repeat in range(int(nr_repeat)):
            repeat_start = datetime.now()
            write_to_sched_log("\n+ " + date_time_tag(), sl_name)
            write_to_sched_log(
                "\n-- Starting repeat {}/{}".format(repeat + 1, nr_repeat), sl_name,
            )

            for job in job_ids:
                write_to_sched_log("\n+ " + date_time_tag(), sl_name)
                write_to_sched_log("\n---- Executing " + job, sl_name)
                current_job = self.graph.find_process(name=job)
                if current_job is None:
                    current_job = self.graph.find_process(alias=job)
                    if current_job is None:
                        schedule_fail(
                            "ERROR: Cannot find process with name/alias:"
                            + job
                            + " schedule terminated"
                        )
                # use the job.star files, only use run.job if not available
                job_file = os.path.join(job, "job.star")
                if not os.path.isfile(job_file):
                    job_file = os.path.join(job, "run.job")

                jobtype = current_job.type
                try:
                    myjob = job_factory.read_job(job_file, True)
                except ValueError:
                    schedule_fail(
                        "ERROR: there was an error reading job:"
                        + current_job.name
                        + " schedule terminated"
                    )
                # if certain jobs are repeats they should always be continued
                if (
                    jobtype == PROCS["MotionCorr"]
                    or jobtype == PROCS["CtfFind"]
                    or jobtype == PROCS["AutoPick"]
                    or jobtype == PROCS["Extract"]
                    or jobtype == PROCS["PostProcess"]
                    and repeat >= 1
                ):
                    myjob.is_continue = True

                # check for input nodes before executing job
                for curr_node in current_job.input_nodes:
                    node_job = os.path.dirname(curr_node.name)
                    waiting_for_node = 0
                    while self.graph.find_node(curr_node.name) is None:
                        print(
                            "\n\n WARNING: node",
                            curr_node.name,
                            "does not exist, waiting 1 second...",
                        )
                        time.sleep(1)
                        waiting_for_node += 1
                        if waiting_for_node > 600:
                            schedule_fail(
                                "ERROR: Waited 10 minutes for node {} to appear after"
                                " job {} finished successfully, but it never did. Could"
                                " there be a file system issue?".format(
                                    curr_node.name, node_job
                                )
                            )
                # write the current job to lock file, in case it needs to be cancelled
                with open(sched_lock, "a") as sched_lockfile:
                    sched_lockfile.write(current_job.name + "\n")

                # read the pipeline in case other jobs have changed it
                self.graph.read(do_lock=False)
                self.graph.check_process_completion()

                # run the job - marked as a subsequent run of a schedule
                self.run_job(
                    myjob, current_job, False, myjob.is_continue, True, False, True
                )

                # look for the control files to tell the job has finished
                success_file = os.path.isfile(
                    os.path.join(myjob.output_name, "RELION_JOB_EXIT_SUCCESS",)
                )
                fail_file = os.path.isfile(
                    os.path.join(myjob.output_name, "RELION_JOB_EXIT_FAILURE",)
                )
                abort_file = os.path.isfile(
                    os.path.join(myjob.output_name, "RELION_JOB_EXIT_ABORT",)
                )

                while not success_file:
                    if fail_file or abort_file:
                        schedule_fail(
                            "Schedule terminated because process {}"
                            " failed".format(myjob.output_name)
                        )
                    time.sleep(1)
                    success_file = os.path.isfile(
                        os.path.join(myjob.output_name, "RELION_JOB_EXIT_SUCCESS",)
                    )
                    fail_file = os.path.isfile(
                        os.path.join(myjob.output_name, "RELION_JOB_EXIT_FAILURE",)
                    )
                    abort_file = os.path.isfile(
                        os.path.join(myjob.output_name, "RELION_JOB_EXIT_ABORT",)
                    )

                    # if jobtype is plugin do a check for the expected outputs.
                    # if the expected outputs are there then mark the job as success

                    if myjob.is_plugin and myjob.plugin_use_queue:
                        if os.path.isfile(
                            os.path.join(myjob.output_name, "PLUGIN_QUEUED_FINISHED")
                        ):
                            self.check_plugin_job_has_finished(myjob)

                time.sleep(seconds_wait_after)

            repeat_finish = datetime.now()
            wait_time = timedelta(minutes=minutes_wait)
            while repeat_finish < repeat_start + wait_time and repeat != nr_repeat - 1:
                time.sleep(1)
                repeat_finish = datetime.now()

        write_to_sched_log("\n+ " + date_time_tag(), sl_name)
        write_to_sched_log(
            "\n+ performed all requested repeats in scheduler {}. Stopping "
            "pipeliner now ...\n".format(fn_sched) + "+" * 35,
            sl_name,
        )
        subprocess.run(["rm", sched_lock])

    """
    COMPLETED MARKED BY "*", alternatives completed marked by "-":

    bool setAliasJob(int this_job, string alias, string &error_message)

    * void addNewInputEdge(Node &node, long int input_for_process)
    * void addNewOutputEdge(long int output_from_process, Node &node)

    * long int addNode(Node &node, bool touch_if_not_exist=false)
    * long int addNewProcess(Process &process, bool do_overwrite=false)

    - long int findNodeByName(string name)
        - replaced with findNode
    - long int findProcessByName(string name)
    - long int findProcessByAlias(string name)
        - both replaced just by findProcess

    * bool touchTemporaryNodeFile(Node &node, bool touch_even_if_not_exitst=false)
    * void touchTemporaryNodeFiles(Process &process)
    -these are in project_graph

    *void deleteTemporaryNodeFile(Node &node)
    *void deleteTemporaryNodeFiles(Process &process)
    - these are in project_graph

    - void remakeNodeDirectory()
    - done in project_graph.py

    - bool checkProcessCompletion()
    - done in project_graph.py

    - bool markAsFinishedJob(int this_job, string &error_message)
    - done in project_graph.py
    * bool get CommandLineJob(RelionJob &thisjob, int current_job,
                            bool is_main_continue, bool is_scheduled, bool do_makedir,
                            vector<string> &commands, string &final_command,
                            string &error_message)

    * long int addJob(RelionJob &job, int as_status, bool do_overwrite)
    * bool runJob(RelionJob &job, int &current_job,
                bool only_schedule, bool is_main_continue, bool is_scheduled,
                string &error_message)

    * int addScheduledJob(string job_type, string fn_options)
    * int addScheduledJob(int job_type, string fn_options)
    * void runScheduledJobs(FileName fn_sched, FileName fn_jobids, int nr_repeat,
                            long int minutes_wait,
                            long int minutes_wait_before=0,
                            long int seconds_wait_afer=10)
    - void deleteJobGetNodesAndProesses(int this_job, bool do_recturive,
                                vector<bool> &deleteNodes,
                                vector<bool> &deleteProcesses)
    - done in project_graph.py
    - void deleteNodesAndProcesses(vector<bool> &deleteNodes,
                                 vector<bool> &deleteProcesses)
    - done in project_graph.py
    - void undeleteJob(FileName fn_undel)
    - done in project_graph.py

    - bool cleanupJob(int this_job, bool do_harsh, string &error_message)
    - done in project_graph.py
    - bool cleanupAllJobs(bool do_hars, string &error_message)
    - done on project_graph.py

    - makeFlowChart(long it current_job, bool do_display_pdf, string &error_message)
        - replaced by Pandas Framework visualisation for now TODO needs better graph

    - void replaceFilesForImportExportOfScheduledJobs(Filename fn_in_dir,
                FileName fn_out_dir,
                vector<string> &find_pattern,
                vector<string> &replace_pattern)
    - bool exportAllScheduledJobs(string mydir, string &error_message)
    - done in project_graph.py
    -void importJobs(FileName fn_export)
    - done in project_graph.py
    bool importPipeline(string name)

    * void write(bool do_lock=false, Filename  fn_del="",
                vector<bool> deleteNode=vector<bool>(),
                vector<bool> deleteProcess=vector<bool>(),
    * void read(bool do_loc=false, string lock_message="Undefined lock message")

    """
