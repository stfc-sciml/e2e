from pipeliner.utils import raise_error


class JobOption(object):

    SAMPLING = [
        "30 degrees",
        "15 degrees",
        "7.5 degrees",
        "3.7 degrees",
        "1.8 degrees",
        "0.9 degrees",
        "0.5 degrees",
        "0.2 degrees",
        "0.1 degrees",
    ]

    NODETYPE = [
        "2D micrograph movies (*.mrcs, *.tiff)",
        "2D micrographs/tomograms (*.mrc)",
        "2D/3D particle coordinates (*.box, *_pick.star)",
        "Particles STAR file (.star)",
        "Movie-particles STAR file (.star)",
        "2D references (.star or .mrcs)",
        "Micrographs STAR file (.star)",
        "3D reference (.mrc)",
        "3D mask (.mrc)",
        "Unfiltered half-map (unfil.mrc)",
        "Other",
    ]

    NODETYPE_OPTIONS = {
        "2D micrograph movies (*.mrcs, *.tiff)": 0,
        "2D micrographs/tomograms (*.mrc)": 1,
        "2D/3D particle coordinates (*.box, *_pick.star)": 2,
        "Particles STAR file (.star)": 3,
        "Movie-particles STAR file (.star)": 4,
        "2D references (.star or .mrcs)": 5,
        "Micrographs STAR file (.star)": 1,
        "3D reference (.mrc)": 6,
        "3D mask (.mrc)": 7,
        "Unfiltered half-map (unfil.mrc)": 10,
        "Other": 99,
    }

    GAIN_ROTATION = [
        "No rotation (0)",
        "90 degrees (1)",
        "180 degrees (2)",
        "270 degrees (3)",
    ]

    CTF_FIT = ["No", "Per-micrograph", "Per-particle"]

    GAIN_FLIP = ["No flipping (0)", "Flip upside down (1)", "Flip left to right (2)"]

    def __init__(self, label, defaultvalue, helptext, in_continue):
        self.joboption_type = "ANY"

        self.label = label
        self.labelgui = label
        self.value = defaultvalue
        self.defaultvalue = defaultvalue
        self.helptext = helptext
        self.in_continue = in_continue

    @classmethod
    def as_fn(
        cls, label, defaultvalue, pattern, directory, helptext, in_continue=False
    ):
        joboption = cls(label, defaultvalue, helptext, in_continue)
        joboption.pattern = pattern  # TODO should this all be cls.xx ?
        joboption.directory = directory
        joboption.joboption_type = "FILENAME"
        joboption.in_continue = in_continue
        return joboption

    @classmethod
    def as_inputnode(
        cls, label, nodetype, defaultvalue, pattern, helptext, in_continue=False
    ):
        joboption = cls(label, defaultvalue, helptext, in_continue)
        joboption.pattern = pattern
        joboption.nodetype = nodetype
        joboption.joboption_type = "INPUTNODE"
        joboption.in_continue = in_continue
        return joboption

    @classmethod
    def as_radio(cls, label, radiomenu, ioption, helptext, in_continue=False):
        defaultvalue = None
        if radiomenu == "SAMPLING":
            defaultvalue = cls.SAMPLING[ioption]
        elif radiomenu == "NODETYPE":
            defaultvalue = cls.NODETYPE[ioption]
        elif radiomenu == "GAIN_ROTATION":
            defaultvalue = cls.GAIN_ROTATION[ioption]
        elif radiomenu == "GAIN_FLIP":
            defaultvalue = cls.GAIN_FLIP[ioption]
        elif radiomenu == "CTF_FIT":
            defaultvalue = cls.CTF_FIT[ioption]
        if defaultvalue is None:
            print("\n\nBUG: Unrecognised radio_menu type.")
            exit(1)
        joboption = cls(label, defaultvalue, helptext, in_continue)
        joboption.joboption_type = "RADIO"
        joboption.radiomenu = radiomenu
        joboption.in_continue = in_continue
        return joboption

    @classmethod
    def as_boolean(cls, label, boolvalue, helptext, in_continue=False):
        defaultvalue = "Yes" if boolvalue else "No"
        joboption = cls(label, defaultvalue, helptext, in_continue)
        joboption.joboption_type = "BOOLEAN"
        joboption.in_continue = in_continue
        return joboption

    @classmethod
    def as_slider(
        cls,
        label,
        defaultvalue,
        minvalue,
        maxvalue,
        stepvalue,
        helptext,
        in_continue=False,
    ):
        joboption = cls(label, defaultvalue, helptext, in_continue)
        joboption.minvalue = minvalue
        joboption.maxvalue = maxvalue
        joboption.stepvalue = stepvalue
        joboption.joboption_type = "SLIDER"
        joboption.in_continue = in_continue
        return joboption

    @classmethod
    def as_textbox(cls, label, defaultvalue, helptext, in_continue=False):
        joboption = cls(label, defaultvalue, helptext, in_continue)
        joboption.joboption_type = "TEXTBOX"
        joboption.in_continue = in_continue
        return joboption

    def get_string(self, required=False, errormsg=""):
        if required and str(self.value) == "":
            raise_error(errormsg)
        return str(self.value)

    def set_string(self, setTo):
        self.value = str(setTo)

    def get_number(self):
        if self.joboption_type not in ("SLIDER", "TEXTBOX"):
            raise_error("JobOption {} does not return a number".format(self.label))
        return float(self.value)

    def get_boolean(self):
        if self.joboption_type != "BOOLEAN":
            raise_error("JobOption {} does not return a boolean".format(self.label))
        return self.value == "Yes"

    # readValue and writeValue are implemented in RelionJob instead
    # prevents passing in/out stream as argument
