# TODO: redefine these as subtypes of RelionJob, with constant names and type nums in
#  the class definitions
IMPORT_NAME = "Import"
IMPORT_TYPE_NUM = 0

POSTPROCESS_NAME = "PostProcess"
POSTPROCESS_TYPE_NUM = 15

MASKCREATE_NAME = "MaskCreate"
MASKCREATE_TYPE_NUM = 12

CTFFIND_NAME = "CtfFind"
CTFFIND_TYPE_NUM = 2

MOTIONCORR_NAME = "MotionCorr"
MOTIONCORR_TYPE_NUM = 1

MANUALPICK_NAME = "ManualPick"
MANUALPICK_TYPE_NUM = 3

AUTOPICK_NAME = "AutoPick"
AUTOPICK_TYPE_NUM = 4

EXTRACT_NAME = "Extract"
EXTRACT_TYPE_NUM = 5

SELECT_NAME = "Select"
SELECT_TYPE_NUM = 7

CLASS2D_NAME = "Class2D"
CLASS2D_TYPE_NUM = 8

INIMODEL_NAME = "InitialModel"
INIMODEL_TYPE_NUM = 18

CLASS3D_NAME = "Class3D"
CLASS3D_TYPE_NUM = 9

REFINE3D_NAME = "Refine3D"
REFINE3D_TYPE_NUM = 10

MULTIBODY_NAME = "MultiBody"
MULTIBODY_TYPE_NUM = 19

JOINSTAR_NAME = "JoinStar"
JOINSTAR_TYPE_NUM = 13

SUBTRACT_NAME = "Subtract"
SUBTRACT_TYPE_NUM = 14

LOCALRES_NAME = "LocalRes"
LOCALRES_TYPE_NUM = 16

CTFREFINE_NAME = "CtfRefine"
CTFREFINE_TYPE_NUM = 21

EXTERNAL_NAME = "External"
EXTERNAL_TYPE_NUM = 22

BAYESPOLISH_NAME = "Polish"
BAYESPOLISH_TYPE_NUM = 20

PLUGIN_NAME = "PlugIn"
PLUGIN_TYPE_NUM = 101

PROCS = {
    IMPORT_NAME: IMPORT_TYPE_NUM,
    MOTIONCORR_NAME: MOTIONCORR_TYPE_NUM,
    CTFFIND_NAME: CTFFIND_TYPE_NUM,
    MANUALPICK_NAME: MANUALPICK_TYPE_NUM,
    AUTOPICK_NAME: AUTOPICK_TYPE_NUM,
    EXTRACT_NAME: EXTRACT_TYPE_NUM,
    # Sort is no longer used in relion 3.1
    # "Sort": 6,
    SELECT_NAME: SELECT_TYPE_NUM,
    CLASS2D_NAME: CLASS2D_TYPE_NUM,
    CLASS3D_NAME: CLASS3D_TYPE_NUM,
    REFINE3D_NAME: REFINE3D_TYPE_NUM,
    # Job type 11 is the old style polishing from Relion 2.x
    # this has been replaced by Bayesian polishing (job type 20)
    # in Relion 3.x
    # "Polish": 11,
    MASKCREATE_NAME: MASKCREATE_TYPE_NUM,
    JOINSTAR_NAME: JOINSTAR_TYPE_NUM,
    SUBTRACT_NAME: SUBTRACT_TYPE_NUM,
    POSTPROCESS_NAME: POSTPROCESS_TYPE_NUM,
    LOCALRES_NAME: LOCALRES_TYPE_NUM,
    # "MovieRefine": 17,
    INIMODEL_NAME: INIMODEL_TYPE_NUM,
    MULTIBODY_NAME: MULTIBODY_TYPE_NUM,
    BAYESPOLISH_NAME: BAYESPOLISH_TYPE_NUM,
    CTFREFINE_NAME: CTFREFINE_TYPE_NUM,
    EXTERNAL_NAME: EXTERNAL_TYPE_NUM,
    # this job type has been added by MGI, not approved yet
    PLUGIN_NAME: PLUGIN_TYPE_NUM,
}

PROC_NAMES = {
    IMPORT_TYPE_NUM: IMPORT_NAME,
    MOTIONCORR_TYPE_NUM: MOTIONCORR_NAME,
    CTFFIND_TYPE_NUM: CTFFIND_NAME,
    MANUALPICK_TYPE_NUM: MANUALPICK_NAME,
    AUTOPICK_TYPE_NUM: AUTOPICK_NAME,
    EXTRACT_TYPE_NUM: EXTRACT_NAME,
    # 6: "Sort",  # depreciated
    SELECT_TYPE_NUM: SELECT_NAME,
    CLASS2D_TYPE_NUM: CLASS2D_NAME,
    CLASS3D_TYPE_NUM: CLASS3D_NAME,
    REFINE3D_TYPE_NUM: REFINE3D_NAME,
    # 11: "Polish",  # depreciated
    MASKCREATE_TYPE_NUM: MASKCREATE_NAME,
    JOINSTAR_TYPE_NUM: JOINSTAR_NAME,
    SUBTRACT_TYPE_NUM: SUBTRACT_NAME,
    POSTPROCESS_TYPE_NUM: POSTPROCESS_NAME,
    LOCALRES_TYPE_NUM: LOCALRES_NAME,
    # 17: "MovieRefine",  # depreciated
    INIMODEL_TYPE_NUM: INIMODEL_NAME,
    MULTIBODY_TYPE_NUM: MULTIBODY_NAME,
    BAYESPOLISH_TYPE_NUM: BAYESPOLISH_NAME,
    CTFREFINE_TYPE_NUM: CTFREFINE_NAME,
    EXTERNAL_TYPE_NUM: EXTERNAL_NAME,
    # this job type has been added by MGI, not approved yet
    PLUGIN_TYPE_NUM: PLUGIN_NAME,
}

NODES = {
    "Movies": 0,
    "Mics": 1,
    "Mic coords": 2,
    "Part data": 3,
    "Movie data": 4,
    "2D refs": 5,
    "3D refs": 6,
    "Mask": 7,
    "Model": 8,
    "Optimiser": 9,
    "Halfmap": 10,
    "Finalmap": 11,
    "Resmap": 12,
    "PdfLogfile": 13,
    "Post": 14,
    "Polish params": 15,
    "Other": 99,
}

STATUS = {
    "running": 0,
    "scheduled": 1,
    "finished_success": 2,
    "finished_failure": 3,
    "finished_aborted": 4,
}

# for illustrating flowcharts
NODES_COLORS = {
    0: (0.75, 0.75, 0.75),
    1: (0.75, 0.75, 0.75),
    2: (1, 0, 1),
    3: (0, 0, 1),
    4: (0, 0, 0),
    5: (0, 1, 1),
    6: (1, 0, 0),
    7: (0, 1, 0),
    8: (0, 1, 1),
    9: (0, 0, 0),
    10: (1, 1, 0),
    11: (1, 0, 0),
    12: (0, 1, 0),
    13: (0, 0, 0),
    14: (1, 0, 0),
    15: (0, 0, 0),
    99: (0, 0, 0),
}


NODES_DIR = ".Nodes/"


class Node(object):

    # list rather than None to prevent from errors when len(node.ALLOWED_IN)
    ALLOWED_IN = []  # what can be parent
    ALLOWED_OUT = []  # what can be fed

    def __init__(self, name, n_type, directory="."):
        self.name = str(name)
        # TODO self.directory
        # TODO check if exists

        # work around until we change all node types to strings
        try:
            self.type = int(n_type)
        except ValueError:
            self.type = n_type

        # must have producer process, can have consumers
        self.output_from_process = None  # process that produced this node
        self.input_for_processes_list = list()  # processes that use this node as input

    def clear(self):
        self.output_from_process = None
        self.input_for_processes_list.clear()


class Process(object):

    ALLOWED_IN = []  # what is fed
    ALLOWED_OUT = []  # what are children

    def __init__(self, name, p_type, status, alias=None):

        self.name = str(name)
        self.alias = alias
        try:
            self.type = int(p_type)
        except ValueError:
            self.type = p_type

        self.status = int(status)

        # needs both inputs and outputs
        self.input_nodes = list()  # nodes used by this process
        self.output_nodes = list()  # nodes produced by this process

    def clear(self):
        self.input_nodes.clear()
        self.output_nodes.clear()
