"""
star_writer

Writes STAR files in the same style as RELION 3.0.
"""

from gemmi import cif
from pipeliner.jobstar_reader import JobStar
from pipeliner.utils import raise_error

COMMENT_LINE = "version 30001 / CCP-EM_pipeliner"


def write(doc, filename, commentline=COMMENT_LINE):
    """Write a Gemmi CIF document to a RELION-style STAR file."""
    with open(filename, "w") as star_file:
        write_to_stream(doc, star_file, commentline)


def write_to_stream(doc, out_stream, commentline=COMMENT_LINE):
    """Write a Gemmi CIF document to an output stream using RELION's output style."""
    for block in doc:
        if commentline is not None:
            out_stream.write("\n# " + commentline + "\n")
        out_stream.write("\ndata_{}\n\n".format(block.name))
        for item in block:
            if item.pair:
                out_stream.write("{}{:>24}\n".format(*item.pair))
            elif item.loop:
                out_stream.write("loop_ \n")
                loop = item.loop
                for ii, tag in enumerate(loop.tags, start=1):
                    out_stream.write("{} #{} \n".format(tag, ii))
                for row in range(loop.length()):
                    for col in range(loop.width()):
                        value = loop.val(row, col)
                        # Annoyingly, RELION's output uses 12-char wide fields except
                        # if value is "None"
                        if value == "None":
                            out_stream.write("{:>10} ".format(value))
                        # Need to quote empty strings
                        # (can normally use gemmi.cif.quote() for this but not if we
                        # want strict RELION-style output)
                        elif value == "":
                            out_stream.write("{:>12} ".format('""'))
                        else:
                            out_stream.write("{:>12} ".format(value))
                    out_stream.write("\n")
            out_stream.write(" \n")


def write_jobstar(in_dict, out_fn):
    """Write a job.star file from a dictionary of options"""
    jobstar = cif.Document()

    # make the job block - don't know why I have to separate these
    # two functions but Gemmi seg faults if you don't....
    job_block = jobstar.add_new_block("job")

    for param in in_dict:
        val = in_dict[param]
        # get the two that go to the job block
        if param in ["_rlnJobType", "_rlnJobIsContinue"]:
            job_block.set_pair(param, val)

    # make the options block
    jobop_block = jobstar.add_new_block("joboptions_values")
    jobop_loop = jobop_block.init_loop(
        "_", ["rlnJobOptionVariable", "rlnJobOptionValue"]
    )

    for param in in_dict:
        val = in_dict[param]
        # get the two that go to the job block
        if param not in ["_rlnJobType", "_rlnJobIsContinue"]:
            jobop_loop.add_row([cif.quote(param), cif.quote(val)])

    write(jobstar, out_fn)


def modify_jobstar(fn_template, params_to_change, out_fn):
    """Edits the template file and saves a copy
    Params to change = {param:value}"""
    if type(params_to_change) != dict:
        raise_error("ERROR: modify_jobstar() requires a dict as the 2nd input")

    # get the template and make joboptions dict
    the_template = JobStar(fn_template)
    joboptions = the_template.get_all_options()

    # change any necessary parameters
    for changed_opt in params_to_change:
        joboptions[changed_opt] = params_to_change[changed_opt]

    # make sure the output ends in _job.star
    if out_fn[-9:] != "_job.star":
        out_fn = out_fn.replace(".star", "") + "_job.star"

    write_jobstar(joboptions, out_fn)
    return out_fn
