import re
import os
from datetime import datetime
from pathlib import Path


def get_project_root() -> Path:
    return Path(__file__).parent


def truncate_number(number, maxlength):
    """ Return a number with no more than x decimal places but no trailing 0s"""
    numsplit = str(number).split(".")
    if numsplit[-1] == "0":
        return numsplit[0]
    elif len(numsplit[-1]) > maxlength:
        number = round(number, maxlength)
        truncated = re.sub(r"^(\d+\.\d{,{maxlength}})\d*$", r"\1", str(number))
        if truncated.split(".")[-1] == "0":
            return truncated.split(".")[0]
        else:
            return truncated
    else:
        return str(number)


def decompose_pipeline_filename(fn_in):
    """Returns everything before the job number, the job number as an int
    and everything after the job number setup for up to 20 dirs deep.
    The 20 dir limit is from the relion code but no really necessary anymore"""
    fn_split = fn_in.split("/")
    # > 20 dirs doesn't really need to be an error any more with the way it
    # is being done now.
    if len(fn_split) > 20:
        raise_error(
            "decomposePipelineFileName: BUG or found more than 20"
            " directories deep structure for pipeline filename: " + fn_in
        )
    # return everything before job number, job number, and everything after
    i = 0
    for chunk in fn_split:
        if len(chunk) == 6 and chunk[0:3] == "job":
            fn_jobnr = False
            try:
                fn_jobnr = int(chunk[3:])
            except ValueError:
                fn_jobnr = False
            if bool(fn_jobnr):
                fn_pre = "/".join(fn_split[:i])
                fn_post = "/".join(fn_split[i + 1 :])
                return (fn_pre, fn_jobnr, fn_post)
        i += 1
    # return just the file name if it wasn't a pipeline file
    return ("", "", fn_in)


def get_env_var(envvar_name, alternative=""):
    """Get an environment variable. """
    env_var = os.environ.get(envvar_name)
    if env_var is None:
        env_var = alternative
    return env_var


def check_for_illegal_symbols(check_string, string_name, exclude=[]):
    """Check a text string doesn't have any of the disallowed symbols
    to allow a specific one put it in the exclude list"""
    badsym = ""
    for symbol in [
        "!",
        "*",
        "?",
        "(",
        ")",
        "^",
        "/",
        "\\",
        "|",
        "#",
        "<",
        ">",
        "&",
        "%",
        "{",
        "}",
        "$",
        ",",
        '"',
        "'",
    ]:
        if symbol in check_string and symbol not in exclude:
            badsym += symbol
    if len(badsym) > 0:
        raise_error(
            "ERROR: Symbol(s) {0} in {1}. \n{1} cannot contain following"
            ' symbols: ! * ? / " \\ | # < > & % ^ '
            ", ' or $".format("".join(badsym), string_name)
        )


def date_time_tag():
    now = datetime.now()
    date_time = now.strftime("%Y-%m-%d %H:%M:%S")  # put this in relion format
    return date_time


def raise_error(message):
    """Raise and informative error puts clean error message into
    stdout and full traceback into stderr"""
    print(message)
    raise ValueError(message)


def clean_jobname(jobname):
    """make sure there is a trailing slash on the end of a job name"""
    if jobname[-1] != "/":
        jobname = jobname + "/"
    return jobname
