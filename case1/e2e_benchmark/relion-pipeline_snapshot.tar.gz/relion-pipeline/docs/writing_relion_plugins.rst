##################################################
Writing Plugins for the Relion Integrated Pipeline
##################################################

Any program that runs from the command line can be integrated into relion through a plugin
in the integrated pipeline.  Write a plugin file and put it in the folder ``relion-pipeline/pipeliner/plugins/``
The plugin file needs to be written in python 3.6 and the name should have the extension ".rln".

The plugin file consists of two parts: a header section and a code section.

The header is delineated by the comment ``#relion_plugin_header`` and must define the following
vatiables ::

   #relion_plugin_header
   pluginName = "My Really Great Plugin"
   pluginAuthor = "Matt Iadanza"
   pluginVersion = 0.1
   pluginID = "MRGPI"
   pluginProcessName = "ReallyGreatPlugin"
   plugin_exes = ["executable1", "path/to/executable2"] 
   plugin_input_types = {"mrgpiInputType": [".txt, ".dat", ".mrgpi"]}
   plugin_output_types = {
      "mrgpiOutputType1": ".mrc",
      "mrgpiOutputType2": [".txt", ".dat"].
      }

**pluginName**, **pluginAuthor**, and **pluginVersion** will be displayed 
when the plugin is run

**pluginID** is the identifier that relion uses for the plugin. It must be unique. 
Convention is to use all caps but it is not necessary.

**pluginProcessName** is what the directory containing the plugin's jobs will be
created IE: ReallyGreatPlugin/

The list **plugin_exes** contains the executables the plugin may use.
The plug in will check that the programs in the list actually exists before trying 
to run them 

As many executables as desired can be listed in **plugin_exes**.  They can
be put in as just the program name if the are in the system path (recommended) or 
as absolute paths (not recommended as it will have to be edited by the user).  The
plugin will check that the executables are available before running.

**plugin_input_types** and **plugin_output_types** are dictionaries that contain 
the types of inputs the plugin can take and outputs the plugin might produce

**pluginNodeType** is the identifier Relion will use in its pipeliner for the type of the file.
If the plugin produces outputs of identical type to relion (EX: a .mrc density map, or a particles 
.star file) you can use the node type that Relion uses (rlnDensityMap and rlnParticlesStar respectivly).
If the plugin produces file types that aren't already included in the relion pipeline give the node 
type a name.  Convention is to use the pluginID in lowercase as the first part of the name.

**pluginNodeExtensions** are the extensions the files of this node type are allowed to have. To use multiple
extensions put them is a list.

|

The code block of the plugin, delineated by the command ``#relion_plugin_code`` contains python code 
that is executed when the plugin is run. This code can be pretty much anything the only requirements
are that it defines three variables:

**commands**: a list of the command line arguments that should be run
IE: ::

   commands = ["command1", "command2", "command3"] 

if only a single command needs to be run::

   commands = ["command"]

**inputs**: a dictionary of the input files and their node types

**outputs**:  a dictionary of the output files and their node types

Node types should be identified by the Relion node IDs which are defined in the NODES dict
which is available to the plugin code as it executes.  All non relion files must be designated
with node ID 99 (NODES["Other"]). A later version will allow you to define your own node types.
 ::
 
   NODES = {
      "Movies" 0,
      "Mics": 1,
      "Mic coords": 2,
      "Part data": 3,
      "Movie data": 4,
      "2D refs": 5,
      "3D refs": 6,
      "Mask": 7,
      "Model": 8,
      "Optimiser": 9,
      "Halfmap": 10,
      "Finalmap": 11,
      "Resmap": 12,
      "PdfLogfile": 13,
      "Post": 14,
      "Polish params": 15,
      "Other": 99,
   }

An example of the nodes : :: 

   inputs = {"particles.star": NODES["Part data"], "my_file.mrgpi": NODES["Other"]}
   outputs = {"output_file1.mrc": NODES["Other"], "output_file2.txt": NODES["Other"]}

These will be checked against the node types specified in the header, so make sure 
the node types are specified and the extensions of the files match those specified 
in the header.


**The code in the relion_plugin_code block has the following variables predefined when it is run:**

**output_dir**: the name of the job's output directory.  This will be assigned by
the pipeliner when the job is run. EX::

   ReallyGreatPlugin/job002/

**joboptions**: a dict that contains all of the joboptions specified in the job.star that 
was used to call the plugin (see below). 

|

Example plugin
++++++++++++++

This simple plugin runs the program 'executable1' with a few options.

The job.star file used to call it looks like this ::
   
   data_job
   _rlnJobType                            SIMPLE
   _rlnJobIsContinue                       0
       
   data_joboptions_values
   loop_ 
   _rlnJobOptionVariable   
   _rlnJobOptionValue  
   input_file         my_input_file.txt
   option1            run1
   option2            run2
   option3            run3

The plugin looks like this::

   #this is a really simple plugin!
   
   #relion_plugin_header
   pluginName = "A very simple plugin"
   pluginAuthor = "Matt Iadanza"
   pluginVersion = 0.1
   pluginID = "SIMPLE"
   pluginProcessName = "Simple"
   
   plugin_exes = ["executable1"]
   
   plugin_output_types = {NODES["Other"]: ".simple"}
   plugin_input_types = {NODES["Other"]: [".txt", ".dat"]}
   
   #relion_plugin_code  
   
   in_file = joboptions["input_file"]
   out_file = output_dir + "output.simple"
   option1 = joboptions["option1"]
   option2 = joboptions["option2"]
   option3 = joboptions["option3"]
   
   the_command = plugin_exes[0]
   the_command += " --input {} ".format(in_file)
   the_command += "--output {} ".format(out_file)
   the_command += "--arg1 {} ".format(option1)
   the_command += "--args2and3 {} {}".format(option2, option3) 
   
   commands = [the_command]
   inputs = {in_file: NODES["Other"]}
   outputs = {out_file: NODES["Other"]}
  
This would run the following command line as a relion job::

   executable1 --input my_input_file.txt --output Simple/job001/output.simple
        --arg1 run1 --args2and3 run2 run3

Using mpi and queue submission
++++++++++++++++++++++++++++++

To use mpis to run a plugin add the following field to the job.star used to run it::

   nr_mpi   8

This will result in ``mpirun -n 8`` being added to the front of the command

To run plugin jobs using relion's qsub system add the following fields to the job.star file
used to run it ::

   nr_mpi            8  
   do_queue          Yes 
   min_dedicated     1 
   qsub              qsub 
   qsubscript        /public/EM/RELION/relion/bin/relion_qsub.csh 
   queuename         openmpi 
   
Real life example
+++++++++++++++++

This plugin runs the program cryoEF by CJ Russo & K Naydenova.  CryoEF takes a text file
with two columns as an input, but the plugin also allows for using a relion particles star file.

If the plugin encounters a star file it uses the module gemmi to read the starfile and then writes
a new input file in the format cryoEF wants.

Also, because cryoEF uses the location of the input file to determine the output directory the plugin   
creates the output dir (Which normally shouldn't be necesssary) and either copies the input file there 
(in the case of input in .txt or .dat format) or writes the data file created from the .star file there. ::

   #relion_plugin_header
   
   pluginName = "cryoEF - particle orientation distribution analysis"
   pluginAuthor = "Matt Iadanza"
   pluginVersion = 0.1
   pluginID = "CRYOEF"
   pluginProcessName = "CryoEF"
   
   plugin_exes = ["cryoEF"]
   
   plugin_output_types = { 
      NODES["Other"]: ".mrc",
      NODES["Other"]: ".mrc",
      }
   
   plugin_input_types = {
      NODES["Part data"]: ".star",  
      NODES["Other"]: [".txt", ".dat"]
      }
   
   #relion_plugin_code
   
   import os
   import subprocess
   from gemmi import cif
   
   # get input file
   
   raw_input_file = joboptions["input_file"]
   filename,ext = os.path.basename(raw_input_file).split(".")
   
   # make the output dir
   # normally this wouldn't be necessary, but the input file needs to be
   # in the output dir
   
   os.makedirs(output_dir)
   
   # if input file is relion particles convert it to an angles file
   if ext == "star":
      in_star = cif.read_file(raw_input_file)
      parts_block = in_star.find_block("particles")
      phi_angs = parts_block.find_loop("_rlnAngleTilt")
      psi_angs = parts_block.find_loop("_rlnAngleRot")
      input_file = "{}{}_angles.dat".format(output_dir,filename)
      with open(input_file, "w") as output_file:
         for pair in zip(phi_angs, psi_angs):
            output_file.write("{}\n".format("\t".join(pair)))
      
   # else just copy it into the output dir
   if ext in ["txt", "dat"]:
      input_file = os.path.join(output_dir, os.path.basename(raw_input_file))
      subprocess.run(["cp", raw_input_file, output_dir])
   
   b_factor = joboptions["b_factor"]
   particle_diameter_ang = joboptions["particle_diameter_ang"]
   box_size_px = joboptions["box_size_px"]
   res = joboptions["resolution"]
   sym = joboptions["symmetry"]
   
   command = plugin_exes[0]
   command += " -f " + input_file
   
   if float(b_factor) > 0 :
      command += " -B " + b_factor
   
   if float(particle_diameter_ang) > 0:
      command += " -D " + particle_diameter_ang
   
   if int(box_size_px) > 0:
      command += " -b " + box_size_px
   
   if float(res) > 0:
      command += " -r " + res
      
   if len(sym) > 0:
      command += " -g " + sym
   
   outK = "{}_K.mrc".format(filename)
   outR = "{}_R.mrc".format(filename)
   inputs = {input_file: NODES["Other"]}
   outputs = {outK: NODES["Other"], outR: NODES["Other"]}
   commands = [command]

A job.star file used to run this plugin looks like this ::
   
   data_job
   
   _rlnJobType                            CRYOEF
   _rlnJobIsContinue                       0
    
   data_joboptions_values
   
   loop_ 
   _rlnJobOptionVariable   
   _rlnJobOptionValue  
   input_file                 my_angles.dat
   b_factor                   150      # optional put -1 to use default
   particle_diameter_ang      80       # optional put -1 to use default
   box_size_px                128      # optional put -1 to use default
   resolution                 3.8      # optional put -1 to not use it
   symmetry                   C1       # optional put "" to not use it
   do_queue                   No 
   min_dedicated              1 
   qsub                       qsub 
   qsubscript                 /public/EM/RELION/relion/bin/relion_qsub.csh 
   queuename                  openmpi 
   other_args                 ""  

Running the cryoEF plugin with this job.star file would run the following command as a 
relion job ::

   cryoEF -f CryoEF/job001/run_data_angles.dat -B 150 -D 80 -b 128 -r 3.8 -g C1 
      >> CryoEF/job001/run.out 2>> CryoEF/job001/run.err & 

