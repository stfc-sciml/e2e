Directly modifying the pipeline
+++++++++++++++++++++++++++++++
Although most tasks can be done through the **RelionProject** object, Direct access to 
the pipeline **ProjectGraph** object is available through ``RelionProject``\ .\ **pipeline**

|

class **ProjectGraph**

``name`` = *String*
 The default name is 'default'.  The pipeline file is always called <name>_pipeline.star

``node_list`` = *list* of **Node** objects
 
 Each node contains info about a single input/out file

``process_list`` = *List* of **Process** objects
 
 Each process contains info about a single Relion job

``job_counter`` = *Int*
 
 The variable used to increment the job names.  Job_counter is the number of the next job, 
 not the number of jobs in the pipeline. 

``do_read_only`` = *Boolean*
 If ``True`` the pipeline cannot be edited, only viewed.  Used if pipeline is accessed without sufficient permissions.

|

The ProjectGraph also contains **Process** objects which hold individual Relion jobs and **Node** 
objects, which hold info on input/out files for these jobs

|

class **Process**

Processes are the Relion jobs that have been run or scheduled.
When initialized a **Process** object has the following attributes:

``name`` = *String*
 IE: "Import/job001"

``alias`` = *String*
 IE: "Import/my_first_import/“.  Default is ``None``

``type`` = *Int*
 Relion job types are defined at the end of this document

``status`` = *Int*
 0 = running
 
 1 = scheduled
 
 2 = finished success
 
 3 = finished failed
 
 4 = finished aborted

``input_nodes`` = *List* of **Node** objects

 The node(s) that input into this process

``output_nodes`` = *List* of **Node** objects

 The node(s) output from this process

|

When a specific job type is assigned to a **Process** the following attributes are 
added , but they are not saved in the pipeline:

|

``output_name`` = *String*
 Generally the same as the ``name``

``hidden_name`` = *String*
 The name Relion uses for the GUI hidden files

``is_continue`` = *Boolean*
 If the job is a continuation of a previous job
 
``joboptions`` = *Dict*
 A dictionary containing all the job parameters in the format {option:value}.  The option names are taken directly from the job.star file.

``final_command`` = *String*
 The command Relion will run, in a single string

|

Nodes describe files that are input or output for processes.  

class **Node**

``name`` = *String*
 IE: "Import/job001/microghraphs.star"

``type`` = *int*
 Node types are detailed somewhere else

``output_from_process`` =  **Process** object

 The process that created the node. The 'parent process' 

``input_for_processes_list`` = *List* of **Process** objects

 Processes that use the node as an input.  The 'child processes'

Functions that modify the ProjectGraph
++++++++++++++++++++++++++++++++++++++

``get_pipeline_filename()``
 Returns the full name of the pipeline file as a *String*

|

``is_empty()``
 Returns ``True`` if there are no jobs in the pipeline

|

``read(do_lock=False, lock_wait=2)``

**do_lock**

*Boolean*; If ``True`` creates a lock file which prevents other processes from 
simultaneously editing the pipeline 

**lock_wait**

*Float*; If the lock cannot be created continue trying for this many minutes 

 Reads the pipeline data into the **ProjectGraph** object

|

``write(delete_nodes, delete_processes, lockfile_expected=True, lock_wait=2,)``

**delete_nodes**

*List* of **Node** objects; Remove these Nodes when writing the pipeline

**delete_processes**

*List* of **Process** objects; Remove these Processes when writing the pipeline

**lockfile_expected**

*Boolean*; If ``True`` the pipeline should have been locked when read and a lock file should be present 

**lock_wait**

*Float*; If the lock cannot be removed continue trying for this many minutes 

 Writes the pipeline data in the **ProjectGraph** object to the file <pipeline_name>_pipeline.star

|

``set_name(name, new_lock=True, overwrite=False)``

**name**

*String*; the new name for the pipeline

**new_lock**

*Boolean*; If ``True`` A lockfile will be created for the pipeline with its new name 

**overwrite**

*Boolean*; If a pipeline with the new name already exists, should it be overwritten?

 Sets a new name for the pipeline.  The lock on the old pipline (if any) will be removed

|

``find_node(name)``

**name**

*String*; The name of the node to be found IE: “Import/job001/”
 
 Returns the **Node** object with this name, if it exists, else returns ``None`` 

|

``find_process(name=None, alias=None)``

**name**

*String*; The name of the node to be found IE: “Import/job001/”
 
**alias**

*String*; The alias of the node to be found IE: “Import/my_alias/”
 
 Returns the **Process** object with this name or alias, if it exists, else returns ``None``.  
 Use either a name or an alias, but not both.

|

``add_node(node, touch_if_not_exists=False)``

**node**

**Node** *object*; 

**touch_if_not_exists**

*Boolean*; If ``True`` the node will be added to the .Nodes dir like it is
for scheduled jobs.

 Adds the node to the node list in the **ProjectGraph** object

|

``add_new_process(process, do_overwrite)``

**process**

**Process** *object*; 

**do_overwrite**

*Boolean*; If ``True`` any process with the same name will be overwritte, 
if ``False`` attempting to add processes with duplicated names will raise an error

 Adds the process to the process list in the **ProjectGraph** object

|

``check_process_completion()``

 Checks the directories of all processes in the pipeline, if any processes are marked
 'running' but also have a RELION_JOB_EXIT status files the status of the processes 
 will be updated appropriatly
 
|

``export_all_scheduled_jobs(mydir)``

**mydir**

*String*; Name of the of the directory to export to

 Exported processes can be imported through the Relion GUI or API function import_jobs()

|

``import_jobs(fn_export)``

**fn_export**

*String*; Name of the files created by the export job

 Processes can be exported through the Relion GUI or API function export_all_scheduled_jobs()

|

**Locking functions**

``create_lock(wait_time=2)``

**wait_time**

*Float*; If a lockfile is already present continue trying create a new lock for this many minutes
before raising an error

 The pipeline should be locked by any function that will modify it to prevent multiple programs
 attempting to modify it simultaniously.  All of the API functions that need to lock the pipeline
 do it automatically.

|

``check_lock(lock_expected, wait_time=2)``

**lock_expected**

*Boolean*; If ``True`` a lockfile should be present and the function will raise an error if it
is not found.  if ``False`` and lockfile should not be present, an error will be raised if one is present.

**wait_time**

*Float*; If the presense/absense of a lockfile is not as expected wait for this many minutes
to see if it appears/disappears before raising an error

 Lockfiles are in the dir .RelionLock.

|

``remove_lock()``

 Removes the lockfile for the pipeline.  If no lockfile is present returns an error

|

``update_lock_message(lock_message)``

**lock_message**

*String*; The message to be added to the lockfile

 The lockfile for a pipeline contains a message so the function that created the lock
 can be identified.

|

Examples
++++++++

All of the pipeline control functions are performed automatically by the 
API functions.  There shouldn't be a need to manually modify the pipeline
during normal use.

|

    >>> my_project = RelionProject()
    >>> my_project.start_new_project()
    >>> my_project.pipeline.read()
    >>> print(my_project.pipeline.name)
    default
    
    >>> print(my_project.pipeline.is_empty())
    True
    
 
    >>> my_project.pipeline.set_name("two_jobs")
    >>> print(myproject.pipeline.name)
    two_jobs
    
    >>> my_project.run_job("import1_job.star")        
    >>> my_project.run_job("motioncorr1_job.star")   
    >>> first_job = my_project.pipeline.process_list[0]
    >>> print(first_job.name)
    Import/job001/
    
    >>> print(first_job.type) 
    0
    
    >>> print(vars(first_job.output_nodes[0]))
    {'name': 'Import/job001/movies.star', 'type': 0, 
         'output_from_process': 'Import/job001/',
         'input_for_processes':['MotionCorr/job002/']}

|

Node and job types
++++++++++++++++++

+-----------------+-----------+----------------------------------------------------------------+
| Node Name       | Node type | Description                                                    |
+=================+===========+================================================================+
| "Movies"        | 0         | Raw movies in .mrc or .tif format                              |
+-----------------+-----------+----------------------------------------------------------------+
| "Mics"          | 1         | .star file containing micrographs                              |
+-----------------+-----------+----------------------------------------------------------------+
| "Mic coords"    | 2         | .star file containing coordinates                              |
+-----------------+-----------+----------------------------------------------------------------+
| "Part data"     | 3         | .star file containing particles                                |
+-----------------+-----------+----------------------------------------------------------------+
| "Movie data"    | 4         | Depreciated - no longer used                                   |
+-----------------+-----------+----------------------------------------------------------------+
| "2D refs"       | 5         | 2D .mrc or .mrcs file containing a stack of 2D images          |
+-----------------+-----------+----------------------------------------------------------------+
| "3D refs"       | 6         | 3D .mrc file                                                   |
+-----------------+-----------+----------------------------------------------------------------+
| "Mask"          | 7         | In .mrc format                                                 |
+-----------------+-----------+----------------------------------------------------------------+
| "Model"         | 8         | _model.star file generated by Relion                           |
+-----------------+-----------+----------------------------------------------------------------+
| "Optimiser"     | 9         | _optimiser.star file generated by Relion                       |
+-----------------+-----------+----------------------------------------------------------------+
| "Halfmap"       | 10        | .mrc halfmap                                                   |
+-----------------+-----------+----------------------------------------------------------------+
| "Finalmap"      | 11        | Postprocessed filtered .mrc file                               |
+-----------------+-----------+----------------------------------------------------------------+
| "Resmap"        | 12        | Local resolution map in .mrc format                            |
+-----------------+-----------+----------------------------------------------------------------+
| "PdfLogfile"    | 13        | Any sort of pdf logfile from various jobs                      |
+-----------------+-----------+----------------------------------------------------------------+
| "Post"          | 14        | Postprocessed unfiltered map in .mrc format                    |
+-----------------+-----------+----------------------------------------------------------------+
| "Polish params" | 15        | .txt file containing trained parameters for Bayesian polishing |
+-----------------+-----------+----------------------------------------------------------------+
| "Other"         | 99        | Any other type of file                                         |
+-----------------+-----------+----------------------------------------------------------------+

|

+--------------+----------+
| Job name     | Job type |
+==============+==========+
| Import       | 0        |
+--------------+----------+
| MotionCorr   | 1        |
+--------------+----------+
| CtfFind      | 2        |
+--------------+----------+
| ManualPick   | 3        |
+--------------+----------+
| AutoPick     | 4        |
+--------------+----------+
| Extract      | 5        |
+--------------+----------+
| Select       | 7        |
+--------------+----------+
| Class2D      | 8        |
+--------------+----------+
| Class3D      | 9        |
+--------------+----------+
| Refine3D     | 10       |
+--------------+----------+
| MaskCreate   | 12       |
+--------------+----------+
| JoinStar     | 13       |
+--------------+----------+
| Subtract     | 14       |
+--------------+----------+
| PostProcess  | 15       |
+--------------+----------+
| LocalRes     | 16       |
+--------------+----------+
| InitialModel | 18       |
+--------------+----------+
| MultiBody    | 19       |
+--------------+----------+
| Polish       | 20       |
+--------------+----------+
| CtfRefine    | 21       |
+--------------+----------+
| External     | 22       |
+--------------+----------+
| ThreeDFSC    | 99       |
+--------------+----------+

