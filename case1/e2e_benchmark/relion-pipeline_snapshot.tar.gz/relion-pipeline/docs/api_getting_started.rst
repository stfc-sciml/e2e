########################
CCP-EM Relion Python API
########################
DRAFT 2020/12/16 - MGI

|

The **RelionProject** class provides access to all of the functions of Relion through a python API. More advanced functions are available to edit the pipeline and perform operations outside of the pipeline.

|

class **RelionProject**

``initialized`` = *Boolean*

 Has a pipeline file been written for this project yet?

``pipeline_name`` = *String*

 The default name is 'default'. The pipeline file is named <name>_pipeline.star

``pipeline`` = **ProjectGraph** object

 Contains the data stored in the pipeline.  The format of the **ProjectGraph** object 
 is detailed in the advanced functions documentation.

|

**Setting up a project**

``start_new_project()``
 
 Initialises a new project in the current directory and creates a new pipeline   
 called ``<project_name>_pipeline.star``. If no name was specified when the project was 
 initialized it will be called ``default_pipeline.star``. It will return an error if a 
 Relion project already exists in the current directory.

|

Job running functions
+++++++++++++++++++++

``run_job(job_file, overwrite=False)``

**job_file**

*String*; Path to a job.star or run.job file

**overwrite**

*String*; Job name to overwrite.  Jobs can only be overwritten with jobs of the same type

 Reads a Relion job from a job.star or run.job file, adds the job to the pipeline and runs it immediately.  The job’s output dir is created and entries in the .Nodes dir for selecting files in the GUI are created when the job finishes successfully.

Returns: 

**job_name**

*String*; Job name that was run (IE: Class2D/Job004/)


|

``continue_job(job_name, is_only_schedule)``

**job_name**

*String*; The full name of the job IE: "Import/job001/".

**is_only_schedule**

*Boolean*; If ``True`` the continuation of the job will be scheduled but not run.  Default is ``False``.

Returns: 

**job_name**

*String*; Job name that was continued (IE: Class2D/Job004/)

|

``schedule_job(job_file)``

**job_file**

*String*; Path to a job.star or run.job file

 Reads a Relion job from a job.star or run.job file, adds the job to the pipeline, but sets its status to scheduled and does not run it.  The entries for the expected outputs are created in the .Nodes dir so the predicted outputs can be used as inputs for additional scheduled jobs

Returns: 

**job_name**

*String*; Job name that was scheduled (IE: Class2D/Job004/)

|

``run_schedule(fn_sched, job_ids, nr_repeat, minutes_wait, minutes_wait_before, seconds_wait_after)``

**fn_sched**

*String*; The name that will be used for the schedule
	
**job_ids**

*List*; names of the jobs to be run, in order IE [“Import/job001/”, “MotionCorr/job002/”, “CtfFind/job003/”]

**nr_repeat**

*Int*; Number of times to repeat the entire schedule

**minutes_wait**

*Float*; Minimum number of minutes to wait between each job in the schedule

**minutes_wait_before**

*Float*; Time to wait before initially starting the schedule

**seconds_wait_after**

*Int*; Time to wait between execution of each job

 Creates a schedule and runs the jobs in it.  These jobs need to have already been added to the pipeline using ``schedule_job()``.

Returns: 

**schedule_name**

*String*; Name of the schedule that was run (IE: Schedule1).  The schedule control file is called PIPELINER_RUNNING_<schedule_name>

Set up and job running examples
+++++++++++++++++++++++++++++++

Start and new project and run several jobs in series::

    >>> my_project = RelionProject()
    >>> my_project.start_new_project()
    >>> my_project.run_job("import1_job.star")        # Adds and runs Import/job001/
    >>> my_project.run_job("motioncorr1_job.star")    # Adds and runs MotionCorr/job002/

Add some scheduled jobs to a project and then run them::

    >>> my_project.schedule_job(ctffind1_job.star)   # Schedules CtfFind/job003/
    >>> my_project.schedule_job(autopick1_job.star)  # Schedules AutoPick/job004/
    >>> myproject.run_schedule(
            "Schedule1", 
            ["CtfFind/job003/", "AutoPick/job004/"], 
            nr_repeat=1
            miutes_wait=15, 
            minutes_wait_before=0, 
            seconds_wait_after=10,
        )


Making Dynamic Pipelines
++++++++++++++++++++++++

``modify_jobstar(fn_template, params_to_change, out_fn)``

**fn_template**

*String*; A relion job.star file

**params_to_change**

*Dict*; A dictionary of the paramaters in the template which should be changed in the form {parameter\:value, parameter\:value} 

**out_fn**

*String*; The name of the new starfile to be written.  If it does not eand with '_job.star' it will be modified so it does

 Takes a template starfile and modifies one or more parameters.  This is useful for when you need to use a file output from a job that hasn't run yet as an input. (see example below)

Returns:

**out_fn**

*String*; The output file name

Example: Using the output of a motion corr job as input for ctffind ::


    >>> mocorr_job = my_project.run_job("motioncorr1_job.star")    # Adds and runs MotionCorr job
    >>> my_project.modify_jobstar(                                 # Sets the input of the ctf job
            "ctf_job.star",                                        # to the file generated by the 
            {"input_star_mics": mocorr_job + "corrected_micrographs.star"} 
            "new_ctf_job.star"                                     # MotionCorr job
        )
   >>> my_project.run_job("new_ctf_job.star")

Other Relion functions
++++++++++++++++++++++

``add_alias(job, new_alias)``

**job**

*String*; The name of the job to operate on

**new_alias**

*String*; The new alias

 Changes the alias of a job in the pipeline.  To remove the alias use "" as the new alias

|

``update_job_status(job, is_failed, is_aborted)``

**job**

*String*; The name of the job to operate on

**is_failed**

*Boolean*; Should the job be marked as failed

**is_aborted**

*Boolean*; Should the job be marked as aborted

 Marks a job as finished unless ``is_failed`` or ``is_aborted`` is specified in which case 
 it is marked as such.  If a job is marke as aborted or failed while it is running Relion will stop
 the running job. If both ``is_failed`` and ``is_aborted`` are ``True`` the job is marked as 
 failed. More granular control of job status is available in ``pipeline`` functions

|

``delete_job(job, do_recursive=True)``

**jobs**

*String*; The name of the job to remove IE: "Import/job001/"

**do_recursive**

*Boolean*; If True all child jobs from the deleted job will also be removed. 

 Removed jobs will be moved to ``Trash/``. Performing non-recursive job deletions will 
 generally cause problems with the pipeline and is *not* recommended 

|

``undelete_job(job)``

**job**

*String*; The name of the job to recover Import/job001/"

 Recovered jobs will be moved from``Trash/`` and any aliases restored assuming they do not cause the creation of duplicate aliases. Any deleted parent jobs will also be restored.

|

``run_cleanup(jobs, harsh=False)``

**jobs**

*List*; A list of jobs to be cleaned ["Import/job001/", "MotionCorr/job002/"]

**harsh**

*Boolean*; If True, a more thorough cleanup will be performed

 Saves memory by removing intermediate files. See the Relion documentation for which files are removed

|

``cleanup_all(harsh=False)``

**harsh**

*Boolean*; If True, a more thorough cleanup will be performed
 
 Runs cleanup on all jobs in the project

Other job function examples
+++++++++++++++++++++++++++
Changing an alias::

    >>> my_project.add_alias(“AutoPick/job004/”, “new_alias”)
    
Deleting then undeleteing a job::

   >>> my_project.delete_job("Autopick/job004/")
   >>> my_project.undelete_job("Autopick/job004/")
   
Other utilities
+++++++++++++++

``print_command(job_file)``
 
**job_file**
 
*String*; Name of a job.star or run.job file
 
 Prints the command Relion would execute if the file indicated was
 used in the the ``run_job`` or ``schedule_job`` function.  It shows the actual job number 
 based on the current project.  If no Relion  project is initialized in the current dir it
 reports the job number as 000.  

|

``draw_flowcharts(job="", do_upstream=False, do_downstream=False, do_full=False)``

**job**

*String*; Specifices which job the flowchart focuses on.  This argument is not necessary if
``do_full`` is ``True``.

**do_upstream**

*Boolean*; Draw a flowchart showing the jobs that lead up to the job specified in the ``job`` argument

**do_downstream**

*Boolean*; Draw a flowchart showing the jobs that follow from the job specified in the ``job`` argument

**do_full**

*Boolean*; Draw a flowchart for the entire project

 Draws flowcharts for visulization of the project.  It will draw a separate flowchart for each of the 
 arguments that is ``True``.

|

``validate_starfile(fn_in)``

**fn_in**

*String*; .star file to be checked.

 Checks to make sure the .star file is readable.  A common error in star files is using 
 reserved words ("list\_", "save\_", and "data\_" to name a few) in data labels, which causes 
 errors when parsing the file.  Attempts to correct any errors it finds, returns an error
 if it cannot.

|

``empty_trash()``

 Deletes all of the files and folders in the Trash/ dir

|


``check_for_existing_project()``

 Checks if there is an existing Relion project in the current dir and reads the pipeline.  
 Returns an error if there is not an initialised Relion project in the current dir. 
 This function usually doesn’t need to be used by itself because it is automatically 
 run by ``initilize_existing_project``

|

``initialize_existing_project()``

 Checks that a Relion project exists and, assuming the current dir contains a Relion project, 
 checks if the pipeline has been updated and then reads the pipeline for the project.  Calling 
 this function is usually unnecessary as all of the functions that require an existing project 
 will run it automatically before executing. 
