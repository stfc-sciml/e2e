# Copyright (c) 2021, Science and Technology Facilities Council

import os.path
from setuptools import setup

setup(
    name='pipeliner',
    version='0.0.1',
    packages=['pipeliner'],
    install_requires=['gemmi', 'matplotlib', 'networkx', 'pandas', 'scipy'],
    test_suite='pipeliner_tests',
    
    entry_points = {
        'console_scripts': [
            'CL_relion = pipeliner.api.CL_relion:main',
            'reSPYon = pipeliner.api.reSPYon:main',
            'relion_job_create = pipeliner.api.interactive:interactive_job_create',
        ],
    },
)

