import unittest
import os
import shutil
import tempfile

from pipeliner import data_structure
from pipeliner.relion_jobs import job_factory, relion_job
from pipeliner.relion_jobs.buccaneer_job import BuccaneerJob
from pipeliner_tests import test_data
from pipeliner_tests import generic_tests
from pipeliner.data_structure import NODES


class RelionJobTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_relion_job_cannot_be_instantiated(self):
        with self.assertRaises(NotImplementedError):
            relion_job.RelionJob()

    def test_reading_import_mask_job(self):
        job = job_factory.read_job(
            os.path.join(self.test_data, "import_mask.job"), do_initialise=True
        )
        assert job.type == data_structure.IMPORT_TYPE_NUM
        assert job.output_name == ""
        assert job.hidden_name == ".gui_import"
        assert len(job.input_nodes) == 0
        assert len(job.output_nodes) == 0
        assert len(job.joboptions) == 15
        assert job.joboptions["fn_in_other"].label == "Input file:"
        assert job.joboptions["fn_in_other"].value == "emd_3488_mask.mrc"
        assert job.joboptions["node_type"].label == "Node type:"
        assert job.joboptions["node_type"].value == "3D mask (.mrc)"

    def test_reading_import_map_job(self):
        job = job_factory.read_job(
            os.path.join(self.test_data, "import_map.job"), do_initialise=True
        )
        assert job.type == data_structure.IMPORT_TYPE_NUM
        assert job.output_name == ""
        assert job.hidden_name == ".gui_import"
        assert len(job.input_nodes) == 0
        assert len(job.output_nodes) == 0
        assert len(job.joboptions) == 15
        assert job.joboptions["fn_in_other"].label == "Input file:"
        assert job.joboptions["fn_in_other"].value == "emd_3488.mrc"
        assert job.joboptions["node_type"].label == "Node type:"
        assert job.joboptions["node_type"].value == "3D reference (.mrc)"

    def test_reading_import_halfmap_job(self):
        job = job_factory.read_job(
            os.path.join(self.test_data, "import_halfmaps.job"), do_initialise=True
        )
        assert job.type == data_structure.IMPORT_TYPE_NUM
        assert job.output_name == ""
        assert job.hidden_name == ".gui_import"
        assert len(job.input_nodes) == 0
        assert len(job.output_nodes) == 0
        assert (
            len(job.joboptions) == 15
        )  # relion holds all possible options in this list (even if not passed as arg)
        assert job.joboptions["fn_in_other"].label == "Input file:"
        assert (
            job.joboptions["fn_in_other"].value == "3488_run_half1_class001_unfil.mrc"
        )
        assert job.joboptions["node_type"].label == "Node type:"
        assert job.joboptions["node_type"].value == "Unfiltered half-map (unfil.mrc)"

    def test_get_import_mask_commands(self):
        generic_tests.general_get_command_test(
            self,
            "Import",
            "import_mask.job",
            1,
            {},
            {"emd_3488_mask.mrc": NODES["Mask"]},
            '`which relion_import`  --do_other --i "emd_3488_mask.mrc" '
            "--odir Import/job001/ --ofile emd_3488_mask.mrc "
            "--pipeline_control Import/job001/ "
            ">> Import/job001/run.out 2>> Import/job001/run.err & ",
        )

    def test_get_import_halfmaps_commands(self):
        generic_tests.general_get_command_test(
            self,
            "Import",
            "import_halfmaps.job",
            1,
            {},
            {"3488_run_half1_class001_unfil.mrc": NODES["Halfmap"]},
            "`which relion_import`  --do_halfmaps --i "
            '"3488_run_half1_class001_unfil.mrc" --odir Import/job001/ --ofile '
            "3488_run_half1_class001_unfil.mrc --pipeline_control Import/job001/ "
            ">> Import/job001/run.out 2>> Import/job001/run.err & ",
        )

    def test_get_import_halfmaps_jobstar(self):
        generic_tests.general_get_command_test(
            self,
            "Import",
            "import_halfmaps_job.star",
            1,
            {},
            {"3488_run_half1_class001_unfil.mrc": NODES["Halfmap"]},
            "`which relion_import`  --do_halfmaps --i "
            '"3488_run_half1_class001_unfil.mrc" --odir Import/job001/ --ofile '
            "3488_run_half1_class001_unfil.mrc --pipeline_control Import/job001/ "
            ">> Import/job001/run.out 2>> Import/job001/run.err & ",
        )

    def test_get_import_map_commands(self):
        job = job_factory.read_job(
            os.path.join(self.test_data, "import_map.job"), do_initialise=True
        )
        commands = job.get_commands("", False, 1)
        expected_commands = (
            '`which relion_import`  --do_other --i "emd_3488.mrc" '
            "--odir Import/job001/ --ofile emd_3488.mrc "
            "--pipeline_control Import/job001/ "
            ">> Import/job001/run.out 2>> Import/job001/run.err & "
        )
        assert commands == expected_commands

    def test_import_job_directory_creation_with_default_jobdir(self):
        job = job_factory.read_job(
            os.path.join(self.test_data, "import_mask.job"), do_initialise=True
        )
        job_dir = os.path.join(self.test_dir, "Import/job023/")
        assert not os.path.isdir(job_dir)
        job.get_commands("", True, 23)
        assert os.path.isdir(job_dir)

    def test_import_job_directory_creation_with_defined_jobdir(self):
        job = job_factory.read_job(
            os.path.join(self.test_data, "import_mask.job"), do_initialise=True
        )
        job_dir = os.path.join(self.test_dir, "job_directory/")
        assert not os.path.isdir(job_dir)
        job.get_commands(job_dir, True, 1)
        assert os.path.isdir(job_dir)

    def test_get_buccaneer_commands(self):
        args_file = os.path.join(self.test_data, "buccaneer_args.json")
        job = BuccaneerJob(args_file)
        commands = job.get_commands("", False, 1502)
        assert (
            commands
            == "ccpem-buccaneer --no-gui --args "
            + args_file
            + " --job_location Buccaneer/job1502/ "
            ">> Buccaneer/job1502/run.out 2>> Buccaneer/job1502/run.err & "
        )


if __name__ == "__main__":
    unittest.main()
