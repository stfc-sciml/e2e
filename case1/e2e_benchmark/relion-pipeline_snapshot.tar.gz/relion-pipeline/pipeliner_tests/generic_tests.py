import os
import shutil
import time
import subprocess
from glob import glob

from pipeliner.job_runner import JobRunner
from pipeliner.relion_jobs import job_factory
from pipeliner.data_structure import PROCS
from pipeliner.utils import get_project_root


def print_coms(commands, expected_commands):
    print("\n" + commands)
    print(expected_commands)
    compare = ""
    for i in range(len(commands)):
        try:
            if commands[i] == expected_commands[i]:
                compare += " "
            else:
                compare += "*"
        except IndexError:
            pass
    print(compare)


def general_get_command_test(
    self,
    jobtype,
    jobfile,
    jobnumber,
    input_nodes,
    output_nodes,
    expected_command,
    show_coms=False,
    show_inputnodes=False,
    show_outputnodes=False,
    jobfiles_dir="JobFiles/{}/{}",
):
    """Tests that executing the get command function returns the expected
    commands and input and output nodes. Input and output nodes and entered
    as a dict {NodeName:Nodetype}.  The full path is necessary for input nodes
    but only the file name for output nodes as it is assumed they are in the
    output dir."""

    jobfile_path = jobfiles_dir.format(jobtype, jobfile)
    job = job_factory.read_job(
        os.path.join(self.test_data, jobfile_path), do_initialise=True
    )
    commands = job.get_commands("", False, jobnumber)
    expected_commands = expected_command

    assert commands == expected_commands, print_coms(commands, expected_commands)

    def print_inputnodes(expected):
        print("\nINPUT NODES: ({}/{})".format(len(job.input_nodes), len(expected)))
        for i in job.input_nodes:
            print(i.name)

    def print_outputnodes(expected):
        print("\nOUTPUT NODES: ({}/{})".format(len(job.output_nodes), len(expected)))
        for i in job.output_nodes:
            print(i.name)

    # make sure the expected nodes have been created
    expected_in_nodes = input_nodes
    expected_out_nodes = [
        jobtype + "/job{:03d}/".format(jobnumber) + x for x in output_nodes
    ]
    actual_in_nodes = [x.name for x in job.input_nodes]
    actual_out_nodes = [x.name for x in job.output_nodes]

    if show_coms:
        print_coms(commands, expected_commands)
    if show_inputnodes:
        print_inputnodes(input_nodes)
    if show_outputnodes:
        print_outputnodes(output_nodes)

    for node in expected_in_nodes:
        assert node in actual_in_nodes, node
    for node in expected_out_nodes:
        assert node in actual_out_nodes, node

    # make sure no extra nodes have been produced
    for node in actual_in_nodes:
        assert node in expected_in_nodes, "EXTRA NODE: " + node
    for node in actual_out_nodes:
        assert node in expected_out_nodes, "EXTRA NODE: " + node

    # make sure all of the nodes are of the correct type
    for node in job.input_nodes:
        assert node.type == input_nodes[node.name], (
            node.name,
            "node error expect/act",
            input_nodes[node.name],
            node.type,
        )
    # using the expected list here, but it has already been checked
    for node in job.output_nodes:
        node_name = os.path.basename(node.name)
        assert node.type == output_nodes[node_name], (
            node_name,
            "node error expect/act",
            output_nodes[node_name],
            node.type,
        )

    return job


def running_job(
    self,
    test_jobfile,
    job_dir_type,
    job_no,
    input_files,  # [(dir,file), ... (dir,file)]
    expected_outfiles,  # (file, file, ... file)
    sleep_time,  # to let the job finish - why is this needed?
    print_run=False,
    print_err=False,
    show_contents=False,
    jobfiles_dir="JobFiles/{}/{}",
    overwrite=False,
    target_job=None,
):
    # Prepare the directory structure as if previous jobs have been run:
    for infile in input_files:
        import_dir = infile[0]
        if not os.path.isdir(import_dir):
            os.makedirs(import_dir)
        assert os.path.isfile(os.path.join(self.test_data, infile[1])), infile[1]
        shutil.copy(
            os.path.join(self.test_data, infile[1]), import_dir,
        )

    pipeline = JobRunner()
    pipeline.graph.job_counter = job_no
    jobfile_path = jobfiles_dir.format(job_dir_type, test_jobfile)
    job = job_factory.read_job(
        os.path.join(self.test_data, jobfile_path), do_initialise=True
    )
    job_dir = job_dir_type + "/job00{}/".format(job_no)

    job_run = pipeline.run_job(job, target_job, False, False, False, overwrite)

    # Wait for job to finish, otherwise test fails. Shouldn't be necessary...
    time.sleep(sleep_time)
    if print_run:
        os.system("cat {}".format(os.path.join(job_dir, "run.out")))
    if print_err:
        os.system("cat {}".format(os.path.join(job_dir, "run.err")))

    if show_contents:
        os.system("ls -al")
        input("")
        os.system("ls -al " + job_dir)
        input("")
        os.system("cat default_pipeline.star")
        input("")
        os.system("cat {}/job.star".format(job_dir))
        input("")
        os.system("cat {}/job_pipeline.star".format(job_dir))
        input("")

        # test for output files
    assert os.path.isdir(job_dir)
    for outfile in expected_outfiles:
        assert os.path.isfile(os.path.join(job_dir, outfile)), outfile
    hiddenfile = job.hidden_name + "job.star"
    assert os.path.isfile(hiddenfile)
    return job_run


def make_shortpipe_filestructure(procs_to_make):
    """Builds the entire file structure for test_data/Pipelines/short_pipeline.star
    input a list of processes or 'all' to make the entire pipeline"""

    # only making the first few .Nodes dirs for testing deletion later
    nodes_files = [
        ".Nodes/0/Import/job001/movies.star",
        ".Nodes/13/MotionCorr/job002/logfile.pdf",
        ".Nodes/1/MotionCorr/job002/corrected_micrographs.star",
        ".Nodes/13/CtfFind/job003/logfile.pdf",
        ".Nodes/1/CtfFind/job003/micrographs_ctf.star",
    ]

    nodes_dirs = [
        ".Nodes/0/Import/job001",
        ".Nodes/13/MotionCorr/job002",
        ".Nodes/1/MotionCorr/job002",
        ".Nodes/13/CtfFind/job003",
        ".Nodes/1/CtfFind/job003",
    ]

    common_files = [
        "default_pipeline.star",
        "job_pipeline.star",
        "job.star",
        "note.txt",
        "RELION_JOB_EXIT_SUCCESS",
        "run.err",
        "run.out",
        "run.job",
    ]

    loop_procs = {
        "MotionCorr": [
            "_Fractions0-Patch-FitCoeff.log",
            "_Fractions0-Patch-Frame.log",
            "_Fractions0-Patch-Full.log",
            "_Fractions0-Patch-Patch.log",
            "_Fractions.com",
            "_Fractions.err",
            "_Fractions.mrc",
            "_Fractions.out",
            "_Fractions_shifts.eps",
            "_Fractions.star",
        ],
        "CtfFind": [
            "_Fractions.mrc",
            "_Fractions.pow",
            "_Fractions.ctf",
            "_Fractions.gctf.log",
        ],
        "AutoPick": ["_Fractions_autopick.star", "_Fractions_autopick.spi"],
        "Extract": ["_Fractions.mrcs", "_Fractions_extract.star"],
        "Class2D": [
            "_data.star",
            "_model.star",
            "_classes.mrcs",
            "_optimiser.star",
            "_sampling.star",
        ],
        "Class3D": [
            "_class001.mrc",
            "_class001_angdist.bild",
            "_class002.mrc",
            "_class002_angdist.bild",
            "_class003.mrc",
            "_class003_angdist.bild",
            "_sampling.star",
            "_data.star",
            "_model.star",
            "_optimiser.star",
        ],
        "Refine3D": [
            "_half1_class001.mrc",
            "_half1_class001_angdist.bild",
            "_half1_model.star",
            "_half2_class001.mrc",
            "_half2_class001_angdist.bild",
            "_half2_model.star",
            "_sampling.star",
            "_data.star",
            "_optimiser.star",
        ],
        "InitialModel": [
            "_class001.mrc",
            "_grad001.mrc",
            "_class002.mrc",
            "_grad002.mrc",
            "_sampling.star",
            "_data.star",
            "_model.star",
            "_optimiser.star",
        ],
        # need to add optimiser files here
        "MultiBody": [
            "_data.star",
            "_half1_body001_angdist.bild",
            "_half1_body001.mrc",
            "_half1_body002_angdist.bild",
            "_half1_body002.mrc",
            "_half1_model.star",
            "_half2_body001_angdist.bild",
            "_half2_body001.mrc",
            "_half2_body002_angdist.bild",
            "_half2_body002.mrc",
            "_half2_model.star",
        ],
        "CtfRefine": [
            "_fit.star",
            "_fit.eps",
            "_wAcc.mrc",
            "_xyAcc_real.mrc",
            "_xyAcc_imag.mrc",
        ],
        "Polish": [
            "_FCC_cc.mrc",
            "_FCC_w0.mrc",
            "_FCC_w1.mrc",
            "_shiny.mrcs",
            "_shiny.star",
            "_tracks.eps",
            "_tracks.star",
        ],
        "Subtract": ["star", "_opticsgroup1.mrcs", "_opticsgroup2.mrcs"],
    }

    single_files = {
        "MotionCorr": [
            "corrected_micrographs_all_rlnAccumMotionEarly.eps",
            "corrected_micrographs_all_rlnAccumMotionLate.eps",
            "corrected_micrographs_all_rlnAccumMotionTotal.eps",
            "corrected_micrographs_hist_rlnAccumMotionEarly.eps",
            "corrected_micrographs_hist_rlnAccumMotionLate.eps",
            "corrected_micrographs_hist_rlnAccumMotionTotal.eps",
            "corrected_micrographs.star",
            "logfile.pdf",
            "logfile.pdf.lst",
        ],
        "CtfFind": [
            "gctf0.err",
            "gctf0.out",
            "gctf1.err",
            "gctf1.out",
            "micrographs_ctf_all_rlnCtfAstigmatism.eps",
            "micrographs_ctf_all_rlnCtfFigureOfMerit.eps",
            "micrographs_ctf_all_rlnDefocusAngle.eps",
            "micrographs_ctf_all_rlnDefocusU.eps",
            "micrographs_ctf_hist_rlnCtfAstigmatism.eps",
            "micrographs_ctf_hist_rlnCtfFigureOfMerit.eps",
            "micrographs_ctf_hist_rlnDefocusAngle.eps",
            "micrographs_ctf_hist_rlnDefocusU.eps",
            "micrographs_ctf.star",
        ],
        "Select": ["backup_selection.star", "particles.star", "class_averages.star"],
        "Refine3D": [
            "run_class001.mrc",
            "run_half1_class001.mrc",
            "run_half2_class001.mrc",
            "run_class001_angdist.bild",
            "run_model.star",
            "run_sampling.star",
        ],
        "MultiBody": [
            "run_bodies.bild",
            "run_body001_angdist.bild",
            "run_body001_mask.mrc",
            "run_body001.mrc",
            "run_body002_angdist.bild",
            "run_body002_mask.mrc",
            "run_body002.mrc",
            "run_data.star",
            "run_half1_body001_unfil.mrc",
            "run_half1_body002_unfil.mrc",
            "run_half2_body001_unfil.mrc",
            "run_half2_body002_unfil.mrc",
        ],
        "CtfRefine": [
            "aberr_delta-phase_iter-fit_optics-group_1_N-4.mrc",
            "aberr_delta-phase_lin-fit_optics-group_1_N-4.mrc",
            "aberr_delta-phase_lin-fit_optics-group_1_N-4_residual.mrc",
            "aberr_delta-phase_per-pixel_optics-group_1.mrc",
            "asymmetric_aberrations_optics-group_1.eps",
            "beamtilt_delta-phase_iter-fit_optics-group_1_N-3.mrc",
            "beamtilt_delta-phase_lin-fit_optics-group_1_N-3.mrc",
            "beamtilt_delta-phase_lin-fit_optics-group_1_N-3_residual.mrc",
            "beamtilt_delta-phase_per-pixel_optics-group_1.mrc]",
            "particles_ctf_refine.star",
        ],
        "MaskCreate": ["mask.mrc.old", "mask.mrc"],
        "Polish": ["bfactors.eps", "bfactors.star", "scalefactors.eps", "shiny.star"],
        "PostProcess": [
            "postprocess_fsc.eps",
            "postprocess_fsc.xml",
            "postprocess_guinier.eps",
            "postprocess_masked.mrc",
            "postprocess.mrc",
            "postprocess.star",
        ],
        "LocalRes": [
            "relion_locres.mrc",
            "relion_locres_filtered.mrc",
            "relion_locres_fscs.star]",
        ],
    }

    def make_files(jobdir, filelist, out_list, common=common_files):
        os.system("mkdir -p " + jobdir)

        for node_dir in nodes_dirs:
            subprocess.run(["mkdir", "-p", node_dir])

        touchcom = ["touch"]
        for f in nodes_files:
            touchcom.append(f)
        for f in common:
            ff = jobdir + f
            touchcom.append(ff)
        subprocess.run(touchcom)
        for f in touchcom[1:]:
            assert os.path.isfile(f)

        touchcom = ["touch"]
        for f in filelist:
            ff = jobdir + f
            touchcom.append(ff)
            out_list.append(ff)
        if len(touchcom) > 1:
            subprocess.run(touchcom)

        for f in touchcom[1:]:
            assert os.path.isfile(f)

    def make_loopfiles(writedir, file_list, n, fn, out=False):
        if not os.path.isdir(writedir):
            os.system("mkdir -p " + writedir)

        touchcom = ["touch"]
        for i in range(1, n + 1):
            for f in file_list:
                ff = writedir + "/" + fn.replace("*", "{:03d}".format(i)) + f
                touchcom.append(ff)
                # os.system("touch " + ff)
                if out:
                    out.append(ff)
        subprocess.run(touchcom)

        for ff in touchcom[1:]:
            assert os.path.isfile(ff), ff

    outfiles = {}
    for proc in PROCS:
        if proc in procs_to_make or procs_to_make == "all":
            if proc == "Import":
                jobdir = proc + "/job001/"
                outfiles[proc] = [jobdir + x for x in common_files]
                make_files(jobdir, ["movies.star"], outfiles[proc])

            if proc == "MotionCorr":
                jobdir = proc + "/job002/"
                outfiles[proc] = [jobdir + x for x in common_files]
                make_files(jobdir, single_files[proc], outfiles[proc])
                raw_dir = jobdir + "Raw_data"
                make_loopfiles(
                    raw_dir, loop_procs[proc], 100, "FoilHole_62762_*", outfiles[proc],
                )

            if proc == "CtfFind":
                jobdir = proc + "/job003/"
                outfiles[proc] = [jobdir + x for x in common_files]
                make_files(jobdir, single_files[proc], outfiles[proc])
                raw_data = jobdir + "Raw_data"
                make_loopfiles(
                    raw_data,
                    loop_procs["CtfFind"],
                    100,
                    "FoilHole_62762_*",
                    outfiles[proc],
                )

            if proc == "AutoPick":
                jobdir = proc + "/job004/"
                outfiles[proc] = [jobdir + x for x in common_files]
                make_files(jobdir, ["coords_suffix_autopick.star"], outfiles[proc])
                raw_dir = jobdir + "Raw_data"
                make_loopfiles(
                    raw_dir, loop_procs[proc], 100, "FoilHole_62762_*", outfiles[proc],
                )

            if proc == "Extract":
                jobdir = proc + "/job005/"
                outfiles[proc] = [jobdir + x for x in common_files]
                make_files(jobdir, ["particles.star"], outfiles[proc])
                raw_dir = jobdir + "Raw_data"
                make_loopfiles(
                    raw_dir, loop_procs[proc], 100, "FoilHole_62762_*", outfiles[proc],
                )

            if proc == "Class2D":
                jobdir = proc + "/job006/"
                outfiles[proc] = [jobdir + x for x in common_files]
                make_files(jobdir, [], outfiles[proc])
                make_loopfiles(
                    jobdir[:-1], loop_procs[proc], 25, "run_it*", outfiles[proc],
                )

            if proc == "Select":
                jobdir = proc + "/job007/"
                outfiles[proc] = [jobdir + x for x in common_files]
                make_files(jobdir, single_files[proc], outfiles[proc])

            if proc == "InitialModel":
                jobdir = proc + "/job008/"
                outfiles[proc] = [jobdir + x for x in common_files]
                make_files(jobdir, [], outfiles[proc])
                make_loopfiles(
                    jobdir[:-1], loop_procs[proc], 150, "run_it*", outfiles[proc],
                )

            if proc == "Class3D":
                jobdir = proc + "/job009/"
                outfiles[proc] = [jobdir + x for x in common_files]
                make_files(jobdir, [], outfiles[proc])
                make_loopfiles(
                    jobdir[:-1], loop_procs[proc], 25, "run_it*", outfiles[proc],
                )

            if proc == "Refine3D":
                jobdir = proc + "/job010/"
                outfiles[proc] = [jobdir + x for x in common_files]
                make_files(jobdir, single_files[proc], outfiles[proc])
                make_loopfiles(
                    jobdir[:-1], loop_procs[proc], 16, "run_it*", outfiles[proc],
                )

            if proc == "MultiBody":
                jobdir = proc + "/job011/"
                outfiles[proc] = [jobdir + x for x in common_files]
                make_files(jobdir, single_files[proc], outfiles[proc])
                make_loopfiles(
                    jobdir[:-1], loop_procs[proc], 12, "run_it*", outfiles[proc],
                )
                touchcom = ["touch"]
                for i in range(0, 6):
                    h = "analyse_component{:03d}_histogram.eps".format(i)
                    hh = jobdir + h
                    # os.system("touch " + hh)
                    touchcom.append(hh)
                    outfiles[proc].append(hh)

                    for j in range(1, 11):
                        f = "analyse_component{:03d}_bin{:03d}.mrc".format(i, j)
                        ff = jobdir + f
                        touchcom.append(ff)
                        # os.system("touch " + ff)
                        outfiles[proc].append(ff)
                subprocess.run(touchcom)

            if proc == "CtfRefine":
                jobdir = proc + "/job012/"
                outfiles[proc] = [jobdir + x for x in common_files]
                make_files(jobdir, single_files["CtfRefine"], outfiles[proc])
                raw_data = jobdir + "Raw_data"
                make_loopfiles(
                    raw_data, loop_procs[proc], 100, "FoilHole_62762_*", outfiles[proc],
                )

            if proc == "MaskCreate":
                jobdir = proc + "/job013/"
                outfiles[proc] = [jobdir + x for x in common_files]
                make_files(jobdir, single_files[proc], outfiles[proc])

            if proc == "Polish":
                jobdir = proc + "/job014/"
                outfiles[proc] = [jobdir + x for x in common_files]
                make_files(jobdir, single_files[proc], outfiles[proc])
                raw_dir = jobdir + "Raw_data"
                make_loopfiles(
                    raw_dir, loop_procs[proc], 100, "FoilHole_62762_*", outfiles[proc],
                )

            if proc == "JoinStar":
                jobdir = proc + "/job015/"
                outfiles[proc] = [jobdir + x for x in common_files]
                make_files(jobdir, ["join_particles.star"], outfiles[proc])

            if proc == "Subtract":
                jobdir = proc + "/job016/"
                outfiles[proc] = [jobdir + x for x in common_files]
                make_files(jobdir, ["particles_subtract.star"], outfiles[proc])
                part_dir = jobdir + "Particles"
                make_loopfiles(
                    part_dir, loop_procs[proc], 10, "subtracted_rank*", outfiles[proc],
                )
            if proc == "PostProcess":
                jobdir = proc + "/job017/"
                outfiles[proc] = [jobdir + x for x in common_files]
                make_files(jobdir, single_files[proc], outfiles[proc])

            if proc == "External":
                jobdir = proc + "/job018/"
                outfiles[proc] = [jobdir + x for x in common_files]
                make_files(jobdir, [], outfiles[proc])
                make_loopfiles(
                    jobdir[:-1], [".file"], 10, "External_file_*", outfiles[proc]
                )
            if proc == "LocalRes":
                jobdir = proc + "/job019/"
                outfiles[proc] = [jobdir + x for x in common_files]
                make_files(jobdir, single_files[proc], outfiles[proc])
    return outfiles


def make_pipeline_entries(lines, newlines=False):
    """Make a the lines for a pipeline file formatted
    in the manner the programs output, eliminates test errors
    due to formatting problems, like the wrong number of spaces
    and prevents having to change EVERY test when/if node Names
    are changed
    - input format is a list of lists where each item contains the
    entries on one line
    If a pipeline file is to be compared line by line newlines need to
    be set as true
    """

    output_lines = []
    for line in lines:
        out_line = ""
        for value in line:
            if value in ("None", None):
                out_line += "{:>10} ".format("None")
            # Need to quote empty strings
            # (can normally use gemmi.cif.quote() for this but not if we
            # want strict RELION-style output)
            elif value == "":
                out_line += "{:>12} ".format('""')
            else:
                out_line += "{:>12} ".format(value)
        if not newlines:
            output_lines.append(out_line)
        else:
            output_lines.append(out_line + "\n")
    if len(output_lines) == 1:
        return output_lines[0]
    else:
        return output_lines


def check_for_plugin(plugin_file):
    """Check to see if a plugin is in the active plugind folder
    Used to skip plugin tests if the plugin in not installed"""

    plugin_dir = os.path.join(get_project_root(), "plugins/active")
    plugins = glob(plugin_dir + "/*.rln")
    plugfiles = [os.path.basename(x) for x in plugins]
    if plugin_file in plugfiles:
        return True
    else:
        return False
