import unittest
import os
import shutil
import tempfile
import subprocess

from pipeliner_tests import test_data, generic_tests
from pipeliner.star_writer import modify_jobstar


class JobStarWriterTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_with_postprocess_withmtf(self):
        generic_tests.running_job(
            self,
            "postprocess_adhocbf.job",
            "PostProcess",
            3,
            [
                ("Import/job001", "3488_run_half1_class001_unfil.mrc"),
                ("Import/job001", "3488_run_half2_class001_unfil.mrc"),
                ("Import/job002", "emd_3488_mask.mrc"),
                ("Import/mtffile", "mtf_k2_200kV.star"),
            ],
            (
                "run.out",
                "run.err",
                "postprocess.mrc",
                "postprocess_masked.mrc",
                "logfile.pdf",
            ),
            1,
        )
        actual_path = os.path.join(
            self.test_data, "JobFiles/PostProcess/postprocess_job.star"
        )
        wrote_path = os.path.join(self.test_dir, "PostProcess/job003/job.star")
        with open(actual_path) as actual:
            actual_file = actual.read()
        with open(wrote_path) as wrote:
            wrote_file = wrote.read()
        assert actual_file == wrote_file, subprocess.call(
            ["diff", actual_path, wrote_path]
        )

    def test_with_maskcreate_job(self):
        generic_tests.running_job(
            self,
            "maskcreate.job",
            "MaskCreate",
            2,
            [("Import/job001", "emd_3488.mrc")],
            ("run.out", "run.err", "mask.mrc"),
            5,
        )
        actual_path = os.path.join(
            self.test_data, "JobFiles/MaskCreate/maskcreate_job.star"
        )
        wrote_path = os.path.join(self.test_dir, "MaskCreate/job002/job.star")
        # subprocess.call(["cat",wrote_path])
        with open(actual_path) as actual:
            actual_file = actual.read()
        with open(wrote_path) as wrote:
            wrote_file = wrote.read()
        assert actual_file == wrote_file, subprocess.call(
            ["diff", actual_path, wrote_path]
        )

    def test_modify_jobstar(self):
        """modify a parameter in a jobstar"""

        # template file
        jobstar_file = os.path.join(
            self.test_data, "JobFiles/MaskCreate/maskcreate_job.star"
        )

        shutil.copy(jobstar_file, os.path.join(self.test_dir, "test_job.star"))

        modify_jobstar(jobstar_file, {"width_mask_edge": "100"}, "changed_job.star")

        # read the two files
        with open(jobstar_file) as original:
            original_lines = original.readlines()
        with open("changed_job.star") as written:
            written_lines = written.readlines()

        # make sure the change has been written
        for line in original_lines:
            if "width_mask_edge" not in line:
                assert line in written_lines, line
            else:
                assert line.split()[1] == "6", line
                assert line not in written_lines

        for line in written_lines:
            if "width_mask_edge" not in line:
                assert line in original_lines, line
            else:
                assert line.split()[1] == "100", line
                assert line not in original_lines

    def test_modify_jobstar_fix_filename(self):
        """modify a parameter in a jobstar, fix a bad filename"""

        # template file
        jobstar_file = os.path.join(
            self.test_data, "JobFiles/MaskCreate/maskcreate_job.star"
        )

        shutil.copy(jobstar_file, os.path.join(self.test_dir, "test_job.star"))

        modify_jobstar(jobstar_file, {"width_mask_edge": "100"}, "changed")

        # read the two files
        with open(jobstar_file) as original:
            original_lines = original.readlines()
        with open("changed_job.star") as written:
            written_lines = written.readlines()

        # make sure the change has been written
        for line in original_lines:
            if "width_mask_edge" not in line:
                assert line in written_lines, line
            else:
                assert line.split()[1] == "6", line
                assert line not in written_lines

        for line in written_lines:
            if "width_mask_edge" not in line:
                assert line in original_lines, line
            else:
                assert line.split()[1] == "100", line
                assert line not in original_lines

    def test_modify_jobstar_fix_filename_withext(self):
        """modify a parameter in a jobstar, fix a bad filename
        that has .star extension"""

        # template file
        jobstar_file = os.path.join(
            self.test_data, "JobFiles/MaskCreate/maskcreate_job.star"
        )

        shutil.copy(jobstar_file, os.path.join(self.test_dir, "test_job.star"))

        modify_jobstar(jobstar_file, {"width_mask_edge": "100"}, "changed.star")

        # read the two files
        with open(jobstar_file) as original:
            original_lines = original.readlines()
        with open("changed_job.star") as written:
            written_lines = written.readlines()

        # make sure the change has been written
        for line in original_lines:
            if "width_mask_edge" not in line:
                assert line in written_lines, line
            else:
                assert line.split()[1] == "6", line
                assert line not in written_lines

        for line in written_lines:
            if "width_mask_edge" not in line:
                assert line in original_lines, line
            else:
                assert line.split()[1] == "100", line
                assert line not in original_lines

    def test_modify_jobstar_change_datablock(self):
        """modify a parameter in a jobstar data block"""

        # template file
        jobstar_file = os.path.join(
            self.test_data, "JobFiles/MaskCreate/maskcreate_job.star"
        )

        shutil.copy(jobstar_file, os.path.join(self.test_dir, "test_job.star"))

        modify_jobstar(jobstar_file, {"_rlnJobType": "100"}, "changed_job.star")

        # read the two files
        with open(jobstar_file) as original:
            original_lines = original.readlines()
        with open("changed_job.star") as written:
            written_lines = written.readlines()

        # make sure the change has been written
        for line in original_lines:
            if "_rlnJobType" not in line:
                assert line in written_lines, line
            else:
                assert line.split()[1] == "12", line
                assert line not in written_lines

        for line in written_lines:
            if "_rlnJobType" not in line:
                assert line in original_lines, line
            else:
                assert line.split()[1] == "100", line
                assert line not in original_lines


if __name__ == "__main__":
    unittest.main()
