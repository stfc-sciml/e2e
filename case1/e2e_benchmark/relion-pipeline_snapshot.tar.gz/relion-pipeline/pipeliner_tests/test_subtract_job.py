import unittest
import os
import shutil
import tempfile

from pipeliner_tests import test_data
from pipeliner_tests.generic_tests import general_get_command_test
from pipeliner.data_structure import NODES


class SubtractTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_get_subtract_commands(self):
        general_get_command_test(
            self,
            "Subtract",
            "subtract.job",
            4,
            {
                "Refine3D/job500/run_it017_optimiser.star": NODES["Optimiser"],
                "MaskCreate/job501/mask.mrc": NODES["Mask"],
            },
            {"particles_subtracted.star": NODES["Part data"]},
            "mpirun -n 16 `which relion_particle_subtract_mpi` --i "
            "Refine3D/job500/run_it017_optimiser.star --mask "
            "MaskCreate/job501/mask.mrc --o Subtract/job004/ --new_box 420"
            " --pipeline_control Subtract/job004/ >> Subtract/job004/run.out"
            " 2>> Subtract/job004/run.err & ",
        )

    def test_get_subtract_commands_diff_parts(self):
        general_get_command_test(
            self,
            "Subtract",
            "subtract_diff_parts.job",
            4,
            {
                "Refine3D/job500/run_it017_optimiser.star": NODES["Optimiser"],
                "MaskCreate/job501/mask.mrc": NODES["Mask"],
                "myother_particles.star": NODES["Part data"],
            },
            {"particles_subtracted.star": NODES["Part data"]},
            "mpirun -n 16 `which relion_particle_subtract_mpi` --i "
            "Refine3D/job500/run_it017_optimiser.star --mask "
            "MaskCreate/job501/mask.mrc --data myother_particles.star"
            " --o Subtract/job004/ --new_box 420 --pipeline_control Subtract/job004/ "
            ">> Subtract/job004/run.out 2>> Subtract/job004/run.err & ",
        )

    def test_get_subtract_commands_revert_MPI(self):
        os.mkdir("Subtract")
        os.mkdir("Subtract/job004")
        general_get_command_test(
            self,
            "Subtract",
            "subtract_revert_MPI.job",
            4,
            {"these_were_original.star": NODES["Part data"]},
            {"original.star": NODES["Part data"]},
            "`which relion_particle_subtract` --revert these_were_original.star"
            " --o Subtract/job004/ --pipeline_control Subtract/job004/"
            " >> Subtract/job004/run.out 2>> Subtract/job004/run.err & ",
        )
        exp_errmsg = (
            "You cannot use MPI parallelization to revert particle"
            " labels. Changing number of mpis to 1\n"
        )

        with open("Subtract/job004/run.err", "r") as errfile:
            errmsg = errfile.readline()
            assert errmsg == exp_errmsg

    def test_get_subtract_commands_revert(self):
        os.mkdir("Subtract")
        os.mkdir("Subtract/job004")
        general_get_command_test(
            self,
            "Subtract",
            "subtract_revert_MPI.job",
            4,
            {"these_were_original.star": NODES["Part data"]},
            {"original.star": NODES["Part data"]},
            "`which relion_particle_subtract` --revert these_were_original.star"
            " --o Subtract/job004/ --pipeline_control Subtract/job004/"
            " >> Subtract/job004/run.out 2>> Subtract/job004/run.err & ",
        )

    def test_get_subtract_commands_centonmask(self):
        general_get_command_test(
            self,
            "Subtract",
            "subtract_centonmask.job",
            4,
            {
                "Refine3D/job500/run_it017_optimiser.star": NODES["Optimiser"],
                "MaskCreate/job501/mask.mrc": NODES["Mask"],
            },
            {"particles_subtracted.star": NODES["Part data"]},
            "mpirun -n 16 `which relion_particle_subtract_mpi` --i "
            "Refine3D/job500/run_it017_optimiser.star --mask "
            "MaskCreate/job501/mask.mrc --o Subtract/job004/ "
            "--recenter_on_mask --new_box 420 --pipeline_control Subtract/job004/"
            " >> Subtract/job004/run.out 2>> Subtract/job004/run.err & ",
        )

    def test_get_subtract_commands_centoncoords(self):
        general_get_command_test(
            self,
            "Subtract",
            "subtract_centoncoords.job",
            4,
            {
                "Refine3D/job500/run_it017_optimiser.star": NODES["Optimiser"],
                "MaskCreate/job501/mask.mrc": NODES["Mask"],
            },
            {"particles_subtracted.star": NODES["Part data"]},
            "mpirun -n 16 `which relion_particle_subtract_mpi` --i "
            "Refine3D/job500/run_it017_optimiser.star --mask "
            "MaskCreate/job501/mask.mrc --o Subtract/job004/ "
            "--center_x 101 --center_y 102 --center_z 103 --new_box 420"
            " --pipeline_control Subtract/job004/ >> "
            "Subtract/job004/run.out 2>> Subtract/job004/run.err & ",
        )

    def test_get_subtract_commands_additional_arg(self):
        general_get_command_test(
            self,
            "Subtract",
            "subtract_addarg.job",
            4,
            {
                "Refine3D/job500/run_it017_optimiser.star": NODES["Optimiser"],
                "MaskCreate/job501/mask.mrc": NODES["Mask"],
            },
            {"particles_subtracted.star": NODES["Part data"]},
            "mpirun -n 16 `which relion_particle_subtract_mpi` --i "
            "Refine3D/job500/run_it017_optimiser.star --mask "
            "MaskCreate/job501/mask.mrc --o Subtract/job004/ --new_box 420 "
            "--here_is_an_additional_arg --pipeline_control Subtract/job004/ >> "
            "Subtract/job004/run.out 2>> Subtract/job004/run.err & ",
        )

    def test_get_subtract_commands_additional_arg_jobstar(self):
        general_get_command_test(
            self,
            "Subtract",
            "subtract_addarg_job.star",
            4,
            {
                "Refine3D/job500/run_it017_optimiser.star": NODES["Optimiser"],
                "MaskCreate/job501/mask.mrc": NODES["Mask"],
            },
            {"particles_subtracted.star": NODES["Part data"]},
            "mpirun -n 16 `which relion_particle_subtract_mpi` --i "
            "Refine3D/job500/run_it017_optimiser.star --mask "
            "MaskCreate/job501/mask.mrc --o Subtract/job004/ --new_box 420 "
            "--here_is_an_additional_arg --pipeline_control Subtract/job004/ >> "
            "Subtract/job004/run.out 2>> Subtract/job004/run.err & ",
        )


if __name__ == "__main__":
    unittest.main()
