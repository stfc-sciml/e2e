import unittest
import os
import shutil
import tempfile
import subprocess

from pipeliner.project_graph import ProjectGraph
from pipeliner_tests import test_data

do_full = os.environ.get("UNITTEST_FULL", False) == "True"
do_interactive = os.environ.get("UNITTEST_INTERACTIVE", False) == "True"
# do_interactive = "True"


@unittest.skipUnless(do_interactive, "Slow test: only run in full unittest")
class ProjectGraphTestFlowcharts(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

        # copy in a few test files for particle counts
        # dirs[item][0] = the name of the file in test_data
        # dirs[item][1] = the name when it's copied over
        dirs = {
            "Import/job001": ("import1.star", "movies.star"),
            "MotionCorr/job002": ("mocorr2.star", "corrected_micrographs.star"),
            "CtfFind/job003": ("ctffind3.star", "micrographs_ctf.star"),
            "Select/job005": ("select5.star", "micrographs_selected.star"),
            "Extract/job007": ("extract7.star", "particles.star"),
            "Extract/job012": ("extract12.star", "particles.star"),
            "Sort/job013": ("extract12.star", "particles_sort.star"),
            "Select/job014": ("extract12.star", "particles.star"),
            "Select/job016": ("select16.star", "particles.star"),
            "Select/job019": ("select19.star", "particles.star"),
            "Extract/job020": ("extract20.star", "particles.star"),
            "Refine3D/job021": ("refine3d21.star", "run_data.star"),
            "CtfRefine/job024": ("refine3d21.star", "particles_ctf_refine.star"),
            "Polish/job026": ("refine3d21.star", "shiny.star"),
        }
        flowchart_dir = os.path.join(self.test_data, "Flowchart_data")
        for adir in dirs:
            subprocess.run(["mkdir", "-p", adir])
            thefile = os.path.join(flowchart_dir, dirs[adir][0])
            shutil.copy(thefile, os.path.join(adir, dirs[adir][1]))

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_flowchart_tutorial_whole_pipeline(self):
        # Copy tutorial pipeline file to test directory
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/tutorial_pipeline.star"),
            self.test_dir,
        )

        # Read pipeline STAR file
        pipeline = ProjectGraph(name="tutorial")
        pipeline.read()

        pipeline.full_process_graph()

    def test_flowchart_tutorial_job011_pipeline(self):
        # Copy tutorial pipeline file to test directory
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/tutorial_pipeline.star"),
            self.test_dir,
        )

        # Read pipeline STAR file
        pipeline = ProjectGraph(name="tutorial")
        pipeline.read()
        proc_name = pipeline.process_list[10]
        pipeline.downstream_process_graph(proc_name)

    def test_flowchart_tutorial_job017_pipeline(self):
        # Copy tutorial pipeline file to test directory
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/tutorial_pipeline.star"),
            self.test_dir,
        )

        # Read pipeline STAR file
        pipeline = ProjectGraph(name="tutorial")
        pipeline.read()
        proc_name = pipeline.process_list[16]
        pipeline.downstream_process_graph(proc_name)

    def test_flowchart_tutorial_job010_pipeline(self):
        # Copy tutorial pipeline file to test directory
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/tutorial_pipeline.star"),
            self.test_dir,
        )

        # Read pipeline STAR file
        pipeline = ProjectGraph(name="tutorial")
        pipeline.read()
        proc_name = pipeline.process_list[9]
        assert not pipeline.downstream_process_graph(proc_name)

    def test_flowchart_tutorial_job001_pipeline(self):
        # Copy tutorial pipeline file to test directory
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/tutorial_pipeline.star"),
            self.test_dir,
        )

        # Read pipeline STAR file
        pipeline = ProjectGraph(name="tutorial")
        pipeline.read()
        proc_name = pipeline.process_list[0]
        pipeline.downstream_process_graph(proc_name)

    def test_flowchart_tutorial_job002_pipeline(self):
        # Copy tutorial pipeline file to test directory
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/tutorial_pipeline.star"),
            self.test_dir,
        )

        # Read pipeline STAR file
        pipeline = ProjectGraph(name="tutorial")
        pipeline.read()
        proc_name = pipeline.process_list[1]
        pipeline.downstream_process_graph(proc_name)

    def test_flowchart_tutorial_job021_pipeline(self):
        # Copy tutorial pipeline file to test directory
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/tutorial_pipeline.star"),
            self.test_dir,
        )

        # Read pipeline STAR file
        pipeline = ProjectGraph(name="tutorial")
        pipeline.read()
        proc_name = pipeline.process_list[20]
        pipeline.downstream_process_graph(proc_name)

    def test_upstream_flowchart_tutorial_job002_pipeline(self):
        # Copy tutorial pipeline file to test directory
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/tutorial_pipeline.star"),
            self.test_dir,
        )

        # Read pipeline STAR file
        pipeline = ProjectGraph(name="tutorial")
        pipeline.read()
        proc_name = pipeline.process_list[1]
        pipeline.upstream_process_graph(proc_name)

    def test_upstream_flowchart_tutorial_job021_pipeline(self):
        # Copy tutorial pipeline file to test directory
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/tutorial_pipeline.star"),
            self.test_dir,
        )
        # Read pipeline STAR file
        pipeline = ProjectGraph(name="tutorial")
        pipeline.read()
        proc_name = pipeline.process_list[20]
        pipeline.upstream_process_graph(proc_name)

    def test_upstream_flowchart_tutorial_job011_pipeline(self):
        # Copy tutorial pipeline file to test directory
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/tutorial_pipeline.star"),
            self.test_dir,
        )

        # Read pipeline STAR file
        pipeline = ProjectGraph(name="tutorial")
        pipeline.read()
        proc_name = pipeline.process_list[10]
        pipeline.upstream_process_graph(proc_name)

    def test_upstream_flowchart_tutorial_job017_pipeline(self):
        # Copy tutorial pipeline file to test directory
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/tutorial_pipeline.star"),
            self.test_dir,
        )

        # Read pipeline STAR file
        pipeline = ProjectGraph(name="tutorial")
        pipeline.read()
        proc_name = pipeline.process_list[16]
        pipeline.upstream_process_graph(proc_name)

    def test_upstream_flowchart_tutorial_job010_pipeline(self):
        # Copy tutorial pipeline file to test directory
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/tutorial_pipeline.star"),
            self.test_dir,
        )

        # Read pipeline STAR file
        pipeline = ProjectGraph(name="tutorial")
        pipeline.read()
        proc_name = pipeline.process_list[9]
        assert pipeline.upstream_process_graph(proc_name)

    def test_upstream_flowchart_tutorial_job001_pipeline(self):
        # Copy tutorial pipeline file to test directory
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/tutorial_pipeline.star"),
            self.test_dir,
        )

        # Read pipeline STAR file
        pipeline = ProjectGraph(name="tutorial")
        pipeline.read()
        proc_name = pipeline.process_list[0]
        assert not pipeline.upstream_process_graph(proc_name)


if __name__ == "__main__":
    unittest.main()
