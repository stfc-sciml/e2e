import unittest
import os
import shutil
import tempfile
import time
from glob import glob

from pipeliner import data_structure
from pipeliner.job_runner import JobRunner
from pipeliner.relion_jobs import job_factory
from pipeliner_tests import test_data, generic_tests


class JobRunnerTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def wait_for_file(self, path, time_in_seconds=1):
        """Wait for a file to appear after a job"""
        step = 0.1
        total = 0
        while not os.path.isfile(path):
            time.sleep(step)
            total += step
            assert total < time_in_seconds, (
                f"File {path} does not exist after " f"{time_in_seconds} seconds"
            )

    def test_running_import_mask_job(self):
        # Copy the mask file into place
        # TODO: would be better to just pass the path to the mask as a job option
        shutil.copy(os.path.join(self.test_data, "emd_3488_mask.mrc"), self.test_dir)

        # Prepare a new pipeline and run the job
        pipeline = JobRunner()
        job = job_factory.read_job(
            os.path.join(self.test_data, "import_mask.job"), do_initialise=True
        )
        job_dir = "Import/job001/"
        assert not os.path.isdir(job_dir)
        pipeline.run_job(job, None, False, False, False)

        # Need to wait a short time, otherwise test fails. Shouldn't really be
        # necessary. Maybe this happens because new files take time to be flushed to
        # disk?
        time.sleep(0.1)

        # Test for output files
        assert os.path.isdir(job_dir)
        assert os.path.isfile(os.path.join(job_dir, "run.out"))
        assert os.path.isfile(os.path.join(job_dir, "run.err"))
        assert os.path.isfile(os.path.join(job_dir, "emd_3488_mask.mrc"))

        # Test for correct project graph state
        project_graph = pipeline.graph
        assert len(project_graph.process_list) == 1
        assert project_graph.job_counter == 2
        assert len(project_graph.node_list) == 1
        assert project_graph.node_list[0].name == "Import/job001/emd_3488_mask.mrc"
        assert project_graph.node_list[0].type == data_structure.NODES["Mask"]
        assert os.path.isfile(".gui_importjob.star")

    def test_running_import_map_job(self):
        # Copy the map file into place
        # TODO: would be better to just pass the path to the mask as a job option
        shutil.copy(os.path.join(self.test_data, "emd_3488.mrc"), self.test_dir)

        # Prepare a new pipeline and run the job
        pipeline = JobRunner()
        job = job_factory.read_job(
            os.path.join(self.test_data, "import_map.job"), do_initialise=True
        )
        job_dir = "Import/job001/"
        assert not os.path.isdir(job_dir)
        pipeline.run_job(job, None, False, False, False)

        # Need to wait a short time, otherwise test fails. Shouldn't really be
        # necessary. Maybe this happens because new files take time to be flushed to
        # disk?
        time.sleep(0.1)

        # Test for output files
        assert os.path.isdir(job_dir)
        assert os.path.isfile(os.path.join(job_dir, "run.out"))
        assert os.path.isfile(os.path.join(job_dir, "run.err"))
        assert os.path.isfile(os.path.join(job_dir, "emd_3488.mrc"))

        # Test for correct project graph state
        project_graph = pipeline.graph
        assert len(project_graph.process_list) == 1
        assert project_graph.job_counter == 2
        assert len(project_graph.node_list) == 1
        assert project_graph.node_list[0].name == "Import/job001/emd_3488.mrc"
        assert project_graph.node_list[0].type == data_structure.NODES["3D refs"]

    def test_running_postprocess_job(self):
        # Prepare the directory structure as if Import jobs have been run
        halfmap_import_dir = "Import/job001/"
        os.makedirs(halfmap_import_dir)
        shutil.copy(
            os.path.join(self.test_data, "3488_run_half1_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        shutil.copy(
            os.path.join(self.test_data, "3488_run_half2_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        mask_import_dir = "Import/job002/"
        os.makedirs(mask_import_dir)
        shutil.copy(os.path.join(self.test_data, "emd_3488_mask.mrc"), mask_import_dir)

        pipeline = JobRunner()
        pipeline.graph.job_counter = 3
        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/PostProcess/postprocess.job"),
            do_initialise=True,
        )
        job.get_commands("", False, 3)
        job_dir = "PostProcess/job003/"
        assert not os.path.isdir(job_dir)
        pipeline.run_job(job, None, False, False, False)

        # Wait for job to finish, otherwise test fails. Shouldn't be necessary...
        time.sleep(1)

        # Test for output files
        assert os.path.isdir(job_dir)
        assert os.path.isfile(os.path.join(job_dir, "run.out"))
        assert os.path.isfile(os.path.join(job_dir, "run.err"))
        assert os.path.isfile(os.path.join(job_dir, "postprocess.mrc"))
        assert os.path.isfile(os.path.join(job_dir, "postprocess_masked.mrc"))
        assert os.path.isfile(os.path.join(job_dir, "logfile.pdf"))
        assert os.path.isfile(".gui_postjob.star")

    def test_generic_with_PP(self):
        generic_tests.running_job(
            self,
            "postprocess.job",
            "PostProcess",
            3,
            [
                ("Import/job001", "3488_run_half1_class001_unfil.mrc"),
                ("Import/job001", "3488_run_half2_class001_unfil.mrc"),
                ("Import/job002", "emd_3488_mask.mrc"),
            ],
            (
                "run.out",
                "run.err",
                "postprocess.mrc",
                "postprocess_masked.mrc",
                "logfile.pdf",
            ),
            1,
        )

    def test_running_maskcreate_job(self):
        generic_tests.running_job(
            self,
            "maskcreate.job",
            "MaskCreate",
            2,
            [("Import/job001", "emd_3488.mrc")],
            ("run.out", "run.err", "mask.mrc"),
            5,
        )

    def test_postprocess_adhocbf(self):
        generic_tests.running_job(
            self,
            "postprocess_adhocbf.job",
            "PostProcess",
            3,
            [
                ("Import/job001", "3488_run_half1_class001_unfil.mrc"),
                ("Import/job001", "3488_run_half2_class001_unfil.mrc"),
                ("Import/job002", "emd_3488_mask.mrc"),
            ],
            (
                "run.out",
                "run.err",
                "postprocess.mrc",
                "postprocess_masked.mrc",
                "logfile.pdf",
            ),
            1,
            # show_contents=True,
        )

    def test_postprocess_autobf(self):
        generic_tests.running_job(
            self,
            "postprocess_autobf.job",
            "PostProcess",
            3,
            [
                ("Import/job001", "3488_run_half1_class001_unfil.mrc"),
                ("Import/job001", "3488_run_half2_class001_unfil.mrc"),
                ("Import/job002", "emd_3488_mask.mrc"),
            ],
            (
                "run.out",
                "run.err",
                "postprocess.mrc",
                "postprocess_masked.mrc",
                "logfile.pdf",
            ),
            1,
        )

    def test_split_job(self):
        """Select jobs that split star files in defined size groups generate
        an unknown number of output files so they are a special case where
        output nodes are generated after the job runs"""

        # first run a job to create the dirs
        generic_tests.running_job(
            self,
            "select_parts_split_runtest.job",
            "Select",
            3,
            [("Extract/job001", "particles.star")],
            (
                "run.out",
                "run.err",
                "particles_split1.star",
                "particles_split2.star",
                "particles_split3.star",
                "particles_split4.star",
                "particles_split5.star",
                "particles_split6.star",
                "particles_split7.star",
                "particles_split8.star",
                "particles_split9.star",
                "particles_split10.star",
                "particles_split11.star",
                "particles_split12.star",
            ),
            1,
        )

        exp_lines = [
            "Select/job003/ Select/job003/particles_split1.star",
            "Select/job003/ Select/job003/particles_split10.star",
            "Select/job003/ Select/job003/particles_split11.star",
            "Select/job003/ Select/job003/particles_split12.star",
            "Select/job003/ Select/job003/particles_split2.star",
            "Select/job003/ Select/job003/particles_split3.star",
            "Select/job003/ Select/job003/particles_split4.star",
            "Select/job003/ Select/job003/particles_split5.star",
            "Select/job003/ Select/job003/particles_split6.star",
            "Select/job003/ Select/job003/particles_split7.star",
            "Select/job003/ Select/job003/particles_split8.star",
            "Select/job003/ Select/job003/particles_split9.star",
            "Select/job003/particles_split1.star            3",
            "Select/job003/particles_split10.star            3",
            "Select/job003/particles_split11.star            3",
            "Select/job003/particles_split12.star            3",
            "Select/job003/particles_split2.star            3",
            "Select/job003/particles_split3.star            3",
            "Select/job003/particles_split4.star            3",
            "Select/job003/particles_split5.star            3",
            "Select/job003/particles_split6.star            3",
            "Select/job003/particles_split7.star            3",
            "Select/job003/particles_split8.star            3",
            "Select/job003/particles_split9.star            3",
        ]
        with open("default_pipeline.star", "r") as pipeline:
            lines = pipeline.readlines()
        for i in exp_lines:
            assert i + " \n" in lines, [i]

    def test_overwriting_job_with_different_type_raises_error(self):
        """Can't overwrite a job with a different type of job"""
        # run the job to create the dirs
        job_run = generic_tests.running_job(
            self,
            "postprocess_autobf.job",
            "PostProcess",
            3,
            [
                ("Import/job001", "3488_run_half1_class001_unfil.mrc"),
                ("Import/job001", "3488_run_half2_class001_unfil.mrc"),
                ("Import/job002", "emd_3488_mask.mrc"),
            ],
            (
                "run.out",
                "run.err",
                "postprocess.mrc",
                "postprocess_masked.mrc",
                "logfile.pdf",
            ),
            1,
        )

        # then overwrite it with a different job
        with self.assertRaises(ValueError):
            generic_tests.running_job(
                self,
                "maskcreate.job",
                "MaskCreate",
                0,  # this should not be used because it's overwrite
                [("Import/job001", "emd_3488.mrc")],
                ("run.out", "run.err", "mask.mrc"),
                5,
                overwrite=True,
                target_job=job_run,
            )

    def test_overwriting_job(self):
        """Overwrite a job with a new run of the same type"""
        # first run a job to create the dirs
        job_run = generic_tests.running_job(
            self,
            "postprocess_autobf.job",
            "PostProcess",
            3,
            [
                ("Import/job001", "3488_run_half1_class001_unfil.mrc"),
                ("Import/job001", "3488_run_half2_class001_unfil.mrc"),
                ("Import/job002", "emd_3488_mask.mrc"),
            ],
            (
                "run.out",
                "run.err",
                "postprocess.mrc",
                "postprocess_masked.mrc",
                "logfile.pdf",
            ),
            1,
        )

        # then overwrite it with another job
        generic_tests.running_job(
            self,
            "postprocess_skipfsc.job",
            "PostProcess",
            3,
            [
                ("Import/job001", "3488_run_half1_class001_unfil.mrc"),
                ("Import/job001", "3488_run_half2_class001_unfil.mrc"),
                ("Import/job002", "emd_3488_mask.mrc"),
            ],
            (
                "run.out",
                "run.err",
                "postprocess.mrc",
                "postprocess_masked.mrc",
                "logfile.pdf",
            ),
            1,
            overwrite=True,
            target_job=job_run,
        )

    def test_overwriting_job_with_children(self):
        """Overwrite a job with children, make sure it is archived and
        The change is noted on the children"""
        # first run a job to create the dirs
        job_run = generic_tests.running_job(
            self,
            "postprocess_autobf.job",
            "PostProcess",
            3,
            [
                ("Import/job001", "3488_run_half1_class001_unfil.mrc"),
                ("Import/job001", "3488_run_half2_class001_unfil.mrc"),
                ("Import/job002", "emd_3488_mask.mrc"),
            ],
            (
                "run.out",
                "run.err",
                "postprocess.mrc",
                "postprocess_masked.mrc",
                "logfile.pdf",
            ),
            1,
        )

        # copy in a pipeline with fake child jobs
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/children_pipeline.star"),
            "default_pipeline.star",
        )

        # make the childjob dirs
        os.makedirs("ChildProcess/job004/")
        os.makedirs("ChildProcess/job005/")

        # then overwrite it with another job
        generic_tests.running_job(
            self,
            "postprocess_autobf.job",
            "PostProcess",
            3,
            [
                ("Import/job001", "3488_run_half1_class001_unfil.mrc"),
                ("Import/job001", "3488_run_half2_class001_unfil.mrc"),
                ("Import/job002", "emd_3488_mask.mrc"),
            ],
            (
                "run.out",
                "run.err",
                "postprocess.mrc",
                "postprocess_masked.mrc",
                "logfile.pdf",
            ),
            1,
            overwrite=True,
            target_job=job_run,
        )
        # check that the overwritten markers have been written
        for child_dir in ["ChildProcess/job004/", "ChildProcess/job005/"]:
            PO_marker = glob(child_dir + "PARENT_OVERWRITTEN*")
            assert len(PO_marker) == 1, PO_marker

        # find the archive dir
        alldirs = glob(".*")
        for i in alldirs:
            if "PostProcess.job003" in i:
                archive_dir = i
                break

        # get the files in it
        adir_files = glob(archive_dir + "/*")
        expected_files = [
            "RELION_JOB_EXIT_SUCCESS",
            "continue_job.star",
            "default_pipeline.star",
            "job.star",
            "job_pipeline.star",
            "logfile.pdf",
            "logfile.pdf.lst",
            "note.txt",
            "postprocess.mrc",
            "postprocess.star",
            "postprocess_fsc.eps",
            "postprocess_fsc.xml",
            "postprocess_guinier.eps",
            "postprocess_masked.mrc",
            "run.err",
            "run.job",
            "run.out",
        ]
        for f in expected_files:
            assert os.path.join(archive_dir, f) in adir_files, f

    def test_postprocess_skipfsc(self):
        generic_tests.running_job(
            self,
            "postprocess_skipfsc.job",
            "PostProcess",
            3,
            [
                ("Import/job001", "3488_run_half1_class001_unfil.mrc"),
                ("Import/job001", "3488_run_half2_class001_unfil.mrc"),
                ("Import/job002", "emd_3488_mask.mrc"),
            ],
            (
                "run.out",
                "run.err",
                "postprocess.mrc",
                "postprocess_masked.mrc",
                "logfile.pdf",
            ),
            1,
        )

    def test_postprocess_withmtf(self):
        generic_tests.running_job(
            self,
            "postprocess_adhocbf.job",
            "PostProcess",
            3,
            [
                ("Import/job001", "3488_run_half1_class001_unfil.mrc"),
                ("Import/job001", "3488_run_half2_class001_unfil.mrc"),
                ("Import/job002", "emd_3488_mask.mrc"),
                ("Import/mtffile", "mtf_k2_200kV.star"),
            ],
            (
                "run.out",
                "run.err",
                "postprocess.mrc",
                "postprocess_masked.mrc",
                "logfile.pdf",
            ),
            1,
        )


if __name__ == "__main__":
    unittest.main()
