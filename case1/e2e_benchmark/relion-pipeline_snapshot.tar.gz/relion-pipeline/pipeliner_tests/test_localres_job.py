import unittest
import os
import shutil
import tempfile

from pipeliner_tests import test_data
from pipeliner_tests.generic_tests import general_get_command_test
from pipeliner.data_structure import NODES


class LocalResTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)
        # make some dirs for testing sym link making
        os.mkdir("Refine3D")
        os.mkdir("Refine3D/job029")
        open("Refine3D/job029/run_half1_class001_unfil.mrc", "a").close()
        open("Refine3D/job029/run_half1_class002_unfil.mrc", "a").close()
        os.mkdir("LocalRes")
        os.mkdir("LocalRes/job014")

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_relion_localres(self):
        general_get_command_test(
            self,
            "LocalRes",
            "localres_relion.job",
            14,
            {"Refine3D/job029/run_half1_class001_unfil.mrc": NODES["Halfmap"]},
            {
                "histogram.pdf": NODES["PdfLogfile"],
                "relion_locres_filtered.mrc": NODES["Finalmap"],
                "relion_locres.mrc": NODES["Resmap"],
            },
            "mpirun -n 12 `which relion_postprocess_mpi` --locres --i "
            "Refine3D/job029/run_half1_class001_unfil.mrc --o "
            "LocalRes/job014/relion --angpix 1.244 --adhoc_bfac -30"
            " --pipeline_control LocalRes/job014/"
            " >> LocalRes/job014/run.out 2>> LocalRes/job014/run.err & ",
        )

    def test_relion_localres_jobstar(self):
        general_get_command_test(
            self,
            "LocalRes",
            "localres_relion_job.star",
            14,
            {"Refine3D/job029/run_half1_class001_unfil.mrc": NODES["Halfmap"]},
            {
                "histogram.pdf": NODES["PdfLogfile"],
                "relion_locres_filtered.mrc": NODES["Finalmap"],
                "relion_locres.mrc": NODES["Resmap"],
            },
            "mpirun -n 12 `which relion_postprocess_mpi` --locres --i "
            "Refine3D/job029/run_half1_class001_unfil.mrc --o "
            "LocalRes/job014/relion --angpix 1.244 --adhoc_bfac -30"
            " --pipeline_control LocalRes/job014/"
            " >> LocalRes/job014/run.out 2>> LocalRes/job014/run.err & ",
        )

    def test_relion_localres_mtf(self):
        general_get_command_test(
            self,
            "LocalRes",
            "localres_relion_mtf.job",
            14,
            {"Refine3D/job029/run_half1_class001_unfil.mrc": NODES["Halfmap"]},
            {
                "histogram.pdf": NODES["PdfLogfile"],
                "relion_locres_filtered.mrc": NODES["Finalmap"],
                "relion_locres.mrc": NODES["Resmap"],
            },
            "mpirun -n 12 `which relion_postprocess_mpi` --locres --i "
            "Refine3D/job029/run_half1_class001_unfil.mrc --o "
            "LocalRes/job014/relion --angpix 1.244 --adhoc_bfac -30"
            " --mtf my_MTF_file.star --pipeline_control LocalRes/job014/"
            " >> LocalRes/job014/run.out 2>> LocalRes/job014/run.err & ",
        )

    def test_relion_localres_nompi(self):
        general_get_command_test(
            self,
            "LocalRes",
            "localres_relion_nompi.job",
            14,
            {"Refine3D/job029/run_half1_class001_unfil.mrc": NODES["Halfmap"]},
            {
                "histogram.pdf": NODES["PdfLogfile"],
                "relion_locres_filtered.mrc": NODES["Finalmap"],
                "relion_locres.mrc": NODES["Resmap"],
            },
            "`which relion_postprocess` --locres --i "
            "Refine3D/job029/run_half1_class001_unfil.mrc --o "
            "LocalRes/job014/relion --angpix 1.244 --adhoc_bfac -30"
            " --pipeline_control LocalRes/job014/"
            " >> LocalRes/job014/run.out 2>> LocalRes/job014/run.err & ",
        )

    def test_resmap_localres(self):
        general_get_command_test(
            self,
            "LocalRes",
            "localres_resmap.job",
            14,
            {
                "MaskCreate/job400/mask.mrc": NODES["Mask"],
                "Refine3D/job029/run_half1_class001_unfil.mrc": NODES["Halfmap"],
            },
            {"half1_resmap.mrc": NODES["Resmap"]},
            "/public/EM/ResMap/ResMap-1.1.4-linux64 "
            "--maskVol=MaskCreate/job400/mask.mrc --noguiSplit "
            "LocalRes/job014/half1.mrc LocalRes/job014/half2.mrc --vxSize=1.244 "
            "--pVal=0.05 --minRes=10 --maxRes=2.5 --stepRes=1"
            " >> LocalRes/job014/run.out 2>> LocalRes/job014/run.err & ",
        )
        # check that the symlinks were made correctly
        assert os.path.islink("LocalRes/job014/half1.mrc")
        assert os.path.islink("LocalRes/job014/half2.mrc")

    def test_localres_both_error(self):
        with self.assertRaises(ValueError):
            general_get_command_test(
                self, "LocalRes", "localres_both_error.job", 14, 1, 3, "",
            )

    def test_localres_resmap_mpi_fix(self):
        general_get_command_test(
            self,
            "LocalRes",
            "localres_resmap_mpi.job",
            14,
            {
                "MaskCreate/job400/mask.mrc": NODES["Mask"],
                "Refine3D/job029/run_half1_class001_unfil.mrc": NODES["Halfmap"],
            },
            {"half1_resmap.mrc": NODES["Resmap"]},
            "/public/EM/ResMap/ResMap-1.1.4-linux64 "
            "--maskVol=MaskCreate/job400/mask.mrc --noguiSplit "
            "LocalRes/job014/half1.mrc LocalRes/job014/half2.mrc --vxSize=1.244 "
            "--pVal=0.05 --minRes=10 --maxRes=2.5 --stepRes=1"
            " >> LocalRes/job014/run.out 2>> LocalRes/job014/run.err & ",
        )

        exp_errmsg = (
            "You cannot use more than 1 MPI processor for the ResMap wrapper..."
            " Changing number of mpis to 1\n"
        )

        with open("LocalRes/job014/run.err", "r") as errfile:
            errmsg = errfile.readline()
            assert errmsg == exp_errmsg


if __name__ == "__main__":
    unittest.main()
