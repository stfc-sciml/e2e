import unittest
import os
import shutil
import tempfile
import subprocess

from pipeliner.relion_jobs import job_factory
from pipeliner_tests import test_data


class QsubJobsTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        for envvar in (
            "RELION_QSUB_EXTRA_COUNT",
            "RELION_QSUB_EXTRA1",
            "RELION_QSUB_EXTRA1_DEFAULT",
            "RELION_QSUB_EXTRA1_HELP",
            "RELION_QSUB_EXTRA2",
            "RELION_QSUB_EXTRA2_DEFAULT",
            "RELION_QSUB_EXTRA2_HELP" "RELION_QSUB_EXTRA3",
            "RELION_QSUB_EXTRA3_DEFAULT",
            "RELION_QSUB_EXTRA3_HELP" "RELION_QSUB_EXTRA4",
            "RELION_QSUB_EXTRA4_DEFAULT",
            "RELION_QSUB_EXTRA4_HELP",
        ):
            if envvar in os.environ:
                del os.environ[envvar]

        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_get_env_vars_defaults(self):
        envvars = {
            "RELION_QSUB_EXTRA_COUNT": "4",
            "RELION_QSUB_EXTRA1": "Extra variable 1: ",
            "RELION_QSUB_EXTRA1_DEFAULT": "101",
            "RELION_QSUB_EXTRA1_HELP": "HELP! 1",
            "RELION_QSUB_EXTRA2": "Extra variable 2: ",
            "RELION_QSUB_EXTRA2_DEFAULT": "202",
            "RELION_QSUB_EXTRA2_HELP": "HELP! 2",
            "RELION_QSUB_EXTRA3": "Extra variable 3: ",
            "RELION_QSUB_EXTRA3_DEFAULT": "303",
            "RELION_QSUB_EXTRA3_HELP": "HELP! 3",
            "RELION_QSUB_EXTRA4": "Extra variable 4: ",
            "RELION_QSUB_EXTRA4_DEFAULT": "404",
            "RELION_QSUB_EXTRA4_HELP": "HELP! 4",
        }
        for envvar in envvars:
            os.environ[envvar] = envvars[envvar]

        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/Qsub/refine3D_qsub_defaults.job")
        )

        assert job.joboptions["qsub_extra_1"].value == "101"
        assert job.joboptions["qsub_extra_2"].value == "202"
        assert job.joboptions["qsub_extra_3"].value == "303"
        assert job.joboptions["qsub_extra_4"].value == "404"

    def test_get_env_vars_2extras(self):
        envvars = {
            "RELION_QSUB_EXTRA_COUNT": "2",
            "RELION_QSUB_EXTRA1": "Extra variable 1: ",
            "RELION_QSUB_EXTRA1_DEFAULT": "101",
            "RELION_QSUB_EXTRA1_HELP": "HELP! 1",
            "RELION_QSUB_EXTRA2": "Extra variable 2: ",
            "RELION_QSUB_EXTRA2_DEFAULT": "202",
            "RELION_QSUB_EXTRA2_HELP": "HELP! 2",
        }
        for envvar in envvars:
            os.environ[envvar] = envvars[envvar]

        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/Qsub/refine3D_qsub_2extras.job")
        )

        assert job.joboptions["qsub_extra_1"].value == "Here is number 1"
        assert job.joboptions["qsub_extra_2"].value == "Here is number 2"

    def test_get_env_vars_4extras(self):
        envvars = {
            "RELION_QSUB_EXTRA_COUNT": "4",
            "RELION_QSUB_EXTRA1": "Extra variable 1: ",
            "RELION_QSUB_EXTRA1_DEFAULT": "101",
            "RELION_QSUB_EXTRA1_HELP": "HELP! 1",
            "RELION_QSUB_EXTRA2": "Extra variable 2: ",
            "RELION_QSUB_EXTRA2_DEFAULT": "202",
            "RELION_QSUB_EXTRA2_HELP": "HELP! 2",
            "RELION_QSUB_EXTRA3": "Extra variable 3: ",
            "RELION_QSUB_EXTRA3_DEFAULT": "303",
            "RELION_QSUB_EXTRA3_HELP": "HELP! 3",
            "RELION_QSUB_EXTRA4": "Extra variable 4: ",
            "RELION_QSUB_EXTRA4_DEFAULT": "404",
            "RELION_QSUB_EXTRA4_HELP": "HELP! 4",
        }
        for envvar in envvars:
            os.environ[envvar] = envvars[envvar]

        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/Qsub/refine3D_qsub_4extras.job")
        )

        assert job.joboptions["qsub_extra_1"].value == "Here is number 1"
        assert job.joboptions["qsub_extra_2"].value == "Here is number 2"
        assert job.joboptions["qsub_extra_3"].value == "Here is number 3"
        assert job.joboptions["qsub_extra_4"].value == "Here is number 4"

    def test_qsub_write_script_refine3D(self):
        envvars = {
            "RELION_QSUB_EXTRA_COUNT": "4",
            "RELION_QSUB_EXTRA1": "Extra variable 1: ",
            "RELION_QSUB_EXTRA1_DEFAULT": "101",
            "RELION_QSUB_EXTRA1_HELP": "HELP! 1",
            "RELION_QSUB_EXTRA2": "Extra variable 2: ",
            "RELION_QSUB_EXTRA2_DEFAULT": "202",
            "RELION_QSUB_EXTRA2_HELP": "HELP! 2",
            "RELION_QSUB_EXTRA3": "Extra variable 3: ",
            "RELION_QSUB_EXTRA3_DEFAULT": "303",
            "RELION_QSUB_EXTRA3_HELP": "HELP! 3",
            "RELION_QSUB_EXTRA4": "Extra variable 4: ",
            "RELION_QSUB_EXTRA4_DEFAULT": "404",
            "RELION_QSUB_EXTRA4_HELP": "HELP! 4",
        }
        for envvar in envvars:
            os.environ[envvar] = envvars[envvar]

        scriptfile = os.path.join(self.test_data + "/submission_script.sh")
        subprocess.call(["cp", scriptfile, "."])

        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/Qsub/refine3D_qsub_4extras.job")
        )
        command = job.get_commands("", True, 1)
        expected_command = "qsub Refine3D/job001/run_submit.script &"

        assert command == expected_command
        assert job.joboptions["qsub_extra_1"].value == "Here is number 1"
        assert job.joboptions["qsub_extra_2"].value == "Here is number 2"
        assert job.joboptions["qsub_extra_3"].value == "Here is number 3"
        assert job.joboptions["qsub_extra_4"].value == "Here is number 4"

        actual_script = os.path.join(
            self.test_data + "/JobFiles/Qsub/submission_script_ref3d.sh"
        )
        out_script = os.path.join(self.test_dir, "Refine3D/job001/run_submit.script")

        with open(actual_script) as actual:
            actual = actual.read()
        with open(out_script) as wrote:
            wrote = wrote.read()
        assert actual == wrote

    def test_qsub_write_script_refine3D_1mpi(self):
        envvars = {
            "RELION_QSUB_EXTRA_COUNT": "4",
            "RELION_QSUB_EXTRA1": "Extra variable 1: ",
            "RELION_QSUB_EXTRA1_DEFAULT": "101",
            "RELION_QSUB_EXTRA1_HELP": "HELP! 1",
            "RELION_QSUB_EXTRA2": "Extra variable 2: ",
            "RELION_QSUB_EXTRA2_DEFAULT": "202",
            "RELION_QSUB_EXTRA2_HELP": "HELP! 2",
            "RELION_QSUB_EXTRA3": "Extra variable 3: ",
            "RELION_QSUB_EXTRA3_DEFAULT": "303",
            "RELION_QSUB_EXTRA3_HELP": "HELP! 3",
            "RELION_QSUB_EXTRA4": "Extra variable 4: ",
            "RELION_QSUB_EXTRA4_DEFAULT": "404",
            "RELION_QSUB_EXTRA4_HELP": "HELP! 4",
        }
        for envvar in envvars:
            os.environ[envvar] = envvars[envvar]

        scriptfile = os.path.join(self.test_data + "/submission_script.sh")
        subprocess.call(["cp", scriptfile, "."])

        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/Qsub/refine3D_qsub_4extras_1mpi.job")
        )
        command = job.get_commands("", True, 1)
        expected_command = "qsub Refine3D/job001/run_submit.script &"

        assert command == expected_command
        assert job.joboptions["qsub_extra_1"].value == "Here is number 1"
        assert job.joboptions["qsub_extra_2"].value == "Here is number 2"
        assert job.joboptions["qsub_extra_3"].value == "Here is number 3"
        assert job.joboptions["qsub_extra_4"].value == "Here is number 4"

        actual_script = os.path.join(
            self.test_data + "/JobFiles/Qsub/submission_script_ref3d_1mpi.sh"
        )
        out_script = os.path.join(self.test_dir, "Refine3D/job001/run_submit.script")

        with open(actual_script) as actual:
            actual = actual.read()
        with open(out_script) as wrote:
            wrote = wrote.read()
        assert actual == wrote

    def test_qsub_write_script_autopick(self):
        envvars = {
            "RELION_QSUB_EXTRA_COUNT": "4",
            "RELION_QSUB_EXTRA1": "Extra variable 1: ",
            "RELION_QSUB_EXTRA1_DEFAULT": "101",
            "RELION_QSUB_EXTRA1_HELP": "HELP! 1",
            "RELION_QSUB_EXTRA2": "Extra variable 2: ",
            "RELION_QSUB_EXTRA2_DEFAULT": "202",
            "RELION_QSUB_EXTRA2_HELP": "HELP! 2",
            "RELION_QSUB_EXTRA3": "Extra variable 3: ",
            "RELION_QSUB_EXTRA3_DEFAULT": "303",
            "RELION_QSUB_EXTRA3_HELP": "HELP! 3",
            "RELION_QSUB_EXTRA4": "Extra variable 4: ",
            "RELION_QSUB_EXTRA4_DEFAULT": "404",
            "RELION_QSUB_EXTRA4_HELP": "HELP! 4",
        }
        for envvar in envvars:
            os.environ[envvar] = envvars[envvar]

        scriptfile = os.path.join(self.test_data + "/submission_script.sh")
        subprocess.call(["cp", scriptfile, "."])

        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/Qsub/autopick_2dref_qsub.job")
        )
        command = job.get_commands("", True, 1)
        expected_command = "qsub AutoPick/job001/run_submit.script &"

        assert command == expected_command
        assert job.joboptions["qsub_extra_1"].value == "Here is number 1"
        assert job.joboptions["qsub_extra_2"].value == "Here is number 2"
        assert job.joboptions["qsub_extra_3"].value == "Here is number 3"
        assert job.joboptions["qsub_extra_4"].value == "Here is number 4"

        actual_script = os.path.join(
            self.test_data + "/JobFiles/Qsub/submission_script_autopick_2dref.sh"
        )
        out_script = os.path.join(self.test_dir, "AutoPick/job001/run_submit.script")

        with open(actual_script) as actual:
            actual = actual.read()
        with open(out_script) as wrote:
            wrote = wrote.read()
        assert actual == wrote

    def test_qsub_write_script_multibody(self):
        envvars = {
            "RELION_QSUB_EXTRA_COUNT": "4",
            "RELION_QSUB_EXTRA1": "Extra variable 1: ",
            "RELION_QSUB_EXTRA1_DEFAULT": "101",
            "RELION_QSUB_EXTRA1_HELP": "HELP! 1",
            "RELION_QSUB_EXTRA2": "Extra variable 2: ",
            "RELION_QSUB_EXTRA2_DEFAULT": "202",
            "RELION_QSUB_EXTRA2_HELP": "HELP! 2",
            "RELION_QSUB_EXTRA3": "Extra variable 3: ",
            "RELION_QSUB_EXTRA3_DEFAULT": "303",
            "RELION_QSUB_EXTRA3_HELP": "HELP! 3",
            "RELION_QSUB_EXTRA4": "Extra variable 4: ",
            "RELION_QSUB_EXTRA4_DEFAULT": "404",
            "RELION_QSUB_EXTRA4_HELP": "HELP! 4",
        }
        for envvar in envvars:
            os.environ[envvar] = envvars[envvar]

        scriptfile = os.path.join(self.test_data + "/submission_script.sh")
        subprocess.call(["cp", scriptfile, "."])
        bodyfile = os.path.join(self.test_data + "/JobFiles/MultiBody/bodyfile.star")
        subprocess.call(["cp", bodyfile, "."])

        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/Qsub/multibody_sep_eigen_qsub.job")
        )
        command = job.get_commands("", True, 1)
        expected_command = "qsub MultiBody/job001/run_submit.script &"

        assert command == expected_command
        assert job.joboptions["qsub_extra_1"].value == "Here is number 1"
        assert job.joboptions["qsub_extra_2"].value == "Here is number 2"
        assert job.joboptions["qsub_extra_3"].value == "Here is number 3"
        assert job.joboptions["qsub_extra_4"].value == "Here is number 4"

        actual_script = os.path.join(
            self.test_data + "/JobFiles/Qsub/submission_script_multibody.sh"
        )
        out_script = os.path.join(self.test_dir, "MultiBody/job001/run_submit.script")

        with open(actual_script) as actual:
            actual = actual.read()
        with open(out_script) as wrote:
            wrote = wrote.read()
        subprocess.call(["diff", actual_script, out_script])
        assert actual == wrote

    def test_qsub_no_template_specified(self):
        with self.assertRaises(ValueError):
            job = job_factory.read_job(
                os.path.join(self.test_data, "JobFiles/Qsub/qsub_notemplate.job")
            )
            job.get_commands("", True, 1)

    def test_qsub_template_missing(self):
        with self.assertRaises(ValueError):
            job = job_factory.read_job(
                os.path.join(self.test_data, "JobFiles/Qsub/autopick_2dref_qsub.job")
            )
            job.get_commands("", True, 1)

    def test_qsub_cant_write_output_script(self):
        with self.assertRaises(ValueError):
            scriptfile = os.path.join(self.test_data + "/submission_script.sh")
            subprocess.call(["cp", scriptfile, "."])
            job = job_factory.read_job(
                os.path.join(self.test_data, "JobFiles/Qsub/autopick_2dref_qsub.job")
            )
            job.get_commands("", False, 1)


if __name__ == "__main__":
    unittest.main()
