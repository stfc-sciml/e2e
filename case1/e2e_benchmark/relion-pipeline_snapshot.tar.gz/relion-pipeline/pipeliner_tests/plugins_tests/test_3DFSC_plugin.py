import unittest
import os
import shutil
import tempfile

from pipeliner_tests.plugins_tests import test_data
from pipeliner_tests import generic_tests
from pipeliner.data_structure import NODES
from pipeliner_tests.generic_tests import check_for_plugin

do_full = os.environ.get("UNITTEST_FULL", False) == "True"
do_interactive = os.environ.get("UNITTEST_INTERACTIVE", False) == "True"

plugin_present = check_for_plugin("threeDFSC_plugin.rln")


@unittest.skipIf(
    not plugin_present or os.environ.get("RELION_THREEDFSC_PATH") is None, 
    "Skipping because plugin not active"
)
class ThreeDFSCPlugInsTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

        # set up the files threeDFSC needs to run
        os.system("mkdir -p Refine3D/job001")
        os.system("touch Refine3D/job001/run_class001_half2_unfil.mrc")
        os.system("touch Refine3D/job001/run_class001.mrc")
        os.system("touch Refine3D/job001/run_class001_half1_unfil.mrc")
        model_file = os.path.join(self.test_data, "run_model.star")
        os.system("cp {} Refine3D/job001".format(model_file))

        # set the path to find ThreeDFSC_Start.py
        self.oldpath = os.environ["PATH"]
        tdfsc_path = os.environ.get("RELION_THREEDFSC_PATH")
        os.environ["PATH"] = self.oldpath + ":" + tdfsc_path

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)
        os.environ["PATH"] = self.oldpath

    def test_get_command_3dfsc_plugin(self):

        generic_tests.general_get_command_test(
            self,
            "ThreeDFSC",
            "threed_fsc_apix_job.star",
            2,
            {
                "Refine3D/job001/run_class001_half1_unfil.mrc": NODES["Halfmap"],
                "Refine3D/job001/run_class001.mrc": NODES["3D refs"],
                "MaskCreate/job002/mask.mrc": NODES["Mask"],
            },
            {"3DFSCOutput.mrc": NODES["Other"]},
            "ThreeDFSC_Start.py "
            "--halfmap1=Refine3D/job001/run_class001_half1_unfil.mrc "
            "--halfmap2=Refine3D/job001/run_class001_half2_unfil.mrc "
            "--fullmap=Refine3D/job001/run_class001.mrc "
            "--maskMaskCreate/job002/mask.mrc"
            " --apix=1.244 --dthetaInDegrees=20.0 --FSCCutoff=0.143 "
            "--ThresholdForSphericity=0.5 --HighPassFilter=200.0 "
            "--numThresholdsForSphericityCalcs=0 "
            ">> ThreeDFSC/job002/run.out 2>> ThreeDFSC/job002/run.err "
            "&& mv Results_3DFSCOutput/* ThreeDFSC/job002/ >> "
            "ThreeDFSC/job002/run.out 2>> ThreeDFSC/job002/run.err && rm "
            "Results_3DFSCOutput >> ThreeDFSC/job002/run.out 2>> "
            "ThreeDFSC/job002/run.err & ",
            jobfiles_dir="{}/{}",
        )

    def test_get_command_3dfsc_plugin_queued(self):
        sub_script = os.path.join(
            self.test_data, "../../test_data/submission_script.sh"
        )
        shutil.copy(sub_script, self.test_dir)
        os.makedirs("ThreeDFSC/job002")
        generic_tests.general_get_command_test(
            self,
            "ThreeDFSC",
            "threed_fsc_queued_job.star",
            2,
            {
                "Refine3D/job001/run_class001_half1_unfil.mrc": NODES["Halfmap"],
                "Refine3D/job001/run_class001.mrc": NODES["3D refs"],
                "MaskCreate/job002/mask.mrc": NODES["Mask"],
            },
            {"3DFSCOutput.mrc": NODES["Other"]},
            "qsub ThreeDFSC/job002/run_submit.script &",
            jobfiles_dir="{}/{}",
        )
        sub_script_lines = [
            "#$ -cwd -V\n",
            "#$ -l h_rt=96:00:00     # specifiy max run time here\n",
            "#$ -m be\n",
            "#$ -e ThreeDFSC/job002/run.err\n",
            "#$ -o ThreeDFSC/job002/run.out\n",
            "#$ -P openmpi\n",
            "#$  -M matthew.iadanza@stfc.ac.uk    # put your email address here \n",
            "#$  -l coproc_v100=4   # GPUS in relion should be left blank\n",
            "## load modules \n",
            "module load intel/19.0.4 cuda/10.1.168\n",
            "## Here are some more extra variables\n",
            "kwanze queuesub extra var: moja\n",
            "pili queuesub extra var: mbili\n",
            "## set library paths\n",
            "export PATH=$CUDA_HOME/bin:$PATH\n",
            "export LD_LIBRARY_PATH=$CUDA_HOME/lib64:$LD_LIBRARY_PATH\n",
            (
                "export LD_LIBRARY_PATH=/home/ufaserv1_k/fbscem/relion_arc/arc4/"
                "relion/build/lib/:\n"
            ),
            "## print some diagnostic info \n",
            "module list\n",
            "nvidia-smi -L\n",
            "which relion_refine_mpi\n",
            "## run relion\n",
            "let NSLOTS=NSLOTS/2\n",
            (
                "ThreeDFSC_Start.py --halfmap1=Refine3D/job001/run_class"
                "001_half1_unfil.mrc --halfmap2=Refine3D/job001/run_class001"
                "_half2_unfil.mrc --fullmap=Refine3D/job001/run_class001.mrc"
                " --maskMaskCreate/job002/mask.mrc --apix=1.04 --dthetaInDegr"
                "ees=20.0 --FSCCutoff=0.143 --ThresholdForSphericity=0.5 --Hi"
                "ghPassFilter=200.0 --numThresholdsForSphericityCalcs=0\n"
            ),
            "mv Results_3DFSCOutput/* ThreeDFSC/job002/\n",
            "rm Results_3DFSCOutput\n",
            "touch ThreeDFSC/job002/PLUGIN_QUEUED_FINISHED\n",
            "#One more extra command for good measure \n",
            "wa tatu queuesub extra var: tatu\n",
            "dedicated nodes: 1\n",
            "output name: ThreeDFSC/job002/\n",
        ]

        with open("ThreeDFSC/job002/run_submit.script") as sub_script_data:
            sub_script = sub_script_data.readlines()
        for line in sub_script_lines:
            assert line in sub_script, line

    def test_get_command_threedfsc_with_mask(self):
        generic_tests.general_get_command_test(
            self,
            "ThreeDFSC",
            "threed_fsc_job.star",
            3,
            {
                "Refine3D/job001/run_class001_half1_unfil.mrc": NODES["Halfmap"],
                "Refine3D/job001/run_class001.mrc": NODES["3D refs"],
                "MaskCreate/job002/mask.mrc": NODES["Mask"],
            },
            {"3DFSCOutput.mrc": NODES["Other"]},
            "ThreeDFSC_Start.py "
            "--halfmap1=Refine3D/job001/run_class001_half1_unfil.mrc "
            "--halfmap2=Refine3D/job001/run_class001_half2_unfil.mrc "
            "--fullmap=Refine3D/job001/run_class001.mrc "
            "--maskMaskCreate/job002/mask.mrc --apix=1.04 "
            "--dthetaInDegrees=20.0 --FSCCutoff=0.143 "
            "--ThresholdForSphericity=0.5 --HighPassFilter=200.0 "
            "--numThresholdsForSphericityCalcs=0"
            " >> ThreeDFSC/job003/run.out 2>> ThreeDFSC/job003/run.err "
            "&& mv Results_3DFSCOutput/* ThreeDFSC/job003/ >> "
            "ThreeDFSC/job003/run.out 2>> ThreeDFSC/job003/run.err && rm "
            "Results_3DFSCOutput >> ThreeDFSC/job003/run.out 2>> "
            "ThreeDFSC/job003/run.err & ",
            jobfiles_dir="{}/{}",
        )

    def test_get_command_threedfsc_with_mask_1gpu(self):
        generic_tests.general_get_command_test(
            self,
            "ThreeDFSC",
            "threed_fsc_mask_1gpu_job.star",
            3,
            {
                "Refine3D/job001/run_class001_half1_unfil.mrc": NODES["Halfmap"],
                "Refine3D/job001/run_class001.mrc": NODES["3D refs"],
                "MaskCreate/job002/mask.mrc": NODES["Mask"],
            },
            {"3DFSCOutput.mrc": NODES["Other"]},
            "ThreeDFSC_Start.py "
            "--halfmap1=Refine3D/job001/run_class001_half1_unfil.mrc "
            "--halfmap2=Refine3D/job001/run_class001_half2_unfil.mrc "
            "--fullmap=Refine3D/job001/run_class001.mrc "
            "--maskMaskCreate/job002/mask.mrc --apix=1.04 "
            "--dthetaInDegrees=20.0 --FSCCutoff=0.143 "
            "--ThresholdForSphericity=0.5 --HighPassFilter=200.0 "
            "--numThresholdsForSphericityCalcs=0"
            " --gpu --gpu_id=1 >> ThreeDFSC/job003/run.out 2>> "
            "ThreeDFSC/job003/run.err "
            "&& mv Results_3DFSCOutput/* ThreeDFSC/job003/ >> "
            "ThreeDFSC/job003/run.out 2>> ThreeDFSC/job003/run.err && rm "
            "Results_3DFSCOutput >> ThreeDFSC/job003/run.out 2>> "
            "ThreeDFSC/job003/run.err & ",
            jobfiles_dir="{}/{}",
        )

    def test_get_command_threedfsc_with_mask_toomany_gpu(self):
        generic_tests.general_get_command_test(
            self,
            "ThreeDFSC",
            "threed_fsc_mask_2gpu_job.star",
            3,
            {
                "Refine3D/job001/run_class001_half1_unfil.mrc": NODES["Halfmap"],
                "Refine3D/job001/run_class001.mrc": NODES["3D refs"],
                "MaskCreate/job002/mask.mrc": NODES["Mask"],
            },
            {"3DFSCOutput.mrc": NODES["Other"]},
            "ThreeDFSC_Start.py "
            "--halfmap1=Refine3D/job001/run_class001_half1_unfil.mrc "
            "--halfmap2=Refine3D/job001/run_class001_half2_unfil.mrc "
            "--fullmap=Refine3D/job001/run_class001.mrc "
            "--maskMaskCreate/job002/mask.mrc --apix=1.04 "
            "--dthetaInDegrees=20.0 --FSCCutoff=0.143 "
            "--ThresholdForSphericity=0.5 --HighPassFilter=200.0 "
            "--numThresholdsForSphericityCalcs=0"
            " --gpu --gpu_id=1 >> ThreeDFSC/job003/run.out 2>> "
            "ThreeDFSC/job003/run.err "
            "&& mv Results_3DFSCOutput/* ThreeDFSC/job003/ >> "
            "ThreeDFSC/job003/run.out 2>> ThreeDFSC/job003/run.err && rm "
            "Results_3DFSCOutput >> ThreeDFSC/job003/run.out 2>> "
            "ThreeDFSC/job003/run.err & ",
            jobfiles_dir="{}/{}",
        )

    def test_get_command_threedfsc_no_mask(self):
        generic_tests.general_get_command_test(
            self,
            "ThreeDFSC",
            "threed_fsc_nomask_job.star",
            3,
            {
                "Refine3D/job001/run_class001_half1_unfil.mrc": NODES["Halfmap"],
                "Refine3D/job001/run_class001.mrc": NODES["3D refs"],
            },
            {"3DFSCOutput.mrc": NODES["Other"]},
            "ThreeDFSC_Start.py "
            "--halfmap1=Refine3D/job001/run_class001_half1_unfil.mrc "
            "--halfmap2=Refine3D/job001/run_class001_half2_unfil.mrc "
            "--fullmap=Refine3D/job001/run_class001.mrc "
            "--apix=1.04 "
            "--dthetaInDegrees=20.0 --FSCCutoff=0.143 "
            "--ThresholdForSphericity=0.5 --HighPassFilter=200.0 "
            "--numThresholdsForSphericityCalcs=0"
            " >> ThreeDFSC/job003/run.out 2>> ThreeDFSC/job003/run.err "
            "&& mv Results_3DFSCOutput/* ThreeDFSC/job003/ >> "
            "ThreeDFSC/job003/run.out 2>> ThreeDFSC/job003/run.err && rm "
            "Results_3DFSCOutput >> ThreeDFSC/job003/run.out 2>> "
            "ThreeDFSC/job003/run.err & ",
            jobfiles_dir="{}/{}",
        )

    def test_get_command_threedfsc_auto_apix(self):
        generic_tests.general_get_command_test(
            self,
            "ThreeDFSC",
            "threed_fsc_apix_job.star",
            3,
            {
                "Refine3D/job001/run_class001_half1_unfil.mrc": NODES["Halfmap"],
                "Refine3D/job001/run_class001.mrc": NODES["3D refs"],
                "MaskCreate/job002/mask.mrc": NODES["Mask"],
            },
            {"3DFSCOutput.mrc": NODES["Other"]},
            "ThreeDFSC_Start.py "
            "--halfmap1=Refine3D/job001/run_class001_half1_unfil.mrc "
            "--halfmap2=Refine3D/job001/run_class001_half2_unfil.mrc "
            "--fullmap=Refine3D/job001/run_class001.mrc "
            "--maskMaskCreate/job002/mask.mrc --apix=1.244 "
            "--dthetaInDegrees=20.0 --FSCCutoff=0.143 "
            "--ThresholdForSphericity=0.5 --HighPassFilter=200.0 "
            "--numThresholdsForSphericityCalcs=0"
            " >> ThreeDFSC/job003/run.out 2>> ThreeDFSC/job003/run.err "
            "&& mv Results_3DFSCOutput/* ThreeDFSC/job003/ >> "
            "ThreeDFSC/job003/run.out 2>> ThreeDFSC/job003/run.err && rm "
            "Results_3DFSCOutput >> ThreeDFSC/job003/run.out 2>> "
            "ThreeDFSC/job003/run.err & ",
            jobfiles_dir="{}/{}",
        )

    def test_get_command_threedfsc_error_halfmap1_misnamed(self):
        os.system(
            "mv Refine3D/job001/run_class001_half1_unfil.mrc"
            " Refine3D/job001/run_class001_junk_unfil.mrc"
        )
        with self.assertRaises(RuntimeError):
            generic_tests.general_get_command_test(
                self,
                "ThreeDFSC",
                "threed_fsc_badmap_job.star",
                3,
                {
                    "Refine3D/job001/run_class001_half1_unfil.mrc": NODES["Halfmap"],
                    "Refine3D/job001/run_class001.mrc": NODES["3D refs"],
                    "MaskCreate/job002/mask.mrc": NODES["Mask"],
                },
                {"3DFSCOutput.mrc": NODES["Other"]},
                "ThreeDFSC_Start.py "
                "--halfmap1=Refine3D/job001/run_class001_half1_unfil.mrc "
                "--halfmap2=Refine3D/job001/run_class001_half2_unfil.mrc "
                "--fullmap=Refine3D/job001/run_class001.mrc "
                "--maskMaskCreate/job002/mask.mrc --apix=1.04 "
                "--dthetaInDegrees=20.0 --FSCCutoff=0.143 "
                "--ThresholdForSphericity=0.5 --HighPassFilter=200.0 "
                "--numThresholdsForSphericityCalcs=0"
                ">> ThreeDFSC/job003/run.out 2>> ThreeDFSC/job003/run.err "
                "&& mv Results_3DFSCOutput/* ThreeDFSC/job003/ >> "
                "ThreeDFSC/job003/run.out 2>> ThreeDFSC/job003/run.err && rm "
                "Results_3DFSCOutput >> ThreeDFSC/job003/run.out 2>> "
                "ThreeDFSC/job003/run.err & ",
                jobfiles_dir="{}/{}",
            )

    def test_get_command_threedfsc_error_halfmap1_missing(self):
        os.system("rm Refine3D/job001/run_class001_half1_unfil.mrc")
        with self.assertRaises(RuntimeError):
            generic_tests.general_get_command_test(
                self,
                "ThreeDFSC",
                "threed_fsc_job.star",
                3,
                {
                    "Refine3D/job001/run_class001_half1_unfil.mrc": NODES["Halfmap"],
                    "Refine3D/job001/run_class001.mrc": NODES["3D refs"],
                    "MaskCreate/job002/mask.mrc": NODES["Mask"],
                },
                {"3DFSCOutput.mrc": NODES["Other"]},
                "ThreeDFSC_Start.py "
                "--halfmap1=Refine3D/job001/run_class001_half1_unfil.mrc "
                "--halfmap2=Refine3D/job001/run_class001_half2_unfil.mrc "
                "--fullmap=Refine3D/job001/run_class001.mrc "
                "--maskMaskCreate/job002/mask.mrc --apix=1.04 "
                "--dthetaInDegrees=20.0 --FSCCutoff=0.143 "
                "--ThresholdForSphericity=0.5 --HighPassFilter=200.0 "
                "--numThresholdsForSphericityCalcs=0"
                ">> ThreeDFSC/job003/run.out 2>> ThreeDFSC/job003/run.err "
                "&& mv Results_3DFSCOutput/* ThreeDFSC/job003/ >> "
                "ThreeDFSC/job003/run.out 2>> ThreeDFSC/job003/run.err && rm "
                "Results_3DFSCOutput >> ThreeDFSC/job003/run.out 2>> "
                "ThreeDFSC/job003/run.err & ",
                jobfiles_dir="{}/{}",
            )

    def test_get_command_threedfsc_error_halfmap2_missing(self):
        os.system("rm Refine3D/job001/run_class001_half2_unfil.mrc")
        with self.assertRaises(RuntimeError):
            generic_tests.general_get_command_test(
                self,
                "ThreeDFSC",
                "threed_fsc_job.star",
                3,
                {
                    "Refine3D/job001/run_class001_half1_unfil.mrc": NODES["Halfmap"],
                    "Refine3D/job001/run_class001.mrc": NODES["3D refs"],
                    "MaskCreate/job002/mask.mrc": NODES["Mask"],
                },
                {"3DFSCOutput.mrc": NODES["Other"]},
                "ThreeDFSC_Start.py "
                "--halfmap1=Refine3D/job001/run_class001_half1_unfil.mrc "
                "--halfmap2=Refine3D/job001/run_class001_half2_unfil.mrc "
                "--fullmap=Refine3D/job001/run_class001.mrc "
                "--maskMaskCreate/job002/mask.mrc --apix=1.04 "
                "--dthetaInDegrees=20.0 --FSCCutoff=0.143 "
                "--ThresholdForSphericity=0.5 --HighPassFilter=200.0 "
                "--numThresholdsForSphericityCalcs=0"
                " >> ThreeDFSC/job003/run.out 2>> ThreeDFSC/job003/run.err "
                "&& mv Results_3DFSCOutput/* ThreeDFSC/job003/ >> "
                "ThreeDFSC/job003/run.out 2>> ThreeDFSC/job003/run.err && rm "
                "Results_3DFSCOutput >> ThreeDFSC/job003/run.out 2>> "
                "ThreeDFSC/job003/run.err & ",
                jobfiles_dir="{}/{}",
            )

    def test_get_command_threedfsc_error_fullmap_missing(self):
        os.system("rm Refine3D/job001/run_class001.mrc")
        with self.assertRaises(RuntimeError):
            generic_tests.general_get_command_test(
                self,
                "ThreeDFSC",
                "threed_fsc_job.star",
                3,
                {
                    "Refine3D/job001/run_class001_half1_unfil.mrc": NODES["Halfmap"],
                    "Refine3D/job001/run_class001.mrc": NODES["3D refs"],
                    "MaskCreate/job002/mask.mrc": NODES["Mask"],
                },
                {"3DFSCOutput.mrc": NODES["Other"]},
                "ThreeDFSC_Start.py "
                "--halfmap1=Refine3D/job001/run_class001_half1_unfil.mrc "
                "--halfmap2=Refine3D/job001/run_class001_half2_unfil.mrc "
                "--fullmap=Refine3D/job001/run_class001.mrc "
                "--maskMaskCreate/job002/mask.mrc --apix=1.04 "
                "--dthetaInDegrees=20.0 --FSCCutoff=0.143 "
                "--ThresholdForSphericity=0.5 --HighPassFilter=200.0 "
                "--numThresholdsForSphericityCalcs=0"
                " >> ThreeDFSC/job003/run.out 2>> ThreeDFSC/job003/run.err "
                "&& mv Results_3DFSCOutput/* ThreeDFSC/job003/ >> "
                "ThreeDFSC/job003/run.out 2>> ThreeDFSC/job003/run.err && rm "
                "Results_3DFSCOutput >> ThreeDFSC/job003/run.out 2>> "
                "ThreeDFSC/job003/run.err & ",
                jobfiles_dir="{}/{}",
            )

    def test_get_command_threedfsc_error_exe_broken(self):
        with self.assertRaises(ValueError):
            os.environ["PATH"] = self.oldpath
            generic_tests.general_get_command_test(
                self,
                "ThreeDFSC",
                "threed_fsc_job.star",
                3,
                {
                    "Refine3D/job001/run_class001_half1_unfil.mrc": NODES["Halfmap"],
                    "Refine3D/job001/run_class001.mrc": NODES["3D refs"],
                    "MaskCreate/job002/mask.mrc": NODES["Mask"],
                },
                {"3DFSCOutput.mrc": NODES["Other"]},
                "ThreeDFSC_Start.py "
                "--halfmap1=Refine3D/job001/run_class001_half1_unfil.mrc "
                "--halfmap2=Refine3D/job001/run_class001_half2_unfil.mrc "
                "--fullmap=Refine3D/job001/run_class001.mrc "
                "--maskMaskCreate/job002/mask.mrc --apix=1.04 "
                "--dthetaInDegrees=20.0 --FSCCutoff=0.143 "
                "--ThresholdForSphericity=0.5 --HighPassFilter=200.0 "
                "--numThresholdsForSphericityCalcs=0"
                " >> ThreeDFSC/job003/run.out 2>> ThreeDFSC/job003/run.err "
                "&& mv Results_3DFSCOutput/* ThreeDFSC/job003/ >> "
                "ThreeDFSC/job003/run.out 2>> ThreeDFSC/job003/run.err && rm "
                "Results_3DFSCOutput >> ThreeDFSC/job003/run.out 2>> "
                "ThreeDFSC/job003/run.err & ",
                jobfiles_dir="{}/{}",
            )


if __name__ == "__main__":
    unittest.main()
