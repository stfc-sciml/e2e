import unittest
import os
import shutil
import tempfile

from pipeliner.utils import get_project_root
from pipeliner_tests.plugins_tests import test_data
from pipeliner.plugins.plugins_data import RelionPlugIn
from pipeliner.plugins.get_plugins import gather_plugins
from pipeliner_tests import generic_tests
from pipeliner.data_structure import NODES

do_full = os.environ.get("UNITTEST_FULL", False) == "True"
do_interactive = os.environ.get("UNITTEST_INTERACTIVE", False) == "True"
# do_full = "True"

plugins_dir = os.path.join(get_project_root(), "plugins")
test_plugins_dir = os.path.abspath(
    os.path.join(get_project_root(), "../pipeliner_tests/plugins_tests/testing_plugins")
)

@unittest.skipIf(
    (
        os.environ.get("RELION_THREEDFSC_PATH") is None or
        os.environ.get("RELION_CRYOEF_PATH") is None
    ), 
    "Skipping because plugin not active"
)
class PlugInsTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

        # checking the path
        self.oldpath = os.environ["PATH"]
        tdfsc_path = os.environ.get("RELION_THREEDFSC_PATH")
        cryoef_path = os.environ.get("RELION_CRYOEF_PATH")

        os.environ["PATH"] = self.oldpath + ":" + tdfsc_path + ":" + cryoef_path

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

        # remove the testing plugins if they were put in
        tps = [
            os.path.join(plugins_dir, "reproject_plugin_output_error.rln"),
            os.path.join(plugins_dir, "reproject_plugin_input_error.rln"),
        ]
        for f in tps:
            if os.path.isfile(f):
                os.remove(f)

        os.environ["PATH"] = self.oldpath

    def test_initialize_read_plugin_file_reproject(self):
        """Get the plugin in for the reprojection plugin"""
        plugin_file = os.path.join(
            get_project_root(), "plugins/active/reproject_plugin.rln"
        )
        the_plugin = RelionPlugIn(plugin_file)
        the_plugin.read_plugin_file()
        expected_values = {
            "plugin_file": plugin_file,
            "python_code": (
                "#relion_plugin_code\n\ncommand = plugin_exes[0]\n\nmap_file"
                ' = joboptions["map_filename"]'
                '\ncommand += " --i " + map_file\ninputs = {map_file: NODES["3D refs"]}'
                '\n\nnr_uniform = joboptions["nr_uniform"]\nif nr_uniform != "":'
                '\n\tcommand += " --nr_uniform " + nr_uniform\nelse:\n\tangles_file'
                ' = joboptions["angles_filename"]\n\tcommand += " -ang " + angles_file'
                '\n\tinputs[angles_file] = NODES["Other"]\n\t\napix = '
                'joboptions["apix"]\ncommand += " --apix " + apix\n\ncommand += " '
                '--o {}reproj".format(output_dir)\n\nother_args = joboptions["other_'
                'args"]\nif other_args != "":\n\tcommand += " " + other_args '
                '\n\ncommands = [command]\n\noutputs = {\n\t"reproj.mrcs": '
                'NODES["2D refs"],\n\t"reproj.star": NODES["Other"],\n\t}\n'
            ),
            "name": "Matt's example plugin for reprojections",
            "id": "MEPFR",
            "process_name": "Reproject",
            "inputs_types": {NODES["3D refs"]: ".mrc", NODES["Other"]: ".star"},
            "outputs_types": {NODES["2D refs"]: ".mrcs", NODES["Other"]: ".star"},
            "exe_list": ["relion_project"],
        }
        for item in expected_values:
            assert vars(the_plugin)[item] == expected_values[item], print(
                str([vars(the_plugin)[item]]), "\n", str([expected_values[item]]),
            )

    def test_initialize_read_plugin_file_useless(self):
        """Get the info for the useless plugin"""
        plugin_file = os.path.join(
            get_project_root(), "plugins/active/useless_plugin.rln"
        )
        the_plugin = RelionPlugIn(plugin_file)
        the_plugin.read_plugin_file()
        expected_values = {
            "plugin_file": plugin_file,
            "python_code": (
                '#relion_plugin_code\n\nuseless_file = "{}useless_file.txt".'
                "format(output_dir)\ncommands ="
                ' ["touch " + useless_file, "echo \'waste of time\' > " + '
                'useless_file]\noutputs = {useless_file: NODES["Other"]'
                "}\ninputs = {}"
            ),
            "name": "Matt's example useless plugin",
            "id": "USELESS",
            "process_name": "Useless",
            "inputs_types": {},
            "outputs_types": {NODES["Other"]: ".txt"},
            "exe_list": [],
        }
        print(vars(the_plugin))
        for item in expected_values:
            print(expected_values[item])
            assert vars(the_plugin)[item] == expected_values[item], item

    def test_get_plugins(self):
        plugins_dict, err_msg = gather_plugins()
        for plugin in ["MEPFR", "USELESS"]:
            assert plugin in plugins_dict, plugin

        useless_values = {
            "plugin_file": os.path.join(
                get_project_root(), "plugins/active/useless_plugin.rln"
            ),
            "python_code": (
                '#relion_plugin_code\n\nuseless_file = "{}useless_file.txt".'
                "format(output_dir)\ncommands ="
                ' ["touch " + useless_file, "echo \'waste of time\' > " + '
                'useless_file]\noutputs = {useless_file: NODES["Other"]'
                "}\ninputs = {}"
            ),
            "name": "Matt's example useless plugin",
            "id": "USELESS",
            "process_name": "Useless",
            "inputs_types": {},
            "outputs_types": {NODES["Other"]: ".txt"},
            "exe_list": [],
        }
        for item in useless_values:
            assert vars(plugins_dict["USELESS"])[item] == useless_values[item], item

        reproject_values = {
            "plugin_file": os.path.join(
                get_project_root(), "plugins/active/reproject_plugin.rln"
            ),
            "python_code": (
                "#relion_plugin_code\n\ncommand = plugin_exes[0]\n\nmap_file ="
                ' joboptions["map_filename"]\n'
                'command += " --i " + map_file\ninputs = {map_file: NODES["3D refs"]}'
                '\n\nnr_uniform = joboptions["nr_uniform"]\nif nr_uniform != "":\n\t'
                'command += " --nr_uniform " + nr_uniform\nelse:\n\tangles_file = jo'
                'boptions["angles_filename"]\n\tcommand += " -ang " + angles_file\n\t'
                'inputs[angles_file] = NODES["Other"]\n\t\napix = joboptions'
                '["apix"]\ncommand += " --apix " + apix\n\ncommand += " --o {}reproj"'
                '.format(output_dir)\n\nother_args = joboptions["other_args"]\nif '
                'other_args != "":\n\tcommand += " " + other_args \n\ncommands = [co'
                'mmand]\n\noutputs = {\n\t"reproj.mrcs": NODES["2D refs"],\n\t"re'
                'proj.star": NODES["Other"],\n\t}\n'
            ),
            "name": "Matt's example plugin for reprojections",
            "id": "MEPFR",
            "process_name": "Reproject",
            "inputs_types": {NODES["3D refs"]: ".mrc", NODES["Other"]: ".star"},
            "outputs_types": {NODES["2D refs"]: ".mrcs", NODES["Other"]: ".star"},
            "exe_list": ["relion_project"],
        }
        for item in reproject_values:
            assert vars(plugins_dict["MEPFR"])[item] == reproject_values[item], print(
                str([vars(plugins_dict["MEPFR"])[item]]),
                "\n",
                str([reproject_values[item]]),
            )

    def test_get_command_project_plugin(self):
        generic_tests.general_get_command_test(
            self,
            "Reproject",
            "project_plugin_job.star",
            2,
            {"emd_3488.mrc": NODES["3D refs"]},
            {"reproj.mrcs": NODES["2D refs"], "reproj.star": NODES["Other"]},
            "relion_project --i emd_3488.mrc --nr_uniform 10 --apix 1.07"
            " --o Reproject/job002/reproj >> Reproject/job002/run.out 2>> "
            "Reproject/job002/run.err & ",
            jobfiles_dir="{}/{}",
        )

    def test_get_command_reconstruct_plugin(self):
        generic_tests.general_get_command_test(
            self,
            "Reconstruct",
            "reconstruct_plugin_job.star",
            2,
            {"test_particles.star": NODES["Part data"]},
            {"reconstruction.mrc": NODES["3D refs"]},
            "relion_reconstruct --i test_particles.star --o "
            "Reconstruct/job002/reconstruction.mrc --maxres -1 --angpix 1.07"
            " --sym C1 >> Reconstruct/job002/run.out 2>> Reconstruct/job002/run.err & ",
            jobfiles_dir="{}/{}",
        )

    def test_get_command_reconstruct_mpi_plugin(self):
        generic_tests.general_get_command_test(
            self,
            "Reconstruct",
            "reconstruct_plugin_mpi_job.star",
            2,
            {"test_particles.star": NODES["Part data"]},
            {"reconstruction.mrc": NODES["3D refs"]},
            "mpirun -n 8 relion_reconstruct_mpi --i test_particles.star --o "
            "Reconstruct/job002/reconstruction.mrc --maxres -1 --angpix 1.07"
            " --sym C1 >> Reconstruct/job002/run.out 2>> Reconstruct/job002/run.err & ",
            jobfiles_dir="{}/{}",
        )

    def test_get_command_project_plugin_error_bad_inputs(self):
        """ Error raised if the input file types are not specified
        in the plugin header"""

        # copy in the testing plugin
        shutil.copy(
            os.path.join(test_plugins_dir, "reproject_plugin_input_error.rln"),
            plugins_dir,
        )

        with self.assertRaises(RuntimeError):
            generic_tests.general_get_command_test(
                self,
                "Reproject",
                "project_plugin_badin_job.star",
                2,
                {},
                {"reproj.mrcs": NODES["2D refs"], "reproj.star": NODES["Other"]},
                "relion_project --i emd_3488.mrc --nr_uniform 10 --angpix 1.07"
                " --o Reproject/job002/reproj >> Reproject/job002/run.out 2>> "
                "Reproject/job002/run.err & ",
                jobfiles_dir="{}/{}",
            )

    def test_get_command_project_plugin_error_bad_outputs(self):
        """ Error raised if the output file types are not specified
        in the plugin header"""

        # copy in the testing plugin
        shutil.copy(
            os.path.join(test_plugins_dir, "reproject_plugin_output_error.rln"),
            plugins_dir,
        )

        with self.assertRaises(RuntimeError):
            generic_tests.general_get_command_test(
                self,
                "Reproject",
                "project_plugin_badout_job.star",
                2,
                {},
                {"reproj.mrcs": NODES["2D refs"], "reproj.star": NODES["Other"]},
                "relion_project --i emd_3488.mrc --nr_uniform 10 --angpix 1.07"
                " --o Reproject/job002/reproj >> Reproject/job002/run.out 2>> "
                "Reproject/job002/run.err & ",
                jobfiles_dir="{}/{}",
            )

    def test_get_command_useless_plugin(self):
        generic_tests.general_get_command_test(
            self,
            "Useless",
            "useless_plugin_job.star",
            900,
            {},
            {"useless_file.txt": NODES["Other"]},
            "touch Useless/job900/useless_file.txt >> Useless/job900/run.out "
            "2>> Useless/job900/run.err && echo 'waste of time' > "
            "Useless/job900/useless_file.txt & ",
            jobfiles_dir="{}/{}",
        )

    def test_running_useless_plugin(self):
        generic_tests.running_job(
            self,
            "useless_plugin_job.star",
            "Useless",
            3,
            [],
            ("run.out", "run.err", "useless_file.txt",),
            1,
            jobfiles_dir="{}/{}",
        )

    @unittest.skipUnless(do_full, "Takes 30 sec to search for file")
    def test_running_projection_plugin(self):
        shutil.copy(
            os.path.join(self.test_data, "../../test_data/emd_3488.mrc"), self.test_dir
        )
        generic_tests.running_job(
            self,
            "project_plugin_job.star",
            "Reproject",
            3,
            [],
            ("run.out", "run.err", "reproj.mrcs", "reproj.star",),
            1,
            jobfiles_dir="{}/{}",
        )


if __name__ == "__main__":
    unittest.main()
