import unittest
import os
import shutil
import tempfile

from pipeliner_tests.plugins_tests import test_data
from pipeliner_tests import generic_tests
from pipeliner.data_structure import NODES
from pipeliner_tests.generic_tests import check_for_plugin

do_full = os.environ.get("UNITTEST_FULL", False) == "True"
do_interactive = os.environ.get("UNITTEST_INTERACTIVE", False) == "True"

plugin_present = check_for_plugin("cryolo_plugin.rln")


@unittest.skipIf(
    not plugin_present or os.environ.get("RELION_CRYOLO_PATH") is None,
    "Skipping because plugin not active"
)
class CrYOLOTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

        self.oldpath = os.environ["PATH"]
        crYOLO_path = os.environ.get("RELION_CRYOLO_PATH")
        os.environ["PATH"] = self.oldpath + ":" + crYOLO_path

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)
        os.environ["PATH"] = self.oldpath

    def test_get_command_crYOLO_plugin_with_dir_input(self):
        """Test using a dir of image files as an input"""
        os.makedirs("MotionCorr/job002/Movies/")
        generic_tests.general_get_command_test(
            self,
            "CrYOLO",
            "crYOLO_dir_input_job.star",
            2,
            {},
            {"coords_suffix.star": NODES["Mic coords"]},
            "cryolo_gui.py config CrYOLO/job002/cryolo_config.json 256 --filter "
            "LOWPASS --low_pass_cutoff 0.1 >> CrYOLO/job002/run.out 2>> "
            "CrYOLO/job002/run.err && cryolo_predict.py -c CrYOLO/job002/config.json"
            " -w path/to/model -i MotionCorr/job002/Movies/ -g 0,1 -o CrYOLO/job002/"
            " -t 0.3 >> CrYOLO/job002/run.out 2>> CrYOLO/job002/run.err && mv "
            "CrYOLO/job002/STAR CrYOLO/job002/Movies >> CrYOLO/job002/run.out 2>>"
            " CrYOLO/job002/run.err && touch CrYOLO/job002/coords_suffix.star >> "
            "CrYOLO/job002/run.out 2>> CrYOLO/job002/run.err & ",
            jobfiles_dir="{}/{}",
        )

    def test_get_command_crYOLO_plugin_with_file_input(self):
        """Test using a starfile as in input"""
        os.makedirs("CtfFind/job003/")
        shutil.copy(
            os.path.join(self.test_data, "micrographs_ctf.star"),
            os.path.join(self.test_dir, "CtfFind/job003/"),
        )
        generic_tests.general_get_command_test(
            self,
            "CrYOLO",
            "crYOLO_file_input_job.star",
            2,
            {"CtfFind/job003/micrographs_ctf.star": NODES["Mics"]},
            {"coords_suffix.star": NODES["Mic coords"]},
            "cryolo_gui.py config CrYOLO/job002/cryolo_config.json 256 --filter "
            "LOWPASS --low_pass_cutoff 0.1 >> CrYOLO/job002/run.out 2>> "
            "CrYOLO/job002/run.err && cryolo_predict.py -c CrYOLO/job002/config.json"
            " -w path/to/model -i MotionCorr/job002/Movies/ -g 0,1 -o CrYOLO/job002/"
            " -t 0.3 >> CrYOLO/job002/run.out 2>> CrYOLO/job002/run.err && mv "
            "CrYOLO/job002/STAR CrYOLO/job002/Movies >> CrYOLO/job002/run.out 2>>"
            " CrYOLO/job002/run.err && touch CrYOLO/job002/coords_suffix.star >> "
            "CrYOLO/job002/run.out 2>> CrYOLO/job002/run.err & ",
            jobfiles_dir="{}/{}",
        )

    def test_get_command_crYOLO_plugin_with_file_input_use_JANNI(self):
        """Test using a starfile as in input, using JANNI instead of LOWPASS"""
        os.makedirs("CtfFind/job003/")
        shutil.copy(
            os.path.join(self.test_data, "micrographs_ctf.star"),
            os.path.join(self.test_dir, "CtfFind/job003/"),
        )
        generic_tests.general_get_command_test(
            self,
            "CrYOLO",
            "crYOLO_file_JANNI_job.star",
            2,
            {"CtfFind/job003/micrographs_ctf.star": NODES["Mics"]},
            {"coords_suffix.star": NODES["Mic coords"]},
            "cryolo_gui.py config CrYOLO/job002/cryolo_config.json 256 --filter "
            "JANNI --janni_model path/to/JANNI >> CrYOLO/job002/run.out 2>> "
            "CrYOLO/job002/run.err && cryolo_predict.py -c CrYOLO/job002/config.json"
            " -w path/to/model -i MotionCorr/job002/Movies/ -g 0,1 -o CrYOLO/job002/"
            " -t 0.3 >> CrYOLO/job002/run.out 2>> CrYOLO/job002/run.err && mv "
            "CrYOLO/job002/STAR CrYOLO/job002/Movies >> CrYOLO/job002/run.out 2>> "
            "CrYOLO/job002/run.err && touch CrYOLO/job002/coords_suffix.star >> "
            "CrYOLO/job002/run.out 2>> CrYOLO/job002/run.err & ",
            jobfiles_dir="{}/{}",
        )

    def test_get_command_crYOLO_plugin_with_file_input_2dirs(self):
        """ Check function when the files in the input starfile have
        multiple directories"""
        os.makedirs("CtfFind/job003/")
        shutil.copy(
            os.path.join(self.test_data, "micrographs2_ctf.star"),
            os.path.join(self.test_dir, "CtfFind/job003/"),
        )
        generic_tests.general_get_command_test(
            self,
            "CrYOLO",
            "crYOLO_file_multi_dir_input_job.star",
            2,
            {"CtfFind/job003/micrographs2_ctf.star": NODES["Mics"]},
            {"coords_suffix.star": NODES["Mic coords"]},
            "cryolo_gui.py config CrYOLO/job002/cryolo_config.json 256 "
            "--filter LOWPASS --low_pass_cutoff 0.1 >> CrYOLO/job002/run.out "
            "2>> CrYOLO/job002/run.err && cryolo_predict.py -c "
            "CrYOLO/job002/config.json -w path/to/model -i "
            "MotionCorr/job002/Movies/ -g 0,1 -o CrYOLO/job002/ -t 0.3 >> "
            "CrYOLO/job002/run.out 2>> CrYOLO/job002/run.err && mv "
            "CrYOLO/job002/STAR CrYOLO/job002/Movies >> CrYOLO/job002/run.out"
            " 2>> CrYOLO/job002/run.err && cryolo_predict.py -c "
            "CrYOLO/job002/config.json -w path/to/model -i "
            "MotionCorr/job002/OTHER_Movies/ -g 0,1 -o CrYOLO/job002/ "
            "-t 0.3 >> CrYOLO/job002/run.out 2>> CrYOLO/job002/run.err "
            "&& mv CrYOLO/job002/STAR CrYOLO/job002/OTHER_Movies >> "
            "CrYOLO/job002/run.out 2>> CrYOLO/job002/run.err && touch "
            "CrYOLO/job002/coords_suffix.star >> CrYOLO/job002/run.out "
            "2>> CrYOLO/job002/run.err & ",
            jobfiles_dir="{}/{}",
        )

    def test_get_command_crYOLO_plugin_multiple_dirs(self):
        """Test using a dir of image files as an input but dir is missing"""
        generic_tests.general_get_command_test(
            self,
            "CrYOLO",
            "crYOLO_multi_dir_input_job.star",
            2,
            {},
            {"coords_suffix.star": NODES["Mic coords"]},
            "cryolo_gui.py config CrYOLO/job002/cryolo_config.json 256 --filter"
            " LOWPASS --low_pass_cutoff 0.1 >> CrYOLO/job002/run.out 2>> CrYOLO/"
            "job002/run.err && cryolo_predict.py -c CrYOLO/job002/config.json -w "
            "path/to/model -i CtfFind/job003/Movies -g 0,1 -o CrYOLO/job002/ -t 0.3"
            " >> CrYOLO/job002/run.out 2>> CrYOLO/job002/run.err && mv CrYOLO/job002"
            "/STAR CrYOLO/job002/Movie >> CrYOLO/job002/run.out 2>> CrYOLO/job002/"
            "run.err && cryolo_predict.py -c CrYOLO/job002/config.json -w path/to/"
            "model -i CtfFind/job004/Raw_data -g 0,1 -o CrYOLO/job002/ -t 0.3 >> "
            "CrYOLO/job002/run.out 2>> CrYOLO/job002/run.err && mv CrYOLO/job002/STAR"
            " CrYOLO/job002/Raw_dat >> CrYOLO/job002/run.out 2>> CrYOLO/job002/run.err"
            " && touch CrYOLO/job002/coords_suffix.star >> CrYOLO/job002/run.out 2>>"
            " CrYOLO/job002/run.err & ",
            jobfiles_dir="{}/{}",
        )

    def test_get_command_crYOLO_plugin_file_missing(self):
        """Test using a starfile as in input but file is missing"""
        with self.assertRaises((ValueError, RuntimeError)):
            generic_tests.general_get_command_test(
                self,
                "CrYOLO",
                "crYOLO_file_input_job.star",
                2,
                {"CtfFind/job003/micrographs_ctf.star": NODES["Mics"]},
                {"coords_suffix.star": NODES["Mic coords"]},
                "cryolo_gui.py config CrYOLO/job002/cryolo_config.json 256 --filter "
                "LOWPASS --low_pass_cutoff 0.1 >> CrYOLO/job002/run.out 2>> "
                "CrYOLO/job002/run.err && cryolo_predict.py -c "
                "CrYOLO/job002/config.json"
                " -w path/to/model -i MotionCorr/job002/Movies/ -g 0,1 -o "
                "CrYOLO/job002/"
                " -t 0.3 >> CrYOLO/job002/run.out 2>> CrYOLO/job002/run.err && mv "
                "CrYOLO/job002/STAR CrYOLO/job002/Movies >> CrYOLO/job002/run.out 2>>"
                " CrYOLO/job002/run.err && touch CrYOLO/job002/coords_suffix.star >> "
                "CrYOLO/job002/run.out 2>> CrYOLO/job002/run.err & ",
                jobfiles_dir="{}/{}",
            )


if __name__ == "__main__":
    unittest.main()
