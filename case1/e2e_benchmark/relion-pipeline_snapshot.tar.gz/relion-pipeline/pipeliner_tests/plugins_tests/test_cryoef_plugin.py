import unittest
import os
import shutil
import tempfile

from pipeliner_tests.plugins_tests import test_data
from pipeliner_tests import generic_tests
from pipeliner.data_structure import NODES
from pipeliner_tests.generic_tests import check_for_plugin

do_full = os.environ.get("UNITTEST_FULL", False) == "True"
do_interactive = os.environ.get("UNITTEST_INTERACTIVE", False) == "True"
# do_full = "True"

plugin_present = check_for_plugin("cryoef_plugin.rln")


@unittest.skipIf(
    not plugin_present or os.environ.get("RELION_CRYOEF_PATH") is None, 
    "Skipping because plugin not active"
)
class CryoEFTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

        # set the path to find cryoEF
        self.oldpath = os.environ["PATH"]
        cryoEF_path = os.environ.get("RELION_CRYOEF_PATH")
        os.environ["PATH"] = self.oldpath + ":" + cryoEF_path

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)
        os.environ["PATH"] = self.oldpath

    def test_get_command_cryoEF_plugin_txt_input(self):
        os.system("touch my_angles.txt")
        generic_tests.general_get_command_test(
            self,
            "CryoEF",
            "cryoef_txt_job.star",
            2,
            {"CryoEF/job002/my_angles.txt": NODES["Other"]},
            {"my_angles_K.mrc": NODES["Other"], "my_angles_R.mrc": NODES["Other"]},
            "cryoEF -f CryoEF/job002/my_angles.txt -B 150 -D 80 -b 128 -r 3.8 -g C1 >>"
            " CryoEF/job002/run.out 2>> CryoEF/job002/run.err & ",
            jobfiles_dir="{}/{}",
        )

    def test_get_command_cryoEF_plugin_star_input(self):
        os.makedirs(os.path.join(self.test_dir, "Refine3D/job001/"))
        shutil.copy(
            os.path.join(self.test_data, "run_data.star"),
            os.path.join(self.test_dir, "Refine3D/job001/"),
        )
        generic_tests.general_get_command_test(
            self,
            "CryoEF",
            "cryoef_star_job.star",
            2,
            {"CryoEF/job002/run_data_angles.dat": NODES["Other"]},
            {
                "run_data_angles_K.mrc": NODES["Other"],
                "run_data_angles_R.mrc": NODES["Other"],
            },
            "cryoEF -f CryoEF/job002/run_data_angles.dat -B 150 "
            "-D 80 -b 128 -r 3.8 -g C1 >>"
            " CryoEF/job002/run.out 2>> CryoEF/job002/run.err & ",
            jobfiles_dir="{}/{}",
        )

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_run_cryoEF_with_starfile(self):
        os.makedirs(os.path.join(self.test_dir, "Refine3D/job001/"))
        shutil.copy(
            os.path.join(self.test_data, "run_data.star"),
            os.path.join(self.test_dir, "Refine3D/job001/"),
        )
        generic_tests.running_job(
            self,
            "cryoef_star_job.star",
            "CryoEF",
            2,
            [],
            ("run.out", "run.err", "run_data_angles_K.mrc", "run_data_angles_R.mrc",),
            5,
            jobfiles_dir="{}/{}",
        )

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_run_cryoEF_with_txtfile(self):
        shutil.copy(
            os.path.join(self.test_data, "my_angles.txt"),
            os.path.join(self.test_dir, "my_angles.txt"),
        )

        generic_tests.running_job(
            self,
            "cryoef_txt_job.star",
            "CryoEF",
            2,
            [],
            (
                "run.out",
                "run.err",
                "my_angles_K.mrc",
                "my_angles_R.mrc",
                "RELION_JOB_EXIT_SUCCESS",
            ),
            5,
            jobfiles_dir="{}/{}",
        )

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_run_cryoEF_with_datfile(self):
        shutil.copy(
            os.path.join(self.test_data, "my_angles.txt"),
            os.path.join(self.test_dir, "my_angles.dat"),
        )

        generic_tests.running_job(
            self,
            "cryoef_dat_job.star",
            "CryoEF",
            2,
            [],
            (
                "run.out",
                "run.err",
                "my_angles_K.mrc",
                "my_angles_R.mrc",
                "RELION_JOB_EXIT_SUCCESS",
            ),
            5,
            jobfiles_dir="{}/{}",
        )

    @unittest.skipUnless(do_full, "Takes 30 sec to search for file")
    def test_run_cryoEF_failure_badfilename(self):
        """The file is missing so the job fails, looking for RELION_JOB_EXIT_FAILURE"""
        generic_tests.running_job(
            self,
            "cryoef_dat_job.star",
            "CryoEF",
            2,
            [],
            ("run.out", "run.err", "RELION_JOB_EXIT_FAILURE",),
            5,
            jobfiles_dir="{}/{}",
        )


if __name__ == "__main__":
    unittest.main()
