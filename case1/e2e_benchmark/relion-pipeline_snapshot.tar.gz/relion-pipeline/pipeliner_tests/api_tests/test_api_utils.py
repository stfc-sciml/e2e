import unittest
import os
import shutil
import tempfile

from pipeliner.api.api_utils import parse_procname, parse_proclist
from pipeliner.project_graph import ProjectGraph


class APIUtilsTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_dir = tempfile.mkdtemp(prefix="relion_")
        self.pipeliner_test_data = os.path.join(
            os.path.abspath(os.path.join(__file__, "../..")), "test_data",
        )

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_proc_name_parse_from_pipeline(self):
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "Pipelines/tutorial_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )

        pipeline = ProjectGraph(name="default")
        pipeline.read()

        actual_name = "Class3D/job018/"

        variations = {
            "full name": "Class3D/job018/",
            "missing slash": "Class3D/job018",
            "no type": "job018/",
            "no type no slash": "job018",
            "alias": "Class3D/first_exhaustive/",
            "alias no slash": "Class3D/first_exhaustive",
            "extra space": "Class3D/job018/ ",
        }

        for var in variations:
            fixed = parse_procname(pipeline.name, variations[var])
            assert fixed == actual_name, (fixed, var)

    def test_proc_name_parse_from_trash(self):
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "Pipelines/tutorial_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )

        pipeline = ProjectGraph(name="default")
        pipeline.read()
        os.system("mkdir -p Trash/Class3D/job180/")

        actual_name = "Class3D/job180/"

        trash_vars = {
            "full name": "Class3D/job180/",
            "missing slash": "Class3D/job180",
            "no type": "job180/",
            "no type no slash": "job180",
            "no type no slash space": "job180 ",
        }
        for trash_var in trash_vars:
            from_trash = parse_procname(
                pipeline.name, trash_vars[trash_var], search_trash=True,
            )
            assert from_trash == actual_name, (from_trash, trash_var)
            from_trash = parse_procname(
                pipeline.name, "Trash/" + trash_vars[trash_var], search_trash=True,
            )
            assert from_trash == actual_name, (from_trash, trash_var)

    def test_proc_name_trashed_jobs_raise_errors(self):
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "Pipelines/tutorial_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )

        pipeline = ProjectGraph(name="default")
        pipeline.read()
        os.system("mkdir -p Trash/Class3D/job180/")

        actual_name = "Class3D/job180/"

        trash_vars = {
            "full name": "Class3D/job180/",
            "missing slash": "Class3D/job180",
            "no type": "job180/",
            "no type no slash": "job180",
            "no type no slash space": "job180 ",
        }
        for trash_var in trash_vars:
            with self.assertRaises(ValueError):
                from_trash = parse_procname(pipeline.name, trash_vars[trash_var])
                assert from_trash == actual_name, (from_trash, trash_var)
                from_trash = parse_procname(
                    pipeline.name, "Trash/" + trash_vars[trash_var]
                )
                assert from_trash == actual_name, (from_trash, trash_var)

    def test_parse_procname_list(self):
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "Pipelines/tutorial_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )
        jobs_list = [
            "Select/job014/",
            "Class2D/job015/",
            "Select/job016/",
            "InitialModel/job017/",
            "Class3D/job018/",
            "Select/job019/",
            "Extract/job020/",
            "Refine3D/job021/",
            "MaskCreate/job022/",
        ]
        pipeline = ProjectGraph(name="default")
        pipeline.read()

        found_list = parse_proclist(pipeline.name, jobs_list)
        assert found_list == jobs_list

        altered_jobs_list = [
            "Select/job014",
            "job015/",
            "job016",
            "job017/",
            "/job018/",
            "Select/job019/ ",
            "job020 ",
            "job021/",
            "MaskCreate/job022/",
        ]
        found_list = parse_proclist(pipeline.name, altered_jobs_list)
        assert found_list == jobs_list


if __name__ == "__main__":
    unittest.main()
