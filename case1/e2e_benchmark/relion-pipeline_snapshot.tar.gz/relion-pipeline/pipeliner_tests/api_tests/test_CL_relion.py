import unittest
import os
import shutil
import tempfile
import time
import subprocess
from glob import glob

from pipeliner_tests import test_data, generic_tests
from pipeliner.api import CL_relion

do_full = os.environ.get("UNITTEST_FULL", False) == "True"
do_interactive = os.environ.get("UNITTEST_INTERACTIVE", False) == "True"


class CL_RelionTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")
        self.pipeliner_test_data = os.path.join(
            os.path.abspath(os.path.join(__file__, "../..")), "test_data",
        )
        self.plugins = os.path.join(
            os.path.abspath(os.path.join(__file__, "../..")),
            "plugins_tests/testing_plugins",
        )
        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def read_pipeline(self, pipeline_name="default"):
        """Return the contents of the pipline as a string, for comparisons"""
        with open("{}_pipeline.star".format(pipeline_name)) as pipe:
            pipe_data = pipe.read()
        return pipe_data

    def run_postprocess_job(self):
        """copy in the necessary files and run a postprocess job"""

        # get the files
        assert not os.path.isfile("default_pipeline.star")

        jobfile = os.path.join(
            self.test_data, "JobFiles/PostProcess/postprocess_CL_job.star"
        )

        halfmap_import_dir = "HalfMaps"
        os.makedirs(halfmap_import_dir)
        shutil.copy(
            os.path.join(self.test_data, "3488_run_half1_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        shutil.copy(
            os.path.join(self.test_data, "3488_run_half2_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        mask_import_dir = "Mask"
        os.makedirs(mask_import_dir)
        shutil.copy(os.path.join(self.test_data, "emd_3488_mask.mrc"), mask_import_dir)

        # intialize a new project
        CL_relion.main(["CL_relion.py", "--new_project"])

        # run the job
        CL_relion.main(["CL_relion.py", "--run_job", jobfile])

        # wait for the pipeliner to update the job status
        time.sleep(3)

    def test_initialize_project(self):
        # there should not be a default_pipeline files
        assert not os.path.isfile("default_pipeline.star")

        # initialize a new project
        CL_relion.main(["CL_relion.py", "--new_project"])

        # check the pipeline is written as expected
        assert os.path.isfile("default_pipeline.star")
        lines = [
            "# version 30001 / CCP-EM_pipeliner",
            "data_pipeline_general",
            "_rlnPipeLineJobCounter                       1",
        ]
        pipe_data = self.read_pipeline()
        for line in lines:
            assert line in pipe_data, line

        with open(".CL_relion_project") as project_file:
            project_name = project_file.read()
        assert project_name == "default", project_name

    def test_initialize_project_nondefault_name(self):
        # there should not be a default_pipeline files
        assert not os.path.isfile("fancyfancy_pipeline.star")

        # initialize a new project
        CL_relion.main(["CL_relion.py", "--new_project", "fancyfancy"])

        # check the pipeline is written as expected
        assert os.path.isfile("fancyfancy_pipeline.star")
        lines = [
            "# version 30001 / CCP-EM_pipeliner",
            "data_pipeline_general",
            "_rlnPipeLineJobCounter                       1",
        ]
        pipe_data = self.read_pipeline(pipeline_name="fancyfancy")
        for line in lines:
            assert line in pipe_data, line

        with open(".CL_relion_project") as project_file:
            project_name = project_file.read()
        assert project_name == "fancyfancy", project_name

    def test_initialize_project_name_error_illegal_symbol(self):
        """using an illegal symbol in pipeline name should raise error"""

        # initialize a new project with a bad name
        with self.assertRaises(ValueError):
            CL_relion.main(["CL_relion.py", "--new_project", "BAD!!"])

    def test_initialize_project_name_illegal_name(self):
        """calling th pipeline 'mini' should raise error"""

        # initialize a new project with a bad name
        with self.assertRaises(ValueError):
            CL_relion.main(["CL_relion.py", "--new_project", "mini"])

    def test_initializing_with_existing_project_fails(self):
        # make the directory already contain a pipeline files
        os.system("touch default_pipeline.star")
        assert os.path.isfile("default_pipeline.star")

        # initializing a new project should should raise error
        with self.assertRaises(ValueError):
            CL_relion.main(["CL_relion.py", "--new_project"])

    def test_checking_plugin_all_ok(self):
        good_plugin = os.path.join(self.plugins, "test_reproject_plugin.rln")
        assert CL_relion.main(["CL_relion.py", "--test_plugin", good_plugin])

    def test_checking_plugin_with_error(self):
        """Give it a file that is not a plugin to get an error"""
        err_plugin = os.path.join(self.plugins, "error_reproject_plugin.rln")
        assert not CL_relion.main(["CL_relion.py", "--test_plugin", err_plugin])

    def test_run_job(self):
        # run a postprocess job
        self.run_postprocess_job()

        # check the expected files are produced
        pp_files = [
            "RELION_JOB_EXIT_SUCCESS",
            "logfile.pdf",
            "logfile.pdf.lst",
            "postprocess.mrc",
            "postprocess.star",
            "postprocess_fsc.eps",
            "postprocess_fsc.xml",
            "postprocess_guinier.eps",
            "postprocess_masked.mrc",
            "default_pipeline.star",
            "job.star",
            "job_pipeline.star",
            "note.txt",
            "run.err",
            "run.job",
            "run.out",
        ]
        for f in pp_files:
            assert os.path.isfile(os.path.join("PostProcess/job001", f)), f

        # check the expected lines are added to the pipeline
        pipe_lines = [
            "_rlnPipeLineJobCounter                       2",
            "PostProcess/job001/       None           15            2",
            "Mask/emd_3488_mask.mrc            7",
            "HalfMaps/3488_run_half1_class001_unfil.mrc           10",
            "PostProcess/job001/postprocess.mrc           11",
            "PostProcess/job001/postprocess_masked.mrc           11",
            "PostProcess/job001/postprocess.star           14",
            "PostProcess/job001/logfile.pdf           13",
            "Mask/emd_3488_mask.mrc PostProcess/job001/",
            "HalfMaps/3488_run_half1_class001_unfil.mrc PostProcess/job001/",
            "PostProcess/job001/ PostProcess/job001/postprocess.mrc",
            "PostProcess/job001/ PostProcess/job001/postprocess_masked.mrc",
            "PostProcess/job001/ PostProcess/job001/postprocess.star",
            "PostProcess/job001/ PostProcess/job001/logfile.pdf",
        ]
        pipe_data = self.read_pipeline()
        for line in pipe_lines:
            assert line in pipe_data, line

    def test_set_alias(self):
        # run the postprocess job to make the files
        self.run_postprocess_job()

        # change the alias
        CL_relion.main(
            ["CL_relion.py", "--set_alias", "PostProcess/job001/", "new_alias"]
        )

        # check the pipeline has been updated
        pipe_data = self.read_pipeline()
        new_ln = "PostProcess/job001/ PostProcess/new_alias/           15            2"
        old_ln = "PostProcess/job001/       None           15            2"
        assert new_ln in pipe_data, new_ln
        assert old_ln not in pipe_data, old_ln
        return (new_ln, old_ln)

    def test_set_alias_and_clear(self):
        # run the previous test to make a job with an alias
        new_ln, old_ln = self.test_set_alias()

        # clear the alias
        CL_relion.main(["CL_relion.py", "--clear_alias", "PostProcess/job001/"])

        # check the pipeline has been updated
        pipe_data = self.read_pipeline()
        assert new_ln not in pipe_data, new_ln
        assert old_ln in pipe_data, old_ln

    def test_set_status_to_failed_and_revert(self):
        # run the postporcess job to make the files
        self.run_postprocess_job()

        # make a dir like the job was actually run
        subprocess.run(["mkdir", "-p", "PostProcess/job001"])

        # change the status to failed
        CL_relion.main(
            ["CL_relion.py", "--set_status", "PostProcess/job001/", "failed"]
        )
        assert os.path.isfile("PostProcess/job001/RELION_JOB_EXIT_FAILED")

        # check the pipeline has been updated
        pipe_data = self.read_pipeline()
        fail_line = "PostProcess/job001/       None           15            3"
        assert fail_line in pipe_data

        # change the status back to finished
        CL_relion.main(
            ["CL_relion.py", "--set_status", "PostProcess/job001/", "finished"]
        )
        assert os.path.isfile("PostProcess/job001/RELION_JOB_EXIT_SUCCESS")
        assert not os.path.isfile("PostProcess/job001/RELION_JOB_EXIT_FAILED")

        # check the pipeline has been updated
        fin_line = "PostProcess/job001/       None           15            2"
        pipe_data = self.read_pipeline()
        assert fin_line in pipe_data

    def test_set_status_from_failed_to_aborted(self):
        """Can't make any type of status except running into aborted"""
        # run the postporcess job to make the files
        self.run_postprocess_job()
        # make a dir like the job was actually run
        subprocess.run(["mkdir", "-p", "PostProcess/job001"])

        # change the status to failed
        CL_relion.main(
            ["CL_relion.py", "--set_status", "PostProcess/job001/", "failed"]
        )
        assert os.path.isfile("PostProcess/job001/RELION_JOB_EXIT_FAILED")

        # check the pipeline has been updated
        pipe_data = self.read_pipeline()
        fail_line = "PostProcess/job001/       None           15            3"
        assert fail_line in pipe_data

        # set the status to aborted
        with self.assertRaises(ValueError):
            CL_relion.main(
                ["CL_relion.py", "--set_status", "PostProcess/job001/", "aborted"]
            )

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_deleting_job(self):
        # make the necessary files
        generic_tests.make_shortpipe_filestructure(["Import", "MotionCorr", "CtfFind"])
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_3jobs_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )

        # count the files
        mocorr_file_count = len(os.listdir("MotionCorr/job002"))
        mocorr_rawdata_file_count = len(os.listdir("MotionCorr/job002/Raw_data"))
        ctffind_file_count = len(os.listdir("CtfFind/job003"))

        # make sure the expected lines are in the pipeline
        pipe_data = self.read_pipeline()
        inc_lines = [
            "MotionCorr/job002/       None            1            2",
            "CtfFind/job003/       None            2            2",
            "MotionCorr/job002/corrected_micrographs.star            1",
            "MotionCorr/job002/logfile.pdf           13",
            "CtfFind/job003/micrographs_ctf.star            1",
            "CtfFind/job003/logfile.pdf           13",
            "MotionCorr/job002/corrected_micrographs.star CtfFind/job003/",
            "MotionCorr/job002/ MotionCorr/job002/corrected_micrographs.star",
            "MotionCorr/job002/ MotionCorr/job002/logfile.pdf",
            "CtfFind/job003/ CtfFind/job003/micrographs_ctf.star",
            "CtfFind/job003/ CtfFind/job003/logfile.pdf",
        ]
        for line in inc_lines:
            assert line in pipe_data

        # delete the MotionCorr job, child CtfFind job should go with it
        CL_relion.main(["CL_relion.py", "--delete_job", "MotionCorr/job002/"])

        # check the lines are gone from the pipeline
        pipe_data = self.read_pipeline()
        for line in inc_lines:
            assert line not in pipe_data, line

        # make sure the files have been moved to the trash
        mocorr_trash_count = len(os.listdir("Trash/MotionCorr/job002"))
        mocorr_rawdata_trash_count = len(os.listdir("Trash/MotionCorr/job002/Raw_data"))
        ctffind_trash_count = len(os.listdir("Trash/CtfFind/job003"))
        assert mocorr_trash_count == mocorr_file_count
        assert mocorr_rawdata_trash_count == mocorr_rawdata_file_count
        assert ctffind_trash_count == ctffind_file_count

        # the job directories shoudl be gone
        assert not os.path.isdir("MotionCorr/job002")
        assert not os.path.isdir("CtfFind/job003")

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_deleting_job_no_recursive(self):
        # make the necessary files
        generic_tests.make_shortpipe_filestructure(["Import", "MotionCorr", "CtfFind"])
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_3jobs_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )

        # make sure the expected lines are in the pipeline
        pipe_data = self.read_pipeline()
        del_lines = [
            "MotionCorr/job002/       None            1            2",
            "MotionCorr/job002/corrected_micrographs.star            1",
            "MotionCorr/job002/logfile.pdf           13",
            "MotionCorr/job002/corrected_micrographs.star CtfFind/job003/",
            "MotionCorr/job002/ MotionCorr/job002/corrected_micrographs.star",
            "MotionCorr/job002/ MotionCorr/job002/logfile.pdf",
        ]
        # lines from the child job that shouldn't be deleted
        kept_lines = [
            "CtfFind/job003/       None            2            2",
            "CtfFind/job003/micrographs_ctf.star            1",
            "CtfFind/job003/logfile.pdf           13",
            "CtfFind/job003/ CtfFind/job003/micrographs_ctf.star",
            "CtfFind/job003/ CtfFind/job003/logfile.pdf",
        ]
        for line in kept_lines:
            assert line in pipe_data
        for line in del_lines:
            assert line in pipe_data

        # count the files
        mocorr_file_count = len(os.listdir("MotionCorr/job002"))
        mocorr_rawdata_file_count = len(os.listdir("MotionCorr/job002/Raw_data"))

        # do the deletion
        CL_relion.main(
            ["CL_relion.py", "--delete_job", "MotionCorr/job002/", "--no_recursive"]
        )

        # check the deleted lines are gone from the pipeline
        pipe_data = self.read_pipeline()
        for line in del_lines:
            assert line not in pipe_data, line
        # check the child process lines are still there
        for line in kept_lines:
            assert line in pipe_data, line

        # make sure the files have been moved to the trash
        mocorr_trash_count = len(os.listdir("Trash/MotionCorr/job002"))
        mocorr_rawdata_trash_count = len(os.listdir("Trash/MotionCorr/job002/Raw_data"))
        # ctffind job shouldn't have been trashed
        assert not os.path.isdir("Trash/CtfFind/job003")
        assert mocorr_trash_count == mocorr_file_count
        assert mocorr_rawdata_trash_count == mocorr_rawdata_file_count

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_delete_then_undelete(self):
        # make all of the necessary files
        generic_tests.make_shortpipe_filestructure(["Import", "MotionCorr", "CtfFind"])
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_3jobs_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/minipipe_mocorr_pipeline.star"),
            os.path.join(self.test_dir, "MotionCorr/job002/job_pipeline.star"),
        )
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/minipipe_ctffind_pipeline.star"),
            os.path.join(self.test_dir, "CtfFind/job003/job_pipeline.star"),
        )

        # count the files
        mocorr_file_count = len(os.listdir("MotionCorr/job002"))
        mocorr_rawdata_file_count = len(os.listdir("MotionCorr/job002/Raw_data"))
        ctffind_file_count = len(os.listdir("CtfFind/job003"))

        # read the default pipeline and check that the expected lines are there
        pipe_data = self.read_pipeline()
        inc_lines = [
            "MotionCorr/job002/       None            1            2",
            "CtfFind/job003/       None            2            2",
            "MotionCorr/job002/corrected_micrographs.star            1",
            "MotionCorr/job002/logfile.pdf           13",
            "CtfFind/job003/micrographs_ctf.star            1",
            "CtfFind/job003/logfile.pdf           13",
            "MotionCorr/job002/corrected_micrographs.star CtfFind/job003/",
            "MotionCorr/job002/ MotionCorr/job002/corrected_micrographs.star",
            "MotionCorr/job002/ MotionCorr/job002/logfile.pdf",
            "CtfFind/job003/ CtfFind/job003/micrographs_ctf.star",
            "CtfFind/job003/ CtfFind/job003/logfile.pdf",
        ]
        for line in inc_lines:
            assert line in pipe_data

        # delete the mocorr job along with 1 child
        CL_relion.main(["CL_relion.py", "--delete_job", "MotionCorr/job002/"])

        # make sure the files have been moved to the trash
        mocorr_trash_count = len(os.listdir("Trash/MotionCorr/job002"))
        mocorr_rawdata_trash_count = len(os.listdir("Trash/MotionCorr/job002/Raw_data"))
        ctffind_trash_count = len(os.listdir("Trash/CtfFind/job003"))
        assert mocorr_trash_count == mocorr_file_count
        assert mocorr_rawdata_trash_count == mocorr_rawdata_file_count
        assert ctffind_trash_count == ctffind_file_count

        # reread the pipeline and make sure the lines are gone
        pipe_data = self.read_pipeline()
        for line in inc_lines:
            assert line not in pipe_data, line

        # undelete the ctffind job - which should include 1 parent
        CL_relion.main(["CL_relion.py", "--undelete_job", "CtfFind/job003/"])

        # check that the lines are back in the default pipeline
        pipe_data = self.read_pipeline()
        for line in inc_lines:
            assert line in pipe_data, line

        # count the files - make sure they have been moved back from the trash...
        assert not os.path.isdir("Trash/MotionCorr/job002")
        assert not os.path.isdir("Trash/CtfFind/job003")

        # ...and are back in the right place
        mocorr_file_count2 = len(os.listdir("MotionCorr/job002"))
        mocorr_rawdata_file_count2 = len(os.listdir("MotionCorr/job002/Raw_data"))
        ctffind_file_count2 = len(os.listdir("CtfFind/job003"))
        assert mocorr_file_count2 == mocorr_file_count
        assert mocorr_rawdata_file_count2 == mocorr_rawdata_file_count
        assert ctffind_file_count2 == ctffind_file_count

    def test_schedule_job(self, job="001"):
        """job number is flexible so the test can be used again later"""
        # get the files
        jobfile = os.path.join(
            self.test_data, "JobFiles/PostProcess/postprocess_CL_job.star"
        )

        halfmap_import_dir = "HalfMaps"
        if not os.path.isdir(halfmap_import_dir):
            os.makedirs(halfmap_import_dir)
        shutil.copy(
            os.path.join(self.test_data, "3488_run_half1_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        shutil.copy(
            os.path.join(self.test_data, "3488_run_half2_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        mask_import_dir = "Mask"
        if not os.path.isdir(mask_import_dir):
            os.makedirs(mask_import_dir)
        shutil.copy(os.path.join(self.test_data, "emd_3488_mask.mrc"), mask_import_dir)

        # intialize a new project the first time
        if not os.path.isfile("default_pipeline.star"):
            CL_relion.main(["CL_relion.py", "--new_project"])

        # schedule the job
        CL_relion.main(["CL_relion.py", "--schedule_job", jobfile])

        # check the expected lines are in the pipeline
        expected_lines = [
            "PostProcess/job{}/       None           15            1".format(job),
            "Mask/emd_3488_mask.mrc            7",
            "HalfMaps/3488_run_half1_class001_unfil.mrc           10",
            "PostProcess/job{}/postprocess.mrc           11".format(job),
            "PostProcess/job{}/postprocess_masked.mrc           11".format(job),
            "PostProcess/job{}/postprocess.star           14".format(job),
            "PostProcess/job{}/logfile.pdf           13".format(job),
            "Mask/emd_3488_mask.mrc PostProcess/job{}/".format(job),
            (
                "HalfMaps/3488_run_half1_class001_unfil.mrc "
                "PostProcess/job{}/".format(job)
            ),
            "PostProcess/job{0}/ PostProcess/job{0}/postprocess.mrc".format(job),
            "PostProcess/job{0}/ PostProcess/job{0}/postprocess_masked.mrc".format(job),
            "PostProcess/job{0}/ PostProcess/job{0}/postprocess.star".format(job),
            "PostProcess/job{0}/ PostProcess/job{0}/logfile.pdf".format(job),
        ]
        pipe_data = self.read_pipeline()
        for line in expected_lines:
            assert line in pipe_data, line

        # check that the .Nodes files have been made
        expected_files = [
            ".Nodes/11/PostProcess/job{}/postprocess.mrc".format(job),
            ".Nodes/11/PostProcess/job{}/postprocess_masked.mrc".format(job),
            ".Nodes/13/PostProcess/job{}/logfile.pdf".format(job),
            ".Nodes/14/PostProcess/job{}/postprocess.star".format(job),
        ]
        for f in expected_files:
            assert os.path.isfile(f), f

    def test_running_schedule(self):
        """Make a schedule with two jobs and run it 3 times"""

        # use the previous test to schedule two postprocess jobs
        self.test_schedule_job(job="001")
        self.test_schedule_job(job="002")

        # run the schedule 3 times
        CL_relion.main(
            [
                "CL_relion.py",
                "--run_schedule",
                "--name",
                "schedule1",
                "--jobs",
                "PostProcess/job001/",
                "PostProcess/job002/",
                "--nr_repeats",
                "3",
                "--min_between",
                "0",
                "--wait_min_before",
                "0",
                "--wait_sec_after",
                "1",
            ]
        )

        # check the expected files are produced
        pp_files = [
            "RELION_JOB_EXIT_SUCCESS",
            "logfile.pdf",
            "logfile.pdf.lst",
            "postprocess.mrc",
            "postprocess.star",
            "postprocess_fsc.eps",
            "postprocess_fsc.xml",
            "postprocess_guinier.eps",
            "postprocess_masked.mrc",
            "default_pipeline.star",
            "job.star",
            "job_pipeline.star",
            "note.txt",
            "run.err",
            "run.job",
            "run.out",
        ]
        for f in pp_files:
            for job in ["001", "002"]:
                assert os.path.isfile(os.path.join("PostProcess/job" + job, f)), f

        # check the jobs ran 3x and schedule log was written properly
        with open("pipeline_schedule1.log") as logfile:
            log_data = logfile.readlines()
        job001_count = 0
        job002_count = 0
        for line in log_data:
            if "---- Executing PostProcess/job001/" in line:
                job001_count += 1
            if "---- Executing PostProcess/job002/" in line:
                job002_count += 1
        assert job001_count == 3
        assert job002_count == 3

        # TO DO: check the mini_pipeline is as expected

        # TO DO: Add test the 2nd and 3rd runs were continues
        # after that functionality is added to the job runner

    def test_running_schedule_fails_when_schedule_lock_present(self):
        """Make a schedule with two jobs but it fails because the schedule lock
        file is present"""

        # use the previous test to schedule two postprocess jobs
        self.test_schedule_job(job="001")
        self.test_schedule_job(job="002")
        os.system("touch RUNNING_PIPELINER_default_schedule1")
        # run the schedule 3 times
        with self.assertRaises(ValueError):
            CL_relion.main(
                [
                    "CL_relion.py",
                    "--run_schedule",
                    "--name",
                    "schedule1",
                    "--jobs",
                    "PostProcess/job001/",
                    "PostProcess/job002/",
                    "--nr_repeats",
                    "3",
                    "--min_between",
                    "0",
                    "--wait_min_before",
                    "0",
                    "--wait_sec_after",
                    "1",
                ]
            )

    def test_get_command_jobstar_noproject(self):
        # get the files
        jobfile = os.path.join(
            self.test_data, "JobFiles/PostProcess/postprocess_CL_job.star"
        )

        # run print command, don't initialize project
        command = [CL_relion.main(["CL_relion.py", "--print_command", jobfile])]

        # verify command is as expected
        expected_command = [
            "`which relion_postprocess` --mask Mask/emd_3488_mask.mrc"
            " --i HalfMaps/3488_run_half1_class001_unfil.mrc --o "
            "PostProcess/job000/postprocess --angpix 1.244 --adhoc_bfac -1000"
            " --pipeline_control PostProcess/job000/ >> PostProcess/job000/run.out "
            "2>> PostProcess/job000/run.err & "
        ]

        assert command == expected_command, generic_tests.print_coms(
            expected_command, command,
        )

    def test_get_command_runjob_noproject(self):
        # get the files
        jobfile = os.path.join(
            self.test_data, "JobFiles/InitialModel/initialmodel_3classes.job"
        )

        # run print command, don't initialize project
        command = CL_relion.main(["CL_relion.py", "--print_command", jobfile])

        # verify command is as expected
        expected_command = (
            "mpirun -n 5 `which relion_refine_mpi` --sgd --denovo_3dref --i "
            "Select/job014/particles.star --o InitialModel/job000/run "
            "--sgd_ini_iter 25 --sgd_inbetween_iter 100 --sgd_fin_iter 25 "
            "--sgd_write_iter 10 --sgd_ini_resol 35 --sgd_fin_resol 15 "
            "--sgd_ini_subset 100 --sgd_fin_subset 500 --ctf --K 3 --sym C1"
            " --flatten_solvent --zero_mask --dont_combine_weights_via_disc"
            " --scratch_dir my_scratch_dir --pool 30 --pad 2 --skip_gridding "
            "--particle_diameter 200 --oversampling 1 --healpix_order 1 "
            '--offset_range 6 --offset_step 4.0 --j 6 --gpu "4:5:6:7"'
            " --pipeline_control InitialModel/job000/"
            " >> InitialModel/job000/run.out 2>> InitialModel/job000/run.err & "
        )

        assert command == expected_command, generic_tests.print_coms(
            expected_command, command,
        )

    def test_get_command_jobstar(self):
        # get the files
        jobfile = os.path.join(
            self.test_data, "JobFiles/PostProcess/postprocess_CL_job.star"
        )

        # initialize project and run print command
        CL_relion.main(["CL_relion.py", "--new_project"])
        command = [CL_relion.main(["CL_relion.py", "--print_command", jobfile])]

        # verify command is as expected
        expected_command = [
            "`which relion_postprocess` --mask Mask/emd_3488_mask.mrc"
            " --i HalfMaps/3488_run_half1_class001_unfil.mrc --o "
            "PostProcess/job001/postprocess --angpix 1.244 --adhoc_bfac -1000"
            " --pipeline_control PostProcess/job001/ >> PostProcess/job001/run.out "
            "2>> PostProcess/job001/run.err & "
        ]

        assert command == expected_command, generic_tests.print_coms(
            expected_command, command,
        )

    def test_get_command_runjob(self):
        # get the files
        jobfile = os.path.join(
            self.test_data, "JobFiles/InitialModel/initialmodel_3classes.job"
        )
        # initialize project and run print command
        CL_relion.main(["CL_relion.py", "--new_project"])
        command = CL_relion.main(["CL_relion.py", "--print_command", jobfile])

        # verify command is as expected
        expected_command = (
            "mpirun -n 5 `which relion_refine_mpi` --sgd --denovo_3dref --i "
            "Select/job014/particles.star --o InitialModel/job001/run "
            "--sgd_ini_iter 25 --sgd_inbetween_iter 100 --sgd_fin_iter 25 "
            "--sgd_write_iter 10 --sgd_ini_resol 35 --sgd_fin_resol 15 "
            "--sgd_ini_subset 100 --sgd_fin_subset 500 --ctf --K 3 --sym C1"
            " --flatten_solvent --zero_mask --dont_combine_weights_via_disc"
            " --scratch_dir my_scratch_dir --pool 30 --pad 2 --skip_gridding "
            "--particle_diameter 200 --oversampling 1 --healpix_order 1 "
            '--offset_range 6 --offset_step 4.0 --j 6 --gpu "4:5:6:7"'
            " --pipeline_control InitialModel/job001/"
            " >> InitialModel/job001/run.out 2>> InitialModel/job001/run.err & "
        )

        assert command == expected_command, generic_tests.print_coms(
            expected_command, command,
        )

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_cleanup_single_job(self):
        # create the files
        procname = "Class3D"
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_full_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )
        outfiles = generic_tests.make_shortpipe_filestructure([procname])
        files = glob("Class3D/job009/*")
        assert len(files) == len(outfiles[procname]), (
            len(files),
            len(outfiles[procname]),
        )

        # list of files that should be deleted
        del_files = glob("Class3D/job009/run_it*")
        for f in [
            "Class3D/job009/run_it025_class001.mrc",
            "Class3D/job009/run_it025_class001_angdist.bild",
            "Class3D/job009/run_it025_class002.mrc",
            "Class3D/job009/run_it025_class002_angdist.bild",
            "Class3D/job009/run_it025_class003.mrc",
            "Class3D/job009/run_it025_class003_angdist.bild",
            "Class3D/job009/run_it025_sampling.star",
            "Class3D/job009/run_it025_data.star",
            "Class3D/job009/run_it025_model.star",
            "Class3D/job009/run_it025_optimiser.star",
        ]:
            del_files.remove(f)

        # do the cleanup
        CL_relion.main(["CL_relion.py", "--cleanup", "Class3D/job009/"])

        # sort the files
        removed, kept = [], []
        for f in outfiles[procname]:
            if f in del_files:
                removed.append(f)
            else:
                kept.append(f)

        # check they are all in the right place
        files = glob("Class3D/job009/*")
        trash = glob("Trash/**/**/*")
        for f in kept:
            assert f in files, f
        for f in removed:
            assert f not in files, f
            assert "Trash/" + f in trash, f

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_cleanup_multiple_jobs(self):
        # create the files
        procnames = ["Class3D", "InitialModel"]
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_full_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )
        outfiles = generic_tests.make_shortpipe_filestructure(procnames)

        # list of files that should be deleted
        del_files = glob("Class3D/job009/run_it*") + glob("InitialModel/job008/run_it*")
        for f in [
            "Class3D/job009/run_it025_class001.mrc",
            "Class3D/job009/run_it025_class001_angdist.bild",
            "Class3D/job009/run_it025_class002.mrc",
            "Class3D/job009/run_it025_class002_angdist.bild",
            "Class3D/job009/run_it025_class003.mrc",
            "Class3D/job009/run_it025_class003_angdist.bild",
            "Class3D/job009/run_it025_sampling.star",
            "Class3D/job009/run_it025_data.star",
            "Class3D/job009/run_it025_model.star",
            "Class3D/job009/run_it025_optimiser.star",
            "InitialModel/job008/run_it150_data.star",
            "InitialModel/job008/run_it150_sampling.star",
            "InitialModel/job008/run_it150_model.star",
            "InitialModel/job008/run_it150_optimiser.star",
            "InitialModel/job008/run_it150_class001.mrc",
            "InitialModel/job008/run_it150_grad001.mrc",
            "InitialModel/job008/run_it150_class002.mrc",
            "InitialModel/job008/run_it150_grad002.mrc",
        ]:
            del_files.remove(f)

        # do the cleanup
        CL_relion.main(
            ["CL_relion.py", "--cleanup", "Class3D/job009/", "InitialModel/job008/"]
        )

        # sort the files
        removed, kept = [], []
        for procname in procnames:
            for f in outfiles[procname]:
                if f in del_files:
                    removed.append(f)
                else:
                    kept.append(f)

        # check they are all in the right place
        files = glob("Class3D/job009/*") + glob("InitialModel/job008/*")
        trash = glob("Trash/**/**/*")
        for f in kept:
            assert f in files, f
        for f in removed:
            assert f not in files, f
            assert "Trash/" + f in trash, f

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_cleanup_single_job_harsh(self):
        procname = "Polish"
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_full_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )
        outfiles = generic_tests.make_shortpipe_filestructure([procname])

        files = glob("Polish/job014/**/*", recursive=True)

        assert len(files) == len(outfiles[procname]) + 1, (
            len(files),
            len(outfiles[procname]) + 1,
        )

        del_files = []
        for ext in [
            "*_FCC_cc.mrc",
            "*_FCC_w0.mrc",
            "*_FCC_w1.mrc",
            "*shiny.star",
            "*shiny.mrcs",
        ]:
            del_files += glob("Polish/job014/Raw_data/" + ext)

        # do the cleanup
        CL_relion.main(["CL_relion.py", "--cleanup", "Polish/job014/", "--harsh"])

        # sort the files
        removed, kept = [], []
        for f in outfiles[procname]:
            if f in del_files:
                removed.append(f)
            else:
                kept.append(f)

        # check they are all in the right place
        files = glob("Polish/job014/**/*", recursive=True)
        trash = glob("Trash/**/**/**/*", recursive=True)
        for f in kept:
            assert f in files, f
        for f in removed:
            assert f not in files, f
            assert "Trash/" + f in trash, f

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_cleanup_alljobs(self):
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_full_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )
        generic_tests.make_shortpipe_filestructure("all")

        del_files = {
            "Import": [],
            "MotionCorr": [
                "/job002/Raw_data/*.com",
                "/job002/Raw_data/*.err",
                "/job002/Raw_data/*.out",
                "/job002/Raw_data/*.log",
            ],
            "CtfFind": [
                "/job003/gctf*.out",
                "/job003/gctf*.err",
                "/job003/Raw_data/*",
            ],
            "AutoPick": ["/job004/Raw_data/*.spi"],
            "Extract": ["/job005/Raw_data/*_extract.star"],
            "Class2D": ["/job006/run_it*"],
            "Select": [],
            "InitialModel": ["/job008/run_it*"],
            "Class3D": ["/job009/run_it*"],
            "Refine3D": ["/job010/run_it*"],
            "MultiBody": ["/job011/run_it*"],
            "CtfRefine": [
                "/job012/Raw_data/*_wAcc.mrc",
                "/job012/Raw_data/*_xyAcc_real.mrc",
                "/job012/Raw_data/*_xyAcc_imag.mrc",
            ],
            "MaskCreate": [],
            "Polish": [
                "/job014/Raw_data/*_FCC_cc.mrc",
                "/job014/Raw_data/*_FCC_w0.mrc",
                "/job014/Raw_data/*_FCC_w1.mrc",
            ],
            "JoinStar": [],
            "Subtract": [],
            "External": [],
            "PostProcess": ["/job017/*masked.mrc"],
            "LocalRes": [],
        }

        exclude_files = {
            "Import": [],
            "MotionCorr": [],
            "CtfFind": [],
            "AutoPick": [],
            "Extract": [],
            "Class2d": [
                "Class2D/job006/run_it025_data.star",
                "Class2D/job006/run_it025_sampling.star",
                "Class2D/job006/run_it025_model.star",
                "Class2D/job006/run_it025_optimiser.star",
                "Class2D/job006/run_it025_classes.mrcs",
            ],
            "Select": [],
            "InitialModel": [
                "InitialModel/job008/run_it150_data.star",
                "InitialModel/job008/run_it150_sampling.star",
                "InitialModel/job008/run_it150_model.star",
                "InitialModel/job008/run_it150_optimiser.star",
                "InitialModel/job008/run_it150_class001.mrc",
                "InitialModel/job008/run_it150_grad001.mrc",
                "InitialModel/job008/run_it150_class002.mrc",
                "InitialModel/job008/run_it150_grad002.mrc",
            ],
            "Class3D": [
                "Class3D/job009/run_it025_class001.mrc",
                "Class3D/job009/run_it025_class001_angdist.bild",
                "Class3D/job009/run_it025_class002.mrc",
                "Class3D/job009/run_it025_class002_angdist.bild",
                "Class3D/job009/run_it025_class003.mrc",
                "Class3D/job009/run_it025_class003_angdist.bild",
                "Class3D/job009/run_it025_sampling.star",
                "Class3D/job009/run_it025_data.star",
                "Class3D/job009/run_it025_model.star",
                "Class3D/job009/run_it025_optimiser.star",
            ],
            "Refine3D": [
                "Refine3D/job010/run_it016_half1_class001.mrc",
                "Refine3D/job010/run_it016_half1_class001_angdist.bild",
                "Refine3D/job010/run_it016_half1_model.star",
                "Refine3D/job010/run_it016_half2_class001.mrc",
                "Refine3D/job010/run_it016_half2_class001_angdist.bild",
                "Refine3D/job010/run_it016_half2_model.star",
                "Refine3D/job010/run_it016_sampling.star",
                "Refine3D/job010/run_it016_data.star",
                "Refine3D/job010/run_it016_optimiser.star",
            ],
            "MultiBody": [
                "MultiBody/job011/run_it012_data.star",
                "MultiBody/job011/run_it012_half1_body001_angdist.bild",
                "MultiBody/job011/run_it012_half1_body001.mrc",
                "MultiBody/job011/run_it012_half1_body002_angdist.bild",
                "MultiBody/job011/run_it012_half1_body002.mrc",
                "MultiBody/job011/run_it012_half1_model.star",
                "MultiBody/job011/run_it012_half2_body001_angdist.bild",
                "MultiBody/job011/run_it012_half2_body001.mrc",
                "MultiBody/job011/run_it012_half2_body002_angdist.bild",
                "MultiBody/job011/run_it012_half2_body002.mrc",
                "MultiBody/job011/run_it012_half2_model.star",
            ],
            "CtfRefine": [],
            "MaskCreate": [],
            "Polish": [],
            "JoinStar": [],
            "Subtract": [],
            "External": [],
            "LocalRes": [],
        }

        files = list()
        for search_string in del_files:
            files += glob("{}/*/**/*".format(search_string), recursive=True)

        delete_list = list()
        for f in del_files:
            for search_string in del_files[f]:
                if len(search_string) > 1:
                    add = glob(f + search_string)
                    delete_list += add

        for f in exclude_files:
            for ff in exclude_files[f]:
                delete_list.remove(ff)

        CL_relion.main(["CL_relion.py", "--cleanup", "ALL"])

        # sort the files
        dirnames = [
            "Import/job001",
            "MotionCorr/job002",
            "MotionCorr/job002/Raw_data",
            "CtfFind/job003",
            "CtfFind/job003/Raw_data",
            "AutoPick/job004/Raw_data",
            "Extract/job005/Raw_data",
            "Class2D/job006",
            "Select/job007",
            "InitialModel/job008",
            "Class3D/job009",
            "Refine3D/job010",
            "MultiBody/job011",
            "CtfRefine/job012/Raw_data",
            "MaskCreate/job013",
            "Polish/job014/Raw_data",
            "JoinStar/job015",
            "Subtract/job016",
            "External/job017",
            "PostProcess/job018",
            "LocalRes/job019",
        ]
        removed, kept = [], []
        for f in files:
            if f in delete_list:
                removed.append(f)
            else:
                if f not in dirnames:
                    kept.append(f)

        # check they are all in the right place
        files2 = list()
        for search_string in del_files:
            files2 += glob("{}/*/**/*".format(search_string), recursive=True)
        trash = glob("Trash/*/**/*", recursive=True)
        for f in kept:
            assert f in files2, f
        for f in removed:
            assert f not in files2, f
            assert "Trash/" + f in trash, "Trash/" + f

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_cleanup_alljobs_harsh(self):
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_full_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )
        generic_tests.make_shortpipe_filestructure("all")

        del_files = {
            "Import": [],
            "MotionCorr": ["/job002/Raw_data/*"],
            "CtfFind": [
                "/job003/gctf*.out",
                "/job003/gctf*.err",
                "/job003/Raw_data/*",
            ],
            "AutoPick": ["/job004/Raw_data/*.spi"],
            "Extract": ["/job005/Raw_data/*"],
            "Class2D": ["/job006/run_it*"],
            "Select": [],
            "InitialModel": ["/job008/run_it*"],
            "Class3D": ["/job009/run_it*"],
            "Refine3D": ["/job010/run_it*"],
            "MultiBody": ["/job011/run_it*", "/job011/analyse_component*_bin*.mrc"],
            "CtfRefine": [
                "/job012/Raw_data/*_wAcc.mrc",
                "/job012/Raw_data/*_xyAcc_real.mrc",
                "/job012/Raw_data/*_xyAcc_imag.mrc",
            ],
            "MaskCreate": [],
            "Polish": [
                "/job014/Raw_data/*_FCC_cc.mrc",
                "/job014/Raw_data/*_FCC_w0.mrc",
                "/job014/Raw_data/*_FCC_w1.mrc",
                "/job014/Raw_data/*shiny.star",
                "/job014/Raw_data/*shiny.mrcs",
            ],
            "JoinStar": [],
            "Subtract": ["/job016/subtracted_*"],
            "External": [],
            "PostProcess": ["/job017/*masked.mrc"],
            "LocalRes": [],
        }

        exclude_files = {
            "Import": [],
            "MotionCorr": [],
            "CtfFind": [],
            "AutoPick": [],
            "Extract": [],
            "Class2d": [
                "Class2D/job006/run_it025_data.star",
                "Class2D/job006/run_it025_sampling.star",
                "Class2D/job006/run_it025_model.star",
                "Class2D/job006/run_it025_optimiser.star",
                "Class2D/job006/run_it025_classes.mrcs",
            ],
            "Select": [],
            "InitialModel": [
                "InitialModel/job008/run_it150_data.star",
                "InitialModel/job008/run_it150_sampling.star",
                "InitialModel/job008/run_it150_model.star",
                "InitialModel/job008/run_it150_optimiser.star",
                "InitialModel/job008/run_it150_class001.mrc",
                "InitialModel/job008/run_it150_grad001.mrc",
                "InitialModel/job008/run_it150_class002.mrc",
                "InitialModel/job008/run_it150_grad002.mrc",
            ],
            "Class3D": [
                "Class3D/job009/run_it025_class001.mrc",
                "Class3D/job009/run_it025_class001_angdist.bild",
                "Class3D/job009/run_it025_class002.mrc",
                "Class3D/job009/run_it025_class002_angdist.bild",
                "Class3D/job009/run_it025_class003.mrc",
                "Class3D/job009/run_it025_class003_angdist.bild",
                "Class3D/job009/run_it025_sampling.star",
                "Class3D/job009/run_it025_data.star",
                "Class3D/job009/run_it025_model.star",
                "Class3D/job009/run_it025_optimiser.star",
            ],
            "Refine3D": [
                "Refine3D/job010/run_it016_half1_class001.mrc",
                "Refine3D/job010/run_it016_half1_class001_angdist.bild",
                "Refine3D/job010/run_it016_half1_model.star",
                "Refine3D/job010/run_it016_half2_class001.mrc",
                "Refine3D/job010/run_it016_half2_class001_angdist.bild",
                "Refine3D/job010/run_it016_half2_model.star",
                "Refine3D/job010/run_it016_sampling.star",
                "Refine3D/job010/run_it016_data.star",
                "Refine3D/job010/run_it016_optimiser.star",
            ],
            "MultiBody": [
                "MultiBody/job011/run_it012_data.star",
                "MultiBody/job011/run_it012_half1_body001_angdist.bild",
                "MultiBody/job011/run_it012_half1_body001.mrc",
                "MultiBody/job011/run_it012_half1_body002_angdist.bild",
                "MultiBody/job011/run_it012_half1_body002.mrc",
                "MultiBody/job011/run_it012_half1_model.star",
                "MultiBody/job011/run_it012_half2_body001_angdist.bild",
                "MultiBody/job011/run_it012_half2_body001.mrc",
                "MultiBody/job011/run_it012_half2_body002_angdist.bild",
                "MultiBody/job011/run_it012_half2_body002.mrc",
                "MultiBody/job011/run_it012_half2_model.star",
            ],
            "CtfRefine": [],
            "MaskCreate": [],
            "Polish": [],
            "JoinStar": [],
            "Subtract": [],
            "External": [],
            "LocalRes": [],
        }

        files = list()
        for search_string in del_files:
            files += glob("{}/*/**/*".format(search_string), recursive=True)

        delete_list = list()
        for f in del_files:
            for search_string in del_files[f]:
                if len(search_string) > 1:
                    add = glob(f + search_string)
                    delete_list += add

        for f in exclude_files:
            for ff in exclude_files[f]:
                delete_list.remove(ff)

        # run the cleanup
        CL_relion.main(["CL_relion.py", "--cleanup", "ALL", "--harsh"])
        # sort the files
        dirnames = [
            "Import/job001",
            "MotionCorr/job002",
            "MotionCorr/job002/Raw_data",
            "CtfFind/job003",
            "CtfFind/job003/Raw_data",
            "AutoPick/job004/Raw_data",
            "Extract/job005/Raw_data",
            "Class2D/job006",
            "Select/job007",
            "InitialModel/job008",
            "Class3D/job009",
            "Refine3D/job010",
            "MultiBody/job011",
            "CtfRefine/job012/Raw_data",
            "MaskCreate/job013",
            "Polish/job014/Raw_data",
            "JoinStar/job015",
            "Subtract/job016",
            "External/job017",
            "PostProcess/job018",
            "LocalRes/job019",
        ]
        removed, kept = [], []
        for f in files:
            if f in delete_list:
                removed.append(f)
            else:
                if f not in dirnames:
                    kept.append(f)

        # check they are all in the right place
        files2 = list()
        for search_string in del_files:
            files2 += glob("{}/*/**/*".format(search_string), recursive=True)
        trash = glob("Trash/*/**/*", recursive=True)
        for f in kept:
            assert f in files2, f
        for f in removed:
            assert f not in files2, f
            assert "Trash/" + f in trash, "Trash/" + f

    def test_validate_starfile(self):
        """ run validate on a good statfile"""
        shutil.copy(
            os.path.join(self.test_data, "StarFiles/motioncorr_changed.star"),
            self.test_dir,
        )
        CL_relion.main(
            ["CL_relion.py", "--validate_starfile", "motioncorr_changed.star"]
        )

    def test_validate_starfile_reserved_word(self):
        """ run validate on a starfile with a reserved word """
        shutil.copy(
            os.path.join(self.test_data, "StarFiles/motioncorr_not_quotated_fail.star"),
            self.test_dir,
        )
        assert CL_relion.main(
            ["CL_relion.py", "--validate_starfile", "motioncorr_not_quotated_fail.star"]
        )
        badlines = [
            "save_noDW          No\n",
            "save_ps          Yes\n",
        ]
        goodlines = [
            '"save_noDW"          No\n',
            '"save_ps"          Yes\n',
        ]
        with open("fixed_motioncorr_not_quotated_fail.star") as fixed:
            fixed_data = fixed.readlines()
        for line in badlines:
            assert line not in fixed_data, line
        for line in goodlines:
            assert line in fixed_data, line

    def test_validate_starfile_reserved_word_different_dir(self):
        """ run validate on a starfile with a reserved word not located
        in the dir that the program was run from, make sure it writes in
        the correct place"""
        os.makedirs(os.path.join(self.test_dir, "1/2/3"))
        shutil.copy(
            os.path.join(self.test_data, "StarFiles/motioncorr_not_quotated_fail.star"),
            os.path.join(self.test_dir, "1/2/3"),
        )
        assert CL_relion.main(
            [
                "CL_relion.py",
                "--validate_starfile",
                "1/2/3/motioncorr_not_quotated_fail.star",
            ]
        )
        badlines = [
            "save_noDW          No\n",
            "save_ps          Yes\n",
        ]
        goodlines = [
            '"save_noDW"          No\n',
            '"save_ps"          Yes\n',
        ]
        with open("1/2/3/fixed_motioncorr_not_quotated_fail.star") as fixed:
            fixed_data = fixed.readlines()
        for line in badlines:
            assert line not in fixed_data, line
        for line in goodlines:
            assert line in fixed_data, line

    def test_validate_starfile_unfixable(self):
        """ run validate on a good starfile"""
        shutil.copy(
            os.path.join(self.test_data, "StarFiles/invalid_starfile.star"),
            self.test_dir,
        )
        assert not CL_relion.main(
            ["CL_relion.py", "--validate_starfile", "invalid_starfile.star"]
        )

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_deleting_file_then_empty_trash(self):
        self.test_deleting_job()
        nr_trash_files = len(glob("Trash/*/*/*"))
        assert nr_trash_files == 40
        assert CL_relion.main(["CL_relion.py", "--empty_trash"])
        nr_trash_files = len(glob("Trash/*/*/*"))
        assert nr_trash_files == 0

    def test_empty_trash_error_nofiles(self):
        nr_trash_files = len(glob("Trash/*/*/*"))
        assert nr_trash_files == 0
        assert CL_relion.main(["CL_relion.py", "--new_project"])
        assert not CL_relion.main(["CL_relion.py", "--empty_trash"])

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_drawing_flowchart_upstream(self):
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        # make it like CL relion has already been used
        with open(".CL_relion_project", "w") as project_file:
            project_file.write("short_full")

        results = CL_relion.main(
            ["CL_relion.py", "--draw_flowchart", "Refine3D/job010/", "--upstream"]
        )
        assert results == [True, False, False]

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_drawing_flowchart_downstream(self):
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        with open(".CL_relion_project", "w") as project_file:
            project_file.write("short_full")

        results = CL_relion.main(
            ["CL_relion.py", "--draw_flowchart", "Refine3D/job010/", "--downstream"]
        )
        assert results == [False, True, False]

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_drawing_flowchart_full(self):
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )

        with open(".CL_relion_project", "w") as project_file:
            project_file.write("short_full")

        results = CL_relion.main(["CL_relion.py", "--draw_flowchart"])
        assert results == [False, False, True]

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_drawing_flowchart_up_and_down(self):
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )

        with open(".CL_relion_project", "w") as project_file:
            project_file.write("short_full")

        results = CL_relion.main(
            ["CL_relion.py", "--draw_flowchart", "Refine3D/job010/"]
        )
        assert results == [True, True, False]

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_drawing_flowchart_error_upstream_but_no_job(self):
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        with open(".CL_relion_project", "w") as project_file:
            project_file.write("short_full")

        results = CL_relion.main(["CL_relion.py", "--draw_flowchart", "--upstream"])
        assert results == [False, False, False]

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_drawing_flowchart_error_downstream_but_no_job(self):
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        with open(".CL_relion_project", "w") as project_file:
            project_file.write("short_full")

        results = CL_relion.main(["CL_relion.py", "--draw_flowchart", "--upstream"])
        assert results == [False, False, False]

    def test_continuing_job_basic(self):
        """Make sure continuation creates the job.star.ct000 file"""
        # run a postprocess job
        self.run_postprocess_job()
        # continue that job
        CL_relion.main(["CL_relion.py", "--continue_job", "PostProcess/job001"])
        time.sleep(1)
        assert os.path.isfile("PostProcess/job001/job.star.ct000")
        # make sure it actually ran 2x
        with open("PostProcess/job001/run.out") as runout:
            runout_lines = runout.readlines()
        count = 0
        for line in runout_lines:
            if "FINAL RESOLUTION:" in line:
                count += 1
        assert count == 2, count

    def test_continuing_job_multiple(self):
        """Make sure multiple continuations increment the job.star.ctxxx file"""
        # run a postprocess job
        self.run_postprocess_job()
        # continue that job 3x
        CL_relion.main(["CL_relion.py", "--continue_job", "PostProcess/job001"])
        time.sleep(1)
        CL_relion.main(["CL_relion.py", "--continue_job", "PostProcess/job001"])
        time.sleep(1)
        CL_relion.main(["CL_relion.py", "--continue_job", "PostProcess/job001"])
        time.sleep(1)

        # make sure the files are there
        assert os.path.isfile("PostProcess/job001/job.star.ct000")
        assert os.path.isfile("PostProcess/job001/job.star.ct001")
        assert os.path.isfile("PostProcess/job001/job.star.ct002")

        # make sure it actually ran 4x
        with open("PostProcess/job001/run.out") as runout:
            runout_lines = runout.readlines()
        count = 0
        for line in runout_lines:
            if "FINAL RESOLUTION:" in line:
                count += 1
        assert count == 4, count

    def test_continuing_job_continue_file_is_missing(self):
        """If the continue_job.star file is missing fall back to the
        orginial job.star"""
        # run a postprocess job
        self.run_postprocess_job()
        # continue that job
        os.system("rm PostProcess/job001/continue_job.star")
        CL_relion.main(["CL_relion.py", "--continue_job", "PostProcess/job001"])
        time.sleep(1)
        assert os.path.isfile("PostProcess/job001/job.star.ct000")
        # make sure it actually ran 2x
        with open("PostProcess/job001/run.out") as runout:
            runout_lines = runout.readlines()
        count = 0
        for line in runout_lines:
            if "FINAL RESOLUTION:" in line:
                count += 1
        assert count == 2, count

    def test_continuing_job_both_files_missing(self):
        """ If the continue_job.star and the job.star files are
        missing the continue can't run """
        # run a postprocess job
        self.run_postprocess_job()
        # continue that job
        os.system("rm PostProcess/job001/continue_job.star")
        os.system("rm PostProcess/job001/job.star")
        with self.assertRaises(ValueError):
            CL_relion.main(["CL_relion.py", "--continue_job", "PostProcess/job001"])

    def test_continuing_job_paramaters_are_set_correctly(self):
        """Make sure continuation subs in the values from the continue
        as expected """
        # run a postprocess job
        self.run_postprocess_job()

        # read the command that was executed
        with open("PostProcess/job001/note.txt") as notefile:
            note1 = notefile.read()

        # edit the continue_file
        with open("PostProcess/job001/continue_job.star") as confile:
            conlines = confile.readlines()
        conlines[17] = "angpix        2.55\n"
        with open("PostProcess/job001/continue_job.star", "w") as confile:
            confile.writelines(conlines)

        # continue that job
        CL_relion.main(["CL_relion.py", "--continue_job", "PostProcess/job001"])
        time.sleep(1)
        assert os.path.isfile("PostProcess/job001/job.star.ct000")

        # read the new command
        with open("PostProcess/job001/note.txt") as notefile:
            note2 = notefile.read()

        # make sure the commands are different
        assert "--angpix 1.244" in note1
        assert "--angpix 2.55" in note2

        # make sure it actually ran 2x
        with open("PostProcess/job001/run.out") as runout:
            runout_lines = runout.readlines()

        # make sure it was run with the new parameter
        resolution_lines = []
        for line in runout_lines:
            if "FINAL RESOLUTION:" in line:
                resolution_lines.append(line)
        assert len(resolution_lines) == 2
        assert resolution_lines[0] != resolution_lines[1]

    def test_scheduling_continue_job(self):
        """Make sure scheduling continuation of a job
        works as expected """
        # run a postprocess job
        self.run_postprocess_job()

        line = "PostProcess/job001/       None           15            2"
        pipeline = self.read_pipeline()
        assert line in pipeline, line
        # schedule a continuation of that job
        CL_relion.main(["CL_relion.py", "--schedule_job", "PostProcess/job001"])

        line = "PostProcess/job001/       None           15            1"
        pipeline = self.read_pipeline()
        assert line in pipeline

    def test_stop_schedule_GUI_style(self):
        """if the schedule is made by the GUI the RUNNING_ file is empty
        and should be deleted"""
        # make the RUNNING_ file
        subprocess.run(["touch", "RUNNING_PIPELINER_default_empty"])
        assert os.path.isfile("RUNNING_PIPELINER_default_empty")

        # stop the schedule
        CL_relion.main(["CL_relion.py", "--new_project"])
        CL_relion.main(["CL_relion.py", "--stop_schedule", "empty"])

        # file should be gone
        assert not os.path.isfile("RUNNING_PIPELINER_default_empty")

    def test_stop_schedule_from_API_style(self):
        """if the schedule is made by the API the RUNNING_ file
        just has a list of jobs"""

        # make the RUNNING_ file and populate it
        subprocess.run(["touch", "RUNNING_PIPELINER_default_api"])
        with open("RUNNING_PIPELINER_default_api", "w") as f:
            f.write("PostProcess/job001/\n")
        assert os.path.isfile("RUNNING_PIPELINER_default_api")
        with open("RUNNING_PIPELINER_default_api") as f:
            runfile_data = f.readlines()
        assert runfile_data[0] == "PostProcess/job001/\n"

        # initialize the project and copy in the pipeline
        CL_relion.main(["CL_relion.py", "--new_project"])
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "Pipelines/running_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )

        # make the necesary project dirs
        os.makedirs("PostProcess/job001")

        # stop the schedule
        CL_relion.main(["CL_relion.py", "--stop_schedule", "api"])

        # RUNNING file should be gone and ABORTED file should appear
        assert not os.path.isfile("RUNNING_PIPELINER_default_api")
        assert os.path.isfile("PostProcess/job001/RELION_JOB_EXIT_ABORTED")

        # pipeline should be updated
        with open("default_pipeline.star") as f:
            pipeline_data = f.readlines()
        newline = "PostProcess/job001/       None           15            4 \n"
        oldline = "PostProcess/job001/       None           15            0 \n"

        assert newline in pipeline_data
        assert oldline not in pipeline_data

    def test_stop_schedule_from_API_style_pipeliner_custom_name(self):
        """if the schedule is made by the API the RUNNING_ file
        just has a list of jobs.  Check this works if the pipeline
        name is not default"""

        # make the RUNNING_ file and populate it
        subprocess.run(["touch", "RUNNING_PIPELINER_fancypants_api"])
        with open("RUNNING_PIPELINER_fancypants_api", "w") as f:
            f.write("PostProcess/job001/\n")
        assert os.path.isfile("RUNNING_PIPELINER_fancypants_api")
        with open("RUNNING_PIPELINER_fancypants_api") as f:
            runfile_data = f.readlines()
        assert runfile_data[0] == "PostProcess/job001/\n"

        # initialize the project and copy in the pipeline
        CL_relion.main(["CL_relion.py", "--new_project", "fancypants"])
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "Pipelines/running_pipeline.star"),
            os.path.join(self.test_dir, "fancypants_pipeline.star"),
        )

        # make the necesary project dirs
        os.makedirs("PostProcess/job001")

        # stop the schedule
        CL_relion.main(["CL_relion.py", "--stop_schedule", "api"])

        # RUNNING file should be gone and ABORTED file should appear
        assert not os.path.isfile("RUNNING_PIPELINER_fancypants_api")
        assert os.path.isfile("PostProcess/job001/RELION_JOB_EXIT_ABORTED")

        # pipeline should be updated
        with open("fancypants_pipeline.star") as f:
            pipeline_data = f.readlines()
        newline = "PostProcess/job001/       None           15            4 \n"
        oldline = "PostProcess/job001/       None           15            0 \n"

        assert newline in pipeline_data
        assert oldline not in pipeline_data

    def test_stop_schedule_from_CL_style(self):
        """if the schedule is made by CL_relion the RUNNING_ file
        has a PID and a list of jobs, the schedule process needs to
        be killed as well"""

        # make the RUNNING_ file and populate it
        subprocess.run(["touch", "RUNNING_PIPELINER_default_api"])
        with open("RUNNING_PIPELINER_default_api", "w") as f:
            f.write("CL_RELION_SCHEDULE\n")
            f.write("9999999999\n")
            f.write("PostProcess/job001/\n")
        assert os.path.isfile("RUNNING_PIPELINER_default_api")
        with open("RUNNING_PIPELINER_default_api") as f:
            runfile_data = f.readlines()
        assert runfile_data == [
            "CL_RELION_SCHEDULE\n",
            "9999999999\n",
            "PostProcess/job001/\n",
        ]

        # initialize the project and copy in the pipeline
        CL_relion.main(["CL_relion.py", "--new_project"])
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "Pipelines/running_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )

        # make the necesary project dirs
        os.makedirs("PostProcess/job001")

        # stop the schedule
        CL_relion.main(["CL_relion.py", "--stop_schedule", "api"])

        # RUNNING file should be gone and ABORTED file should appear
        assert not os.path.isfile("RUNNING_PIPELINER_default_api")
        assert os.path.isfile("PostProcess/job001/RELION_JOB_EXIT_ABORTED")

        # pipeline should be updated
        with open("default_pipeline.star") as f:
            pipeline_data = f.readlines()
        newline = "PostProcess/job001/       None           15            4 \n"
        oldline = "PostProcess/job001/       None           15            0 \n"

        assert newline in pipeline_data
        assert oldline not in pipeline_data


if __name__ == "__main__":
    unittest.main()
