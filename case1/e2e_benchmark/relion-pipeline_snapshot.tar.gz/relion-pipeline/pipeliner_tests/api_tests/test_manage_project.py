import unittest
import os
import shutil
import tempfile
import time
import subprocess

from glob import glob

from pipeliner.api.manage_project import RelionProject
from pipeliner_tests import generic_tests

do_full = os.environ.get("UNITTEST_FULL", False) == "True"
do_interactive = os.environ.get("UNITTEST_INTERACTIVE", False) == "True"
# do_full = "True"


class APIUtilsTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_dir = tempfile.mkdtemp(prefix="relion_")
        self.pipeliner_test_data = os.path.join(
            os.path.abspath(os.path.join(__file__, "../..")), "test_data",
        )

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_not_a_relion_project(self):
        proj = RelionProject()
        with self.assertRaises(ValueError):
            proj.check_for_existing_project()

    def test_initilize_project(self):
        proj = RelionProject()
        assert proj.start_new_project()
        assert os.path.isfile("default_pipeline.star")

    def test_initilize_project_fail_pipeline_already_exists(self):
        os.system("touch default_pipeline.star")
        proj = RelionProject()
        with self.assertRaises(ValueError):
            proj.start_new_project()

    def test_initialize_existing_project(self):
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        proj = RelionProject(pipeline_name="short_full")
        proj.initialize_existing_project()
        proc_names = [x.name for x in proj.pipeline.process_list]
        node_names = [x.name for x in proj.pipeline.node_list]
        expected_procs = [
            "Import/job001/",
            "MotionCorr/job002/",
            "CtfFind/job003/",
            "AutoPick/job004/",
            "Extract/job005/",
            "Class2D/job006/",
            "Select/job007/",
            "InitialModel/job008/",
            "Class3D/job009/",
            "Refine3D/job010/",
            "MultiBody/job011/",
            "CtfRefine/job012/",
            "MaskCreate/job013/",
            "Polish/job014/",
            "JoinStar/job015/",
            "Subtract/job016/",
            "PostProcess/job017/",
            "External/job018/",
            "LocalRes/job019/",
        ]
        expected_nodes = [
            "Import/job001/movies.star",
            "MotionCorr/job002/corrected_micrographs.star",
            "MotionCorr/job002/logfile.pdf",
            "CtfFind/job003/micrographs_ctf.star",
            "CtfFind/job003/logfile.pdf",
            "AutoPick/job004/coords_suffix_autopick.star",
            "AutoPick/job004/logfile.pdf",
            "Extract/job005/particles.star",
            "Class2D/job006/run_it025_data.star",
            "Class2D/job006/run_it025_model.star",
            "Select/job007/selected_particles.star",
            "InitialModel/job008/run_it150_class001.mrc",
            "InitialModel/job008/run_it150_class002.mrc",
            "InitialModel/job008/run_it150_class001_data.star",
            "InitialModel/job008/run_it150_class002_data.star",
            "InitialModel/job008/run_it150_class001_model.star",
            "InitialModel/job008/run_it150_class001_model.star",
            "Class3D/job009/run_it025_class001.mrc",
            "Class3D/job009/run_it025_class002.mrc",
            "Class3D/job009/run_it025_class003.mrc",
            "Class3D/job009/run_it025_data.star",
            "Class3D/job009/run_it025_model.star",
            "Refine3D/job010/run_data.star",
            "Refine3D/job010/run_model.star",
            "Refine3D/job010/run_class001.mrc",
            "Refine3D/job010/run_class001_half1_unfil.mrc",
            "MultiBody/job011/run_class001_half1_unfil.mrc",
            "MultiBody/job011/run_class002_half1_unfil.mrc",
            "CtfRefine/job012/logfile.pdf",
            "CtfRefine/job012/particles_ctf_refine.star",
            "MaskCreate/job013/mask.mrc",
            "Polish/job014/opt_params_all_groups.txt",
            "Polish/job014/logfile.pdf",
            "Polish/job014/shiny.star",
            "JoinStar/job015/join_particles.star",
            "Subtract/job016/particles_subtract.star",
            "PostProcess/job017/logfile.pdf",
            "PostProcess/job017/postprocess.star",
            "LocalRes/job019/relion_locres_filtered.mrc",
            "LocalRes/job019/relion_locres.mrc",
        ]
        assert node_names == expected_nodes
        assert proc_names == expected_procs

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_cleanup_1job(self):
        outfiles = generic_tests.make_shortpipe_filestructure("MotionCorr")
        assert len(outfiles["MotionCorr"]) == 1017

        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        proj = RelionProject(pipeline_name="short_full")
        assert proj

        files = glob("MotionCorr/job002/**/*", recursive=True)
        procname = "MotionCorr"
        assert len(files) - 1 == len(outfiles[procname])

        proj.run_cleanup(["MotionCorr/job002/"], False)

        del_exts = ["com", "out", "err", "log"]
        removed, kept = [], []
        excluded = [
            "MotionCorr/job002/run.out",
            "MotionCorr/job002/run.err",
            "MotionCorr/job002/RELION_JOB_EXIT_SUCCESS",
        ]
        for f in outfiles[procname]:
            if f not in excluded:
                if f.split(".")[1] in del_exts:
                    removed.append(f)
                else:
                    kept.append(f)

        files = glob("MotionCorr/job002/**/*", recursive=True)
        for f in kept:
            assert f in files, f
        for f in removed:
            assert f not in files, f

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_cleanup_1job_harsh(self):
        outfiles = generic_tests.make_shortpipe_filestructure("MotionCorr")
        assert len(outfiles["MotionCorr"]) == 1017

        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )

        proj = RelionProject(pipeline_name="short_full")
        assert proj

        files = glob("MotionCorr/job002/**/*", recursive=True)
        assert len(files) - 1 == len(outfiles["MotionCorr"])
        assert os.path.isdir("MotionCorr/job002/Raw_data")

        proj.run_cleanup(["MotionCorr/job002/"], True)

        assert not os.path.isdir("MotionCorr/job002/Raw_data")

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_clean_up_multiple_jobs(self):
        outfiles = generic_tests.make_shortpipe_filestructure(
            ["MotionCorr", "AutoPick"]
        )
        assert len(outfiles["AutoPick"]) == 209
        assert len(outfiles["MotionCorr"]) == 1017

        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        proj = RelionProject(pipeline_name="short_full")
        assert proj

        mc_files = glob("MotionCorr/job002/**/*", recursive=True)
        assert len(mc_files) - 1 == len(outfiles["MotionCorr"])

        ap_files = glob("AutoPick/job004/**/*", recursive=True)
        assert len(ap_files) - 1 == len(outfiles["AutoPick"])

        ap_globlist = ["AutoPick/job004/Raw_data/*.spi"]
        ap_del_files = []
        for f in ap_globlist:
            ap_del_files += glob(f)

        proj.run_cleanup(["MotionCorr/job002/", "AutoPick/job004/"], False)

        del_exts = ["com", "out", "err", "log"]
        removed, kept = [], []
        excluded = [
            "MotionCorr/job002/run.out",
            "MotionCorr/job002/run.err",
            "MotionCorr/job002/RELION_JOB_EXIT_SUCCESS",
        ]
        for f in outfiles["MotionCorr"]:
            if f not in excluded:
                if f.split(".")[1] in del_exts:
                    removed.append(f)
                else:
                    kept.append(f)

        ap_files = glob("MotionCorr/job002/**/*", recursive=True)
        for f in kept:
            assert f in ap_files, f
        for f in removed:
            assert f not in ap_files, f

        ap_removed, ap_kept = [], []
        for f in outfiles["AutoPick"]:
            if f in ap_del_files:
                ap_removed.append(f)
            else:
                ap_kept.append(f)
        ap_files = glob("AutoPick/job004/**/*", recursive=True)

        for f in ap_kept:
            assert f in ap_files, f
        for f in ap_removed:
            assert f not in ap_files, f

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_cleanup_alljobs(self):
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )

        proj = RelionProject(pipeline_name="short_full")
        proj.initialize_existing_project()

        generic_tests.make_shortpipe_filestructure("all")

        del_files = {
            "Import": [],
            "MotionCorr": [
                "/job002/Raw_data/*.com",
                "/job002/Raw_data/*.err",
                "/job002/Raw_data/*.out",
                "/job002/Raw_data/*.log",
            ],
            "CtfFind": [
                "/job003/gctf*.out",
                "/job003/gctf*.err",
                "/job003/Raw_data/*",
            ],
            "AutoPick": ["/job004/Raw_data/*.spi"],
            "Extract": ["/job005/Raw_data/*_extract.star"],
            "Class2D": ["/job006/run_it*"],
            "Select": [],
            "InitialModel": ["/job008/run_it*"],
            "Class3D": ["/job009/run_it*"],
            "Refine3D": ["/job010/run_it*"],
            "MultiBody": ["/job011/run_it*"],
            "CtfRefine": [
                "/job012/Raw_data/*_wAcc.mrc",
                "/job012/Raw_data/*_xyAcc_real.mrc",
                "/job012/Raw_data/*_xyAcc_imag.mrc",
            ],
            "MaskCreate": [],
            "Polish": [
                "/job014/Raw_data/*_FCC_cc.mrc",
                "/job014/Raw_data/*_FCC_w0.mrc",
                "/job014/Raw_data/*_FCC_w1.mrc",
            ],
            "JoinStar": [],
            "Subtract": [],
            "External": [],
            "PostProcess": ["/job017/*masked.mrc"],
            "LocalRes": [],
        }

        exclude_files = {
            "Import": [],
            "MotionCorr": [],
            "CtfFind": [],
            "AutoPick": [],
            "Extract": [],
            "Class2d": [
                "Class2D/job006/run_it025_data.star",
                "Class2D/job006/run_it025_sampling.star",
                "Class2D/job006/run_it025_model.star",
                "Class2D/job006/run_it025_optimiser.star",
                "Class2D/job006/run_it025_classes.mrcs",
            ],
            "Select": [],
            "InitialModel": [
                "InitialModel/job008/run_it150_data.star",
                "InitialModel/job008/run_it150_sampling.star",
                "InitialModel/job008/run_it150_model.star",
                "InitialModel/job008/run_it150_optimiser.star",
                "InitialModel/job008/run_it150_class001.mrc",
                "InitialModel/job008/run_it150_grad001.mrc",
                "InitialModel/job008/run_it150_class002.mrc",
                "InitialModel/job008/run_it150_grad002.mrc",
            ],
            "Class3D": [
                "Class3D/job009/run_it025_class001.mrc",
                "Class3D/job009/run_it025_class001_angdist.bild",
                "Class3D/job009/run_it025_class002.mrc",
                "Class3D/job009/run_it025_class002_angdist.bild",
                "Class3D/job009/run_it025_class003.mrc",
                "Class3D/job009/run_it025_class003_angdist.bild",
                "Class3D/job009/run_it025_sampling.star",
                "Class3D/job009/run_it025_data.star",
                "Class3D/job009/run_it025_model.star",
                "Class3D/job009/run_it025_optimiser.star",
            ],
            "Refine3D": [
                "Refine3D/job010/run_it016_half1_class001.mrc",
                "Refine3D/job010/run_it016_half1_class001_angdist.bild",
                "Refine3D/job010/run_it016_half1_model.star",
                "Refine3D/job010/run_it016_half2_class001.mrc",
                "Refine3D/job010/run_it016_half2_class001_angdist.bild",
                "Refine3D/job010/run_it016_half2_model.star",
                "Refine3D/job010/run_it016_sampling.star",
                "Refine3D/job010/run_it016_data.star",
                "Refine3D/job010/run_it016_optimiser.star",
            ],
            "MultiBody": [
                "MultiBody/job011/run_it012_data.star",
                "MultiBody/job011/run_it012_half1_body001_angdist.bild",
                "MultiBody/job011/run_it012_half1_body001.mrc",
                "MultiBody/job011/run_it012_half1_body002_angdist.bild",
                "MultiBody/job011/run_it012_half1_body002.mrc",
                "MultiBody/job011/run_it012_half1_model.star",
                "MultiBody/job011/run_it012_half2_body001_angdist.bild",
                "MultiBody/job011/run_it012_half2_body001.mrc",
                "MultiBody/job011/run_it012_half2_body002_angdist.bild",
                "MultiBody/job011/run_it012_half2_body002.mrc",
                "MultiBody/job011/run_it012_half2_model.star",
            ],
            "CtfRefine": [],
            "MaskCreate": [],
            "Polish": [],
            "JoinStar": [],
            "Subtract": [],
            "External": [],
            "LocalRes": [],
        }

        files = list()
        for search_string in del_files:
            files += glob("{}/*/**/*".format(search_string), recursive=True)

        delete_list = list()
        for f in del_files:
            for search_string in del_files[f]:
                if len(search_string) > 1:
                    add = glob(f + search_string)
                    delete_list += add

        for f in exclude_files:
            for ff in exclude_files[f]:
                delete_list.remove(ff)

        proj.cleanup_all(False)

        # sort the files
        dirnames = [
            "Import/job001",
            "MotionCorr/job002",
            "MotionCorr/job002/Raw_data",
            "CtfFind/job003",
            "CtfFind/job003/Raw_data",
            "AutoPick/job004/Raw_data",
            "Extract/job005/Raw_data",
            "Class2D/job006",
            "Select/job007",
            "InitialModel/job008",
            "Class3D/job009",
            "Refine3D/job010",
            "MultiBody/job011",
            "CtfRefine/job012/Raw_data",
            "MaskCreate/job013",
            "Polish/job014/Raw_data",
            "JoinStar/job015",
            "Subtract/job016",
            "External/job017",
            "PostProcess/job018",
            "LocalRes/job019",
        ]
        removed, kept = [], []
        for f in files:
            if f in delete_list:
                removed.append(f)
            else:
                if f not in dirnames:
                    kept.append(f)

        # check they are all in the right place
        files2 = list()
        for search_string in del_files:
            files2 += glob("{}/*/**/*".format(search_string), recursive=True)
        trash = glob("Trash/*/**/*", recursive=True)
        for f in kept:
            assert f in files2, f
        for f in removed:
            assert f not in files2, f
            assert "Trash/" + f in trash, "Trash/" + f

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_cleanup_alljobs_harsh(self):

        generic_tests.make_shortpipe_filestructure("all")

        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        proj = RelionProject(pipeline_name="short_full")
        assert proj

        del_files = {
            "Import": [],
            "MotionCorr": ["/job002/Raw_data/*"],
            "CtfFind": [
                "/job003/gctf*.out",
                "/job003/gctf*.err",
                "/job003/Raw_data/*",
            ],
            "AutoPick": ["/job004/Raw_data/*.spi"],
            "Extract": ["/job005/Raw_data/*"],
            "Class2D": ["/job006/run_it*"],
            "Select": [],
            "InitialModel": ["/job008/run_it*"],
            "Class3D": ["/job009/run_it*"],
            "Refine3D": ["/job010/run_it*"],
            "MultiBody": ["/job011/run_it*", "/job011/analyse_component*_bin*.mrc"],
            "CtfRefine": [
                "/job012/Raw_data/*_wAcc.mrc",
                "/job012/Raw_data/*_xyAcc_real.mrc",
                "/job012/Raw_data/*_xyAcc_imag.mrc",
            ],
            "MaskCreate": [],
            "Polish": [
                "/job014/Raw_data/*_FCC_cc.mrc",
                "/job014/Raw_data/*_FCC_w0.mrc",
                "/job014/Raw_data/*_FCC_w1.mrc",
                "/job014/Raw_data/*shiny.star",
                "/job014/Raw_data/*shiny.mrcs",
            ],
            "JoinStar": [],
            "Subtract": ["/job016/subtracted_*"],
            "External": [],
            "PostProcess": ["/job017/*masked.mrc"],
            "LocalRes": [],
        }

        exclude_files = {
            "Import": [],
            "MotionCorr": [],
            "CtfFind": [],
            "AutoPick": [],
            "Extract": [],
            "Class2d": [
                "Class2D/job006/run_it025_data.star",
                "Class2D/job006/run_it025_sampling.star",
                "Class2D/job006/run_it025_model.star",
                "Class2D/job006/run_it025_optimiser.star",
                "Class2D/job006/run_it025_classes.mrcs",
            ],
            "Select": [],
            "InitialModel": [
                "InitialModel/job008/run_it150_data.star",
                "InitialModel/job008/run_it150_sampling.star",
                "InitialModel/job008/run_it150_model.star",
                "InitialModel/job008/run_it150_optimiser.star",
                "InitialModel/job008/run_it150_class001.mrc",
                "InitialModel/job008/run_it150_grad001.mrc",
                "InitialModel/job008/run_it150_class002.mrc",
                "InitialModel/job008/run_it150_grad002.mrc",
            ],
            "Class3D": [
                "Class3D/job009/run_it025_class001.mrc",
                "Class3D/job009/run_it025_class001_angdist.bild",
                "Class3D/job009/run_it025_class002.mrc",
                "Class3D/job009/run_it025_class002_angdist.bild",
                "Class3D/job009/run_it025_class003.mrc",
                "Class3D/job009/run_it025_class003_angdist.bild",
                "Class3D/job009/run_it025_sampling.star",
                "Class3D/job009/run_it025_data.star",
                "Class3D/job009/run_it025_model.star",
                "Class3D/job009/run_it025_optimiser.star",
            ],
            "Refine3D": [
                "Refine3D/job010/run_it016_half1_class001.mrc",
                "Refine3D/job010/run_it016_half1_class001_angdist.bild",
                "Refine3D/job010/run_it016_half1_model.star",
                "Refine3D/job010/run_it016_half2_class001.mrc",
                "Refine3D/job010/run_it016_half2_class001_angdist.bild",
                "Refine3D/job010/run_it016_half2_model.star",
                "Refine3D/job010/run_it016_sampling.star",
                "Refine3D/job010/run_it016_data.star",
                "Refine3D/job010/run_it016_optimiser.star",
            ],
            "MultiBody": [
                "MultiBody/job011/run_it012_data.star",
                "MultiBody/job011/run_it012_half1_body001_angdist.bild",
                "MultiBody/job011/run_it012_half1_body001.mrc",
                "MultiBody/job011/run_it012_half1_body002_angdist.bild",
                "MultiBody/job011/run_it012_half1_body002.mrc",
                "MultiBody/job011/run_it012_half1_model.star",
                "MultiBody/job011/run_it012_half2_body001_angdist.bild",
                "MultiBody/job011/run_it012_half2_body001.mrc",
                "MultiBody/job011/run_it012_half2_body002_angdist.bild",
                "MultiBody/job011/run_it012_half2_body002.mrc",
                "MultiBody/job011/run_it012_half2_model.star",
            ],
            "CtfRefine": [],
            "MaskCreate": [],
            "Polish": [],
            "JoinStar": [],
            "Subtract": [],
            "External": [],
            "LocalRes": [],
        }

        files = list()
        for search_string in del_files:
            files += glob("{}/*/**/*".format(search_string), recursive=True)

        delete_list = list()
        for f in del_files:
            for search_string in del_files[f]:
                if len(search_string) > 1:
                    add = glob(f + search_string)
                    delete_list += add

        for f in exclude_files:
            for ff in exclude_files[f]:
                delete_list.remove(ff)

        proj.cleanup_all(True)

        # sort the files
        dirnames = [
            "Import/job001",
            "MotionCorr/job002",
            "MotionCorr/job002/Raw_data",
            "CtfFind/job003",
            "CtfFind/job003/Raw_data",
            "AutoPick/job004/Raw_data",
            "Extract/job005/Raw_data",
            "Class2D/job006",
            "Select/job007",
            "InitialModel/job008",
            "Class3D/job009",
            "Refine3D/job010",
            "MultiBody/job011",
            "CtfRefine/job012/Raw_data",
            "MaskCreate/job013",
            "Polish/job014/Raw_data",
            "JoinStar/job015",
            "Subtract/job016",
            "External/job017",
            "PostProcess/job018",
            "LocalRes/job019",
        ]
        removed, kept = [], []
        for f in files:
            if f in delete_list:
                removed.append(f)
            else:
                if f not in dirnames:
                    kept.append(f)

        # check they are all in the right place
        files2 = list()
        for search_string in del_files:
            files2 += glob("{}/*/**/*".format(search_string), recursive=True)
        trash = glob("Trash/*/**/*", recursive=True)
        for f in kept:
            assert f in files2, f
        for f in removed:
            assert f not in files2, f
            assert "Trash/" + f in trash, "Trash/" + f

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_delete_job(self):
        # copy in the pipeline
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_cl2d_del_pipeline.star"
            ),
            self.test_dir,
        )
        assert os.path.isfile("short_cl2d_del_pipeline.star")

        # initialize the project
        proj = RelionProject(pipeline_name="short_cl2d_del")

        # make the files like the project has been run
        fdirs = {
            "Class2D/job008": "Class2D/LoG_based",
            "Extract/job007": "Extract/LoG_based",
        }
        for fdir in fdirs:
            os.system("mkdir -p " + fdir)
            os.symlink(os.path.abspath(fdir), os.path.join(self.test_dir, fdirs[fdir]))
            assert os.path.isdir(fdir)
            assert os.path.islink(fdirs[fdir])

        cl2d_files = [
            "_data.star",
            "_model.star",
            "_optimiser.star",
        ]
        file_list = list()
        for i in range(0, 26):
            for f in cl2d_files:
                ff = "Class2D/job008/run_it{0:03d}{1}".format(i, f)
                os.system("touch " + ff)
                assert os.path.isfile(ff), ff
                file_list.append(ff)

        cl2d_other_files = [
            "default_pipeline.star",
            "job_pipeline.star",
            "run.job",
            "RELION_JOB_EXIT_SUCCESS",
            "job.star",
            "note.txt",
            "run.err",
            "run.out",
        ]

        for f in cl2d_other_files:
            ff = "Class2D/job008/" + f
            os.system("touch " + ff)
            assert os.path.isfile(ff)
            file_list.append(ff)

        extract_files = [
            "default_pipeline.star",
            "job_pipeline.star",
            "particles.star",
            "run.job",
            "RELION_JOB_EXIT_SUCCESS",
            "job.star",
            "note.txt",
            "run.err",
            "run.out",
        ]

        for f in extract_files:
            ff = "Extract/job007/" + f
            os.system("touch " + ff)
            assert os.path.isfile(ff)
            file_list.append(ff)

        moviedir = "Extract/job007/Movies"
        os.system("mkdir " + moviedir)
        assert os.path.isdir("Extract/job007/Movies")

        for i in range(1, 11):
            f = moviedir + "/movie_parts{:03d}.mrcs".format(i)
            os.system("touch " + f)
            assert os.path.isfile(f)
            file_list.append(f)

        # make the .Nodes files
        nodesfiles = [
            ".Nodes/3/Extract/job007/particles.star",
            ".Nodes/8/Class2D/job008/run_it025_model.star",
            ".Nodes/3/Class2D/job008/run_it025_data.star",
        ]
        for f in nodesfiles:
            subprocess.run(["mkdir", "-p", os.path.dirname(f)])
            subprocess.run(["touch", f])
            assert os.path.isfile(f)

        # delete the extract job
        proj.delete_job("Extract/job007/")

        with open("short_cl2d_del_pipeline.star") as written_pipe:
            written = written_pipe.read()

        removed_lines = [
            "Extract/job007/ Extract/LoG_based/            5            2",
            "Class2D/job008/ Class2D/LoG_based/            8            2",
            "Extract/job007/particles.star            3",
            "Class2D/job008/run_it025_data.star        3",
            "Class2D/job008/run_it025_model.star            8",
            "Extract/job007/particles.star Class2D/job008/",
            "Extract/job007/ Extract/job007/particles.star",
            "Class2D/job008/ Class2D/job008/run_it025_model.star",
            "Class2D/job008/ Class2D/job008/run_it025_data.star",
        ]

        for removed_line in removed_lines:
            assert removed_line not in written, removed_line

        for f in file_list:
            assert not os.path.isfile(f), f
            trashname = "Trash/" + f
            assert os.path.isfile(trashname), trashname

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_delete_job_norecursive(self):
        # copy over files
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_cl2d_del_pipeline.star"
            ),
            self.test_dir,
        )
        assert os.path.isfile("short_cl2d_del_pipeline.star")

        # initiallize the project
        proj = RelionProject(pipeline_name="short_cl2d_del")

        # make the files like the project has been run
        fdirs = {
            "Class2D/job008": "Class2D/LoG_based",
            "Extract/job007": "Extract/LoG_based",
        }
        for fdir in fdirs:
            os.system("mkdir -p " + fdir)
            os.symlink(os.path.abspath(fdir), os.path.join(self.test_dir, fdirs[fdir]))
            assert os.path.isdir(fdir)
            assert os.path.islink(fdirs[fdir])

        cl2d_files = [
            "_data.star",
            "_model.star",
            "_optimiser.star",
        ]
        file_list = list()
        for i in range(0, 26):
            for f in cl2d_files:
                ff = "Class2D/job008/run_it{0:03d}{1}".format(i, f)
                os.system("touch " + ff)
                assert os.path.isfile(ff), ff
                file_list.append(ff)

        cl2d_other_files = [
            "default_pipeline.star",
            "job_pipeline.star",
            "run.job",
            "RELION_JOB_EXIT_SUCCESS",
            "job.star",
            "note.txt",
            "run.err",
            "run.out",
        ]

        for f in cl2d_other_files:
            ff = "Class2D/job008/" + f
            os.system("touch " + ff)
            assert os.path.isfile(ff)
            file_list.append(ff)

        extract_files = [
            "default_pipeline.star",
            "job_pipeline.star",
            "particles.star",
            "run.job",
            "RELION_JOB_EXIT_SUCCESS",
            "job.star",
            "note.txt",
            "run.err",
            "run.out",
        ]

        for f in extract_files:
            ff = "Extract/job007/" + f
            os.system("touch " + ff)
            assert os.path.isfile(ff)
            file_list.append(ff)

        moviedir = "Extract/job007/Movies"
        os.system("mkdir " + moviedir)
        assert os.path.isdir("Extract/job007/Movies")

        for i in range(1, 11):
            f = moviedir + "/movie_parts{:03d}.mrcs".format(i)
            os.system("touch " + f)
            assert os.path.isfile(f)
            file_list.append(f)

        # make the .Nodes files
        nodesfile = ".Nodes/3/Extract/job007/particles.star"
        subprocess.run(["mkdir", "-p", os.path.dirname(nodesfile)])
        subprocess.run(["touch", nodesfile])
        assert os.path.isfile(nodesfile)

        # delete the Extract job
        proj.delete_job("Extract/job007/", no_recursive=True)

        # check lines have been removed from the pipeline
        with open("short_cl2d_del_pipeline.star") as written_pipe:
            written = written_pipe.read()

        removed_lines = [
            "Extract/job007/ Extract/LoG_based/            5            2",
            "Extract/job007/particles.star            3",
            "Extract/job007/particles.star Class2D/job008/",
            "Extract/job007/ Extract/job007/particles.star",
        ]

        for removed_line in removed_lines:
            assert removed_line not in written, removed_line

        # check the files have been removed
        for f in file_list:
            if f.startswith("Extract/"):
                assert not os.path.isfile(f), f
                trashname = "Trash/" + f
                assert os.path.isfile(trashname), trashname
            elif f.startswith("Class2D/"):
                assert os.path.isfile(f), f
                trashname = "Trash/" + f
                assert not os.path.isfile(trashname), trashname

        # check the .Nodes file has been removed
        assert not os.path.isfile(nodesfile)
        assert not os.path.isdir(os.path.dirname(nodesfile))

    def make_undelete_file_structure(self):
        dirs = [
            "Class2D/job008",
            "Extract/job007",
            "Trash",
        ]

        for d in dirs:
            os.system("mkdir -p " + d)
            assert os.path.isdir(d), d

        common_files = [
            "run.out",
            "run.err",
            "note.txt",
            "run.job",
            "default_pipeline.star",
            "RELION_JOB_EXIT_SUCCESS",
        ]

        outfiles = list()
        for d in dirs[:-1]:
            for f in common_files:
                os.system("touch " + d + "/" + f)
                assert os.path.isfile(d + "/" + f), d + "/" + f
                outfiles.append(d + "/" + f)

        shutil.copy(
            os.path.join(
                self.pipeliner_test_data,
                "Pipelines/for_undelete_cl2d_job_pipeline.star",
            ),
            os.path.join(self.test_dir, "Class2D/job008/job_pipeline.star"),
        )
        outfiles.append("Class2D/job008/job_pipeline.star")

        shutil.copy(
            os.path.join(
                self.pipeliner_test_data,
                "Pipelines/for_undelete_extract_job_pipeline.star",
            ),
            os.path.join(self.test_dir, "Extract/job007/job_pipeline.star"),
        )
        outfiles.append("Extract/job007/job_pipeline.star")

        os.system("touch Extract/job007/particles.star")
        assert os.path.isfile("Extract/job007/particles.star")
        outfiles.append("Extract/job007/particles.star")

        os.system("mkdir Extract/job007/Movies")
        assert os.path.isdir("Extract/job007/Movies")

        # make particles files
        for i in range(1, 11):
            f = "Extract/job007/Movies/movie_{:03d}.mrcs".format(i)
            os.system("touch " + f)
            assert os.path.isfile(f), f
            outfiles.append(f)

        # make class2d files
        cl2d_files = ["_data.star", "_model.star", "_optimiser.star"]
        for i in range(1, 26):
            for f in cl2d_files:
                ff = "Class2D/job008/run_it{:03d}{}".format(i, f)
                os.system("touch " + ff)
                assert os.path.isfile(ff)
                outfiles.append(ff)

        os.system("mv Class2D Trash/Class2D")
        os.system("mv Extract Trash/Extract")

        assert not os.path.isdir("Class2D")
        assert not os.path.isdir("Extract")
        assert os.path.isdir("Trash/Class2D")
        assert os.path.isdir("Trash/Extract")

        return outfiles

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_undelete_process_with_parents(self):
        outfiles = self.make_undelete_file_structure()

        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/for_undelete_deleted_pipeline.star"
            ),
            self.test_dir,
        )

        proj = RelionProject(pipeline_name="for_undelete_deleted")

        restored_lines = [
            "Extract/job007/ Extract/LoG_based/            5            2",
            "CtfFind/job003/micrographs_ctf.star Extract/job007/",
            "AutoPick/job006/coords_suffix_autopick.star Extract/job007/",
            "Extract/job007/ Extract/job007/particles.star",
            "Class2D/job008/run_it025_model.star            8",
            "Class2D/job008/run_it025_data.star            3",
            "Extract/job007/particles.star Class2D/job008/",
            "Class2D/job008/ Class2D/job008/run_it025_model.star",
            "Class2D/job008/ Class2D/job008/run_it025_data.star",
        ]

        with open("for_undelete_deleted_pipeline.star") as original_pipe:
            original = original_pipe.read()

        for line in restored_lines:
            assert line not in original, line

        proj.undelete_job("Class2D/job008/")

        with open("for_undelete_deleted_pipeline.star") as edited_pipe:
            wrote = edited_pipe.read()

        for line in restored_lines:
            assert line in wrote, line

        for f in outfiles:
            assert os.path.isfile(f), f

        assert os.path.islink("Extract/LoG_based")
        assert os.path.islink("Class2D/Log_based")

    def test_add_alias(self):
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )

        os.system("mkdir -p Import/job001")
        proj = RelionProject(pipeline_name="short_full")
        proj.initialize_existing_project()
        assert proj.pipeline.process_list[0].alias is None

        proj.add_alias("Import/job001/", "NEW_ALIAS")
        assert proj.pipeline.process_list[0].alias == "Import/NEW_ALIAS/"

    def test_overwrite_alias(self):
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )

        os.system("mkdir -p Import/job001")
        proj = RelionProject(pipeline_name="short_full")
        proj.initialize_existing_project()
        assert proj.pipeline.process_list[0].alias is None

        proj.add_alias("Import/job001/", "NEW_ALIAS")
        assert proj.pipeline.process_list[0].alias == "Import/NEW_ALIAS/"

        proj.add_alias("Import/job001/", "NEW_ALIAS_PART_DEUX")
        assert proj.pipeline.process_list[0].alias == "Import/NEW_ALIAS_PART_DEUX/"

    @unittest.skipUnless(do_full, "Slow test: Only run in full unittest")
    def test_update_status(self):
        """ Go through the entire short pipeline,
        mark every job failed, then aborted"""
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )

        generic_tests.make_shortpipe_filestructure("all")
        proj = RelionProject(pipeline_name="short_full")
        proj.initialize_existing_project()

        for proc in proj.pipeline.process_list:
            assert proc.status == 2
        for proc in proj.pipeline.process_list:
            proj.update_job_status(proc.name, True, False)
            newproc = proj.pipeline.find_process(proc.name)
            assert newproc.status == 3
            assert os.path.isfile(os.path.join(newproc.name, "RELION_JOB_EXIT_FAILED"))
        for proc in proj.pipeline.process_list:
            proj.pipeline.mark_as_finished(proc, False, False, is_running=True)
            proj.update_job_status(proc.name, False, True)
            newproc = proj.pipeline.find_process(proc.name)
            assert newproc.status == 4
            assert os.path.isfile(os.path.join(newproc.name, "RELION_JOB_EXIT_ABORTED"))

        for proc in proj.pipeline.process_list:
            proj.update_job_status(proc.name, False, False)
            newproc = proj.pipeline.find_process(proc.name)
            assert newproc.status == 2

    def test_run_job_from_runjob(self):
        # Prepare the directory structure as if Import jobs have been run
        #
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data,
                "JobFiles/PostProcess/postprocess_manage_test.job",
            ),
            self.test_dir,
        )
        halfmap_import_dir = "Import/job001/"
        os.makedirs(halfmap_import_dir)
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "3488_run_half1_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "3488_run_half2_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        mask_import_dir = "MaskCreate/job013/"
        os.makedirs(mask_import_dir)
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "emd_3488_mask.mrc"), mask_import_dir
        )

        proj = RelionProject(pipeline_name="short_full")
        proj.initialize_existing_project()
        proj.run_job("postprocess_manage_test.job")
        # Wait for job to finish, otherwise test fails. Shouldn't be necessary...
        time.sleep(1)

        added_lines = [
            "PostProcess/job020/postprocess.mrc           11",
            "PostProcess/job020/postprocess_masked.mrc           11",
            "PostProcess/job020/postprocess.star           14",
            "PostProcess/job020/logfile.pdf           13",
            "PostProcess/job020/       None           15            2",
            "MaskCreate/job013/emd_3488_mask.mrc PostProcess/job020/",
            "Import/job001/3488_run_half1_class001_unfil.mrc PostProcess/job020/",
            "PostProcess/job020/ PostProcess/job020/postprocess.mrc",
            "PostProcess/job020/ PostProcess/job020/postprocess_masked.mrc",
            "PostProcess/job020/ PostProcess/job020/postprocess.star",
            "PostProcess/job020/ PostProcess/job020/logfile.pdf",
        ]
        with open("short_full_pipeline.star") as pipe:
            pipeline_data = pipe.read()
        for line in added_lines:
            assert line in pipeline_data, line

        job_dir = "PostProcess/job020/"
        assert os.path.isdir(job_dir)

        # Test for output files
        assert os.path.isdir(job_dir)
        assert os.path.isfile(os.path.join(job_dir, "run.out"))
        assert os.path.isfile(os.path.join(job_dir, "run.err"))
        assert os.path.isfile(os.path.join(job_dir, "postprocess.mrc"))
        assert os.path.isfile(os.path.join(job_dir, "postprocess_masked.mrc"))
        assert os.path.isfile(os.path.join(job_dir, "logfile.pdf"))

    def test_schedule_job_from_runjob(self):
        # Prepare the directory structure as if Import jobs have been run
        #
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data,
                "JobFiles/PostProcess/postprocess_manage_test.job",
            ),
            self.test_dir,
        )
        halfmap_import_dir = "Import/job001/"
        os.makedirs(halfmap_import_dir)
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "3488_run_half1_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "3488_run_half2_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        mask_import_dir = "MaskCreate/job013/"
        os.makedirs(mask_import_dir)
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "emd_3488_mask.mrc"), mask_import_dir
        )

        proj = RelionProject(pipeline_name="short_full")
        proj.initialize_existing_project()
        proj.schedule_job("postprocess_manage_test.job")
        # Wait for job to finish, otherwise test fails. Shouldn't be necessary...
        time.sleep(1)

        added_lines = [
            "PostProcess/job020/postprocess.mrc           11",
            "PostProcess/job020/postprocess_masked.mrc           11",
            "PostProcess/job020/postprocess.star           14",
            "PostProcess/job020/logfile.pdf           13",
            "PostProcess/job020/       None           15            1",
            "MaskCreate/job013/emd_3488_mask.mrc PostProcess/job020/",
            "Import/job001/3488_run_half1_class001_unfil.mrc PostProcess/job020/",
            "PostProcess/job020/ PostProcess/job020/postprocess.mrc",
            "PostProcess/job020/ PostProcess/job020/postprocess_masked.mrc",
            "PostProcess/job020/ PostProcess/job020/postprocess.star",
            "PostProcess/job020/ PostProcess/job020/logfile.pdf",
        ]
        with open("short_full_pipeline.star") as pipe:
            pipeline_data = pipe.read()
        for line in added_lines:
            assert line in pipeline_data, line

    def test_run_job_from_jobstar(self):
        # Prepare the directory structure as if Import jobs have been run
        #
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data,
                "JobFiles/PostProcess/postprocess_manage_job.star",
            ),
            self.test_dir,
        )
        halfmap_import_dir = "Import/job001/"
        os.makedirs(halfmap_import_dir)
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "3488_run_half1_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "3488_run_half2_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        mask_import_dir = "MaskCreate/job013/"
        os.makedirs(mask_import_dir)
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "emd_3488_mask.mrc"), mask_import_dir
        )

        proj = RelionProject(pipeline_name="short_full")
        proj.initialize_existing_project()
        proj.run_job("postprocess_manage_job.star")

        # Wait for job to finish.
        time.sleep(1)

        added_lines = [
            "PostProcess/job020/postprocess.mrc           11",
            "PostProcess/job020/postprocess_masked.mrc           11",
            "PostProcess/job020/postprocess.star           14",
            "PostProcess/job020/logfile.pdf           13",
            "PostProcess/job020/       None           15            2",
            "MaskCreate/job013/emd_3488_mask.mrc PostProcess/job020/",
            "Import/job001/3488_run_half1_class001_unfil.mrc PostProcess/job020/",
            "PostProcess/job020/ PostProcess/job020/postprocess.mrc",
            "PostProcess/job020/ PostProcess/job020/postprocess_masked.mrc",
            "PostProcess/job020/ PostProcess/job020/postprocess.star",
            "PostProcess/job020/ PostProcess/job020/logfile.pdf",
        ]
        with open("short_full_pipeline.star") as pipe:
            pipeline_data = pipe.read()
        for line in added_lines:
            assert line in pipeline_data, line

        job_dir = "PostProcess/job020/"
        assert os.path.isdir(job_dir)

        # Test for output files
        assert os.path.isdir(job_dir)
        assert os.path.isfile(os.path.join(job_dir, "run.out"))
        assert os.path.isfile(os.path.join(job_dir, "run.err"))
        assert os.path.isfile(os.path.join(job_dir, "postprocess.mrc"))
        assert os.path.isfile(os.path.join(job_dir, "postprocess_masked.mrc"))
        assert os.path.isfile(os.path.join(job_dir, "logfile.pdf"))

    def test_run_job_then_overwrite(self):
        # Prepare the directory structure as if Import jobs have been run
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data,
                "JobFiles/PostProcess/postprocess_manage_job.star",
            ),
            self.test_dir,
        )
        halfmap_import_dir = "Import/job001/"
        os.makedirs(halfmap_import_dir)
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "3488_run_half1_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "3488_run_half2_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        mask_import_dir = "MaskCreate/job013/"
        os.makedirs(mask_import_dir)
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "emd_3488_mask.mrc"), mask_import_dir
        )

        # initialize a project and run a job
        proj = RelionProject(pipeline_name="short_full")
        proj.initialize_existing_project()
        proj.run_job("postprocess_manage_job.star")

        # Wait for job to finish.
        time.sleep(1)

        added_lines = [
            "PostProcess/job020/postprocess.mrc           11",
            "PostProcess/job020/postprocess_masked.mrc           11",
            "PostProcess/job020/postprocess.star           14",
            "PostProcess/job020/logfile.pdf           13",
            "PostProcess/job020/       None           15            2",
            "MaskCreate/job013/emd_3488_mask.mrc PostProcess/job020/",
            "Import/job001/3488_run_half1_class001_unfil.mrc PostProcess/job020/",
            "PostProcess/job020/ PostProcess/job020/postprocess.mrc",
            "PostProcess/job020/ PostProcess/job020/postprocess_masked.mrc",
            "PostProcess/job020/ PostProcess/job020/postprocess.star",
            "PostProcess/job020/ PostProcess/job020/logfile.pdf",
        ]
        with open("short_full_pipeline.star") as pipe:
            pipeline_data = pipe.read()
        for line in added_lines:
            assert line in pipeline_data, line

        job_dir = "PostProcess/job020/"
        assert os.path.isdir(job_dir)

        # Test for output files
        assert os.path.isdir(job_dir)
        assert os.path.isfile(os.path.join(job_dir, "run.out"))
        assert os.path.isfile(os.path.join(job_dir, "run.err"))
        assert os.path.isfile(os.path.join(job_dir, "postprocess.mrc"))
        assert os.path.isfile(os.path.join(job_dir, "postprocess_masked.mrc"))
        assert os.path.isfile(os.path.join(job_dir, "logfile.pdf"))

        # rerun the job overwriting it
        proj.run_job("postprocess_manage_job.star", overwrite="PostProcess/job020/")

        # Wait for job to finish.
        time.sleep(1)

        with open("short_full_pipeline.star") as pipe:
            pipeline_data = pipe.read()
        for line in added_lines:
            assert line in pipeline_data, line

        job_dir = "PostProcess/job020/"
        assert os.path.isdir(job_dir)

        # Test for output files
        assert os.path.isdir(job_dir)
        assert os.path.isfile(os.path.join(job_dir, "run.out"))
        assert os.path.isfile(os.path.join(job_dir, "run.err"))
        assert os.path.isfile(os.path.join(job_dir, "postprocess.mrc"))
        assert os.path.isfile(os.path.join(job_dir, "postprocess_masked.mrc"))
        assert os.path.isfile(os.path.join(job_dir, "logfile.pdf"))

    def test_schedule_job_from_jobstar(self):
        # Prepare the directory structure as if Import jobs have been run
        #
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data,
                "JobFiles/PostProcess/postprocess_manage_job.star",
            ),
            self.test_dir,
        )
        halfmap_import_dir = "Import/job001/"
        os.makedirs(halfmap_import_dir)
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "3488_run_half1_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "3488_run_half2_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        mask_import_dir = "MaskCreate/job013/"
        os.makedirs(mask_import_dir)
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "emd_3488_mask.mrc"), mask_import_dir
        )

        proj = RelionProject(pipeline_name="short_full")
        proj.initialize_existing_project()
        proj.schedule_job("postprocess_manage_job.star")

        added_lines = [
            "PostProcess/job020/       None           15            1",
            "PostProcess/job020/postprocess.mrc           11",
            "PostProcess/job020/postprocess_masked.mrc           11",
            "PostProcess/job020/postprocess.star           14",
            "PostProcess/job020/logfile.pdf           13",
            "MaskCreate/job013/emd_3488_mask.mrc PostProcess/job020/",
            "Import/job001/3488_run_half1_class001_unfil.mrc PostProcess/job020/",
            "PostProcess/job020/ PostProcess/job020/postprocess.mrc",
            "PostProcess/job020/ PostProcess/job020/postprocess_masked.mrc",
            "PostProcess/job020/ PostProcess/job020/postprocess.star",
            "PostProcess/job020/ PostProcess/job020/logfile.pdf",
        ]
        with open("short_full_pipeline.star") as pipe:
            pipeline_data = pipe.read()
        for line in added_lines:
            assert line in pipeline_data, line

    def test_secedule_job_then_run(self):
        # Prepare the directory structure as if Import jobs have been run
        #
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data,
                "JobFiles/PostProcess/postprocess_manage_test.job",
            ),
            self.test_dir,
        )
        halfmap_import_dir = "Import/job001/"
        os.makedirs(halfmap_import_dir)
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "3488_run_half1_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "3488_run_half2_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        mask_import_dir = "MaskCreate/job013/"
        os.makedirs(mask_import_dir)
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "emd_3488_mask.mrc"), mask_import_dir
        )

        proj = RelionProject(pipeline_name="short_full")
        proj.initialize_existing_project()
        proj.run_job("postprocess_manage_test.job")
        # Wait for job to finish, otherwise test fails. Shouldn't be necessary...
        time.sleep(1)

        added_lines = [
            "PostProcess/job020/postprocess.mrc           11",
            "PostProcess/job020/postprocess_masked.mrc           11",
            "PostProcess/job020/postprocess.star           14",
            "PostProcess/job020/logfile.pdf           13",
            "PostProcess/job020/       None           15            2",
            "MaskCreate/job013/emd_3488_mask.mrc PostProcess/job020/",
            "Import/job001/3488_run_half1_class001_unfil.mrc PostProcess/job020/",
            "PostProcess/job020/ PostProcess/job020/postprocess.mrc",
            "PostProcess/job020/ PostProcess/job020/postprocess_masked.mrc",
            "PostProcess/job020/ PostProcess/job020/postprocess.star",
            "PostProcess/job020/ PostProcess/job020/logfile.pdf",
        ]
        with open("short_full_pipeline.star") as pipe:
            pipeline_data = pipe.read()
        for line in added_lines:
            assert line in pipeline_data, line

        job_dir = "PostProcess/job020/"
        assert os.path.isdir(job_dir)

        proj.run_schedule(
            fn_sched="schedule1",
            job_ids=["PostProcess/job020/"],
            nr_repeat=3,
            minutes_wait=0,
            minutes_wait_before=0,
            seconds_wait_after=1,
        )

        # Test for output files
        assert os.path.isdir(job_dir)
        assert os.path.isfile(os.path.join(job_dir, "run.out"))
        assert os.path.isfile(os.path.join(job_dir, "run.err"))
        assert os.path.isfile(os.path.join(job_dir, "postprocess.mrc"))
        assert os.path.isfile(os.path.join(job_dir, "postprocess_masked.mrc"))
        assert os.path.isfile(os.path.join(job_dir, "logfile.pdf"))

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_empty_trash(self):
        my_project = RelionProject()
        self.make_undelete_file_structure()
        trash_files = glob("Trash/*/*/*")
        assert len(trash_files) == 91
        my_project.empty_trash()
        trash_files = glob("Trash/*/*/*")
        assert len(trash_files) == 0

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_empty_trash_error_no_files(self):
        my_project = RelionProject()
        trash_files = glob("Trash/*/*/*")
        assert len(trash_files) == 0
        assert not my_project.empty_trash()

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_drawing_flowchart_upstream(self):
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        my_project = RelionProject(pipeline_name="short_full")
        results = my_project.draw_flowcharts(job="Refine3D/job010/", do_upstream=True)
        assert results == [True, False, False]

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_drawing_flowchart_downstream(self):
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        my_project = RelionProject(pipeline_name="short_full")
        results = my_project.draw_flowcharts(job="Refine3D/job010/", do_downstream=True)
        assert results == [False, True, False]

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_drawing_flowchart_full(self):
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        my_project = RelionProject(pipeline_name="short_full")
        results = my_project.draw_flowcharts(do_full=True)
        assert results == [False, False, True]

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_drawing_flowchart_all(self):
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        my_project = RelionProject(pipeline_name="short_full")
        results = my_project.draw_flowcharts(
            job="Refine3D/job010/", do_downstream=True, do_upstream=True, do_full=True
        )
        assert results == [True, True, True]

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_drawing_flowchart_error_no_job(self):
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        my_project = RelionProject(pipeline_name="short_full")
        results = my_project.draw_flowcharts(
            do_downstream=True, do_upstream=True, do_full=True
        )
        assert results == [False, False, True]

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_drawing_flowchart_error_no_job_nofull(self):
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        my_project = RelionProject(pipeline_name="short_full")
        results = my_project.draw_flowcharts(do_downstream=True, do_upstream=True,)
        assert results == [False, False, False]

    def test_stop_schedule_GUI_style(self):
        """if the schedule is made by the GUI the RUNNING_ file is empty
        and should be deleted"""
        # make the RUNNING_ file
        subprocess.run(["touch", "RUNNING_PIPELINER_default_empty"])
        assert os.path.isfile("RUNNING_PIPELINER_default_empty")

        # stop the schedule
        my_project = RelionProject(pipeline_name="default")
        my_project.stop_schedule("empty")

        # file should be gone
        assert not os.path.isfile("RUNNING_PIPELINER_default_empty")

    def test_stop_schedule_from_API_style(self):
        """if the schedule is made by the API the RUNNING_ file
        just has a list of jobs"""

        # make the RUNNING_ file and populate it
        subprocess.run(["touch", "RUNNING_PIPELINER_default_api"])
        with open("RUNNING_PIPELINER_default_api", "w") as f:
            f.write("PostProcess/job001/\n")
        assert os.path.isfile("RUNNING_PIPELINER_default_api")
        with open("RUNNING_PIPELINER_default_api") as f:
            runfile_data = f.readlines()
        assert runfile_data[0] == "PostProcess/job001/\n"

        # copy in the pipeline
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "Pipelines/running_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )

        # make the necesary project dirs
        os.makedirs("PostProcess/job001")

        # stop the schedule
        my_project = RelionProject(pipeline_name="default")
        my_project.stop_schedule("api")

        # RUNNING file should be gone and ABORTED file should appear
        assert not os.path.isfile("RUNNING_PIPELINER_default_api")
        assert os.path.isfile("PostProcess/job001/RELION_JOB_EXIT_ABORTED")

        # pipeline should be updated
        with open("default_pipeline.star") as f:
            pipeline_data = f.readlines()
        newline = "PostProcess/job001/       None           15            4 \n"
        oldline = "PostProcess/job001/       None           15            0 \n"

        assert newline in pipeline_data
        assert oldline not in pipeline_data

    def test_stop_schedule_from_CL_style(self):
        """if the schedule is made by CL_relion the RUNNING_ file
        has a PID and a list of jobs, the schedule process needs to
        be killed as well"""

        # make the RUNNING_ file and populate it
        subprocess.run(["touch", "RUNNING_PIPELINER_default_api"])
        with open("RUNNING_PIPELINER_default_api", "w") as f:
            f.write("CL_RELION_SCHEDULE\n")
            f.write("9999999999\n")
            f.write("PostProcess/job001/\n")
        assert os.path.isfile("RUNNING_PIPELINER_default_api")
        with open("RUNNING_PIPELINER_default_api") as f:
            runfile_data = f.readlines()
        assert runfile_data == [
            "CL_RELION_SCHEDULE\n",
            "9999999999\n",
            "PostProcess/job001/\n",
        ]

        # copy in the pipeline
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "Pipelines/running_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )

        # make the necesary project dirs
        os.makedirs("PostProcess/job001")

        # stop the schedule
        my_project = RelionProject(pipeline_name="default")
        my_project.stop_schedule("api")

        # RUNNING file should be gone and ABORTED file should appear
        assert not os.path.isfile("RUNNING_PIPELINER_default_api")
        assert os.path.isfile("PostProcess/job001/RELION_JOB_EXIT_ABORTED")

        # pipeline should be updated
        with open("default_pipeline.star") as f:
            pipeline_data = f.readlines()
        newline = "PostProcess/job001/       None           15            4 \n"
        oldline = "PostProcess/job001/       None           15            0 \n"

        assert newline in pipeline_data
        assert oldline not in pipeline_data


if __name__ == "__main__":
    unittest.main()
