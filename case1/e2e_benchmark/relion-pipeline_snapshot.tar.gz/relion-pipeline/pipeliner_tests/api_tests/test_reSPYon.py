import unittest
import os
import shutil
import tempfile
import time

from glob import glob
from json import loads

from pipeliner_tests import test_data
from pipeliner.api import reSPYon, CL_relion
from pipeliner_tests import generic_tests
from pipeliner.api.manage_project import RelionProject

do_full = os.environ.get("UNITTEST_FULL", False) == "True"
do_interactive = os.environ.get("UNITTEST_INTERACTIVE", False) == "True"
# do_full = "True"


class CL_reSPYon_Test(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")
        self.pipeliner_test_data = os.path.join(
            os.path.abspath(os.path.join(__file__, "../..")), "test_data",
        )

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir, ignore_errors=True)

    def read_pipeline(self):
        """Return the contents of the pipline as a string, for comparisons"""
        with open("default_pipeline.star") as pipe:
            pipe_data = pipe.read()
        return pipe_data

    def find_outfile(self):
        """Get the name of the output file produced by reSPYon"""
        outfiles = glob("reSPYon/*.json")
        return outfiles[0]

    def read_output_file(self):
        with open(self.find_outfile()) as outfile:
            outdata = outfile.read()
            data_dict = loads(outdata)
            return data_dict

    def check_file_was_written_correctly(self, the_file, json_name):
        """ make sure the 'pipeline' section of the json output file matches the
        actual pipeline"""

        with open(the_file) as original_file:
            file_data = original_file.readlines()

        out_data = self.read_output_file()

        for line in file_data:
            if line != "\n":
                assert line in out_data[json_name]

    def run_postprocess_job(self):
        """copy in the necessary files and run a postprocess job"""

        # get the files
        assert not os.path.isfile("default_pipeline.star")

        jobfile = os.path.join(
            self.test_data, "JobFiles/PostProcess/postprocess_CL_job.star"
        )

        halfmap_import_dir = "Halfmaps"
        os.makedirs(halfmap_import_dir)
        shutil.copy(
            os.path.join(self.test_data, "3488_run_half1_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        shutil.copy(
            os.path.join(self.test_data, "3488_run_half2_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        mask_import_dir = "Mask"
        os.makedirs(mask_import_dir)
        shutil.copy(os.path.join(self.test_data, "emd_3488_mask.mrc"), mask_import_dir)

        # intialize a new project
        CL_relion.main(["CL_relion.py", "--new_project"])

        # run the job
        CL_relion.main(["CL_relion.py", "--run_job", jobfile])

        # wait for it to finish
        time.sleep(2)

    def test_initialize_new_project(self):
        #  initialize a new project
        reSPYon.main(["--new_project"])
        self.check_file_was_written_correctly("default_pipeline.star", "pipeline")

    def test_capture_CL_relion_error(self):
        #  initialize a new project
        reSPYon.main(["--new_project"])
        # run a job with a bad star file
        reSPYon.main(["--run_job", "bad_job.star"])
        # sometimes takes a sec for the error log to write
        # check the error appeared in the log
        respyonfiles = glob("reSPYon/*")
        found = 0
        for respyonfile in respyonfiles:
            with open(respyonfile) as respyon:
                rdata = respyon.read()
                errorstring = "No such file or directory: 'bad_job.star'"
                if errorstring in rdata:
                    found += 1
        assert found == 1, found

    def test_run_job(self):
        # get the files
        assert not os.path.isfile("default_pipeline.star")

        jobfile = os.path.join(
            self.test_data, "JobFiles/PostProcess/postprocess_CL_job.star"
        )

        halfmap_import_dir = "Halfmaps"
        os.makedirs(halfmap_import_dir)
        shutil.copy(
            os.path.join(self.test_data, "3488_run_half1_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        shutil.copy(
            os.path.join(self.test_data, "3488_run_half2_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        mask_import_dir = "Mask"
        os.makedirs(mask_import_dir)
        shutil.copy(os.path.join(self.test_data, "emd_3488_mask.mrc"), mask_import_dir)

        # intialize a new project don't need to capture the data here
        CL_relion.main(["CL_relion.py", "--new_project"])

        # run the job
        reSPYon.main(["--run_job", jobfile])

        # make sure the job ran
        assert os.path.isdir("PostProcess/job001")

        # check the output was written as expected
        self.check_file_was_written_correctly("default_pipeline.star", "pipeline")
        self.check_file_was_written_correctly(
            "PostProcess/job001/run.out", "relion_stdout"
        )
        self.check_file_was_written_correctly(
            "PostProcess/job001/run.err", "relion_stderr"
        )
        self.check_file_was_written_correctly(
            "PostProcess/job001/job.star", "job.star_file"
        )

    def test_set_alias(self):
        # run the postprocess job to make the files
        self.run_postprocess_job()

        # change the alias
        reSPYon.main(["--set_alias", "PostProcess/job001/", "new_alias"])

        # check the pipeline has been updated
        pipe_data = self.read_pipeline()
        new_ln = "PostProcess/job001/ PostProcess/new_alias/           15            2"
        old_ln = "PostProcess/job001/       None           15            2"
        assert new_ln in pipe_data
        assert old_ln not in pipe_data

        # check the data was written
        self.check_file_was_written_correctly("default_pipeline.star", "pipeline")

    def test_set_alias_and_clear(self):
        # run the previous test to make a job with an alias
        self.run_postprocess_job()

        # set the alias
        CL_relion.main(
            ["CL_relion.py", "--set_alias", "PostProcess/job001/", "new_alias"]
        )

        # clear the alias
        reSPYon.main(["--clear_alias", "PostProcess/job001/"])

        # check the pipeline has been updated
        pipe_data = self.read_pipeline()
        new_ln = "PostProcess/job001/ PostProcess/new_alias/           15            2"
        old_ln = "PostProcess/job001/       None           15            2"
        assert new_ln not in pipe_data
        assert old_ln in pipe_data

        # check the data was written
        self.check_file_was_written_correctly("default_pipeline.star", "pipeline")

    def test_set_status_failed(self):
        # run the postporcess job to make the files
        self.run_postprocess_job()
        # change the status to failed
        reSPYon.main(["--set_status", "PostProcess/job001/", "failed"])

        # check the pipeline has been updated
        pipe_data = self.read_pipeline()
        fail_line = "PostProcess/job001/       None           15            3"
        assert fail_line in pipe_data

        # check the data was written
        self.check_file_was_written_correctly("default_pipeline.star", "pipeline")

    def test_set_status_aborted(self):
        os.makedirs("PostProcess/job001")
        # copy in a pipeline with a running job
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/running_pipeline.star"),
            "default_pipeline.star",
        )
        # set the status to aborted
        reSPYon.main(["--set_status", "PostProcess/job001/", "aborted"])

        # check the pipeline has been updated
        fin_line = "PostProcess/job001/       None           15            4"
        pipe_data = self.read_pipeline()
        assert fin_line in pipe_data

        # check the data was written
        self.check_file_was_written_correctly("default_pipeline.star", "pipeline")

    def test_deleting_job_removes_Nodes_dir_entries(self):
        """Make sure when a job is delete the .Nodes dir entries are also removed
        and empty .Nodes dirs are removed"""

        # run the postporcess job to make the files
        self.run_postprocess_job()

        # make sure the nodes are as expected
        expected_keep_dirs = [
            ".Nodes/10",
            ".Nodes/7",
            ".Nodes/10/HalfMaps",
            ".Nodes/7/Mask",
        ]

        expected_remove_dirs = [
            ".Nodes/11/PostProcess",
            ".Nodes/13/PostProcess",
            ".Nodes/14/PostProcess",
            ".Nodes/11",
            ".Nodes/13",
            ".Nodes/14",
        ]
        will_keep_nodes = [
            ".Nodes/10/HalfMaps/3488_run_half1_class001_unfil.mrc",
            ".Nodes/7/Mask/emd_3488_mask.mrc",
        ]
        will_delete_nodes = [
            ".Nodes/11/PostProcess/job001/postprocess.mrc",
            ".Nodes/11/PostProcess/job001/postprocess.mrc",
            ".Nodes/13/PostProcess/job001/logfile.pdf",
            ".Nodes/14/PostProcess/job001/postprocess.star",
        ]
        # are they all there?
        for edir in expected_remove_dirs:
            assert os.path.isdir(edir), edir
        for edir in expected_keep_dirs:
            assert os.path.isdir(edir), edir
        for enode in will_keep_nodes:
            assert os.path.isfile(enode), enode
        for enode in will_delete_nodes:
            assert os.path.isfile(enode), enode

        reSPYon.main(["--delete_job", "PostProcess/job001/"])

        # check the nodes that are empty were removed
        for edir in expected_remove_dirs:
            assert not os.path.isdir(edir), edir
        for edir in expected_keep_dirs:
            assert os.path.isdir(edir), edir
        for enode in will_keep_nodes:
            assert os.path.isfile(enode), enode
        for enode in will_delete_nodes:
            assert not os.path.isfile(enode), enode

    def test_deleting_job(self):
        # make the necessary files
        generic_tests.make_shortpipe_filestructure(["Import", "MotionCorr", "CtfFind"])
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_3jobs_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )

        # count the files
        mocorr_file_count = len(os.listdir("MotionCorr/job002"))
        mocorr_rawdata_file_count = len(os.listdir("MotionCorr/job002/Raw_data"))
        ctffind_file_count = len(os.listdir("CtfFind/job003"))

        # make sure the expected lines are in the pipeline
        pipe_data = self.read_pipeline()
        inc_lines = [
            "MotionCorr/job002/       None            1            2",
            "CtfFind/job003/       None            2            2",
            "MotionCorr/job002/corrected_micrographs.star            1",
            "MotionCorr/job002/logfile.pdf           13",
            "CtfFind/job003/micrographs_ctf.star            1",
            "CtfFind/job003/logfile.pdf           13",
            "MotionCorr/job002/corrected_micrographs.star CtfFind/job003/",
            "MotionCorr/job002/ MotionCorr/job002/corrected_micrographs.star",
            "MotionCorr/job002/ MotionCorr/job002/logfile.pdf",
            "CtfFind/job003/ CtfFind/job003/micrographs_ctf.star",
            "CtfFind/job003/ CtfFind/job003/logfile.pdf",
        ]
        for line in inc_lines:
            assert line in pipe_data

        # delete the MotionCorr job, child CtfFind job should go with it
        reSPYon.main(["--delete_job", "MotionCorr/job002/"])

        # check the lines are gone from the pipeline
        pipe_data = self.read_pipeline()
        for line in inc_lines:
            assert line not in pipe_data, line

        # make sure the files have been moved to the trash
        mocorr_trash_count = len(os.listdir("Trash/MotionCorr/job002"))
        mocorr_rawdata_trash_count = len(os.listdir("Trash/MotionCorr/job002/Raw_data"))
        ctffind_trash_count = len(os.listdir("Trash/CtfFind/job003"))
        assert mocorr_trash_count == mocorr_file_count
        assert mocorr_rawdata_trash_count == mocorr_rawdata_file_count
        assert ctffind_trash_count == ctffind_file_count

        # the job directories should be gone
        assert not os.path.isdir("MotionCorr/job002")
        assert not os.path.isdir("CtfFind/job003")

        # check the data was written
        self.check_file_was_written_correctly("default_pipeline.star", "pipeline")

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_deleting_job_no_recursive(self):
        # make the necessary files
        generic_tests.make_shortpipe_filestructure(["Import", "MotionCorr", "CtfFind"])
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_3jobs_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )

        # make sure the expected lines are in the pipeline
        pipe_data = self.read_pipeline()
        del_lines = [
            "MotionCorr/job002/       None            1            2",
            "MotionCorr/job002/corrected_micrographs.star            1",
            "MotionCorr/job002/logfile.pdf           13",
            "MotionCorr/job002/corrected_micrographs.star CtfFind/job003/",
            "MotionCorr/job002/ MotionCorr/job002/corrected_micrographs.star",
            "MotionCorr/job002/ MotionCorr/job002/logfile.pdf",
        ]
        # lines from the child job that shouldn't be deleted
        kept_lines = [
            "CtfFind/job003/       None            2            2",
            "CtfFind/job003/micrographs_ctf.star            1",
            "CtfFind/job003/logfile.pdf           13",
            "CtfFind/job003/ CtfFind/job003/micrographs_ctf.star",
            "CtfFind/job003/ CtfFind/job003/logfile.pdf",
        ]
        for line in kept_lines:
            assert line in pipe_data
        for line in del_lines:
            assert line in pipe_data

        # count the files
        mocorr_file_count = len(os.listdir("MotionCorr/job002"))
        mocorr_rawdata_file_count = len(os.listdir("MotionCorr/job002/Raw_data"))

        # do the deletion
        reSPYon.main(["--delete_job", "MotionCorr/job002/", "--no_recursive"])

        # check the deleted lines are gone from the pipeline
        pipe_data = self.read_pipeline()
        for line in del_lines:
            assert line not in pipe_data, line
        # check the child process lines are still there
        for line in kept_lines:
            assert line in pipe_data, line

        # make sure the files have been moved to the trash
        mocorr_trash_count = len(os.listdir("Trash/MotionCorr/job002"))
        mocorr_rawdata_trash_count = len(os.listdir("Trash/MotionCorr/job002/Raw_data"))

        # ctffind job shouldn't have been trashed
        assert not os.path.isdir("Trash/CtfFind/job003")
        assert mocorr_trash_count == mocorr_file_count
        assert mocorr_rawdata_trash_count == mocorr_rawdata_file_count

        # check the data was written
        self.check_file_was_written_correctly("default_pipeline.star", "pipeline")

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_delete_then_undelete(self):
        # make all of the necessary files
        generic_tests.make_shortpipe_filestructure(["Import", "MotionCorr", "CtfFind"])
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_3jobs_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/minipipe_mocorr_pipeline.star"),
            os.path.join(self.test_dir, "MotionCorr/job002/job_pipeline.star"),
        )
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/minipipe_ctffind_pipeline.star"),
            os.path.join(self.test_dir, "CtfFind/job003/job_pipeline.star"),
        )

        # count the files
        mocorr_file_count = len(os.listdir("MotionCorr/job002"))
        mocorr_rawdata_file_count = len(os.listdir("MotionCorr/job002/Raw_data"))
        ctffind_file_count = len(os.listdir("CtfFind/job003"))

        # read the default pipeline and check that the expected lines are there
        pipe_data = self.read_pipeline()
        inc_lines = [
            "MotionCorr/job002/       None            1            2",
            "CtfFind/job003/       None            2            2",
            "MotionCorr/job002/corrected_micrographs.star            1",
            "MotionCorr/job002/logfile.pdf           13",
            "CtfFind/job003/micrographs_ctf.star            1",
            "CtfFind/job003/logfile.pdf           13",
            "MotionCorr/job002/corrected_micrographs.star CtfFind/job003/",
            "MotionCorr/job002/ MotionCorr/job002/corrected_micrographs.star",
            "MotionCorr/job002/ MotionCorr/job002/logfile.pdf",
            "CtfFind/job003/ CtfFind/job003/micrographs_ctf.star",
            "CtfFind/job003/ CtfFind/job003/logfile.pdf",
        ]
        for line in inc_lines:
            assert line in pipe_data

        # delete the mocorr job along with 1 child
        CL_relion.main(["CL_relion.py", "--delete_job", "MotionCorr/job002/"])

        # make sure the files have been moved to the trash
        mocorr_trash_count = len(os.listdir("Trash/MotionCorr/job002"))
        mocorr_rawdata_trash_count = len(os.listdir("Trash/MotionCorr/job002/Raw_data"))
        ctffind_trash_count = len(os.listdir("Trash/CtfFind/job003"))
        assert mocorr_trash_count == mocorr_file_count
        assert mocorr_rawdata_trash_count == mocorr_rawdata_file_count
        assert ctffind_trash_count == ctffind_file_count

        # reread the pipeline and make sure the lines are gone
        pipe_data = self.read_pipeline()
        for line in inc_lines:
            assert line not in pipe_data, line

        # undelete the ctffind job - which should include 1 parent
        reSPYon.main(["--undelete_job", "CtfFind/job003/"])

        # check that the lines are back in the default pipeline
        pipe_data = self.read_pipeline()
        for line in inc_lines:
            assert line in pipe_data, line

        # count the files - make sure they have been moved back from the trash...
        assert not os.path.isdir("Trash/MotionCorr/job002")
        assert not os.path.isdir("Trash/CtfFind/job003")

        # ...and are back in the right place
        mocorr_file_count2 = len(os.listdir("MotionCorr/job002"))
        mocorr_rawdata_file_count2 = len(os.listdir("MotionCorr/job002/Raw_data"))
        ctffind_file_count2 = len(os.listdir("CtfFind/job003"))
        assert mocorr_file_count2 == mocorr_file_count
        assert mocorr_rawdata_file_count2 == mocorr_rawdata_file_count
        assert ctffind_file_count2 == ctffind_file_count

        # check the data was written
        self.check_file_was_written_correctly("default_pipeline.star", "pipeline")

    def test_schedule_job(self, job="001"):
        # get the files
        jobfile = os.path.join(
            self.test_data, "JobFiles/PostProcess/postprocess_CL_job.star"
        )

        halfmap_import_dir = "Halfmaps"
        if not os.path.isdir(halfmap_import_dir):
            os.makedirs(halfmap_import_dir)
        shutil.copy(
            os.path.join(self.test_data, "3488_run_half1_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        shutil.copy(
            os.path.join(self.test_data, "3488_run_half2_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        mask_import_dir = "Mask"
        if not os.path.isdir(mask_import_dir):
            os.makedirs(mask_import_dir)
        shutil.copy(os.path.join(self.test_data, "emd_3488_mask.mrc"), mask_import_dir)

        # intialize a new project the first time
        if not os.path.isfile("default_pipeline.star"):
            CL_relion.main(["CL_relion.py", "--new_project"])

        # schedule the job
        reSPYon.main(["--schedule_job", jobfile])

        # check the expected lines are in the pipeline
        expected_lines = [
            "PostProcess/job{}/       None           15            1".format(job),
            "Mask/emd_3488_mask.mrc            7",
            "HalfMaps/3488_run_half1_class001_unfil.mrc           10",
            "PostProcess/job{}/postprocess.mrc           11".format(job),
            "PostProcess/job{}/postprocess_masked.mrc           11".format(job),
            "PostProcess/job{}/postprocess.star           14".format(job),
            "PostProcess/job{}/logfile.pdf           13".format(job),
            "Mask/emd_3488_mask.mrc PostProcess/job{}/".format(job),
            (
                "HalfMaps/3488_run_half1_class001_unfil.mrc "
                "PostProcess/job{}/".format(job)
            ),
            "PostProcess/job{0}/ PostProcess/job{0}/postprocess.mrc".format(job),
            "PostProcess/job{0}/ PostProcess/job{0}/postprocess_masked.mrc".format(job),
            "PostProcess/job{0}/ PostProcess/job{0}/postprocess.star".format(job),
            "PostProcess/job{0}/ PostProcess/job{0}/logfile.pdf".format(job),
        ]
        pipe_data = self.read_pipeline()
        for line in expected_lines:
            assert line in pipe_data, line

        # check that the .Nodes files have been made
        expected_files = [
            ".Nodes/11/PostProcess/job{}/postprocess.mrc".format(job),
            ".Nodes/11/PostProcess/job{}/postprocess_masked.mrc".format(job),
            ".Nodes/13/PostProcess/job{}/logfile.pdf".format(job),
            ".Nodes/14/PostProcess/job{}/postprocess.star".format(job),
        ]
        for f in expected_files:
            assert os.path.isfile(f), f

        # check the data was written
        self.check_file_was_written_correctly("default_pipeline.star", "pipeline")

    def test_running_schedule(self):
        """Make a schedule with two jobs and run it 3 times"""
        # get the files
        jobfile = os.path.join(
            self.test_data, "JobFiles/PostProcess/postprocess_CL_job.star"
        )

        halfmap_import_dir = "Halfmaps"
        if not os.path.isdir(halfmap_import_dir):
            os.makedirs(halfmap_import_dir)
        shutil.copy(
            os.path.join(self.test_data, "3488_run_half1_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        shutil.copy(
            os.path.join(self.test_data, "3488_run_half2_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        mask_import_dir = "Mask"
        if not os.path.isdir(mask_import_dir):
            os.makedirs(mask_import_dir)
        shutil.copy(os.path.join(self.test_data, "emd_3488_mask.mrc"), mask_import_dir)

        # intialize a new project the first time
        CL_relion.main(["CL_relion.py", "--new_project"])

        # schedule 2 jobs
        CL_relion.main(["CL_relion.py", "--schedule_job", jobfile])
        CL_relion.main(["CL_relion.py", "--schedule_job", jobfile])

        # run the schedule 3 times
        reSPYon.main(
            [
                "--run_schedule",
                "--name",
                "schedule1",
                "--jobs",
                "PostProcess/job001/",
                "PostProcess/job002/",
                "--nr_repeats",
                "3",
                "--min_between",
                "0",
                "--wait_min_before",
                "0",
                "--wait_sec_after",
                "1",
            ]
        )

        # check the expected files are produced
        pp_files = [
            "RELION_JOB_EXIT_SUCCESS",
            "logfile.pdf",
            "logfile.pdf.lst",
            "postprocess.mrc",
            "postprocess.star",
            "postprocess_fsc.eps",
            "postprocess_fsc.xml",
            "postprocess_guinier.eps",
            "postprocess_masked.mrc",
            "default_pipeline.star",
            "job.star",
            "job_pipeline.star",
            "note.txt",
            "run.err",
            "run.job",
            "run.out",
        ]
        for f in pp_files:
            for job in ["001", "002"]:
                assert os.path.isfile(os.path.join("PostProcess/job" + job, f)), f

        # check the jobs ran 3x and schedule log was written properly
        with open("pipeline_Schedule1.log") as logfile:
            log_data = logfile.readlines()
        job001_count = 0
        job002_count = 0
        for line in log_data:
            if "---- Executing PostProcess/job001/" in line:
                job001_count += 1
            if "---- Executing PostProcess/job002/" in line:
                job002_count += 1
        assert job001_count == 3
        assert job002_count == 3

        # TO DO: check the mini_pipeline is as expected

        # TO DO: Add test the 2nd and 3rd runs were continues
        # after that functionality is added to the job runner

        # check the data file was written
        self.check_file_was_written_correctly("default_pipeline.star", "pipeline")
        self.check_file_was_written_correctly("pipeline_schedule1.log", "schedule_log")

    def test_get_command_jobstar_noproject(self):
        # get the files
        jobfile = os.path.join(
            self.test_data, "JobFiles/PostProcess/postprocess_CL_job.star"
        )

        # run print command, don't initialize project
        command = [reSPYon.main(["--print_command", jobfile])]

        # verify command is as expected
        expected_command = [
            "`which relion_postprocess` --mask Mask/emd_3488_mask.mrc"
            " --i HalfMaps/3488_run_half1_class001_unfil.mrc --o "
            "PostProcess/job000/postprocess --angpix 1.244 --adhoc_bfac -1000"
            " --pipeline_control PostProcess/job000/ >> PostProcess/job000/run.out "
            "2>> PostProcess/job000/run.err & "
        ]

        assert command == expected_command, generic_tests.print_coms(
            expected_command, command,
        )

    def test_get_command_runjob_noproject(self):
        # get the files
        jobfile = os.path.join(
            self.test_data, "JobFiles/InitialModel/initialmodel_3classes.job"
        )

        # run print command, don't initialize project
        command = reSPYon.main(["--print_command", jobfile])

        # verify command is as expected
        expected_command = (
            "mpirun -n 5 `which relion_refine_mpi` --sgd --denovo_3dref --i "
            "Select/job014/particles.star --o InitialModel/job000/run "
            "--sgd_ini_iter 25 --sgd_inbetween_iter 100 --sgd_fin_iter 25 "
            "--sgd_write_iter 10 --sgd_ini_resol 35 --sgd_fin_resol 15 "
            "--sgd_ini_subset 100 --sgd_fin_subset 500 --ctf --K 3 --sym C1"
            " --flatten_solvent --zero_mask --dont_combine_weights_via_disc"
            " --scratch_dir my_scratch_dir --pool 30 --pad 2 --skip_gridding "
            "--particle_diameter 200 --oversampling 1 --healpix_order 1 "
            '--offset_range 6 --offset_step 4.0 --j 6 --gpu "4:5:6:7"'
            " --pipeline_control InitialModel/job000/"
            " >> InitialModel/job000/run.out 2>> InitialModel/job000/run.err & "
        )

        assert command == expected_command, generic_tests.print_coms(
            expected_command, command,
        )

    def test_get_command_jobstar(self):
        # get the files
        jobfile = os.path.join(
            self.test_data, "JobFiles/PostProcess/postprocess_CL_job.star"
        )

        # initialize project and run print command
        CL_relion.main(["CL_relion.py", "--new_project"])
        command = [reSPYon.main(["--print_command", jobfile])]

        # verify command is as expected
        expected_command = [
            "`which relion_postprocess` --mask Mask/emd_3488_mask.mrc"
            " --i HalfMaps/3488_run_half1_class001_unfil.mrc --o "
            "PostProcess/job001/postprocess --angpix 1.244 --adhoc_bfac -1000"
            " --pipeline_control PostProcess/job001/ >> PostProcess/job001/run.out "
            "2>> PostProcess/job001/run.err & "
        ]

        assert command == expected_command, generic_tests.print_coms(
            expected_command, command,
        )

    def test_get_command_runjob(self):
        # get the files
        jobfile = os.path.join(
            self.test_data, "JobFiles/InitialModel/initialmodel_3classes.job"
        )
        # initialize project and run print command
        CL_relion.main(["CL_relion.py", "--new_project"])
        command = reSPYon.main(["--print_command", jobfile])

        # verify command is as expected
        expected_command = (
            "mpirun -n 5 `which relion_refine_mpi` --sgd --denovo_3dref --i "
            "Select/job014/particles.star --o InitialModel/job001/run "
            "--sgd_ini_iter 25 --sgd_inbetween_iter 100 --sgd_fin_iter 25 "
            "--sgd_write_iter 10 --sgd_ini_resol 35 --sgd_fin_resol 15 "
            "--sgd_ini_subset 100 --sgd_fin_subset 500 --ctf --K 3 --sym C1"
            " --flatten_solvent --zero_mask --dont_combine_weights_via_disc"
            " --scratch_dir my_scratch_dir --pool 30 --pad 2 --skip_gridding "
            "--particle_diameter 200 --oversampling 1 --healpix_order 1 "
            '--offset_range 6 --offset_step 4.0 --j 6 --gpu "4:5:6:7"'
            " --pipeline_control InitialModel/job001/"
            " >> InitialModel/job001/run.out 2>> InitialModel/job001/run.err & "
        )

        assert command == expected_command, generic_tests.print_coms(
            expected_command, command,
        )

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_cleanup_single_job(self):
        # create the files
        procname = "Class3D"
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_full_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )
        outfiles = generic_tests.make_shortpipe_filestructure([procname])
        files = glob("Class3D/job009/*")
        assert len(files) == len(outfiles[procname]), (
            len(files),
            len(outfiles[procname]),
        )

        # list of files that should be deleted
        del_files = glob("Class3D/job009/run_it*")
        for f in [
            "Class3D/job009/run_it025_class001.mrc",
            "Class3D/job009/run_it025_class001_angdist.bild",
            "Class3D/job009/run_it025_class002.mrc",
            "Class3D/job009/run_it025_class002_angdist.bild",
            "Class3D/job009/run_it025_class003.mrc",
            "Class3D/job009/run_it025_class003_angdist.bild",
            "Class3D/job009/run_it025_sampling.star",
            "Class3D/job009/run_it025_data.star",
            "Class3D/job009/run_it025_model.star",
            "Class3D/job009/run_it025_optimiser.star",
        ]:
            del_files.remove(f)

        # do the cleanup
        reSPYon.main(["--cleanup", "Class3D/job009/"])

        # sort the files
        removed, kept = [], []
        for f in outfiles[procname]:
            if f in del_files:
                removed.append(f)
            else:
                kept.append(f)

        # check they are all in the right place
        files = glob("Class3D/job009/*")
        trash = glob("Trash/**/**/*")
        for f in kept:
            assert f in files, f
        for f in removed:
            assert f not in files, f
            assert "Trash/" + f in trash, f

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_cleanup_multiple_jobs(self):
        # create the files
        procnames = ["Class3D", "InitialModel"]
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_full_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )
        outfiles = generic_tests.make_shortpipe_filestructure(procnames)

        # list of files that should be deleted
        del_files = glob("Class3D/job009/run_it*") + glob("InitialModel/job008/run_it*")
        for f in [
            "Class3D/job009/run_it025_class001.mrc",
            "Class3D/job009/run_it025_class001_angdist.bild",
            "Class3D/job009/run_it025_class002.mrc",
            "Class3D/job009/run_it025_class002_angdist.bild",
            "Class3D/job009/run_it025_class003.mrc",
            "Class3D/job009/run_it025_class003_angdist.bild",
            "Class3D/job009/run_it025_sampling.star",
            "Class3D/job009/run_it025_data.star",
            "Class3D/job009/run_it025_model.star",
            "Class3D/job009/run_it025_optimiser.star",
            "InitialModel/job008/run_it150_data.star",
            "InitialModel/job008/run_it150_sampling.star",
            "InitialModel/job008/run_it150_model.star",
            "InitialModel/job008/run_it150_optimiser.star",
            "InitialModel/job008/run_it150_class001.mrc",
            "InitialModel/job008/run_it150_grad001.mrc",
            "InitialModel/job008/run_it150_class002.mrc",
            "InitialModel/job008/run_it150_grad002.mrc",
        ]:
            del_files.remove(f)

        # do the cleanup
        reSPYon.main(["--cleanup", "Class3D/job009/", "InitialModel/job008/"])

        # sort the files
        removed, kept = [], []
        for procname in procnames:
            for f in outfiles[procname]:
                if f in del_files:
                    removed.append(f)
                else:
                    kept.append(f)

        # check they are all in the right place
        files = glob("Class3D/job009/*") + glob("InitialModel/job008/*")
        trash = glob("Trash/**/**/*")
        for f in kept:
            assert f in files, f
        for f in removed:
            assert f not in files, f
            assert "Trash/" + f in trash, f

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_cleanup_single_job_harsh(self):
        procname = "Polish"
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_full_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )
        outfiles = generic_tests.make_shortpipe_filestructure([procname])

        files = glob("Polish/job014/**/*", recursive=True)

        assert len(files) == len(outfiles[procname]) + 1, (
            len(files),
            len(outfiles[procname]) + 1,
        )

        del_files = []
        for ext in [
            "*_FCC_cc.mrc",
            "*_FCC_w0.mrc",
            "*_FCC_w1.mrc",
            "*shiny.star",
            "*shiny.mrcs",
        ]:
            del_files += glob("Polish/job014/Raw_data/" + ext)

        # do the cleanup
        reSPYon.main(["--cleanup", "Polish/job014/", "--harsh"])

        # sort the files
        removed, kept = [], []
        for f in outfiles[procname]:
            if f in del_files:
                removed.append(f)
            else:
                kept.append(f)

        # check they are all in the right place
        files = glob("Polish/job014/**/*", recursive=True)
        trash = glob("Trash/**/**/**/*", recursive=True)
        for f in kept:
            assert f in files, f
        for f in removed:
            assert f not in files, f
            assert "Trash/" + f in trash, f

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_cleanup_alljobs(self):
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_full_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )
        generic_tests.make_shortpipe_filestructure("all")

        del_files = {
            "Import": [],
            "MotionCorr": [
                "/job002/Raw_data/*.com",
                "/job002/Raw_data/*.err",
                "/job002/Raw_data/*.out",
                "/job002/Raw_data/*.log",
            ],
            "CtfFind": [
                "/job003/gctf*.out",
                "/job003/gctf*.err",
                "/job003/Raw_data/*",
            ],
            "AutoPick": ["/job004/Raw_data/*.spi"],
            "Extract": ["/job005/Raw_data/*_extract.star"],
            "Class2D": ["/job006/run_it*"],
            "Select": [],
            "InitialModel": ["/job008/run_it*"],
            "Class3D": ["/job009/run_it*"],
            "Refine3D": ["/job010/run_it*"],
            "MultiBody": ["/job011/run_it*"],
            "CtfRefine": [
                "/job012/Raw_data/*_wAcc.mrc",
                "/job012/Raw_data/*_xyAcc_real.mrc",
                "/job012/Raw_data/*_xyAcc_imag.mrc",
            ],
            "MaskCreate": [],
            "Polish": [
                "/job014/Raw_data/*_FCC_cc.mrc",
                "/job014/Raw_data/*_FCC_w0.mrc",
                "/job014/Raw_data/*_FCC_w1.mrc",
            ],
            "JoinStar": [],
            "Subtract": [],
            "External": [],
            "PostProcess": ["/job017/*masked.mrc"],
            "LocalRes": [],
        }

        exclude_files = {
            "Import": [],
            "MotionCorr": [],
            "CtfFind": [],
            "AutoPick": [],
            "Extract": [],
            "Class2d": [
                "Class2D/job006/run_it025_data.star",
                "Class2D/job006/run_it025_sampling.star",
                "Class2D/job006/run_it025_model.star",
                "Class2D/job006/run_it025_optimiser.star",
                "Class2D/job006/run_it025_classes.mrcs",
            ],
            "Select": [],
            "InitialModel": [
                "InitialModel/job008/run_it150_data.star",
                "InitialModel/job008/run_it150_sampling.star",
                "InitialModel/job008/run_it150_model.star",
                "InitialModel/job008/run_it150_optimiser.star",
                "InitialModel/job008/run_it150_class001.mrc",
                "InitialModel/job008/run_it150_grad001.mrc",
                "InitialModel/job008/run_it150_class002.mrc",
                "InitialModel/job008/run_it150_grad002.mrc",
            ],
            "Class3D": [
                "Class3D/job009/run_it025_class001.mrc",
                "Class3D/job009/run_it025_class001_angdist.bild",
                "Class3D/job009/run_it025_class002.mrc",
                "Class3D/job009/run_it025_class002_angdist.bild",
                "Class3D/job009/run_it025_class003.mrc",
                "Class3D/job009/run_it025_class003_angdist.bild",
                "Class3D/job009/run_it025_sampling.star",
                "Class3D/job009/run_it025_data.star",
                "Class3D/job009/run_it025_model.star",
                "Class3D/job009/run_it025_optimiser.star",
            ],
            "Refine3D": [
                "Refine3D/job010/run_it016_half1_class001.mrc",
                "Refine3D/job010/run_it016_half1_class001_angdist.bild",
                "Refine3D/job010/run_it016_half1_model.star",
                "Refine3D/job010/run_it016_half2_class001.mrc",
                "Refine3D/job010/run_it016_half2_class001_angdist.bild",
                "Refine3D/job010/run_it016_half2_model.star",
                "Refine3D/job010/run_it016_sampling.star",
                "Refine3D/job010/run_it016_data.star",
                "Refine3D/job010/run_it016_optimiser.star",
            ],
            "MultiBody": [
                "MultiBody/job011/run_it012_data.star",
                "MultiBody/job011/run_it012_half1_body001_angdist.bild",
                "MultiBody/job011/run_it012_half1_body001.mrc",
                "MultiBody/job011/run_it012_half1_body002_angdist.bild",
                "MultiBody/job011/run_it012_half1_body002.mrc",
                "MultiBody/job011/run_it012_half1_model.star",
                "MultiBody/job011/run_it012_half2_body001_angdist.bild",
                "MultiBody/job011/run_it012_half2_body001.mrc",
                "MultiBody/job011/run_it012_half2_body002_angdist.bild",
                "MultiBody/job011/run_it012_half2_body002.mrc",
                "MultiBody/job011/run_it012_half2_model.star",
            ],
            "CtfRefine": [],
            "MaskCreate": [],
            "Polish": [],
            "JoinStar": [],
            "Subtract": [],
            "External": [],
            "LocalRes": [],
        }

        files = list()
        for search_string in del_files:
            files += glob("{}/*/**/*".format(search_string), recursive=True)

        delete_list = list()
        for f in del_files:
            for search_string in del_files[f]:
                if len(search_string) > 1:
                    add = glob(f + search_string)
                    delete_list += add

        for f in exclude_files:
            for ff in exclude_files[f]:
                delete_list.remove(ff)

        reSPYon.main(["--cleanup", "ALL"])

        # sort the files
        dirnames = [
            "Import/job001",
            "MotionCorr/job002",
            "MotionCorr/job002/Raw_data",
            "CtfFind/job003",
            "CtfFind/job003/Raw_data",
            "AutoPick/job004/Raw_data",
            "Extract/job005/Raw_data",
            "Class2D/job006",
            "Select/job007",
            "InitialModel/job008",
            "Class3D/job009",
            "Refine3D/job010",
            "MultiBody/job011",
            "CtfRefine/job012/Raw_data",
            "MaskCreate/job013",
            "Polish/job014/Raw_data",
            "JoinStar/job015",
            "Subtract/job016",
            "External/job017",
            "PostProcess/job018",
            "LocalRes/job019",
        ]
        removed, kept = [], []
        for f in files:
            if f in delete_list:
                removed.append(f)
            else:
                if f not in dirnames:
                    kept.append(f)

        # check they are all in the right place
        files2 = list()
        for search_string in del_files:
            files2 += glob("{}/*/**/*".format(search_string), recursive=True)
        trash = glob("Trash/*/**/*", recursive=True)
        for f in kept:
            assert f in files2, f
        for f in removed:
            assert f not in files2, f
            assert "Trash/" + f in trash, "Trash/" + f

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_cleanup_alljobs_harsh(self):
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_full_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )
        generic_tests.make_shortpipe_filestructure("all")

        del_files = {
            "Import": [],
            "MotionCorr": ["/job002/Raw_data/*"],
            "CtfFind": [
                "/job003/gctf*.out",
                "/job003/gctf*.err",
                "/job003/Raw_data/*",
            ],
            "AutoPick": ["/job004/Raw_data/*.spi"],
            "Extract": ["/job005/Raw_data/*"],
            "Class2D": ["/job006/run_it*"],
            "Select": [],
            "InitialModel": ["/job008/run_it*"],
            "Class3D": ["/job009/run_it*"],
            "Refine3D": ["/job010/run_it*"],
            "MultiBody": ["/job011/run_it*", "/job011/analyse_component*_bin*.mrc"],
            "CtfRefine": [
                "/job012/Raw_data/*_wAcc.mrc",
                "/job012/Raw_data/*_xyAcc_real.mrc",
                "/job012/Raw_data/*_xyAcc_imag.mrc",
            ],
            "MaskCreate": [],
            "Polish": [
                "/job014/Raw_data/*_FCC_cc.mrc",
                "/job014/Raw_data/*_FCC_w0.mrc",
                "/job014/Raw_data/*_FCC_w1.mrc",
                "/job014/Raw_data/*shiny.star",
                "/job014/Raw_data/*shiny.mrcs",
            ],
            "JoinStar": [],
            "Subtract": ["/job016/subtracted_*"],
            "External": [],
            "PostProcess": ["/job017/*masked.mrc"],
            "LocalRes": [],
        }

        exclude_files = {
            "Import": [],
            "MotionCorr": [],
            "CtfFind": [],
            "AutoPick": [],
            "Extract": [],
            "Class2d": [
                "Class2D/job006/run_it025_data.star",
                "Class2D/job006/run_it025_sampling.star",
                "Class2D/job006/run_it025_model.star",
                "Class2D/job006/run_it025_optimiser.star",
                "Class2D/job006/run_it025_classes.mrcs",
            ],
            "Select": [],
            "InitialModel": [
                "InitialModel/job008/run_it150_data.star",
                "InitialModel/job008/run_it150_sampling.star",
                "InitialModel/job008/run_it150_model.star",
                "InitialModel/job008/run_it150_optimiser.star",
                "InitialModel/job008/run_it150_class001.mrc",
                "InitialModel/job008/run_it150_grad001.mrc",
                "InitialModel/job008/run_it150_class002.mrc",
                "InitialModel/job008/run_it150_grad002.mrc",
            ],
            "Class3D": [
                "Class3D/job009/run_it025_class001.mrc",
                "Class3D/job009/run_it025_class001_angdist.bild",
                "Class3D/job009/run_it025_class002.mrc",
                "Class3D/job009/run_it025_class002_angdist.bild",
                "Class3D/job009/run_it025_class003.mrc",
                "Class3D/job009/run_it025_class003_angdist.bild",
                "Class3D/job009/run_it025_sampling.star",
                "Class3D/job009/run_it025_data.star",
                "Class3D/job009/run_it025_model.star",
                "Class3D/job009/run_it025_optimiser.star",
            ],
            "Refine3D": [
                "Refine3D/job010/run_it016_half1_class001.mrc",
                "Refine3D/job010/run_it016_half1_class001_angdist.bild",
                "Refine3D/job010/run_it016_half1_model.star",
                "Refine3D/job010/run_it016_half2_class001.mrc",
                "Refine3D/job010/run_it016_half2_class001_angdist.bild",
                "Refine3D/job010/run_it016_half2_model.star",
                "Refine3D/job010/run_it016_sampling.star",
                "Refine3D/job010/run_it016_data.star",
                "Refine3D/job010/run_it016_optimiser.star",
            ],
            "MultiBody": [
                "MultiBody/job011/run_it012_data.star",
                "MultiBody/job011/run_it012_half1_body001_angdist.bild",
                "MultiBody/job011/run_it012_half1_body001.mrc",
                "MultiBody/job011/run_it012_half1_body002_angdist.bild",
                "MultiBody/job011/run_it012_half1_body002.mrc",
                "MultiBody/job011/run_it012_half1_model.star",
                "MultiBody/job011/run_it012_half2_body001_angdist.bild",
                "MultiBody/job011/run_it012_half2_body001.mrc",
                "MultiBody/job011/run_it012_half2_body002_angdist.bild",
                "MultiBody/job011/run_it012_half2_body002.mrc",
                "MultiBody/job011/run_it012_half2_model.star",
            ],
            "CtfRefine": [],
            "MaskCreate": [],
            "Polish": [],
            "JoinStar": [],
            "Subtract": [],
            "External": [],
            "LocalRes": [],
        }

        files = list()
        for search_string in del_files:
            files += glob("{}/*/**/*".format(search_string), recursive=True)

        delete_list = list()
        for f in del_files:
            for search_string in del_files[f]:
                if len(search_string) > 1:
                    add = glob(f + search_string)
                    delete_list += add

        for f in exclude_files:
            for ff in exclude_files[f]:
                delete_list.remove(ff)

        # run the cleanup
        reSPYon.main(["--cleanup", "ALL", "--harsh"])

        # sort the files
        dirnames = [
            "Import/job001",
            "MotionCorr/job002",
            "MotionCorr/job002/Raw_data",
            "CtfFind/job003",
            "CtfFind/job003/Raw_data",
            "AutoPick/job004/Raw_data",
            "Extract/job005/Raw_data",
            "Class2D/job006",
            "Select/job007",
            "InitialModel/job008",
            "Class3D/job009",
            "Refine3D/job010",
            "MultiBody/job011",
            "CtfRefine/job012/Raw_data",
            "MaskCreate/job013",
            "Polish/job014/Raw_data",
            "JoinStar/job015",
            "Subtract/job016",
            "External/job017",
            "PostProcess/job018",
            "LocalRes/job019",
        ]
        removed, kept = [], []
        for f in files:
            if f in delete_list:
                removed.append(f)
            else:
                if f not in dirnames:
                    kept.append(f)

        # check they are all in the right place
        files2 = list()
        for search_string in del_files:
            files2 += glob("{}/*/**/*".format(search_string), recursive=True)
        trash = glob("Trash/*/**/*", recursive=True)
        for f in kept:
            assert f in files2, f
        for f in removed:
            assert f not in files2, f
            assert "Trash/" + f in trash, "Trash/" + f

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_deleting_file_then_empty_trash(self):
        self.test_deleting_job()
        nr_trash_files = len(glob("Trash/*/*/*"))
        assert nr_trash_files == 40
        assert reSPYon.main(["--empty_trash"])
        nr_trash_files = len(glob("Trash/*/*/*"))
        assert nr_trash_files == 0

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_empty_trash_error_nofiles(self):
        nr_trash_files = len(glob("Trash/*/*/*"))
        assert nr_trash_files == 0
        assert reSPYon.main(["--new_project"])
        assert not reSPYon.main(["--empty_trash"])

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_drawing_flowchart_upstream(self):
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        my_project = RelionProject(pipeline_name="short_full")
        results = my_project.draw_flowcharts(job="Refine3D/job010/", do_upstream=True)
        assert results == [True, False, False]

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_drawing_flowchart_downstream(self):
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        my_project = RelionProject(pipeline_name="short_full")
        results = my_project.draw_flowcharts(job="Refine3D/job010/", do_downstream=True)
        assert results == [False, True, False]

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_drawing_flowchart_full(self):
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        my_project = RelionProject(pipeline_name="short_full")
        results = my_project.draw_flowcharts(do_full=True)
        assert results == [False, False, True]

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_drawing_flowchart_all(self):
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        my_project = RelionProject(pipeline_name="short_full")
        results = my_project.draw_flowcharts(
            job="Refine3D/job010/", do_downstream=True, do_upstream=True, do_full=True
        )
        assert results == [True, True, True]

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_drawing_flowchart_error_no_job(self):
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        my_project = RelionProject(pipeline_name="short_full")
        results = my_project.draw_flowcharts(
            do_downstream=True, do_upstream=True, do_full=True
        )
        assert results == [False, False, True]

    @unittest.skipUnless(
        do_interactive, "Requires interaction: only run in full unittest"
    )
    def test_drawing_flowchart_error_no_job_nofull(self):
        shutil.copy(
            os.path.join(
                self.pipeliner_test_data, "Pipelines/short_full_pipeline.star"
            ),
            self.test_dir,
        )
        my_project = RelionProject(pipeline_name="short_full")
        results = my_project.draw_flowcharts(do_downstream=True, do_upstream=True,)
        assert results == [False, False, False]


if __name__ == "__main__":
    unittest.main()
