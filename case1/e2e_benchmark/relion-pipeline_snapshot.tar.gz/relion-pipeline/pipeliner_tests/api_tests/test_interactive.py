import unittest
import os
import shutil
import tempfile

# from pipeliner_tests.api_tests import test_data

from pipeliner.api.interactive import interactive_job_create

do_full = os.environ.get("UNITTEST_INTERACTIVE", "FALSE")
# do_full = "True"


@unittest.skipUnless(
    do_full == "True", "Requires interaction: Only run in full unittest"
)
class InteractiveJobCreatorTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_dir = tempfile.mkdtemp(prefix="relion_")
        # self.test_data = os.path.dirname(test_data.__file__)
        self.pipeliner_test_data = os.path.join(
            os.path.abspath(os.path.join(__file__, "../..")), "test_data",
        )

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_interactive_jobfile_maker(self):
        os.system("mkdir -p Class2D/job008")
        os.system("mkdir -p Extract/job007")
        os.system("touch Extract/job007/particles.star")
        shutil.copy(
            os.path.join(self.pipeliner_test_data, "Pipelines/tutorial_pipeline.star"),
            os.path.join(self.test_dir, "default_pipeline.star"),
        )

        shutil.copy(
            os.path.join(self.pipeliner_test_data, "JobFiles/Class2D/class2D_job.star"),
            os.path.join(self.test_dir, "Class2D/job008/job.star"),
        )
        os.system("touch test.star")
        os.system("mkdir -p Class2D/job008")
        os.system("touch Class2D/job008/run_it025_optimiser.star")

        jobs = interactive_job_create()
        for job in jobs:
            if os.path.isfile("Runfiles/" + job):
                os.system("cat RunFiles/" + job)
            else:
                os.system("cat " + job)


if __name__ == "__main__":
    unittest.main()
