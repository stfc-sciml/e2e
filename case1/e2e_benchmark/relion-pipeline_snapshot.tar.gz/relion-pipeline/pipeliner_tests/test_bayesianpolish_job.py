import unittest
import os
import shutil
import tempfile

from pipeliner_tests import test_data
from pipeliner_tests import generic_tests
from pipeliner.data_structure import NODES


class BayesianPolishTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_get_command_bayesian_train(self):
        generic_tests.general_get_command_test(
            self,
            "Polish",
            "bayesianpolish_train.job",
            14,
            {
                "Refine3D/job025/run_data.star": NODES["Part data"],
                "PostProcess/job026/postprocess.star": NODES["Post"],
            },
            {"opt_params_all_groups.txt": NODES["Polish params"]},
            "`which relion_motion_refine` --i Refine3D/job025/run_data.star"
            " --f PostProcess/job026/postprocess.star --corr_mic "
            "MotionCorr/job002/corrected_micrographs.star --first_frame 1 "
            "--last_frame -1 --o Polish/job014/ --min_p 4000 --eval_frac 0.5 "
            "--align_frac 0.5 --params3 --j 16 --pipeline_control Polish/job014/"
            " >> Polish/job014/run.out 2>> Polish/job014/run.err & ",
        )

    def test_get_command_bayesian_polish_own_params(self):
        generic_tests.general_get_command_test(
            self,
            "Polish",
            "bayesianpolish_polish_ownparam.job",
            14,
            {
                "Refine3D/job025/run_data.star": NODES["Part data"],
                "PostProcess/job026/postprocess.star": NODES["Post"],
            },
            {"logfile.pdf": NODES["PdfLogfile"], "shiny.star": NODES["Part data"]},
            "`which relion_motion_refine` --i Refine3D/job025/run_data.star"
            " --f PostProcess/job026/postprocess.star --corr_mic "
            "MotionCorr/job002/corrected_micrographs.star --first_frame 1 "
            "--last_frame -1 --o Polish/job014/ --s_vel 0.2 --s_div 5000 "
            "--s_acc 2 --combine_frames --bfac_minfreq 20 --bfac_maxfreq -1 --j 16 "
            "--pipeline_control Polish/job014/"
            " >> Polish/job014/run.out 2>> Polish/job014/run.err & ",
        )

    def test_get_command_bayesian_polish_jobstar(self):
        generic_tests.general_get_command_test(
            self,
            "Polish",
            "bayesianpolish_job.star",
            14,
            {
                "Refine3D/job025/run_data.star": NODES["Part data"],
                "PostProcess/job026/postprocess.star": NODES["Post"],
            },
            {"logfile.pdf": NODES["PdfLogfile"], "shiny.star": NODES["Part data"]},
            "`which relion_motion_refine` --i Refine3D/job025/run_data.star"
            " --f PostProcess/job026/postprocess.star --corr_mic "
            "MotionCorr/job002/corrected_micrographs.star --first_frame 1 "
            "--last_frame -1 --o Polish/job014/ --s_vel 0.2 --s_div 5000 "
            "--s_acc 2 --combine_frames --bfac_minfreq 20 --bfac_maxfreq -1 --j 16 "
            "--pipeline_control Polish/job014/"
            " >> Polish/job014/run.out 2>> Polish/job014/run.err & ",
        )

    def test_get_command_bayesian_polish_param_file(self):
        generic_tests.general_get_command_test(
            self,
            "Polish",
            "bayesianpolish_polish_paramfile.job",
            14,
            {
                "Refine3D/job025/run_data.star": NODES["Part data"],
                "PostProcess/job026/postprocess.star": NODES["Post"],
            },
            {"logfile.pdf": NODES["PdfLogfile"], "shiny.star": NODES["Part data"]},
            "`which relion_motion_refine` --i Refine3D/job025/run_data.star"
            " --f PostProcess/job026/postprocess.star --corr_mic "
            "MotionCorr/job002/corrected_micrographs.star --first_frame 1 "
            "--last_frame -1 --o Polish/job014/ --params_file paramfile.txt "
            "--combine_frames --bfac_minfreq 20 --bfac_maxfreq -1 --j 16 "
            "--pipeline_control Polish/job014/ "
            ">> Polish/job014/run.out 2>> Polish/job014/run.err & ",
        )

    def test_get_command_bayesian_polish_continue(self):
        generic_tests.general_get_command_test(
            self,
            "Polish",
            "bayesianpolish_polish_continue.job",
            14,
            {
                "Refine3D/job025/run_data.star": NODES["Part data"],
                "PostProcess/job026/postprocess.star": NODES["Post"],
            },
            {"logfile.pdf": NODES["PdfLogfile"], "shiny.star": NODES["Part data"]},
            "`which relion_motion_refine` --i Refine3D/job025/run_data.star"
            " --f PostProcess/job026/postprocess.star --corr_mic "
            "MotionCorr/job002/corrected_micrographs.star --first_frame 1 "
            "--last_frame -1 --o Polish/job014/ --params_file paramfile.txt "
            "--combine_frames --bfac_minfreq 20 --bfac_maxfreq -1 --only_do_unfinished"
            " --j 16 --pipeline_control Polish/job014/ "
            ">> Polish/job014/run.out 2>> Polish/job014/run.err & ",
        )

    def test_get_command_bayesian_polish_do_nothing(self):
        with self.assertRaises(ValueError):
            generic_tests.general_get_command_test(
                self, "Polish", "bayesianpolish_donothing.job", 14, 2, 2, " ",
            )

    def test_get_command_bayesian_polish_do_both(self):
        with self.assertRaises(ValueError):
            generic_tests.general_get_command_test(
                self, "Polish", "bayesianpolish_doboth.job", 14, 2, 2, " ",
            )


if __name__ == "__main__":
    unittest.main()
