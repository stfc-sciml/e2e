import unittest
from pipeliner.utils import truncate_number, check_for_illegal_symbols


class PipelinerUtilitiesTest(unittest.TestCase):
    def test_number_truncate(self):
        x = 1.66666666666667
        trunc = truncate_number(x, 7)
        assert trunc == "1.6666667", trunc
        x = 1.66666666666667
        trunc = truncate_number(x, 2)
        assert trunc == "1.67", trunc
        x = 2.0
        trunc = truncate_number(x, 7)
        assert trunc == "2", trunc
        x = 0.75
        trunc = truncate_number(x, 2)
        assert trunc == "0.75", trunc
        x = 2
        trunc = truncate_number(x, 7)
        assert trunc == "2", trunc
        x = 1234567890
        trunc = truncate_number(x, 7)
        assert trunc == "1234567890", trunc
        x = 1.89
        trunc = truncate_number(x, 0)
        assert trunc == "2", trunc
        x = 1.324
        trunc = truncate_number(x, 0)
        assert trunc == "1", trunc

    def test_for_illegal_symbols(self):
        with self.assertRaises(ValueError):
            string = "ISUCK!@£$%^&*()"
            check_for_illegal_symbols(string, "string_name")

    def test_for_illegal_symbols_exclude(self):
        string = "YEAHYEAH!"
        check_for_illegal_symbols(string, "string_name", ["!"])


if __name__ == "__main__":
    unittest.main()
