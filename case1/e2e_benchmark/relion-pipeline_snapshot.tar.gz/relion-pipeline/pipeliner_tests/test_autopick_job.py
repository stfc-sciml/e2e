import unittest
import os
import shutil
import tempfile

from pipeliner_tests import test_data
from pipeliner_tests import generic_tests
from pipeliner.data_structure import NODES


class AutoPickTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_get_command_2Dref(self):
        generic_tests.general_get_command_test(
            self,
            "AutoPick",
            "autopick_2dref.job",
            11,
            {
                "CtfFind/job003/micrographs_ctf.star": NODES["Mics"],
                "Select/job009/class_averages.star": NODES["2D refs"],
            },
            {
                "coords_suffix_autopick.star": NODES["Mic coords"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 4 `which relion_autopick_mpi` --i "
            "CtfFind/job003/micrographs_ctf.star"
            " --odir AutoPick/job011/ --pickname autopick --ref "
            "Select/job009/class_averages.star --invert --ctf --ang 5 --shrink 0 "
            "--lowpass 20 --angpix_ref 3.54 --threshold 0 --min_distance 100 "
            '--max_stddev_noise -1 --gpu "0:1:2:3" --pipeline_control AutoPick/job011/ '
            ">> AutoPick/job011/run.out 2>> AutoPick/job011/run.err && echo "
            "CtfFind/job003/micrographs_ctf.star >"
            " AutoPick/job011/coords_suffix_autopick.star & ",
        )

    def test_get_command_2Dref_helical(self):
        generic_tests.general_get_command_test(
            self,
            "AutoPick",
            "autopick_2dref_helical.job",
            11,
            {
                "CtfFind/job003/micrographs_ctf.star": NODES["Mics"],
                "Select/job009/class_averages.star": NODES["2D refs"],
            },
            {
                "coords_suffix_autopick.star": NODES["Mic coords"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 4 `which relion_autopick_mpi` --i "
            "CtfFind/job003/micrographs_ctf.star"
            " --odir AutoPick/job011/ --pickname autopick --ref "
            "Select/job009/class_averages.star --invert --ctf --ang 5 --shrink 0 "
            "--lowpass 20 --angpix_ref 3.54 --threshold 0 --min_distance 7.62 "
            "--max_stddev_noise -1 --helix --helical_tube_outer_diameter 200 "
            "--helical_tube_kappa_max 0.1 --helical_tube_length_min -1 "
            '--gpu "0:1:2:3" --this_one_is_helical --pipeline_control AutoPick/job011/'
            " >> AutoPick/job011/run.out 2>> AutoPick/job011/run.err && echo "
            "CtfFind/job003/micrographs_ctf.star > "
            "AutoPick/job011/coords_suffix_autopick.star & ",
        )

    def test_get_command_2Dref_amyloid(self):
        generic_tests.general_get_command_test(
            self,
            "AutoPick",
            "autopick_2dref_amyloid.job",
            11,
            {
                "CtfFind/job003/micrographs_ctf.star": NODES["Mics"],
                "Select/job009/class_averages.star": NODES["2D refs"],
            },
            {
                "coords_suffix_autopick.star": NODES["Mic coords"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 4 `which relion_autopick_mpi` --i "
            "CtfFind/job003/micrographs_ctf.star"
            " --odir AutoPick/job011/ --pickname autopick --ref "
            "Select/job009/class_averages.star --invert --ctf --ang 5 --shrink 0 "
            "--lowpass 20 --angpix_ref 3.54 --threshold 0 --min_distance 7.62 "
            "--max_stddev_noise -1 --helix --amyloid --helical_tube_outer_diameter"
            " 200 --helical_tube_kappa_max 0.1 --helical_tube_length_min -1 "
            '--gpu "0:1:2:3" --this_one_is_helical --pipeline_control AutoPick/job011/ '
            ">> AutoPick/job011/run.out 2>> AutoPick/job011/run.err && echo "
            "CtfFind/job003/micrographs_ctf.star > "
            "AutoPick/job011/coords_suffix_autopick.star & ",
        )

    def test_get_command_2Dref_continue(self):
        generic_tests.general_get_command_test(
            self,
            "AutoPick",
            "autopick_2dref_continue.job",
            11,
            {
                "CtfFind/job003/micrographs_ctf.star": NODES["Mics"],
                "Select/job009/class_averages.star": NODES["2D refs"],
            },
            {
                "coords_suffix_autopick.star": NODES["Mic coords"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 4 `which relion_autopick_mpi` --i "
            "CtfFind/job003/micrographs_ctf.star"
            " --odir AutoPick/job011/ --pickname autopick --ref "
            "Select/job009/class_averages.star --invert --ctf --ang 5 --shrink 0 "
            "--lowpass 20 --angpix_ref 3.54 --threshold 0 --min_distance 100 "
            '--max_stddev_noise -1 --gpu "0:1:2:3" --only_do_unfinished '
            "--pipeline_control AutoPick/job011/ >>"
            " AutoPick/job011/run.out 2>> AutoPick/job011/run.err && echo"
            " CtfFind/job003/micrographs_ctf.star >"
            " AutoPick/job011/coords_suffix_autopick.star & ",
        )

    def test_get_command_3Dref(self):
        generic_tests.general_get_command_test(
            self,
            "AutoPick",
            "autopick_3dref.job",
            11,
            {
                "CtfFind/job003/micrographs_ctf.star": NODES["Mics"],
                "Import/job000/fake_3D_ref.mrc": NODES["3D refs"],
            },
            {
                "coords_suffix_autopick.star": NODES["Mic coords"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 2 `which relion_autopick_mpi` --i "
            "CtfFind/job003/micrographs_ctf.star --odir AutoPick/job011/ "
            "--pickname autopick --ref Import/job000/fake_3D_ref.mrc --sym C1 "
            "--healpix_order 1 --ang 5 --shrink 0 --lowpass 20 --angpix_ref 3.54"
            " --threshold 0 --min_distance 100 --max_stddev_noise -1 --gpu "
            '"0:1" --pipeline_control AutoPick/job011/ >> AutoPick/job011/run.out 2>>'
            " AutoPick/job011/run.err && echo CtfFind/job003/micrographs_ctf.star > "
            "AutoPick/job011/coords_suffix_autopick.star & ",
        )

    def test_get_command_LoG(self):
        generic_tests.general_get_command_test(
            self,
            "AutoPick",
            "autopick_LoG.job",
            11,
            {"CtfFind/job003/micrographs_ctf.star": NODES["Mics"]},
            {
                "coords_suffix_autopick.star": NODES["Mic coords"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 16 `which relion_autopick_mpi` --i "
            "CtfFind/job003/micrographs_ctf.star "
            "--odir AutoPick/job011/ --pickname autopick --LoG --LoG_diam_min 150"
            " --LoG_diam_max 180 --shrink 0 --lowpass 20 --LoG_adjust_threshold 0"
            " --loG_upper_thr 5 --pipeline_control AutoPick/job011/ "
            ">> AutoPick/job011/run.out 2>> AutoPick/job011/run.err"
            " && echo CtfFind/job003/micrographs_ctf.star >"
            " AutoPick/job011/coords_suffix_autopick.star & ",
        )

    def test_get_command_LoG_gpu_error(self):
        with self.assertRaises(ValueError):
            generic_tests.general_get_command_test(
                self, "AutoPick", "autopick_LoG_gpu.job", 11, 1, 2, "",
            )

    def test_get_command_2Dref_writeFOM(self):
        generic_tests.general_get_command_test(
            self,
            "AutoPick",
            "autopick_2dref_writeFOM.job",
            11,
            {
                "CtfFind/job003/micrographs_ctf.star": NODES["Mics"],
                "Select/job009/class_averages.star": NODES["2D refs"],
            },
            {
                "coords_suffix_autopick.star": NODES["Mic coords"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 4 `which relion_autopick_mpi` --i "
            "CtfFind/job003/micrographs_ctf.star"
            " --odir AutoPick/job011/ --pickname autopick --ref "
            "Select/job009/class_averages.star --invert --ctf --ang 5 --shrink 0 "
            "--lowpass 20 --angpix_ref 3.54 --threshold 0 --min_distance 100 "
            '--max_stddev_noise -1 --gpu "0:1:2:3" --write_fom_maps '
            "--pipeline_control AutoPick/job011/ >> AutoPick/job011/run.out 2>> "
            "AutoPick/job011/run.err && echo CtfFind/job003/micrographs_ctf.star >"
            " AutoPick/job011/coords_suffix_autopick.star & ",
        )

    def test_get_command_2Dref_writeFOM_continue(self):
        generic_tests.general_get_command_test(
            self,
            "AutoPick",
            "autopick_2dref_continue_writeFOM.job",
            11,
            {
                "CtfFind/job003/micrographs_ctf.star": NODES["Mics"],
                "Select/job009/class_averages.star": NODES["2D refs"],
            },
            {
                "coords_suffix_autopick.star": NODES["Mic coords"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 4 `which relion_autopick_mpi` --i "
            "CtfFind/job003/micrographs_ctf.star"
            " --odir AutoPick/job011/ --pickname autopick --ref "
            "Select/job009/class_averages.star --invert --ctf --ang 5 --shrink 0 "
            "--lowpass 20 --angpix_ref 3.54 --threshold 0 --min_distance 100 "
            '--max_stddev_noise -1 --gpu "0:1:2:3" --write_fom_maps'
            " --pipeline_control AutoPick/job011/ >> AutoPick/job011/run.out 2>> "
            "AutoPick/job011/run.err && echo CtfFind/job003/micrographs_ctf.star"
            " > AutoPick/job011/coords_suffix_autopick.star & ",
        )

    def test_get_command_readFOM(self):
        generic_tests.general_get_command_test(
            self,
            "AutoPick",
            "autopick_2dref_readFOM.job",
            11,
            {
                "CtfFind/job003/micrographs_ctf.star": NODES["Mics"],
                "Select/job009/class_averages.star": NODES["2D refs"],
            },
            {
                "coords_suffix_autopick.star": NODES["Mic coords"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 4 `which relion_autopick_mpi` --i "
            "CtfFind/job003/micrographs_ctf.star"
            " --odir AutoPick/job011/ --pickname autopick --ref "
            "Select/job009/class_averages.star --invert --ctf --ang 5 --shrink 0 "
            "--lowpass 20 --angpix_ref 3.54 --threshold 0 --min_distance 100 "
            '--max_stddev_noise -1 --gpu "0:1:2:3" --read_fom_maps '
            "--pipeline_control AutoPick/job011/ >> AutoPick/job011/run.out 2>> "
            "AutoPick/job011/run.err && echo CtfFind/job003/micrographs_ctf.star"
            " > AutoPick/job011/coords_suffix_autopick.star & ",
        )

    def test_get_command_readFOM_continue(self):
        generic_tests.general_get_command_test(
            self,
            "AutoPick",
            "autopick_2dref_continue_readFOM.job",
            11,
            {
                "CtfFind/job003/micrographs_ctf.star": NODES["Mics"],
                "Select/job009/class_averages.star": NODES["2D refs"],
            },
            {
                "coords_suffix_autopick.star": NODES["Mic coords"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 4 `which relion_autopick_mpi` --i "
            "CtfFind/job003/micrographs_ctf.star"
            " --odir AutoPick/job011/ --pickname autopick --ref "
            "Select/job009/class_averages.star --invert --ctf --ang 5 --shrink 0 "
            "--lowpass 20 --angpix_ref 3.54 --threshold 0 --min_distance 100 "
            '--max_stddev_noise -1 --gpu "0:1:2:3" --read_fom_maps '
            "--pipeline_control AutoPick/job011/ >> AutoPick/job011/run.out 2>> "
            "AutoPick/job011/run.err && echo CtfFind/job003/micrographs_ctf.star >"
            " AutoPick/job011/coords_suffix_autopick.star & ",
        )

    def test_get_command_jobstar(self):
        generic_tests.general_get_command_test(
            self,
            "AutoPick",
            "autopick_job.star",
            11,
            {
                "CtfFind/job003/micrographs_ctf.star": NODES["Mics"],
                "Select/job009/class_averages.star": NODES["2D refs"],
            },
            {
                "coords_suffix_autopick.star": NODES["Mic coords"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 4 `which relion_autopick_mpi` --i "
            "CtfFind/job003/micrographs_ctf.star"
            " --odir AutoPick/job011/ --pickname autopick --ref "
            "Select/job009/class_averages.star --invert --ctf --ang 5 --shrink 0 "
            "--lowpass 20 --angpix_ref 3.54 --threshold 0.05 --min_distance 100 "
            '--max_stddev_noise -1 --gpu "0:1:2:3" --pipeline_control AutoPick/job011/ '
            ">> AutoPick/job011/run.out 2>> AutoPick/job011/run.err && echo "
            "CtfFind/job003/micrographs_ctf.star >"
            " AutoPick/job011/coords_suffix_autopick.star & ",
        )


if __name__ == "__main__":
    unittest.main()
