import unittest
import os
import shutil
import tempfile

from pipeliner_tests import test_data
from pipeliner_tests import generic_tests
from pipeliner.data_structure import NODES


class ManualPickTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_get_command_basic(self):
        generic_tests.general_get_command_test(
            self,
            "ManualPick",
            "manualpick.job",
            4,
            {"CtfFind/job003/micrographs_ctf.star": NODES["Mics"]},
            {
                "coords_suffix_manualpick.star": NODES["Mic coords"],
                "micrographs_selected.star": NODES["Mics"],
            },
            "`which relion_manualpick` --i CtfFind/job003/micrographs_ctf.star"
            " --odir ManualPick/job004/ --pickname manualpick --allow_save"
            " --fast_save --selection ManualPick/job004/micrographs_selected.star"
            " --scale 0.25 --sigma_contrast 3 --black 0 --white 0 --lowpass 20 "
            "--angpix 0.885 --ctf_scale 1 --particle_diameter 200"
            " --pipeline_control ManualPick/job004/ >> "
            "ManualPick/job004/run.out 2>> ManualPick/job004/run.err && echo"
            " CtfFind/job003/micrographs_ctf.star > "
            "ManualPick/job004/coords_suffix_manualpick.star & ",
        )

    def test_get_command_jobstar(self):
        generic_tests.general_get_command_test(
            self,
            "ManualPick",
            "manualpick_job.star",
            4,
            {"CtfFind/job003/micrographs_ctf.star": NODES["Mics"]},
            {
                "coords_suffix_manualpick.star": NODES["Mic coords"],
                "micrographs_selected.star": NODES["Mics"],
            },
            "`which relion_manualpick` --i CtfFind/job003/micrographs_ctf.star"
            " --odir ManualPick/job004/ --pickname manualpick --allow_save"
            " --fast_save --selection ManualPick/job004/micrographs_selected.star"
            " --scale 0.25 --sigma_contrast 3 --black 0 --white 0 --lowpass 20 "
            "--angpix 0.885 --ctf_scale 1 --particle_diameter 200"
            " --pipeline_control ManualPick/job004/ >> "
            "ManualPick/job004/run.out 2>> ManualPick/job004/run.err && echo"
            " CtfFind/job003/micrographs_ctf.star > "
            "ManualPick/job004/coords_suffix_manualpick.star & ",
        )

    def test_get_command_redblue(self):
        generic_tests.general_get_command_test(
            self,
            "ManualPick",
            "manualpick_color.job",
            4,
            {"CtfFind/job003/micrographs_ctf.star": NODES["Mics"]},
            {
                "coords_suffix_manualpick.star": NODES["Mic coords"],
                "micrographs_selected.star": NODES["Mics"],
            },
            "`which relion_manualpick` --i CtfFind/job003/micrographs_ctf.star"
            " --odir ManualPick/job004/ --pickname manualpick --allow_save"
            " --fast_save --selection ManualPick/job004/micrographs_selected.star"
            " --scale 0.25 --sigma_contrast 3 --black 0 --white 0 --lowpass 20 "
            "--angpix 0.885 --ctf_scale 1 --particle_diameter 200"
            " --color_label rlnParticleSelectZScore --blue 0 --red 2 "
            "--color_star fake_colorfile.star --pipeline_control ManualPick/job004/"
            " >> ManualPick/job004/run.out 2>> ManualPick/job004/run.err && echo "
            "CtfFind/job003/micrographs_ctf.star > "
            "ManualPick/job004/coords_suffix_manualpick.star & ",
        )


if __name__ == "__main__":
    unittest.main()
