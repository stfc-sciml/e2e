import unittest
import os
import shutil
import tempfile
import subprocess

from pipeliner.project_graph import ProjectGraph
from pipeliner_tests import test_data


class ExportTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

        dirs = [
            "Import/job001",
            "MotionCorr/job002",
            "CtfFind/job003",
        ]
        for d in dirs:
            subprocess.run(["mkdir", "-p", d])

        files = {
            "Import/job001/": os.path.join(
                self.test_data, "Pipelines/Import_job_pipeline.star"
            ),
            "MotionCorr/job002/": os.path.join(
                self.test_data, "Pipelines/MotionCorr_job_pipeline.star"
            ),
            "CtfFind/job003/": os.path.join(
                self.test_data, "Pipelines/CtfFind_job_pipeline.star"
            ),
        }
        for f in files:
            subprocess.run(["cp", files[f], f + "job_pipeline.star"])

        import_text = (
            " ++++ Executing new job on Fri May 29 11:25:32 2020"
            "\n++++ with the following command(s):"
            "\necho importing..."
            "\nrelion_star_loopheader rlnMicrographMovieName > "
            "Import/job001/movies.star ls -rt Micrographs/*.mrc >> "
            "Import/job001/movies.star \n++++"
        )

        with open("Import/job001/note.txt", "w") as note:
            note.write(import_text)

        mocorr_text = (
            " ++++ Executing new job on Fri Jul 10 13:59:07 2020"
            "\n++++ with the following command(s):"
            "`which relion_run_motioncorr` --i Import/job001/movies.star --o "
            "MotionCorr/job002/ --first_frame_sum 1 --last_frame_sum -1 --use_own"
            "  --j 24 --bin_factor 1 --bfactor 150 --dose_per_frame 1 "
            "--preexposure 0 --patch_x 1 --patch_y 1 --group_frames 3 "
            "--gainref Movies/gain.mrc --gain_rot 0 --gain_flip 0  "
            "--pipeline_control MotionCorr/job002/\n++++"
        )

        with open("MotionCorr/job002/note.txt", "w") as note:
            note.write(mocorr_text)

        ctffind_text = (
            " ++++ Executing new job on Fri Jul 10 14:00:58 2020"
            "\n++++ with the following command(s):"
            "\n`which relion_run_ctffind` --i "
            "MotionCorr/job002/corrected_micrographs.star --o CtfFind/job003/"
            " --Box 512 --ResMin 30 --ResMax 5 --dFMin 5000 --dFMax 50000 "
            "--FStep 500 --dAst 100 --use_gctf --gctf_exe /public/EM/Gctf/bin/Gctf"
            ' --ignore_ctffind_params --gpu ""  --pipeline_control '
            "CtfFind/job003/\n ++++"
        )

        with open("CtfFind/job003/note.txt", "w") as note:
            note.write(ctffind_text)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_export(self):
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_sched_noalias_pipeline.star"),
            self.test_dir,
        )
        pipeline = ProjectGraph(name="short_sched_noalias")
        pipeline.export_all_scheduled_jobs("export1")

        assert os.path.isfile("ExportJobs/export1/exported.star")
        assert os.path.isdir("ExportJobs/export1/Import/exp001")
        assert os.path.isdir("ExportJobs/export1/MotionCorr/exp002")
        assert os.path.isdir("ExportJobs/export1/CtfFind/exp003")

        with open("ExportJobs/export1/exported.star") as wrote:
            wrote_pipe = wrote.read()
        for f in ["Import/exp001", "MotionCorr/exp002", "CtfFind/exp003"]:
            assert f in wrote_pipe, f

        job_pipe_stars = {
            "Import/exp001": [
                "Import/exp001/       None            0            1",
                "Import/exp001/movies.star            0",
                "Import/exp001/ Import/exp001/movies.star",
            ],
            "MotionCorr/exp002": [
                "MotionCorr/exp002/       None            1            1",
                "MotionCorr/exp002/corrected_micrographs.star            1",
                "MotionCorr/exp002/logfile.pdf           13",
                "Import/job001/movies.star MotionCorr/exp002/",
                "MotionCorr/exp002/ MotionCorr/exp002/corrected_micrographs.star",
                "MotionCorr/exp002/ MotionCorr/exp002/logfile.pdf",
            ],
            "CtfFind/exp003": [
                "CtfFind/exp003/       None            2            1",
                "CtfFind/exp003/micrographs_ctf.star            1 ",
                "CtfFind/exp003/logfile.pdf           13",
                "MotionCorr/job002/corrected_micrographs.star CtfFind/exp003/",
            ],
        }
        for exp_line in job_pipe_stars:
            jp_star_path = os.path.join(
                "ExportJobs/export1/", exp_line + "/job_pipeline.star"
            )
            with open(jp_star_path) as job_pipe:
                job_pipe_data = job_pipe.read()
                for line in job_pipe_stars[exp_line]:
                    assert line in job_pipe_data, line

        with open("ExportJobs/export1/Import/exp001/note.txt") as note:
            note_data = note.read()
        assert "Import/job001" not in note_data
        assert "Import/exp001" in note_data

        with open("ExportJobs/export1/MotionCorr/exp002/note.txt") as note:
            note_data = note.read()
        assert "MotionCorr/job002" not in note_data
        assert "MotionCorr/exp002" in note_data

        with open("ExportJobs/export1/CtfFind/exp003/note.txt") as note:
            note_data = note.read()
        assert "CtfFind/job003" not in note_data
        assert "CtfFind/exp003/" in note_data

    def test_export_with_aliases(self):
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_sched_pipeline.star"),
            self.test_dir,
        )
        pipeline = ProjectGraph(name="short_sched")
        pipeline.export_all_scheduled_jobs("export1")

        assert os.path.isfile("ExportJobs/export1/exported.star")
        assert os.path.isdir("ExportJobs/export1/Import/exp001")
        assert os.path.isdir("ExportJobs/export1/MotionCorr/exp002")
        assert os.path.isdir("ExportJobs/export1/CtfFind/exp003")

        with open("ExportJobs/export1/exported.star") as wrote:
            wrote_pipe = wrote.read()
        for f in ["Import/exp001", "MotionCorr/exp002", "CtfFind/exp003"]:
            assert f in wrote_pipe, f

        job_pipe_stars = {
            "Import/exp001": [
                "Import/exp001/       None            0            1",
                "Import/exp001/movies.star            0",
                "Import/exp001/ Import/exp001/movies.star",
            ],
            "MotionCorr/exp002": [
                "MotionCorr/exp002/       None            1            1",
                "MotionCorr/exp002/corrected_micrographs.star            1",
                "MotionCorr/exp002/logfile.pdf           13",
                "Import/job001/movies.star MotionCorr/exp002/",
                "MotionCorr/exp002/ MotionCorr/exp002/corrected_micrographs.star",
                "MotionCorr/exp002/ MotionCorr/exp002/logfile.pdf",
            ],
            "CtfFind/exp003": [
                "CtfFind/exp003/       None            2            1",
                "CtfFind/exp003/micrographs_ctf.star            1 ",
                "CtfFind/exp003/logfile.pdf           13",
                "MotionCorr/job002/corrected_micrographs.star CtfFind/exp003/",
            ],
        }
        for exp_line in job_pipe_stars:
            jp_star_path = os.path.join(
                "ExportJobs/export1/", exp_line + "/job_pipeline.star"
            )
            with open(jp_star_path) as job_pipe:
                job_pipe_data = job_pipe.read()
                for line in job_pipe_stars[exp_line]:
                    assert line in job_pipe_data, line

        with open("ExportJobs/export1/Import/exp001/note.txt") as note:
            note_data = note.read()
        assert "Import/job001" not in note_data
        assert "Import/exp001" in note_data

        with open("ExportJobs/export1/MotionCorr/exp002/note.txt") as note:
            note_data = note.read()
        assert "MotionCorr/job002" not in note_data
        assert "MotionCorr/exp002" in note_data

        with open("ExportJobs/export1/CtfFind/exp003/note.txt") as note:
            note_data = note.read()
        assert "CtfFind/job003" not in note_data
        assert "CtfFind/exp003/" in note_data

    def test_export_nothing_to_export(self):
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_pipeline.star"),
            self.test_dir,
        )
        pipeline = ProjectGraph(name="short")
        pipeline.export_all_scheduled_jobs("export1")

    def test_import_jobs(self):
        # first export some jobs so there is something to import
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_sched_noalias_pipeline.star"),
            self.test_dir,
        )
        pipeline = ProjectGraph(name="short_sched_noalias")
        pipeline.export_all_scheduled_jobs("export1")

        assert os.path.isfile("ExportJobs/export1/exported.star")
        assert os.path.isdir("ExportJobs/export1/Import/exp001")
        assert os.path.isdir("ExportJobs/export1/MotionCorr/exp002")
        assert os.path.isdir("ExportJobs/export1/CtfFind/exp003")

        with open("ExportJobs/export1/exported.star") as wrote:
            wrote_pipe = wrote.read()
        for f in ["Import/exp001", "MotionCorr/exp002", "CtfFind/exp003"]:
            assert f in wrote_pipe, f

        job_pipe_stars = {
            "Import/exp001": [
                "Import/exp001/       None            0            1",
                "Import/exp001/movies.star            0",
                "Import/exp001/ Import/exp001/movies.star",
            ],
            "MotionCorr/exp002": [
                "MotionCorr/exp002/       None            1            1",
                "MotionCorr/exp002/corrected_micrographs.star            1",
                "MotionCorr/exp002/logfile.pdf           13",
                "Import/job001/movies.star MotionCorr/exp002/",
                "MotionCorr/exp002/ MotionCorr/exp002/corrected_micrographs.star",
                "MotionCorr/exp002/ MotionCorr/exp002/logfile.pdf",
            ],
            "CtfFind/exp003": [
                "CtfFind/exp003/       None            2            1",
                "CtfFind/exp003/micrographs_ctf.star            1 ",
                "CtfFind/exp003/logfile.pdf           13",
                "MotionCorr/job002/corrected_micrographs.star CtfFind/exp003/",
            ],
        }
        for exp_line in job_pipe_stars:
            jp_star_path = os.path.join(
                "ExportJobs/export1/", exp_line + "/job_pipeline.star"
            )
            with open(jp_star_path) as job_pipe:
                job_pipe_data = job_pipe.read()
                for line in job_pipe_stars[exp_line]:
                    assert line in job_pipe_data, line

        with open("ExportJobs/export1/Import/exp001/note.txt") as note:
            note_data = note.read()
        assert "Import/job001" not in note_data
        assert "Import/exp001" in note_data

        with open("ExportJobs/export1/MotionCorr/exp002/note.txt") as note:
            note_data = note.read()
        assert "MotionCorr/job002" not in note_data
        assert "MotionCorr/exp002" in note_data

        with open("ExportJobs/export1/CtfFind/exp003/note.txt") as note:
            note_data = note.read()
        assert "CtfFind/job003" not in note_data
        assert "CtfFind/exp003/" in note_data

        # now import the exported jobs
        pipeline.import_jobs("ExportJobs/export1/exported.star")

        pipeline.read()

        allnodes = [
            "Import/job001/movies.star",
            "MotionCorr/job002/corrected_micrographs.star",
            "MotionCorr/job002/logfile.pdf",
            "CtfFind/job003/micrographs_ctf.star",
            "CtfFind/job003/logfile.pdf",
            "Import/job004/movies.star",
            "Import/job001/movies.star",
            "MotionCorr/job005/corrected_micrographs.star",
            "MotionCorr/job005/logfile.pdf",
            "test.star",
            "CtfFind/job006/micrographs_ctf.star",
            "CtfFind/job006/logfile.pdf",
        ]
        allprocs = [
            "Import/job001/",
            "MotionCorr/job002/",
            "CtfFind/job003/",
            "Import/job004/",
            "MotionCorr/job005/",
            "CtfFind/job006/",
        ]

        nodelist_names = [x.name for x in pipeline.node_list]
        proclist_names = [x.name for x in pipeline.process_list]

        for n in allnodes:
            assert n in nodelist_names
        for p in allprocs:
            assert p in proclist_names

        new_dirs = [
            "Import/job004/",
            "MotionCorr/job005/",
            "CtfFind/job006/",
        ]
        new_files = [
            "job_pipeline.star",
            "note.txt",
        ]
        for nd in new_dirs:
            for nf in new_files:
                nff = nd + nf
                assert os.path.isfile(nff), nff

        jobs = {
            "Import": [1, 4],
            "MotionCorr": [2, 5],
            "CtfFind": [3, 6],
        }
        for j in jobs:
            assert os.path.isdir("{}/job{:03d}".format(j, jobs[j][0]))
            assert os.path.isdir("{}/job{:03d}".format(j, jobs[j][1]))
            for ft in ["note.txt", "job_pipeline.star"]:
                with open("{}/job{:03d}/{}".format(j, jobs[j][0], ft)) as old:
                    old_file = old.read()
                with open("{}/job{:03d}/{}".format(j, jobs[j][1], ft)) as new:
                    new_file = new.read()
                oldjob = "job{:03d}".format(jobs[j][0])
                newjob = "job{:03d}".format(jobs[j][1])

                assert new_file == old_file.replace(oldjob, newjob)
        oldprocs = [
            "Import/job001/       None            0            1",
            "MotionCorr/job002/       None            1            1",
            "CtfFind/job003/       None            2            1",
        ]
        newprocs = [
            "Import/job004/       None            0            1",
            "MotionCorr/job005/       None            1            1",
            "CtfFind/job006/       None            2            1",
        ]
        oldnodes = [
            "Import/job001/movies.star            0",
            "MotionCorr/job002/corrected_micrographs.star            1",
            "MotionCorr/job002/logfile.pdf           13",
            "CtfFind/job003/micrographs_ctf.star            1",
            "CtfFind/job003/logfile.pdf           13",
        ]
        newnodes = [
            "Import/job004/movies.star            0",
            "MotionCorr/job005/corrected_micrographs.star            1",
            "MotionCorr/job005/logfile.pdf           13",
            "test.star            1",
            "CtfFind/job006/micrographs_ctf.star            1",
            "CtfFind/job006/logfile.pdf           13",
        ]
        with open("short_sched_noalias_pipeline.star") as pipe:
            pipe_data = pipe.read()
        for node_proc in oldnodes + newnodes + oldprocs + newprocs:
            assert node_proc in pipe_data, node_proc


if __name__ == "__main__":
    unittest.main()
