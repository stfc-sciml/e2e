import unittest
import os
import shutil
import tempfile

from pipeliner.relion_jobs import job_factory
from pipeliner_tests import test_data
from pipeliner_tests import generic_tests
from pipeliner.data_structure import NODES


class MultiBodyTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")
        shutil.copy(
            os.path.join(self.test_data, "JobFiles/MultiBody/bodyfile.star"),
            self.test_dir,
        )
        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_get_scratch_env_var(self):
        # Ensure RELION_SCRATCH_DIR is unset to begin with
        os.environ["RELION_SCRATCH_DIR"] = ""

        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/MultiBody/multibody.job")
        )
        assert job.joboptions["scratch_dir"].defaultvalue == ""

        os.environ["RELION_SCRATCH_DIR"] = os.path.join(
            self.test_data, "fake_SCRATCH_dir"
        )
        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/MultiBody/multibody.job")
        )
        assert job.joboptions["scratch_dir"].defaultvalue == os.path.join(
            self.test_data, "fake_SCRATCH_dir"
        )

    def test_get_command_multibody_basic(self):
        generic_tests.general_get_command_test(
            self,
            "MultiBody",
            "multibody.job",
            12,
            {"Refine3D/job400/run_it025_optimiser.star": NODES["Optimiser"]},
            {
                "run_half1_body001_unfil.mrc": NODES["Halfmap"],
                "run_half1_body002_unfil.mrc": NODES["Halfmap"],
                "run_half1_body003_unfil.mrc": NODES["Halfmap"],
                "analyse_logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 16 `which relion_refine_mpi` "
            "--continue Refine3D/job400/run_it025_optimiser.star "
            "--o MultiBody/job012/run --solvent_correct_fsc "
            "--multibody_masks bodyfile.star --oversampling 1 "
            "--healpix_order 4 --auto_local_healpix_order 4 "
            '--offset_range 3 --offset_step 1.5 --j 8 --gpu "1:2"'
            " --dont_combine_weights_via_disc"
            " --pool 3 --pad 2 --skip_gridding --pipeline_control MultiBody/job012/ "
            ">> MultiBody/job012/run.out 2>> MultiBody/job012/run.err && "
            "`which relion_flex_analyse` --PCA_orient --model"
            " MultiBody/job012/run_model.star --data MultiBody/job012/run_data.star"
            " --bodies bodyfile.star --o MultiBody/job012/analyse --do_maps --k 3"
            " --pipeline_control MultiBody/job012/"
            " >> MultiBody/job012/run.out 2>> MultiBody/job012/run.err & ",
        )

    def test_get_command_multibody_jobstar(self):
        generic_tests.general_get_command_test(
            self,
            "MultiBody",
            "multibody_job.star",
            12,
            {"Refine3D/job400/run_it025_optimiser.star": NODES["Optimiser"]},
            {
                "run_half1_body001_unfil.mrc": NODES["Halfmap"],
                "run_half1_body002_unfil.mrc": NODES["Halfmap"],
                "run_half1_body003_unfil.mrc": NODES["Halfmap"],
                "analyse_logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 16 `which relion_refine_mpi` "
            "--continue Refine3D/job400/run_it025_optimiser.star "
            "--o MultiBody/job012/run --solvent_correct_fsc "
            "--multibody_masks bodyfile.star --oversampling 1 "
            "--healpix_order 4 --auto_local_healpix_order 4 "
            '--offset_range 3 --offset_step 1.5 --j 8 --gpu "1:2"'
            " --dont_combine_weights_via_disc"
            " --pool 3 --pad 2 --skip_gridding --pipeline_control MultiBody/job012/ "
            ">> MultiBody/job012/run.out 2>> MultiBody/job012/run.err && "
            "`which relion_flex_analyse` --PCA_orient --model"
            " MultiBody/job012/run_model.star --data MultiBody/job012/run_data.star"
            " --bodies bodyfile.star --o MultiBody/job012/analyse --do_maps --k 3"
            " --pipeline_control MultiBody/job012/"
            " >> MultiBody/job012/run.out 2>> MultiBody/job012/run.err & ",
        )

    def test_get_command_multibody_reconstruct_subtracted(self):
        generic_tests.general_get_command_test(
            self,
            "MultiBody",
            "multibody_rec_sub.job",
            12,
            {"Refine3D/job400/run_it025_optimiser.star": NODES["Optimiser"]},
            {
                "run_half1_body001_unfil.mrc": NODES["Halfmap"],
                "run_half1_body002_unfil.mrc": NODES["Halfmap"],
                "run_half1_body003_unfil.mrc": NODES["Halfmap"],
                "analyse_logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 16 `which relion_refine_mpi` "
            "--continue Refine3D/job400/run_it025_optimiser.star "
            "--o MultiBody/job012/run --solvent_correct_fsc "
            "--multibody_masks bodyfile.star --oversampling 1 "
            "--healpix_order 4 --auto_local_healpix_order 4 "
            "--offset_range 3 --offset_step 1.5 --reconstruct_subtracted_bodies"
            ' --j 8 --gpu "1:2" --dont_combine_weights_via_disc'
            " --pool 3 --pad 2 --skip_gridding --pipeline_control MultiBody/job012/ "
            ">> MultiBody/job012/run.out 2>> MultiBody/job012/run.err && "
            "`which relion_flex_analyse` --PCA_orient --model"
            " MultiBody/job012/run_model.star --data MultiBody/job012/run_data.star"
            " --bodies bodyfile.star --o MultiBody/job012/analyse --do_maps --k 3"
            " --pipeline_control MultiBody/job012/"
            " >> MultiBody/job012/run.out 2>> MultiBody/job012/run.err & ",
        )

    def test_get_command_multibody_no_flexanalysis(self):
        generic_tests.general_get_command_test(
            self,
            "MultiBody",
            "multibody_noflex.job",
            12,
            {"Refine3D/job400/run_it025_optimiser.star": NODES["Optimiser"]},
            {
                "run_half1_body001_unfil.mrc": NODES["Halfmap"],
                "run_half1_body002_unfil.mrc": NODES["Halfmap"],
                "run_half1_body003_unfil.mrc": NODES["Halfmap"],
            },
            "mpirun -n 16 `which relion_refine_mpi` "
            "--continue Refine3D/job400/run_it025_optimiser.star "
            "--o MultiBody/job012/run --solvent_correct_fsc "
            "--multibody_masks bodyfile.star --oversampling 1 "
            "--healpix_order 4 --auto_local_healpix_order 4 "
            "--offset_range 3 --offset_step 1.5 --reconstruct_subtracted_bodies"
            ' --j 8 --gpu "1:2" --dont_combine_weights_via_disc'
            " --pool 3 --pad 2 --skip_gridding --pipeline_control MultiBody/job012/ "
            ">> MultiBody/job012/run.out 2>> MultiBody/job012/run.err & ",
        )

    def test_get_command_multibody_separate_oneigen(self):
        generic_tests.general_get_command_test(
            self,
            "MultiBody",
            "multibody_sep_eigen.job",
            12,
            {"Refine3D/job400/run_it025_optimiser.star": NODES["Optimiser"]},
            {
                "run_half1_body001_unfil.mrc": NODES["Halfmap"],
                "run_half1_body002_unfil.mrc": NODES["Halfmap"],
                "run_half1_body003_unfil.mrc": NODES["Halfmap"],
                "analyse_eval1_select_min-15_max10.star": NODES["Part data"],
                "analyse_logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 16 `which relion_refine_mpi` "
            "--continue Refine3D/job400/run_it025_optimiser.star "
            "--o MultiBody/job012/run --solvent_correct_fsc "
            "--multibody_masks bodyfile.star --oversampling 1 "
            "--healpix_order 4 --auto_local_healpix_order 4 "
            '--offset_range 3 --offset_step 1.5 --j 8 --gpu "1:2"'
            " --dont_combine_weights_via_disc"
            " --pool 3 --pad 2 --skip_gridding --pipeline_control MultiBody/job012/ "
            ">> MultiBody/job012/run.out 2>> MultiBody/job012/run.err && "
            "`which relion_flex_analyse` --PCA_orient --model"
            " MultiBody/job012/run_model.star --data MultiBody/job012/run_data.star"
            " --bodies bodyfile.star --o MultiBody/job012/analyse --do_maps --k 3"
            " --select_eigenvalue 1 --select_eigenvalue_min -15.0"
            " --select_eigenvalue_max 10.0 --pipeline_control MultiBody/job012/"
            " >> MultiBody/job012/run.out 2>> MultiBody/job012/run.err & ",
        )

    def test_get_command_multibody_separate_oneigen_small(self):
        generic_tests.general_get_command_test(
            self,
            "MultiBody",
            "multibody_sep_eigen_small.job",
            12,
            {"Refine3D/job400/run_it025_optimiser.star": NODES["Optimiser"]},
            {
                "run_half1_body001_unfil.mrc": NODES["Halfmap"],
                "run_half1_body002_unfil.mrc": NODES["Halfmap"],
                "run_half1_body003_unfil.mrc": NODES["Halfmap"],
                "analyse_logfile.pdf": NODES["PdfLogfile"],
                "analyse_eval1_select_min-0p25_max0p5.star": NODES["Part data"],
            },
            "mpirun -n 16 `which relion_refine_mpi` "
            "--continue Refine3D/job400/run_it025_optimiser.star "
            "--o MultiBody/job012/run --solvent_correct_fsc "
            "--multibody_masks bodyfile.star --oversampling 1 "
            "--healpix_order 4 --auto_local_healpix_order 4 "
            '--offset_range 3 --offset_step 1.5 --j 8 --gpu "1:2"'
            " --dont_combine_weights_via_disc"
            " --pool 3 --pad 2 --skip_gridding --pipeline_control MultiBody/job012/ "
            ">> MultiBody/job012/run.out 2>> MultiBody/job012/run.err && "
            "`which relion_flex_analyse` --PCA_orient --model"
            " MultiBody/job012/run_model.star --data MultiBody/job012/run_data.star"
            " --bodies bodyfile.star --o MultiBody/job012/analyse --do_maps --k 3"
            " --select_eigenvalue 1 --select_eigenvalue_min -0.25"
            " --select_eigenvalue_max 0.5 --pipeline_control MultiBody/job012/"
            " >> MultiBody/job012/run.out 2>> MultiBody/job012/run.err & ",
        )

    def test_get_command_multibody_different_sampling(self):
        generic_tests.general_get_command_test(
            self,
            "MultiBody",
            "multibody_diff_samp.job",
            12,
            {"Refine3D/job400/run_it025_optimiser.star": NODES["Optimiser"]},
            {
                "run_half1_body001_unfil.mrc": NODES["Halfmap"],
                "run_half1_body002_unfil.mrc": NODES["Halfmap"],
                "run_half1_body003_unfil.mrc": NODES["Halfmap"],
                "analyse_logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 16 `which relion_refine_mpi` "
            "--continue Refine3D/job400/run_it025_optimiser.star "
            "--o MultiBody/job012/run --solvent_correct_fsc "
            "--multibody_masks bodyfile.star --oversampling 1 "
            "--healpix_order 2 --auto_local_healpix_order 2 "
            '--offset_range 3 --offset_step 1.5 --j 8 --gpu "1:2"'
            " --dont_combine_weights_via_disc"
            " --pool 3 --pad 2 --skip_gridding --pipeline_control MultiBody/job012/ "
            ">> MultiBody/job012/run.out 2>> MultiBody/job012/run.err && "
            "`which relion_flex_analyse` --PCA_orient --model"
            " MultiBody/job012/run_model.star --data MultiBody/job012/run_data.star"
            " --bodies bodyfile.star --o MultiBody/job012/analyse --do_maps --k 3"
            " --pipeline_control MultiBody/job012/"
            " >> MultiBody/job012/run.out 2>> MultiBody/job012/run.err & ",
        )

    def test_get_command_multibody_noMPI(self):
        generic_tests.general_get_command_test(
            self,
            "MultiBody",
            "multibody_noMPI.job",
            12,
            {"Refine3D/job400/run_it025_optimiser.star": NODES["Optimiser"]},
            {
                "run_half1_body001_unfil.mrc": NODES["Halfmap"],
                "run_half1_body002_unfil.mrc": NODES["Halfmap"],
                "run_half1_body003_unfil.mrc": NODES["Halfmap"],
                "analyse_logfile.pdf": NODES["PdfLogfile"],
            },
            "`which relion_refine` "
            "--continue Refine3D/job400/run_it025_optimiser.star "
            "--o MultiBody/job012/run --solvent_correct_fsc "
            "--multibody_masks bodyfile.star --oversampling 1 "
            "--healpix_order 4 --auto_local_healpix_order 4 "
            '--offset_range 3 --offset_step 1.5 --j 16 --gpu "1:2"'
            " --dont_combine_weights_via_disc"
            " --pool 3 --pad 2 --skip_gridding --pipeline_control MultiBody/job012/ "
            ">> MultiBody/job012/run.out 2>> MultiBody/job012/run.err && "
            "`which relion_flex_analyse` --PCA_orient --model"
            " MultiBody/job012/run_model.star --data MultiBody/job012/run_data.star"
            " --bodies bodyfile.star --o MultiBody/job012/analyse --do_maps --k 3"
            " --pipeline_control MultiBody/job012/"
            " >> MultiBody/job012/run.out 2>> MultiBody/job012/run.err & ",
        )


if __name__ == "__main__":
    unittest.main()
