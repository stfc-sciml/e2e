import unittest
import os
import shutil
import tempfile

from pipeliner.relion_jobs import job_factory
from pipeliner_tests import test_data
from pipeliner_tests import generic_tests
from pipeliner.data_structure import NODES


class Class2DTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_get_scratch_env_var(self):
        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/Class2D/class2D_basic.job")
        )
        assert job.joboptions["scratch_dir"].defaultvalue == ""

        os.environ["RELION_SCRATCH_DIR"] = os.path.join(
            self.test_data, "fake_SCRATCH_dir"
        )
        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/Class2D/class2D_basic.job")
        )
        assert job.joboptions["scratch_dir"].defaultvalue == os.path.join(
            self.test_data, "fake_SCRATCH_dir"
        )

    def test_get_command_class2D_basic(self):
        generic_tests.general_get_command_test(
            self,
            "Class2D",
            "class2D_basic.job",
            8,
            {"Extract/job007/particles.star": NODES["Part data"]},
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Extract/job007/particles.star"
            " --o Class2D/job008/run --dont_combine_weights_via_disc"
            " --preread_images --pool 30 --pad 2 --ctf --iter 25 --tau2_fudge 2"
            " --particle_diameter 200 --K 50 --flatten_solvent --zero_mask"
            " --oversampling 1 --psi_step 12.0 --offset_range 5 --offset_step 4.0"
            ' --norm --scale --j 6 --gpu "0:1:2:3" --pipeline_control Class2D/job008/'
            " >> Class2D/job008/run.out 2>> Class2D/job008/run.err & ",
        )

    def test_get_command_class2D_basic_jobstar(self):
        generic_tests.general_get_command_test(
            self,
            "Class2D",
            "class2D_job.star",
            8,
            {"Extract/job007/particles.star": NODES["Part data"]},
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Extract/job007/particles.star"
            " --o Class2D/job008/run --dont_combine_weights_via_disc"
            " --preread_images --pool 30 --pad 2 --ctf --iter 25 --tau2_fudge 2"
            " --particle_diameter 200 --K 50 --flatten_solvent --zero_mask"
            " --oversampling 1 --psi_step 12.0 --offset_range 5 --offset_step 4.0"
            ' --norm --scale --j 6 --gpu "0:1:2:3" --pipeline_control Class2D/job008/'
            " >> Class2D/job008/run.out 2>> Class2D/job008/run.err & ",
        )

    def test_get_command_class2D_scratch_comb(self):
        generic_tests.general_get_command_test(
            self,
            "Class2D",
            "class2D_scratch_comb.job",
            8,
            {"Extract/job007/particles.star": NODES["Part data"]},
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Extract/job007/particles.star"
            " --o Class2D/job008/run --scratch_dir Fake_scratch_dir"
            " --pool 30 --pad 2 --ctf --iter 25 --tau2_fudge 2"
            " --particle_diameter 200 --K 50 --flatten_solvent --zero_mask"
            " --oversampling 1 --psi_step 12.0 --offset_range 5 --offset_step 4.0"
            ' --norm --scale --j 6 --gpu "0:1:2:3" --pipeline_control Class2D/job008/ '
            ">> Class2D/job008/run.out 2>> Class2D/job008/run.err & ",
        )

    def test_get_command_class2D_corsesample(self):
        generic_tests.general_get_command_test(
            self,
            "Class2D",
            "class2D_coarsesample.job",
            8,
            {"Extract/job007/particles.star": NODES["Part data"]},
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Extract/job007/particles.star"
            " --o Class2D/job008/run --dont_combine_weights_via_disc"
            " --preread_images --pool 30 --pad 2 --ctf --iter 25 --tau2_fudge 2"
            " --particle_diameter 200 --K 50 --flatten_solvent --zero_mask"
            " --oversampling 1 --psi_step 12.0 --offset_range 5 --offset_step 4.0"
            ' --allow_coarser_sampling --norm --scale --j 6 --gpu "0:1:2:3" '
            "--pipeline_control Class2D/job008/ >> "
            "Class2D/job008/run.out 2>> Class2D/job008/run.err & ",
        )

    def test_get_command_class2D_fastss_nozero(self):
        generic_tests.general_get_command_test(
            self,
            "Class2D",
            "class2D_fastss_nozero.job",
            8,
            {"Extract/job007/particles.star": NODES["Part data"]},
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Extract/job007/particles.star"
            " --o Class2D/job008/run --dont_combine_weights_via_disc"
            " --preread_images --pool 30 --pad 2 --ctf --iter 25 --tau2_fudge 2"
            " --particle_diameter 200 --fast_subsets --K 50 --flatten_solvent"
            " --oversampling 1 --psi_step 12.0 --offset_range 5 --offset_step 4.0"
            ' --norm --scale --j 6 --gpu "0:1:2:3" --pipeline_control Class2D/job008/'
            " >> Class2D/job008/run.out 2>> Class2D/job008/run.err & ",
        )

    def test_get_command_class2D_higres10(self):
        generic_tests.general_get_command_test(
            self,
            "Class2D",
            "class2D_highres10.job",
            8,
            {"Extract/job007/particles.star": NODES["Part data"]},
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Extract/job007/particles.star"
            " --o Class2D/job008/run --dont_combine_weights_via_disc"
            " --preread_images --pool 30 --pad 2 --ctf --iter 25 --tau2_fudge 2"
            " --particle_diameter 200 --K 50 --flatten_solvent --zero_mask"
            " --strict_highres_exp 10.0 --oversampling 1 --psi_step 12.0 --offset_range"
            ' 5 --offset_step 4.0 --norm --scale --j 6 --gpu "0:1:2:3" '
            "--high_res_10_this_one --pipeline_control Class2D/job008/"
            " >> Class2D/job008/run.out 2>> Class2D/job008/run.err & ",
        )

    def test_get_command_class2D_helical(self):
        generic_tests.general_get_command_test(
            self,
            "Class2D",
            "class2D_helical.job",
            8,
            {"Extract/job007/particles.star": NODES["Part data"]},
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Extract/job007/particles.star"
            " --o Class2D/job008/run --dont_combine_weights_via_disc"
            " --preread_images --pool 30 --pad 2 --ctf --iter 25 --tau2_fudge 2"
            " --particle_diameter 200 --K 50 --flatten_solvent --zero_mask"
            " --oversampling 1 --psi_step 12.0 --offset_range 5 --offset_step 4.0"
            " --helical_outer_diameter 200 --bimodal_psi --sigma_psi 2.0"
            " --helix --helical_rise_initial 4.75 --norm --scale --j 6 --gpu"
            ' "0:1:2:3" --pipeline_control Class2D/job008/ >> Class2D/job008/run.out'
            " 2>> Class2D/job008/run.err & ",
        )

    def test_get_command_class2D_helical_norestrict(self):
        generic_tests.general_get_command_test(
            self,
            "Class2D",
            "class2D_helical_norestrict.job",
            8,
            {"Extract/job007/particles.star": NODES["Part data"]},
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Extract/job007/particles.star"
            " --o Class2D/job008/run --dont_combine_weights_via_disc"
            " --preread_images --pool 30 --pad 2 --ctf --iter 25 --tau2_fudge 2"
            " --particle_diameter 200 --K 50 --flatten_solvent --zero_mask"
            " --oversampling 1 --psi_step 12.0 --offset_range 5 --offset_step 4.0"
            " --helical_outer_diameter 200 --bimodal_psi --sigma_psi 2.0"
            ' --norm --scale --j 6 --gpu "0:1:2:3" --pipeline_control Class2D/job008/'
            " >> Class2D/job008/run.out 2>> Class2D/job008/run.err & ",
        )

    def test_get_command_class2D_nogpu_nompi(self):
        generic_tests.general_get_command_test(
            self,
            "Class2D",
            "class2D_nogpu_nompi.job",
            8,
            {"Extract/job007/particles.star": NODES["Part data"]},
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
            },
            "`which relion_refine` --i Extract/job007/particles.star"
            " --o Class2D/job008/run --dont_combine_weights_via_disc"
            " --preread_images --pool 30 --pad 2 --ctf --iter 25 --tau2_fudge 2"
            " --particle_diameter 200 --K 50 --flatten_solvent --zero_mask"
            " --oversampling 1 --psi_step 12.0 --offset_range 5 --offset_step 4.0"
            " --norm --scale --j 6 --pipeline_control Class2D/job008/"
            " >> Class2D/job008/run.out 2>> Class2D/job008/run.err & ",
        )

    def test_get_command_class2D_continue(self):
        generic_tests.general_get_command_test(
            self,
            "Class2D",
            "class2D_continue.job",
            8,
            {},
            {
                "run_ct23_it025_data.star": NODES["Part data"],
                "run_ct23_it025_model.star": NODES["Model"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --continue run_it023_optimiser.star"
            " --o Class2D/job008/run_ct23 --dont_combine_weights_via_disc"
            " --preread_images --pool 30 --pad 2 --iter 25 --tau2_fudge 2"
            " --particle_diameter 200"
            " --oversampling 1 --psi_step 12.0 --offset_range 5 --offset_step 4.0"
            ' --j 6 --gpu "0:1:2:3" --pipeline_control Class2D/job008/'
            " >> Class2D/job008/run.out 2>> Class2D/job008/run.err & ",
        )

    def test_get_command_class2D_continue_badfile(self):
        with self.assertRaises(ValueError):
            generic_tests.general_get_command_test(
                self, "Class2D", "class2D_continue_badfile.job", 8, 1, 2, "",
            )


if __name__ == "__main__":
    unittest.main()
