import unittest
import os
import shutil
import tempfile

from pipeliner.relion_jobs import job_factory
from pipeliner_tests import test_data
from pipeliner_tests import generic_tests
from pipeliner.data_structure import NODES


class CtfFindTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_get_ctffind_env_var(self):
        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/CtfFind/ctffind_noexe_run.job")
        )
        assert (
            job.joboptions["fn_ctffind_exe"].defaultvalue
            == "Enter path to CTFFIND executable"
        )

        os.environ["RELION_CTFFIND_EXECUTABLE"] = os.path.join(
            self.test_data, "fake_ctffind.exe"
        )
        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/CtfFind/ctffind_noexe_run.job")
        )
        assert job.joboptions["fn_ctffind_exe"].defaultvalue == os.path.join(
            self.test_data, "fake_ctffind.exe"
        )

    def test_get_gctf_env_var(self):
        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/CtfFind/ctffind_noexe_run.job")
        )
        assert (
            job.joboptions["fn_gctf_exe"].defaultvalue
            == "Enter path to GCTF executable"
        )

        os.environ["RELION_GCTF_EXECUTABLE"] = os.path.join(
            self.test_data, "fake_gctf.exe"
        )
        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/CtfFind/ctffind_noexe_run.job")
        )
        assert job.joboptions["fn_gctf_exe"].defaultvalue == os.path.join(
            self.test_data, "fake_gctf.exe"
        )

    def test_get_command_ctffind(self):
        generic_tests.general_get_command_test(
            self,
            "CtfFind",
            "ctffind_ctffind_run.job",
            3,
            {"MotionCorr/job002/corrected_micrographs.star": NODES["Mics"]},
            {
                "micrographs_ctf.star": NODES["Mics"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 6 `which relion_run_ctffind_mpi` --i "
            "MotionCorr/job002/corrected_micrographs.star --o CtfFind/job003/"
            " --Box 512 --ResMin 30 --ResMax 5 --dFMin 5000 --dFMax 50000 "
            "--FStep 500 --dAst 100 --ctffind_exe /public/EM/ctffind/ctffind.exe"
            " --ctfWin -1 --is_ctffind4 --fast_search --use_given_ps"
            " --pipeline_control CtfFind/job003/"
            " >> CtfFind/job003/run.out 2>> CtfFind/job003/run.err & ",
        )

    def test_get_command_ctffind_jobstar(self):
        generic_tests.general_get_command_test(
            self,
            "CtfFind",
            "ctffind_job.star",
            3,
            {"MotionCorr/job002/corrected_micrographs.star": NODES["Mics"]},
            {
                "micrographs_ctf.star": NODES["Mics"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 6 `which relion_run_ctffind_mpi` --i "
            "MotionCorr/job002/corrected_micrographs.star --o CtfFind/job003/"
            " --Box 512 --ResMin 30 --ResMax 5 --dFMin 5000 --dFMax 50000 "
            "--FStep 500 --dAst 100 --ctffind_exe /public/EM/ctffind/ctffind.exe"
            " --ctfWin -1 --is_ctffind4 --fast_search --use_given_ps"
            " --pipeline_control CtfFind/job003/"
            " >> CtfFind/job003/run.out 2>> CtfFind/job003/run.err & ",
        )

    def test_get_command_ctffind_continue_jobstar(self):
        generic_tests.general_get_command_test(
            self,
            "CtfFind",
            "ctffind_continue_job.star",
            3,
            {"MotionCorr/job002/corrected_micrographs.star": NODES["Mics"]},
            {
                "micrographs_ctf.star": NODES["Mics"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 6 `which relion_run_ctffind_mpi` --i "
            "MotionCorr/job002/corrected_micrographs.star --o CtfFind/job003/"
            " --Box 512 --ResMin 30 --ResMax 5 --dFMin 5000 --dFMax 50000 "
            "--FStep 500 --dAst 100 --ctffind_exe /public/EM/ctffind/ctffind.exe"
            " --ctfWin -1 --is_ctffind4 --fast_search --use_given_ps"
            " --only_do_unfinished --pipeline_control CtfFind/job003/"
            " >> CtfFind/job003/run.out 2>> CtfFind/job003/run.err & ",
        )

    def test_is_continue_works(self):
        generic_tests.general_get_command_test(
            self,
            "CtfFind",
            "ctffind_continue_run.job",
            3,
            {"MotionCorr/job002/corrected_micrographs.star": NODES["Mics"]},
            {
                "micrographs_ctf.star": NODES["Mics"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 6 `which relion_run_ctffind_mpi` --i "
            "MotionCorr/job002/corrected_micrographs.star --o CtfFind/job003/"
            " --Box 512 --ResMin 30 --ResMax 5 --dFMin 5000 --dFMax 50000 "
            "--FStep 500 --dAst 100 --ctffind_exe /public/EM/ctffind/ctffind.exe"
            " --ctfWin -1 --is_ctffind4 --fast_search --use_given_ps"
            " --only_do_unfinished --pipeline_control CtfFind/job003/ "
            ">> CtfFind/job003/run.out 2>> CtfFind/job003/run.err & ",
        )

    def test_get_command_gctf(self):
        generic_tests.general_get_command_test(
            self,
            "CtfFind",
            "ctffind_gctf_run.job",
            3,
            {"MotionCorr/job002/corrected_micrographs.star": NODES["Mics"]},
            {
                "micrographs_ctf.star": NODES["Mics"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 6 `which relion_run_ctffind_mpi` --i "
            "MotionCorr/job002/corrected_micrographs.star --o CtfFind/job003/"
            " --Box 512 --ResMin 30 --ResMax 5 --dFMin 5000 --dFMax 50000 "
            "--FStep 500 --dAst 100 --use_gctf --gctf_exe"
            ' /public/EM/Gctf/bin/Gctf --ignore_ctffind_params --gpu "0:1"'
            " --pipeline_control CtfFind/job003/"
            " >> CtfFind/job003/run.out 2>> CtfFind/job003/run.err & ",
        )

    def test_get_command_nonmpi(self):
        generic_tests.general_get_command_test(
            self,
            "CtfFind",
            "ctffind_nompi_run.job",
            3,
            {"MotionCorr/job002/corrected_micrographs.star": NODES["Mics"]},
            {
                "micrographs_ctf.star": NODES["Mics"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "`which relion_run_ctffind` --i "
            "MotionCorr/job002/corrected_micrographs.star --o CtfFind/job003/"
            " --Box 512 --ResMin 30 --ResMax 5 --dFMin 5000 --dFMax 50000 "
            "--FStep 500 --dAst 100 --ctffind_exe /public/EM/ctffind/ctffind.exe"
            " --ctfWin -1 --is_ctffind4 --fast_search --use_given_ps"
            " --pipeline_control CtfFind/job003/"
            " >> CtfFind/job003/run.out 2>> CtfFind/job003/run.err & ",
        )

    def test_get_command_nofile(self):
        with self.assertRaises(ValueError):
            generic_tests.general_get_command_test(
                self, "CtfFind", "ctffind_ctffind_nofile.job", 3, 1, 2, " ",
            )


if __name__ == "__main__":
    unittest.main()
