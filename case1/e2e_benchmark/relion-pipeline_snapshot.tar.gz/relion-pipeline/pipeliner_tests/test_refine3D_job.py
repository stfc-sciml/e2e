import unittest
import os
import shutil
import tempfile

from pipeliner.relion_jobs import job_factory
from pipeliner_tests import test_data
from pipeliner_tests import generic_tests
from pipeliner.data_structure import NODES


class Refine3DTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_get_scratch_env_var(self):
        # Ensure RELION_SCRATCH_DIR is unset to begin with
        os.environ["RELION_SCRATCH_DIR"] = ""

        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/Refine3D/refine3D.job")
        )
        assert job.joboptions["scratch_dir"].defaultvalue == ""

        os.environ["RELION_SCRATCH_DIR"] = os.path.join(
            self.test_data, "fake_SCRATCH_dir"
        )
        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/Refine3D/refine3D.job")
        )
        assert job.joboptions["scratch_dir"].defaultvalue == os.path.join(
            self.test_data, "fake_SCRATCH_dir"
        )

    def test_get_command_refine3D_basic(self):
        generic_tests.general_get_command_test(
            self,
            "Refine3D",
            "refine3D.job",
            12,
            {
                "Extract/job018/particles.star": NODES["Part data"],
                "Class3D/job016/run_it025_class001_box256.mrc": NODES["3D refs"],
            },
            {
                "run_data.star": NODES["Part data"],
                "run_half1_class001_unfil.mrc": NODES["Halfmap"],
                "run_class001.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Extract/job018/particles.star "
            "--o Refine3D/job012/run --auto_refine --split_random_halves "
            "--ref Class3D/job016/run_it025_class001_box256.mrc --firstiter_cc "
            "--ini_high 50 --dont_combine_weights_via_disc --preread_images --pool 30"
            " --pad 2 --skip_gridding --ctf --ctf_corrected_ref --particle_diameter"
            " 200 --flatten_solvent --zero_mask --oversampling 1 --healpix_order 2"
            " --auto_local_healpix_order 4 --offset_range 5 --offset_step 2 --sym D2"
            ' --low_resol_join_halves 40 --norm --scale --j 6 --gpu "4:5:6:7"'
            " --pipeline_control Refine3D/job012/"
            " >> Refine3D/job012/run.out 2>> Refine3D/job012/run.err & ",
        )

    def test_get_command_refine3D_jobstar(self):
        generic_tests.general_get_command_test(
            self,
            "Refine3D",
            "refine3d_job.star",
            12,
            {
                "Extract/job018/particles.star": NODES["Part data"],
                "Class3D/job016/run_it025_class001_box256.mrc": NODES["3D refs"],
            },
            {
                "run_data.star": NODES["Part data"],
                "run_half1_class001_unfil.mrc": NODES["Halfmap"],
                "run_class001.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Extract/job018/particles.star "
            "--o Refine3D/job012/run --auto_refine --split_random_halves "
            "--ref Class3D/job016/run_it025_class001_box256.mrc --firstiter_cc "
            "--ini_high 50 --dont_combine_weights_via_disc --preread_images --pool 30"
            " --pad 2 --skip_gridding --ctf --ctf_corrected_ref --particle_diameter"
            " 200 --flatten_solvent --zero_mask --oversampling 1 --healpix_order 2"
            " --auto_local_healpix_order 4 --offset_range 5 --offset_step 2 --sym D2"
            ' --low_resol_join_halves 40 --norm --scale --j 6 --gpu "4:5:6:7"'
            " --pipeline_control Refine3D/job012/"
            " >> Refine3D/job012/run.out 2>> Refine3D/job012/run.err & ",
        )

    def test_get_command_refine3D_samplingcheck(self):
        generic_tests.general_get_command_test(
            self,
            "Refine3D",
            "refine3D_sampling.job",
            12,
            {
                "Extract/job018/particles.star": NODES["Part data"],
                "Class3D/job016/run_it025_class001_box256.mrc": NODES["3D refs"],
            },
            {
                "run_data.star": NODES["Part data"],
                "run_half1_class001_unfil.mrc": NODES["Halfmap"],
                "run_class001.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Extract/job018/particles.star "
            "--o Refine3D/job012/run --auto_refine --split_random_halves "
            "--ref Class3D/job016/run_it025_class001_box256.mrc --firstiter_cc "
            "--ini_high 50 --dont_combine_weights_via_disc --preread_images --pool 30"
            " --pad 2 --skip_gridding --ctf --ctf_corrected_ref --particle_diameter"
            " 200 --flatten_solvent --zero_mask --oversampling 1 --healpix_order 4"
            " --auto_local_healpix_order 7 --offset_range 5 --offset_step 2 --sym D2"
            ' --low_resol_join_halves 40 --norm --scale --j 6 --gpu "4:5:6:7"'
            " --pipeline_control Refine3D/job012/"
            " >> Refine3D/job012/run.out 2>> Refine3D/job012/run.err & ",
        )

    def test_get_command_refine3D_mask(self):
        generic_tests.general_get_command_test(
            self,
            "Refine3D",
            "refine3D_mask.job",
            12,
            {
                "Extract/job018/particles.star": NODES["Part data"],
                "Class3D/job016/run_it025_class001_box256.mrc": NODES["3D refs"],
                "MaskCreate/job200/mask.mrc": NODES["Mask"],
            },
            {
                "run_data.star": NODES["Part data"],
                "run_half1_class001_unfil.mrc": NODES["Halfmap"],
                "run_class001.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Extract/job018/particles.star "
            "--o Refine3D/job012/run --auto_refine --split_random_halves "
            "--ref Class3D/job016/run_it025_class001_box256.mrc --firstiter_cc "
            "--ini_high 50 --dont_combine_weights_via_disc --preread_images --pool 30"
            " --pad 2 --skip_gridding --ctf --ctf_corrected_ref --particle_diameter"
            " 200 --flatten_solvent --zero_mask "
            "--solvent_mask MaskCreate/job200/mask.mrc"
            " --oversampling 1 --healpix_order 2 --auto_local_healpix_order 4 "
            "--offset_range 5 --offset_step 2 --sym D2"
            ' --low_resol_join_halves 40 --norm --scale --j 6 --gpu "4:5:6:7"'
            " --pipeline_control Refine3D/job012/"
            " >> Refine3D/job012/run.out 2>> Refine3D/job012/run.err & ",
        )

    def test_get_command_refine3D_mask_solvflat(self):
        generic_tests.general_get_command_test(
            self,
            "Refine3D",
            "refine3D_mask_solvflat.job",
            12,
            {
                "Extract/job018/particles.star": NODES["Part data"],
                "Class3D/job016/run_it025_class001_box256.mrc": NODES["3D refs"],
                "MaskCreate/job200/mask.mrc": NODES["Mask"],
            },
            {
                "run_data.star": NODES["Part data"],
                "run_half1_class001_unfil.mrc": NODES["Halfmap"],
                "run_class001.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Extract/job018/particles.star "
            "--o Refine3D/job012/run --auto_refine --split_random_halves "
            "--ref Class3D/job016/run_it025_class001_box256.mrc --firstiter_cc "
            "--ini_high 50 --dont_combine_weights_via_disc --preread_images --pool 30"
            " --pad 2 --skip_gridding --ctf --ctf_corrected_ref --particle_diameter"
            " 200 --flatten_solvent --zero_mask "
            "--solvent_mask MaskCreate/job200/mask.mrc"
            " --solvent_correct_fsc --oversampling 1 --healpix_order 2 "
            "--auto_local_healpix_order 4 --offset_range 5 --offset_step 2 --sym D2"
            ' --low_resol_join_halves 40 --norm --scale --j 6 --gpu "4:5:6:7"'
            " --pipeline_control Refine3D/job012/"
            " >> Refine3D/job012/run.out 2>> Refine3D/job012/run.err & ",
        )

    def test_get_command_refine3D_absgrey(self):
        generic_tests.general_get_command_test(
            self,
            "Refine3D",
            "refine3D_absgrey.job",
            12,
            {
                "Extract/job018/particles.star": NODES["Part data"],
                "Class3D/job016/run_it025_class001_box256.mrc": NODES["3D refs"],
            },
            {
                "run_data.star": NODES["Part data"],
                "run_half1_class001_unfil.mrc": NODES["Halfmap"],
                "run_class001.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Extract/job018/particles.star "
            "--o Refine3D/job012/run --auto_refine --split_random_halves "
            "--ref Class3D/job016/run_it025_class001_box256.mrc "
            "--ini_high 50 --dont_combine_weights_via_disc --preread_images --pool 30"
            " --pad 2 --skip_gridding --ctf --ctf_corrected_ref --particle_diameter"
            " 200 --flatten_solvent --zero_mask --oversampling 1 --healpix_order 2"
            " --auto_local_healpix_order 4 --offset_range 5 --offset_step 2 --sym D2"
            ' --low_resol_join_halves 40 --norm --scale --j 6 --gpu "4:5:6:7"'
            " --pipeline_control Refine3D/job012/"
            " >> Refine3D/job012/run.out 2>> Refine3D/job012/run.err & ",
        )

    def test_get_command_refine3D_ctf1stpeak(self):
        generic_tests.general_get_command_test(
            self,
            "Refine3D",
            "refine3D_ctf1stpeak.job",
            12,
            {
                "Extract/job018/particles.star": NODES["Part data"],
                "Class3D/job016/run_it025_class001_box256.mrc": NODES["3D refs"],
            },
            {
                "run_data.star": NODES["Part data"],
                "run_half1_class001_unfil.mrc": NODES["Halfmap"],
                "run_class001.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Extract/job018/particles.star "
            "--o Refine3D/job012/run --auto_refine --split_random_halves "
            "--ref Class3D/job016/run_it025_class001_box256.mrc --firstiter_cc "
            "--ini_high 50 --dont_combine_weights_via_disc --preread_images --pool 30"
            " --pad 2 --skip_gridding --ctf --ctf_corrected_ref --ctf_intact_first_peak"
            " --particle_diameter 200 --flatten_solvent --zero_mask --oversampling 1 "
            "--healpix_order 2 --auto_local_healpix_order 4 --offset_range 5 "
            "--offset_step 2 --sym D2"
            ' --low_resol_join_halves 40 --norm --scale --j 6 --gpu "4:5:6:7"'
            " --pipeline_control Refine3D/job012/"
            " >> Refine3D/job012/run.out 2>> Refine3D/job012/run.err & ",
        )

    def test_get_command_refine3D_finerfaster(self):
        generic_tests.general_get_command_test(
            self,
            "Refine3D",
            "refine3D_finerfaster.job",
            12,
            {
                "Extract/job018/particles.star": NODES["Part data"],
                "Class3D/job016/run_it025_class001_box256.mrc": NODES["3D refs"],
            },
            {
                "run_data.star": NODES["Part data"],
                "run_half1_class001_unfil.mrc": NODES["Halfmap"],
                "run_class001.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Extract/job018/particles.star "
            "--o Refine3D/job012/run --auto_refine --split_random_halves "
            "--ref Class3D/job016/run_it025_class001_box256.mrc --firstiter_cc "
            "--ini_high 50 --dont_combine_weights_via_disc --preread_images --pool 30"
            " --pad 2 --skip_gridding --auto_ignore_angles --auto_resol_angles --ctf"
            " --ctf_corrected_ref --particle_diameter"
            " 200 --flatten_solvent --zero_mask --oversampling 1 --healpix_order 2"
            " --auto_local_healpix_order 4 --offset_range 5 --offset_step 2 --sym D2"
            ' --low_resol_join_halves 40 --norm --scale --j 6 --gpu "4:5:6:7"'
            " --pipeline_control Refine3D/job012/"
            " >> Refine3D/job012/run.out 2>> Refine3D/job012/run.err & ",
        )

    def test_get_command_refine3D_helical(self):
        generic_tests.general_get_command_test(
            self,
            "Refine3D",
            "refine3D_helical.job",
            12,
            {
                "Extract/job018/particles.star": NODES["Part data"],
                "Class3D/job016/run_it025_class001_box256.mrc": NODES["3D refs"],
            },
            {
                "run_data.star": NODES["Part data"],
                "run_half1_class001_unfil.mrc": NODES["Halfmap"],
                "run_class001.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Extract/job018/particles.star "
            "--o Refine3D/job012/run --auto_refine --split_random_halves "
            "--ref Class3D/job016/run_it025_class001_box256.mrc --firstiter_cc "
            "--ini_high 50 --dont_combine_weights_via_disc --preread_images --pool 30"
            " --pad 2 --skip_gridding --ctf --ctf_corrected_ref --particle_diameter"
            " 200 --flatten_solvent --zero_mask --oversampling 1 --healpix_order 2"
            " --auto_local_healpix_order 4 --offset_range 5 --offset_step 2 --sym D2"
            " --low_resol_join_halves 40 --norm --scale --helix "
            "--helical_inner_diameter 30 --helical_outer_diameter 100 --helical_nr_asu"
            " 3 --helical_twist_initial 25 --helical_rise_initial 3.8 "
            "--helical_z_percentage 0.3 --sigma_tilt 5 --sigma_psi 3.33333 --sigma_rot"
            ' 0 --helical_keep_tilt_prior_fixed --j 6 --gpu "4:5:6:7"'
            " --pipeline_control Refine3D/job012/"
            " >> Refine3D/job012/run.out 2>> Refine3D/job012/run.err & ",
        )

    def test_get_command_refine3D_noprior(self):
        generic_tests.general_get_command_test(
            self,
            "Refine3D",
            "refine3D_helical_noprior.job",
            12,
            {
                "Extract/job018/particles.star": NODES["Part data"],
                "Class3D/job016/run_it025_class001_box256.mrc": NODES["3D refs"],
            },
            {
                "run_data.star": NODES["Part data"],
                "run_half1_class001_unfil.mrc": NODES["Halfmap"],
                "run_class001.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Extract/job018/particles.star "
            "--o Refine3D/job012/run --auto_refine --split_random_halves "
            "--ref Class3D/job016/run_it025_class001_box256.mrc --firstiter_cc "
            "--ini_high 50 --dont_combine_weights_via_disc --preread_images --pool 30"
            " --pad 2 --skip_gridding --ctf --ctf_corrected_ref --particle_diameter"
            " 200 --flatten_solvent --zero_mask --oversampling 1 --healpix_order 2"
            " --auto_local_healpix_order 4 --offset_range 5 --offset_step 2 --sym D2"
            " --low_resol_join_halves 40 --norm --scale --helix "
            "--helical_inner_diameter 30 --helical_outer_diameter 100 --helical_nr_asu"
            " 3 --helical_twist_initial 25 --helical_rise_initial 3.8 "
            "--helical_z_percentage 0.3 --sigma_tilt 5 --sigma_psi 3.33333 --sigma_rot"
            ' 0 --j 6 --gpu "4:5:6:7" --pipeline_control Refine3D/job012/'
            " >> Refine3D/job012/run.out 2>> Refine3D/job012/run.err & ",
        )

    def test_get_command_refine3D_helical_noHsym(self):
        generic_tests.general_get_command_test(
            self,
            "Refine3D",
            "refine3D_helical_noHsym.job",
            12,
            {
                "Extract/job018/particles.star": NODES["Part data"],
                "Class3D/job016/run_it025_class001_box256.mrc": NODES["3D refs"],
            },
            {
                "run_data.star": NODES["Part data"],
                "run_half1_class001_unfil.mrc": NODES["Halfmap"],
                "run_class001.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Extract/job018/particles.star "
            "--o Refine3D/job012/run --auto_refine --split_random_halves "
            "--ref Class3D/job016/run_it025_class001_box256.mrc --firstiter_cc "
            "--ini_high 50 --dont_combine_weights_via_disc --preread_images --pool 30"
            " --pad 2 --skip_gridding --ctf --ctf_corrected_ref --particle_diameter"
            " 200 --flatten_solvent --zero_mask --oversampling 1 --healpix_order 2"
            " --auto_local_healpix_order 4 --offset_range 5 --offset_step 2 --sym D2"
            " --low_resol_join_halves 40 --norm --scale --helix "
            "--helical_inner_diameter 30 --helical_outer_diameter 100 "
            "--ignore_helical_symmetry --sigma_tilt 5 --sigma_psi 3.33333 --sigma_rot"
            ' 0 --helical_keep_tilt_prior_fixed --j 6 --gpu "4:5:6:7"'
            " --pipeline_control Refine3D/job012/"
            " >> Refine3D/job012/run.out 2>> Refine3D/job012/run.err & ",
        )

    def test_get_command_refine3D_helical_search(self):
        generic_tests.general_get_command_test(
            self,
            "Refine3D",
            "refine3D_helical_search.job",
            12,
            {
                "Extract/job018/particles.star": NODES["Part data"],
                "Class3D/job016/run_it025_class001_box256.mrc": NODES["3D refs"],
            },
            {
                "run_data.star": NODES["Part data"],
                "run_half1_class001_unfil.mrc": NODES["Halfmap"],
                "run_class001.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Extract/job018/particles.star "
            "--o Refine3D/job012/run --auto_refine --split_random_halves "
            "--ref Class3D/job016/run_it025_class001_box256.mrc --firstiter_cc "
            "--ini_high 50 --dont_combine_weights_via_disc --preread_images --pool 30"
            " --pad 2 --skip_gridding --ctf --ctf_corrected_ref --particle_diameter"
            " 200 --flatten_solvent --zero_mask --oversampling 1 --healpix_order 2"
            " --auto_local_healpix_order 4 --offset_range 5 --offset_step 2 --sym D2"
            " --low_resol_join_halves 40 --norm --scale --helix "
            "--helical_inner_diameter 30 --helical_outer_diameter 100 --helical_nr_asu"
            " 3 --helical_twist_initial 25 --helical_rise_initial 3.8 "
            "--helical_z_percentage 0.3 --helical_symmetry_search --helical_twist_min"
            " 20 --helical_twist_max 30 --helical_twist_inistep 1 --helical_rise_min 3"
            " --helical_rise_max 4.5 --helical_rise_inistep 0.25 --sigma_tilt 5 "
            "--sigma_psi 3.33333 --sigma_rot"
            ' 0 --helical_keep_tilt_prior_fixed --j 6 --gpu "4:5:6:7"'
            " --pipeline_control Refine3D/job012/"
            " >> Refine3D/job012/run.out 2>> Refine3D/job012/run.err & ",
        )

    def test_get_command_refine3D_helical_sigmarot(self):
        generic_tests.general_get_command_test(
            self,
            "Refine3D",
            "refine3D_helical_sigmarot.job",
            12,
            {
                "Extract/job018/particles.star": NODES["Part data"],
                "Class3D/job016/run_it025_class001_box256.mrc": NODES["3D refs"],
            },
            {
                "run_data.star": NODES["Part data"],
                "run_half1_class001_unfil.mrc": NODES["Halfmap"],
                "run_class001.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Extract/job018/particles.star "
            "--o Refine3D/job012/run --auto_refine --split_random_halves "
            "--ref Class3D/job016/run_it025_class001_box256.mrc --firstiter_cc "
            "--ini_high 50 --dont_combine_weights_via_disc --preread_images --pool 30"
            " --pad 2 --skip_gridding --ctf --ctf_corrected_ref --particle_diameter"
            " 200 --flatten_solvent --zero_mask --oversampling 1 --healpix_order 2"
            " --auto_local_healpix_order 4 --offset_range 5 --offset_step 2 --sym D2"
            " --low_resol_join_halves 40 --norm --scale --helix "
            "--helical_inner_diameter 30 --helical_outer_diameter 100 --helical_nr_asu"
            " 3 --helical_twist_initial 25 --helical_rise_initial 3.8 "
            "--helical_z_percentage 0.3 --sigma_tilt 5 --sigma_psi 3.33333 --sigma_rot"
            " 0 --helical_sigma_distance 5 --helical_keep_tilt_prior_fixed --j 6"
            ' --gpu "4:5:6:7" --pipeline_control Refine3D/job012/ >> '
            "Refine3D/job012/run.out 2>> Refine3D/job012/run.err & ",
        )

    def test_get_command_refine3D_nompiGPU(self):
        generic_tests.general_get_command_test(
            self,
            "Refine3D",
            "refine3D_nompiGPU.job",
            12,
            {
                "Extract/job018/particles.star": NODES["Part data"],
                "Class3D/job016/run_it025_class001_box256.mrc": NODES["3D refs"],
            },
            {
                "run_data.star": NODES["Part data"],
                "run_half1_class001_unfil.mrc": NODES["Halfmap"],
                "run_class001.mrc": NODES["3D refs"],
            },
            "`which relion_refine` --i Extract/job018/particles.star "
            "--o Refine3D/job012/run --auto_refine --split_random_halves "
            "--ref Class3D/job016/run_it025_class001_box256.mrc --firstiter_cc "
            "--ini_high 50 --dont_combine_weights_via_disc --preread_images --pool 30"
            " --pad 2 --skip_gridding --ctf --ctf_corrected_ref --particle_diameter"
            " 200 --flatten_solvent --zero_mask --oversampling 1 --healpix_order 2"
            " --auto_local_healpix_order 4 --offset_range 5 --offset_step 2 --sym D2"
            " --low_resol_join_halves 40 --norm --scale --j 6 "
            "--pipeline_control Refine3D/job012/"
            " >> Refine3D/job012/run.out 2>> Refine3D/job012/run.err & ",
        )

    def test_get_command_refine3D_2masks(self):
        generic_tests.general_get_command_test(
            self,
            "Refine3D",
            "refine3D_2masks.job",
            12,
            {
                "Extract/job018/particles.star": NODES["Part data"],
                "Class3D/job016/run_it025_class001_box256.mrc": NODES["3D refs"],
                "MaskCreate/job200/mask.mrc": NODES["Mask"],
                "MaskCreate/job013/mask.mrc": NODES["Mask"],
            },
            {
                "run_data.star": NODES["Part data"],
                "run_half1_class001_unfil.mrc": NODES["Halfmap"],
                "run_class001.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Extract/job018/particles.star "
            "--o Refine3D/job012/run --auto_refine --split_random_halves "
            "--ref Class3D/job016/run_it025_class001_box256.mrc --firstiter_cc "
            "--ini_high 50 --dont_combine_weights_via_disc --preread_images --pool 30"
            " --pad 2 --skip_gridding --ctf --ctf_corrected_ref --particle_diameter"
            " 200 --flatten_solvent --zero_mask "
            "--solvent_mask MaskCreate/job200/mask.mrc"
            " --oversampling 1 --healpix_order 2 --auto_local_healpix_order 4 "
            "--offset_range 5 --offset_step 2 --sym D2"
            ' --low_resol_join_halves 40 --norm --scale --j 6 --gpu "4:5:6:7"'
            " --solvent_mask2 MaskCreate/job013/mask.mrc --pipeline_control "
            "Refine3D/job012/"
            " >> Refine3D/job012/run.out 2>> Refine3D/job012/run.err & ",
        )

    def test_get_command_refine3D_continue_nofile(self):
        with self.assertRaises(ValueError):
            generic_tests.general_get_command_test(
                self, "Refine3D", "refine3D_continue_nofile.job", 12, 2, 3, "",
            )

    def test_get_command_refine3D_continue(self):
        with self.assertRaises(ValueError):
            generic_tests.general_get_command_test(
                self,
                "Refine3D",
                "refine3D_continue_nofile.job",
                12,
                {
                    "Extract/job018/particles.star": NODES["Part data"],
                    "Class3D/job016/run_it025_class001_box256.mrc": NODES["3D refs"],
                    "MaskCreate/job200/mask.mrc": NODES["Mask"],
                },
                {
                    "run_data.star": NODES["Part data"],
                    "run_half1_class001_unfil.mrc": NODES["Halfmap"],
                    "run_class001.mrc": NODES["3D refs"],
                },
                "mpirun -n 5 `which relion_refine_mpi` --continue "
                "run_ct01_it003_optimiser.star --o Refine3D/job011/run_ct3 "
                "--dont_combine_weights_via_disc --preread_images  --pool 3 --pad 2"
                ' --skip_gridding  --particle_diameter 200 --j 6 --gpu "4:5:6:7"'
                "--pipeline_control Refine3D/job012/ >> Refine3D/job012/run.out "
                "2>> Refine3D/job012/run.err & ",
            )


if __name__ == "__main__":
    unittest.main()
