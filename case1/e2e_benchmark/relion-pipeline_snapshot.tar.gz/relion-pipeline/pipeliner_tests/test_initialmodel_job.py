import unittest
import os
import shutil
import tempfile

from pipeliner.relion_jobs import job_factory
from pipeliner_tests import test_data
from pipeliner_tests import generic_tests
from pipeliner.data_structure import NODES


class InitialModelTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_get_scratch_env_var(self):
        # Ensure RELION_SCRATCH_DIR is unset to begin with
        os.environ["RELION_SCRATCH_DIR"] = ""

        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/InitialModel/initialmodel.job")
        )
        assert job.joboptions["scratch_dir"].defaultvalue == ""

        os.environ["RELION_SCRATCH_DIR"] = os.path.join(
            self.test_data, "fake_SCRATCH_dir"
        )
        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/InitialModel/initialmodel.job")
        )
        assert job.joboptions["scratch_dir"].defaultvalue == os.path.join(
            self.test_data, "fake_SCRATCH_dir"
        )

    def test_get_command_inimodel(self):
        generic_tests.general_get_command_test(
            self,
            "InitialModel",
            "initialmodel.job",
            12,
            {"Select/job014/particles.star": NODES["Part data"]},
            {
                "run_it150_data.star": NODES["Part data"],
                "run_it150_model.star": NODES["Model"],
                "run_it150_class001.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --sgd --denovo_3dref --i "
            "Select/job014/particles.star --o InitialModel/job012/run "
            "--sgd_ini_iter 25 --sgd_inbetween_iter 100 --sgd_fin_iter 25 "
            "--sgd_write_iter 10 --sgd_ini_resol 35 --sgd_fin_resol 15 "
            "--sgd_ini_subset 100 --sgd_fin_subset 500 --ctf --K 1 --sym C1"
            " --flatten_solvent --zero_mask --dont_combine_weights_via_disc"
            " --preread_images --pool 30 --pad 2 --skip_gridding "
            "--particle_diameter 200 --oversampling 1 --healpix_order 1 "
            '--offset_range 6 --offset_step 4.0 --j 6 --gpu "4:5:6:7"'
            " --pipeline_control InitialModel/job012/"
            " >> InitialModel/job012/run.out 2>> InitialModel/job012/run.err & ",
        )

    def test_get_command_inimodel_jobstar(self):
        generic_tests.general_get_command_test(
            self,
            "InitialModel",
            "initialmodel_job.star",
            12,
            {"Select/job014/particles.star": NODES["Part data"]},
            {
                "run_it150_data.star": NODES["Part data"],
                "run_it150_model.star": NODES["Model"],
                "run_it150_class001.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --sgd --denovo_3dref --i "
            "Select/job014/particles.star --o InitialModel/job012/run "
            "--sgd_ini_iter 25 --sgd_inbetween_iter 100 --sgd_fin_iter 25 "
            "--sgd_write_iter 10 --sgd_ini_resol 35 --sgd_fin_resol 15 "
            "--sgd_ini_subset 100 --sgd_fin_subset 500 --ctf --K 1 --sym C1"
            " --flatten_solvent --zero_mask --dont_combine_weights_via_disc"
            " --preread_images --pool 30 --pad 2 --skip_gridding "
            "--particle_diameter 200 --oversampling 1 --healpix_order 1 "
            '--offset_range 6 --offset_step 4.0 --j 6 --gpu "4:5:6:7"'
            " --pipeline_control InitialModel/job012/"
            " >> InitialModel/job012/run.out 2>> InitialModel/job012/run.err & ",
        )

    def test_get_command_inimodel_3classes(self):
        generic_tests.general_get_command_test(
            self,
            "InitialModel",
            "initialmodel_3classes.job",
            12,
            {"Select/job014/particles.star": NODES["Part data"]},
            {
                "run_it150_data.star": NODES["Part data"],
                "run_it150_model.star": NODES["Model"],
                "run_it150_class001.mrc": NODES["3D refs"],
                "run_it150_class002.mrc": NODES["3D refs"],
                "run_it150_class003.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --sgd --denovo_3dref --i "
            "Select/job014/particles.star --o InitialModel/job012/run "
            "--sgd_ini_iter 25 --sgd_inbetween_iter 100 --sgd_fin_iter 25 "
            "--sgd_write_iter 10 --sgd_ini_resol 35 --sgd_fin_resol 15 "
            "--sgd_ini_subset 100 --sgd_fin_subset 500 --ctf --K 3 --sym C1"
            " --flatten_solvent --zero_mask --dont_combine_weights_via_disc"
            " --scratch_dir my_scratch_dir --pool 30 --pad 2 --skip_gridding "
            "--particle_diameter 200 --oversampling 1 --healpix_order 1 "
            '--offset_range 6 --offset_step 4.0 --j 6 --gpu "4:5:6:7"'
            " --pipeline_control InitialModel/job012/"
            " >> InitialModel/job012/run.out 2>> InitialModel/job012/run.err & ",
        )

    def test_get_command_inimodel_continue(self):
        generic_tests.general_get_command_test(
            self,
            "InitialModel",
            "initialmodel_continue.job",
            12,
            {},
            {
                "run_ct200_it150_data.star": NODES["Part data"],
                "run_ct200_it150_model.star": NODES["Model"],
                "run_ct200_it150_class001.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` "
            "--continue run_it200_optimiser.star"
            " --o InitialModel/job012/run_ct200 --sgd_ini_iter 25 "
            "--sgd_inbetween_iter 100 --sgd_fin_iter 25 --sgd_write_iter 10"
            " --sgd_ini_resol 35 --sgd_fin_resol 15 --sgd_ini_subset 100 "
            "--sgd_fin_subset 500 --ctf --K 1 --sym C1 --flatten_solvent --zero_mask "
            "--dont_combine_weights_via_disc --preread_images --pool 30 --pad 2 "
            "--skip_gridding --particle_diameter 200 --oversampling 1 --healpix_order 1"
            ' --offset_range 6 --offset_step 4.0 --j 6 --gpu "4:5:6:7"'
            " --pipeline_control InitialModel/job012/"
            " >> InitialModel/job012/run.out 2>> InitialModel/job012/run.err & ",
        )

    def test_get_command_inimodel_finesampling(self):
        generic_tests.general_get_command_test(
            self,
            "InitialModel",
            "initialmodel_finesampling.job",
            12,
            {"Select/job014/particles.star": NODES["Part data"]},
            {
                "run_it150_data.star": NODES["Part data"],
                "run_it150_model.star": NODES["Model"],
                "run_it150_class001.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --sgd --denovo_3dref --i "
            "Select/job014/particles.star --o InitialModel/job012/run "
            "--sgd_ini_iter 25 --sgd_inbetween_iter 100 --sgd_fin_iter 25 "
            "--sgd_write_iter 10 --sgd_ini_resol 35 --sgd_fin_resol 15 "
            "--sgd_ini_subset 100 --sgd_fin_subset 500 --ctf --K 1 --sym C1"
            " --flatten_solvent --zero_mask --dont_combine_weights_via_disc"
            " --preread_images --pool 30 --pad 2 --skip_gridding "
            "--particle_diameter 200 --oversampling 1 --healpix_order 5 "
            '--offset_range 6 --offset_step 4.0 --j 6 --gpu "4:5:6:7"'
            " --pipeline_control InitialModel/job012/"
            " >> InitialModel/job012/run.out 2>> InitialModel/job012/run.err & ",
        )

    def test_get_command_inimodel_noMPI(self):
        generic_tests.general_get_command_test(
            self,
            "InitialModel",
            "initialmodel_noMPI.job",
            12,
            {"Select/job014/particles.star": NODES["Part data"]},
            {
                "run_it150_data.star": NODES["Part data"],
                "run_it150_model.star": NODES["Model"],
                "run_it150_class001.mrc": NODES["3D refs"],
            },
            "`which relion_refine` --sgd --denovo_3dref --i "
            "Select/job014/particles.star --o InitialModel/job012/run "
            "--sgd_ini_iter 25 --sgd_inbetween_iter 100 --sgd_fin_iter 25 "
            "--sgd_write_iter 10 --sgd_ini_resol 35 --sgd_fin_resol 15 "
            "--sgd_ini_subset 100 --sgd_fin_subset 500 --ctf --K 1 --sym C1"
            " --flatten_solvent --zero_mask --dont_combine_weights_via_disc"
            " --preread_images --pool 30 --pad 2 --skip_gridding "
            "--particle_diameter 200 --oversampling 1 --healpix_order 1 "
            "--offset_range 6 --offset_step 4.0 --j 16 --pipeline_control "
            "InitialModel/job012/"
            " >> InitialModel/job012/run.out 2>> InitialModel/job012/run.err & ",
        )


if __name__ == "__main__":
    unittest.main()
