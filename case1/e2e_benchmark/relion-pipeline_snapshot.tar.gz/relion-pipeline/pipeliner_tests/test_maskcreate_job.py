import unittest
import os
import shutil
import tempfile

from pipeliner_tests import test_data
from pipeliner_tests import generic_tests
from pipeliner.data_structure import NODES


class MaskCreateTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_get_mask_create_commands(self):
        generic_tests.general_get_command_test(
            self,
            "MaskCreate",
            "maskcreate.job",
            4,
            {"Import/job001/emd_3488.mrc": NODES["3D refs"]},
            {"mask.mrc": NODES["Mask"]},
            "`which relion_mask_create` --i Import/job001/emd_3488.mrc --o "
            "MaskCreate/job004/mask.mrc --lowpass 15 --angpix -1 --ini_threshold 0.005"
            " --extend_inimask 0 --width_soft_edge 6 --j 12 "
            "--pipeline_control MaskCreate/job004/ >> "
            "MaskCreate/job004/run.out 2>> MaskCreate/job004/run.err & ",
        )

    def test_get_mask_create_commands_with_jobstar(self):
        generic_tests.general_get_command_test(
            self,
            "MaskCreate",
            "maskcreate_job.star",
            4,
            {"Import/job001/emd_3488.mrc": NODES["3D refs"]},
            {"mask.mrc": NODES["Mask"]},
            "`which relion_mask_create` --i Import/job001/emd_3488.mrc --o "
            "MaskCreate/job004/mask.mrc --lowpass 15 --angpix -1 --ini_threshold 0.005"
            " --extend_inimask 0 --width_soft_edge 6 --j 12 "
            "--pipeline_control MaskCreate/job004/ >> "
            "MaskCreate/job004/run.out 2>> MaskCreate/job004/run.err & ",
        )

    def test_get_mask_create_commands_helical(self):
        generic_tests.general_get_command_test(
            self,
            "MaskCreate",
            "maskcreate_helical.job",
            5,
            {"Import/job001/emd_3488.mrc": NODES["3D refs"]},
            {"mask.mrc": NODES["Mask"]},
            "`which relion_mask_create` --i Import/job001/emd_3488.mrc --o "
            "MaskCreate/job005/mask.mrc --lowpass 15 --angpix -1 --ini_threshold 0.005"
            " --extend_inimask 0 --width_soft_edge 6 --helix --z_percentage 0.3 --j 12"
            " --pipeline_control MaskCreate/job005/"
            " >> MaskCreate/job005/run.out 2>> MaskCreate/job005/run.err & ",
        )


if __name__ == "__main__":
    unittest.main()
