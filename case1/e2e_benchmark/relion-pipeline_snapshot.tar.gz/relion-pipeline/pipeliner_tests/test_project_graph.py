import io
import unittest
import os
import shutil
import tempfile
import time
import subprocess

from gemmi import cif

from pipeliner import star_writer
from pipeliner.project_graph import ProjectGraph
from pipeliner_tests import test_data
from pipeliner.data_structure import NODES, NODES_DIR
from pipeliner.job_runner import JobRunner
from pipeliner.relion_jobs import job_factory

do_full = os.environ.get("UNITTEST_FULL", False) == "True"
do_interactive = os.environ.get("UNITTEST_INTERACTIVE", False) == "True"
do_full = True


class ProjectGraphTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_reading_tutorial_pipeline(self):
        # Copy tutorial pipeline file to test directory
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/tutorial_pipeline.star"),
            self.test_dir,
        )

        # Read pipeline STAR file
        pipeline = ProjectGraph(name="tutorial")
        pipeline.read()

        # Check pipeline was read correctly
        assert pipeline.job_counter == 30
        assert len(pipeline.process_list) == 29
        assert len(pipeline.node_list) == 64

    def test_star_writer_formatting_with_tutorial_pipeline(self):
        pipeline_file = os.path.join(self.test_data, "Pipelines/tutorial_pipeline.star")
        doc = cif.read_file(pipeline_file)
        out_stream = io.StringIO()
        star_writer.write_to_stream(doc, out_stream)
        actual = out_stream.getvalue()
        with open("wrote_pipeline.star", "w") as outfile:
            outfile.write(actual)
        with open(pipeline_file) as f:
            expected = f.read()
        assert actual == expected, os.system(
            "diff " + pipeline_file + " wrote_pipeline.star"
        )

    def test_reading_nonexistent_pipeline_raises_exception(self):
        with self.assertRaises(ValueError):
            ProjectGraph().read()

    def test_writing_new_empty_pipeline(self):
        pipeline = ProjectGraph()
        # have to put the lockfiles in like they were created by a read
        os.system("mkdir .relion_lock")
        os.system("touch .relion_lock/lock_default_pipeline.star")
        pipeline.write()

        assert os.path.isfile("default_pipeline.star")

    def test_rewriting_tutorial_pipeline(self):
        # Copy tutorial pipeline file to test directory
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/tutorial_pipeline.star"),
            self.test_dir,
        )

        assert os.path.isfile("tutorial_pipeline.star")
        assert not os.path.isfile("default_pipeline.star")

        # Read pipeline STAR file
        pipeline = ProjectGraph(name="tutorial")
        pipeline.read(do_lock=True)

        # Rename pipeline and write to new STAR file
        pipeline.set_name("default", new_lock=True)
        pipeline.write()

        # Check new file is correct
        assert os.path.isfile("default_pipeline.star")
        with open("tutorial_pipeline.star") as f:
            expected = f.read()
        with open("default_pipeline.star") as f:
            actual = f.read()
        assert actual == expected

        def assert_tutorial_pipeline_correct(pipeline_str):
            assert "data_pipeline_general" in pipeline_str
            self.assertRegex(pipeline_str, "_rlnPipeLineJobCounter +30")
            assert "data_pipeline_processes" in pipeline_str
            self.assertRegex(pipeline_str, "Import/job001/ +Import/movies/ +0 +2")
            self.assertRegex(pipeline_str, "CtfRefine/job024/ +None +21 +2")
            assert "data_pipeline_nodes" in pipeline_str
            self.assertRegex(
                pipeline_str, "ManualPick/job004/coords_suffix_manualpick.star +2"
            )
            assert "data_pipeline_input_edges" in pipeline_str
            self.assertRegex(
                pipeline_str,
                "InitialModel/job017/run_it150_class001_symD2.mrc +Class3D/job018/",
            )
            assert "data_pipeline_output_edges" in pipeline_str
            self.assertRegex(
                pipeline_str,
                "LocalRes/job029/ +LocalRes/job029/relion_locres_filtered.mrc",
            )

        # Check that the original file passes the test, to make sure the test is correct
        assert_tutorial_pipeline_correct(expected)

        # Now check the new pipeline file
        assert_tutorial_pipeline_correct(actual)

        # Check exact contents match.
        # (This can fail if there's a formatting problem even if the information in the
        # file is correct.)
        assert actual == expected

        # Check Gemmi can read the new file
        new_pipeline = ProjectGraph()
        new_pipeline.read()
        assert len(new_pipeline.process_list) == 29

    def test_rename_pipeline_to_existing_name_raises_error(self):
        # Copy tutorial pipeline file to test directory
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/tutorial_pipeline.star"),
            self.test_dir,
        )
        os.system("touch default_pipeline.star")
        assert os.path.isfile("tutorial_pipeline.star")
        assert os.path.isfile("default_pipeline.star")

        # Read pipeline STAR file
        pipeline = ProjectGraph(name="tutorial")
        pipeline.read(do_lock=True)

        # Rename pipeline and write to new STAR file
        with self.assertRaises(ValueError):
            pipeline.set_name("default", new_lock=True)

    def test_remake_pipeline(self):
        # Copy short tutorial pipeline file to test directory
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_pipeline.star"),
            self.test_dir,
        )

        assert os.path.isfile("short_pipeline.star")
        assert not os.path.isfile("default_pipeline.star")

        # make the nodes dir, make sure it's empty
        os.system("mkdir .Nodes")
        assert len(os.listdir(".Nodes")) == 0

        # Read pipeline STAR file
        pipeline = ProjectGraph(name="short")
        pipeline.read(do_lock=True)

        # remake the dir with nothing to write
        pipeline.remake_node_directory()
        assert len(os.listdir(".Nodes")) == 0

        # now make the files exist
        os.system("mkdir -p Import/job001/")
        os.system("mkdir -p MotionCorr/job002/")
        os.system("mkdir -p CtfFind/job003/")
        pretend_files = [
            "Import/job001/movies.star",
            "MotionCorr/job002/corrected_micrographs.star",
            "MotionCorr/job002/logfile.pdf",
            "CtfFind/job003/micrographs_ctf.star",
            "CtfFind/job003/logfile.pdf",
        ]
        for pfile in pretend_files:
            os.system("touch " + pfile)

        pfalias = [
            "0/Import/movies/movies.star",
            "1/MotionCorr/own/corrected_micrographs.star",
            "13/MotionCorr/own/logfile.pdf",
            "1/CtfFind/gctf/micrographs_ctf.star",
            "13/CtfFind/gctf/logfile.pdf",
        ]

        # remake the node dirs again now that the files exist
        pipeline.remake_node_directory()
        for pfa in pfalias:
            thefile = ".Nodes/" + pfa
            assert os.path.isfile(thefile), print(thefile)

    def test_remake_pipeline_with_scheduled(self):
        # Copy short tutorial pipeline file to test directory
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_sched_pipeline.star"),
            self.test_dir,
        )

        assert os.path.isfile("short_sched_pipeline.star")
        assert not os.path.isfile("default_pipeline.star")

        # make the nodes dir, make sure it's empty
        os.system("mkdir .Nodes")
        assert len(os.listdir(".Nodes")) == 0

        # Read pipeline STAR file
        pipeline = ProjectGraph(name="short_sched")
        pipeline.read(do_lock=True)

        # remake the dir
        pipeline.remake_node_directory()

        pfalias = [
            "0/Import/movies/movies.star",
            "1/MotionCorr/own/corrected_micrographs.star",
            "13/MotionCorr/own/logfile.pdf",
            "1/CtfFind/gctf/micrographs_ctf.star",
            "13/CtfFind/gctf/logfile.pdf",
        ]

        for pfa in pfalias:
            thefile = ".Nodes/" + pfa
            assert os.path.isfile(thefile), print(thefile)

    def test_checking_pipline_for_finished_jobs(self):
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_running_pipeline.star"),
            self.test_dir,
        )

        assert os.path.isfile("short_running_pipeline.star")
        assert not os.path.isfile("default_pipeline.star")

        # Read pipeline STAR file
        pipeline = ProjectGraph(name="short_running")
        pipeline.read()

        # no jobs have been completed but pipeline has been
        # renamed, so new one has been written
        pipeline.set_name("updating", new_lock=False)
        pipeline.check_process_completion()

        assert os.path.isfile("updating_pipeline.star")

        with open("short_running_pipeline.star") as running_pipe:
            running = running_pipe.read()
        with open("updating_pipeline.star") as updated_pipe:
            updated = updated_pipe.read()
        assert updated == running

        # make the files
        os.system("mkdir -p Import/job001/")
        os.system("mkdir -p MotionCorr/job002/")
        os.system("mkdir -p CtfFind/job003/")
        for f in [
            "Import/job001/RELION_JOB_EXIT_FAILURE",
            "MotionCorr/job002/corrected_micrographs.star",
            "MotionCorr/job002/logfile.pdf",
            "MotionCorr/job002/RELION_JOB_EXIT_SUCCESS",
            "CtfFind/job003/RELION_JOB_EXIT_ABORTED",
        ]:
            os.system("touch " + f)
            assert os.path.isfile(f), f

        # update the pipeline
        pipeline.check_process_completion()
        with open("updating_pipeline.star") as updated_pipe:
            updated = updated_pipe.read()
        assert updated != running
        uplines = updated.split("\n")
        assert uplines[17].split()[-1] == "3"
        assert uplines[18].split()[-1] == "2"
        assert uplines[19].split()[-1] == "4"
        assert os.listdir(".Nodes/1/MotionCorr/own/") == ["corrected_micrographs.star"]
        assert os.listdir(".Nodes/13/MotionCorr/own/") == ["logfile.pdf"]

    def test_checking_pipline_for_finished_jobs_read_outnodes_file(self):
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_running_pipeline.star"),
            self.test_dir,
        )

        assert os.path.isfile("short_running_pipeline.star")
        assert not os.path.isfile("default_pipeline.star")

        # Read pipeline STAR file
        pipeline = ProjectGraph(name="short_running")
        pipeline.read()

        # make the files
        os.system("mkdir -p Import/job001/")
        os.system("mkdir -p MotionCorr/job002/")
        os.system("mkdir -p CtfFind/job003/")
        os.system("mkdir -p SomeOtherJob/job400/")

        for f in [
            "Import/job001/RELION_JOB_EXIT_FAILURE",
            "MotionCorr/job002/corrected_micrographs.star",
            "MotionCorr/job002/logfile.pdf",
            "MotionCorr/job002/RELION_JOB_EXIT_SUCCESS",
            "CtfFind/job003/RELION_JOB_EXIT_ABORTED",
            "SomeOtherJob/job400/extrafile.star",
        ]:
            os.system("touch " + f)
            assert os.path.isfile(f), f
        outnodes_file = os.path.join(
            self.test_dir, "MotionCorr/job002/RELION_OUTPUT_NODES.star"
        )
        shutil.copy(
            os.path.join(self.test_data, "StarFiles/RELION_OUTPUT_NODES.star"),
            outnodes_file,
        )
        assert os.path.isfile(outnodes_file)

        # update the pipeline
        pipeline.check_process_completion()
        with open("short_running_pipeline.star") as updated_pipe:
            pipe_lines = [x.split() for x in updated_pipe.read().split("\n")]
        assert ["SomeOtherJob/job400/extrafile.star", "99"] in pipe_lines
        assert [
            "MotionCorr/job002/",
            "SomeOtherJob/job400/extrafile.star",
        ] in pipe_lines

    def test_removing_nodes_from_pipeline(self):
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_pipeline.star"),
            self.test_dir,
        )

        assert os.path.isfile("short_pipeline.star")
        assert not os.path.isfile("default_pipeline.star")

        os.system("mkdir -p CtfFind/job003/")
        os.system("touch CtfFind/job003/logfile.pdf")
        assert os.path.isfile("CtfFind/job003/logfile.pdf")
        os.system("touch CtfFind/job003/micrographs_ctf.star")
        assert os.path.isfile("CtfFind/job003/micrographs_ctf.star")

        # Read pipeline STAR file
        pipeline = ProjectGraph(name="short")
        pipeline.read(do_lock=True)
        pipeline.set_name("deleted", new_lock=True)
        delete_nodes = [pipeline.node_list[3], pipeline.node_list[4]]
        pipeline.write(delete_nodes)
        with open("deleted_pipeline.star") as updated_pipeline:
            new_pipe = updated_pipeline.read()
        removed_lines = [
            "CtfFind/job003/micrographs_ctf.star            1",
            "CtfFind/job003/logfile.pdf           13",
            "CtfFind/job003/ CtfFind/job003/micrographs_ctf.star",
            "CtfFind/job003/ CtfFind/job003/logfile.pdf ",
        ]
        for rl in removed_lines:
            assert rl not in new_pipe, rl
        assert not os.path.isfile("CtfFind/job003/logfile.pdf")
        assert not os.path.isfile("CtfFind/job003/micrographs_ctf.star")

    def test_removing_process_from_pipeline(self):
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_pipeline.star"),
            self.test_dir,
        )

        assert os.path.isfile("short_pipeline.star")
        assert not os.path.isfile("default_pipeline.star")

        os.system("mkdir -p CtfFind/job003/")
        os.system("touch CtfFind/job003/logfile.pdf")
        assert os.path.isfile("CtfFind/job003/logfile.pdf")
        os.system("touch CtfFind/job003/micrographs_ctf.star")
        assert os.path.isfile("CtfFind/job003/micrographs_ctf.star")

        pipeline = ProjectGraph(name="short")
        pipeline.read(do_lock=True)
        pipeline.set_name("deleted", new_lock=True)

        delete_proc = pipeline.process_list[2]
        pipeline.write([], [delete_proc])

        with open("deleted_pipeline.star") as updated_pipeline:
            new_pipe = updated_pipeline.read()
        removed_lines = [
            "CtfFind/job003/micrographs_ctf.star            1",
            "CtfFind/job003/logfile.pdf           13",
            "CtfFind/job003/ CtfFind/job003/micrographs_ctf.star",
            "CtfFind/job003/ CtfFind/job003/logfile.pdf ",
            "CtfFind/job003/ CtfFind/gctf/            2            2 ",
        ]
        for rl in removed_lines:
            assert rl not in new_pipe, rl
        assert not os.path.isfile("CtfFind/job003/logfile.pdf")
        assert not os.path.isfile("CtfFind/job003/micrographs_ctf.star")
        assert not os.path.isdir("CtfFind/job003/")

    def test_removing_multiple_processs_from_pipeline(self):
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_pipeline.star"),
            self.test_dir,
        )

        assert os.path.isfile("short_pipeline.star")
        assert not os.path.isfile("default_pipeline.star")

        os.system("mkdir -p CtfFind/job003/")
        os.system("mkdir -p MotionCorr/job002/")

        files = [
            "CtfFind/job003/logfile.pdf",
            "CtfFind/job003/micrographs_ctf.star",
            "MotionCorr/job002/corrected_micrographs.star",
            "MotionCorr/job002/logfile.pdf",
        ]

        for f in files:
            os.system("touch " + f)
            assert os.path.isfile(f), f

        pipeline = ProjectGraph(name="short")
        pipeline.read(do_lock=True)
        pipeline.set_name("deleted", new_lock=True)

        delete_procs = [pipeline.process_list[2], pipeline.process_list[1]]
        pipeline.write([], delete_procs)

        with open("deleted_pipeline.star") as updated_pipeline:
            new_pipe = updated_pipeline.read()
        removed_lines = [
            "CtfFind/job003/micrographs_ctf.star            1",
            "CtfFind/job003/logfile.pdf           13",
            "CtfFind/job003/ CtfFind/job003/micrographs_ctf.star",
            "CtfFind/job003/ CtfFind/job003/logfile.pdf ",
            "CtfFind/job003/ CtfFind/gctf/            2            2 ",
            "MotionCorr/job002/ MotionCorr/own/            1            2 ",
            "MotionCorr/job002/corrected_micrographs.star            1",
            "MotionCorr/job002/logfile.pdf           13",
            "MotionCorr/job002/corrected_micrographs.star CtfFind/job003/",
            "MotionCorr/job002/ MotionCorr/job002/corrected_micrographs.star",
            "MotionCorr/job002/ MotionCorr/job002/logfile.pdf",
        ]
        for rl in removed_lines:
            assert rl not in new_pipe, rl
        assert not os.path.isfile("CtfFind/job003/logfile.pdf")
        assert not os.path.isfile("CtfFind/job003/micrographs_ctf.star")
        assert not os.path.isdir("CtfFind/job003/")

    def test_mark_as_finished_nonrefinejob(self):
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_running_pipeline.star"),
            self.test_dir,
        )
        assert os.path.isfile("short_running_pipeline.star")

        os.system("mkdir -p CtfFind/job003/")
        os.system("touch CtfFind/job003/logfile.pdf")
        assert os.path.isfile("CtfFind/job003/logfile.pdf")
        os.system("touch CtfFind/job003/micrographs_ctf.star")
        assert os.path.isfile("CtfFind/job003/micrographs_ctf.star")

        pipeline = ProjectGraph(name="short_running")
        pipeline.read()

        fin_proc = pipeline.process_list[2]

        mark_as_fin = pipeline.mark_as_finished(fin_proc, False, False)
        assert mark_as_fin
        with open("short_running_pipeline.star") as written_pipe:
            written = written_pipe.read()
        assert "CtfFind/job003/ CtfFind/gctf/            2            2" in written
        assert "CtfFind/job003/ CtfFind/gctf/            2            0" not in written
        assert os.path.isfile("CtfFind/job003/RELION_JOB_EXIT_SUCCESS")

    def test_mark_as_finished_class2d(self):
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_cl2d_pipeline.star"),
            self.test_dir,
        )
        assert os.path.isfile("short_cl2d_pipeline.star")

        fdir = "Class2D/job008"
        os.system("mkdir -p " + fdir)
        os.symlink(
            os.path.abspath(fdir), os.path.join(self.test_dir, "Class2D/LoG_based")
        )
        assert os.path.islink("Class2D/LoG_based")

        files = [
            "_data.star",
            "_model.star",
            "_optimiser.star",
        ]
        for i in range(0, 6):
            for f in files:
                ff = "Class2D/job008/run_it{0:03d}{1}".format(i, f)
                os.system("touch " + ff)
                assert os.path.isfile(ff), ff

        pipeline = ProjectGraph(name="short_cl2d")
        pipeline.read()

        fin_proc = pipeline.process_list[7]

        assert pipeline.mark_as_finished(fin_proc, False, False)

        with open("short_cl2d_pipeline.star") as written_pipe:
            written = written_pipe.read()
        newlines = [
            "Class2D/job008/ Class2D/LoG_based/            8            2",
            "Class2D/job008/run_it005_optimiser.star            9",
            "Class2D/job008/run_it005_data.star            3",
            "Class2D/job008/run_it005_model.star            8",
            "Class2D/job008/ Class2D/job008/run_it005_optimiser.star",
            "Class2D/job008/ Class2D/job008/run_it005_data.star",
            "Class2D/job008/ Class2D/job008/run_it005_model.star",
        ]
        for line in newlines:
            assert line in written, line

        removed_line = "Class2D/job008/ Class2D/LoG_based/            8            0"
        assert removed_line not in written
        assert os.path.isfile("Class2D/job008/RELION_JOB_EXIT_SUCCESS")

    def test_mark_as_finished_inimodel(self):
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_inimod_pipeline.star"),
            self.test_dir,
        )
        assert os.path.isfile("short_inimod_pipeline.star")

        dirs = [
            "Extract/job007",
            "InitialModel/job009",
        ]
        for fdir in dirs:
            os.system("mkdir -p " + fdir)
            assert os.path.isdir(fdir)

        os.symlink(
            os.path.abspath("InitialModel/job009"),
            os.path.join(self.test_dir, "InitialModel/symC1"),
        )
        assert os.path.islink("InitialModel/symC1")

        files = [
            "_data.star",
            "_model.star",
            "_optimiser.star",
            "_class001.mrc",
        ]
        for i in range(0, 103):
            for f in files:
                ff = "InitialModel/job009/run_it{0:03d}{1}".format(i, f)
                os.system("touch " + ff)
                assert os.path.isfile(ff), ff

        in_files = [
            "Extract/job007/particles.star",
        ]

        for f in in_files:
            os.system("touch " + f)
            assert os.path.isfile(f)

        pipeline = ProjectGraph(name="short_inimod")
        pipeline.read()

        fin_proc = pipeline.process_list[8]

        pipeline.mark_as_finished(fin_proc, False, False)

        with open("short_inimod_pipeline.star") as written_pipe:
            written = written_pipe.read()

        newlines = [
            "InitialModel/job009/ InitialModel/symC1/           18            2",
            "InitialModel/job009/run_it102_optimiser.star            9",
            "InitialModel/job009/run_it102_data.star            3",
            "InitialModel/job009/run_it102_model.star            8",
            "InitialModel/job009/ InitialModel/job009/run_it102_optimiser.star",
            "InitialModel/job009/ InitialModel/job009/run_it102_data.star",
            "InitialModel/job009/ InitialModel/job009/run_it102_model.star",
            "InitialModel/job009/ InitialModel/job009/run_it102_class001.mrc",
        ]
        for line in newlines:
            assert line in written, line

        removed_line = "InitialModel/job009/ InitialModel/symC1/     \
              18            0"

        assert removed_line not in written
        assert os.path.isfile("InitialModel/job009/RELION_JOB_EXIT_SUCCESS")

    def test_mark_as_finished_class3d(self):
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_cl3d_pipeline.star"),
            self.test_dir,
        )
        assert os.path.isfile("short_cl3d_pipeline.star")

        dirs = [
            "Class3D/job010",
            "InitialModel/job009",
            "Extract/job007",
        ]

        for fdir in dirs:
            os.system("mkdir -p " + fdir)
            assert os.path.isdir(fdir)

        os.symlink(
            os.path.abspath("Class3D/job010"),
            os.path.join(self.test_dir, "Class3D/first_exhaustive"),
        )
        assert os.path.islink("Class3D/first_exhaustive")

        cl3_files = [
            "_data.star",
            "_model.star",
            "_optimiser.star",
            "_class001.mrc",
            "_class002.mrc",
            "_class003.mrc",
            "_class004.mrc",
        ]
        for i in range(0, 13):
            for f in cl3_files:
                ff = "Class3D/job010/run_it{0:03d}{1}".format(i, f)
                os.system("touch " + ff)
                assert os.path.isfile(ff), ff

        in_files = [
            "InitialModel/job009/run_it150_class001.star",
            "Extract/job007/particles.star",
        ]
        for f in in_files:
            os.system("touch " + f)
            assert os.path.isfile(f)

        pipeline = ProjectGraph(name="short_cl3d")
        pipeline.read()

        fin_proc = pipeline.process_list[9]

        pipeline.mark_as_finished(fin_proc, False, False)

        with open("short_cl3d_pipeline.star") as written_pipe:
            written = written_pipe.read()

        newlines = [
            "Class3D/job010/ Class3D/first_exhaustive/            9            2",
            "Class3D/job010/run_it012_optimiser.star            9",
            "Class3D/job010/run_it012_data.star            3",
            "Class3D/job010/run_it012_model.star            8",
            "Class3D/job010/ Class3D/job010/run_it012_optimiser.star",
            "Class3D/job010/ Class3D/job010/run_it012_data.star",
            "Class3D/job010/ Class3D/job010/run_it012_model.star",
            "Class3D/job010/ Class3D/job010/run_it012_class001.mrc",
            "Class3D/job010/ Class3D/job010/run_it012_class002.mrc",
            "Class3D/job010/ Class3D/job010/run_it012_class003.mrc",
            "Class3D/job010/ Class3D/job010/run_it012_class004.mrc",
        ]
        for line in newlines:
            assert line in written, line

        removed_line = "Class3D/job009/ Class3D/first_exhaustive/      \
              9            0"
        assert removed_line not in written

    def test_mark_as_finished_ref3d(self):
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_ref3d_pipeline.star"),
            self.test_dir,
        )
        assert os.path.isfile("short_ref3d_pipeline.star")

        dirs = [
            "Refine3D/job011",
            "Class3D/job010",
            "Extract/job007",
            "InitialModel/job008",
        ]

        for fdir in dirs:
            os.system("mkdir -p " + fdir)
            assert os.path.isdir(fdir)

        os.symlink(
            os.path.abspath("Refine3D/job011"),
            os.path.join(self.test_dir, "Refine3D/first3dref"),
        )
        os.symlink(
            os.path.abspath("Class3D/job010"),
            os.path.join(self.test_dir, "Class3D/first_exhaustive"),
        )

        assert os.path.islink("Refine3D/first3dref")

        in_files = [
            "InitialModel/job008/run_it150_class001.star",
            "Extract/job007/particles.star",
            "Class3D/job010/run_it025_class001.mrc",
            "Class3D/job010/run_it025_class002.mrc",
            "Class3D/job010/run_it025_class003.mrc",
            "Class3D/job010/run_it025_class004.mrc",
        ]
        for f in in_files:
            os.system("touch " + f)
            assert os.path.isfile(f), f

        r3d_files = [
            "_data.star",
            "_model.star",
            "_optimiser.star",
            "_half1_class001.mrc",
            "_half2_class001.mrc",
        ]
        for i in range(0, 18):
            for f in r3d_files:
                ff = "Refine3D/job011/run_it{0:03d}{1}".format(i, f)
                os.system("touch " + ff)
                assert os.path.isfile(ff), ff

        pipeline = ProjectGraph(name="short_ref3d")
        pipeline.read()

        fin_proc = pipeline.process_list[10]

        pipeline.mark_as_finished(fin_proc, False, False)

        with open("short_ref3d_pipeline.star") as written_pipe:
            written = written_pipe.read()

        newlines = [
            "Refine3D/job011/ Refine3D/first3dref/           10            2",
            "Refine3D/job011/run_it017_optimiser.star            9",
            "Refine3D/job011/run_it017_data.star            3",
            "Refine3D/job011/run_it017__half1model.star            8",
            "Extract/job007/particles.star Refine3D/job011/",
            "InitialModel/job009/run_it150_class001.mrc Refine3D/job011/",
            "Refine3D/job011/ Refine3D/job011/run_it017_optimiser.star",
            "Refine3D/job011/ Refine3D/job011/run_it017_data.star",
        ]
        for line in newlines:
            assert line in written, line

        removed_line = "Refine3D/job011/ Refine3D/first3dref/      \
             10             0"
        assert removed_line not in written
        assert os.path.isfile("Refine3D/job011/RELION_JOB_EXIT_SUCCESS")

    def test_mark_as_finished_class2d_continue(self):
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_cl2d_pipeline.star"),
            self.test_dir,
        )
        assert os.path.isfile("short_cl2d_pipeline.star")

        fdir = "Class2D/job008"
        os.system("mkdir -p " + fdir)
        os.symlink(
            os.path.abspath(fdir), os.path.join(self.test_dir, "Class2D/LoG_based")
        )
        assert os.path.islink("Class2D/LoG_based")

        files = [
            "_data.star",
            "_model.star",
            "_optimiser.star",
        ]
        for i in range(0, 6):
            for f in files:
                ff = "Class2D/job008/run_it{0:03d}{1}".format(i, f)
                os.system("touch " + ff)
                assert os.path.isfile(ff), ff
        for i in range(5, 14):
            for f in files:
                ff = "Class2D/job008/run_ct5_it{0:03d}{1}".format(i, f)
                os.system("touch " + ff)
                assert os.path.isfile(ff), ff
        pipeline = ProjectGraph(name="short_cl2d")
        pipeline.read()

        fin_proc = pipeline.process_list[7]

        assert pipeline.mark_as_finished(fin_proc, False, False)

        with open("short_cl2d_pipeline.star") as written_pipe:
            written = written_pipe.read()
        newlines = [
            "Class2D/job008/ Class2D/LoG_based/            8            2",
            "Class2D/job008/run_ct5_it013_optimiser.star            9",
            "Class2D/job008/run_ct5_it013_data.star            3",
            "Class2D/job008/run_ct5_it013_model.star            8",
            "Class2D/job008/ Class2D/job008/run_ct5_it013_optimiser.star",
            "Class2D/job008/ Class2D/job008/run_ct5_it013_model.star",
            "Class2D/job008/ Class2D/job008/run_ct5_it013_data.star",
        ]
        for line in newlines:
            assert line in written, line

        removed_line = "Class2D/job008/ Class2D/LoG_based/            8            0"
        assert removed_line not in written
        assert os.path.isfile("Class2D/job008/RELION_JOB_EXIT_SUCCESS")

    def test_mark_as_finished_inimodel_continue(self):
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_inimod_pipeline.star"),
            self.test_dir,
        )
        assert os.path.isfile("short_inimod_pipeline.star")

        dirs = [
            "Extract/job007",
            "InitialModel/job009",
        ]
        for fdir in dirs:
            os.system("mkdir -p " + fdir)
            assert os.path.isdir(fdir)

        os.symlink(
            os.path.abspath("InitialModel/job009"),
            os.path.join(self.test_dir, "InitialModel/symC1"),
        )
        assert os.path.islink("InitialModel/symC1")

        files = [
            "_data.star",
            "_model.star",
            "_optimiser.star",
            "_class001.mrc",
        ]
        for i in range(0, 103):
            for f in files:
                ff = "InitialModel/job009/run_it{0:03d}{1}".format(i, f)
                os.system("touch " + ff)
                assert os.path.isfile(ff), ff

        for i in range(102, 144):
            for f in files:
                ff = "InitialModel/job009/run_ct102_it{0:03d}{1}".format(i, f)
                os.system("touch " + ff)
                assert os.path.isfile(ff), ff
        in_files = [
            "Extract/job007/particles.star",
        ]

        for f in in_files:
            os.system("touch " + f)
            assert os.path.isfile(f)

        pipeline = ProjectGraph(name="short_inimod")
        pipeline.read()

        fin_proc = pipeline.process_list[8]

        pipeline.mark_as_finished(fin_proc, False, False)

        with open("short_inimod_pipeline.star") as written_pipe:
            written = written_pipe.read()

        newlines = [
            "InitialModel/job009/ InitialModel/symC1/           18            2",
            "InitialModel/job009/run_ct102_it143_optimiser.star            9",
            "InitialModel/job009/run_ct102_it143_data.star            3",
            "InitialModel/job009/run_ct102_it143_model.star            8",
            "InitialModel/job009/ InitialModel/job009/run_ct102_it143_optimiser.star",
            "InitialModel/job009/ InitialModel/job009/run_ct102_it143_model.star",
            "InitialModel/job009/ InitialModel/job009/run_ct102_it143_class001.mrc",
            "InitialModel/job009/ InitialModel/job009/run_ct102_it143_data.star",
        ]
        for line in newlines:
            assert line in written, line

        removed_line = "InitialModel/job009/ InitialModel/symC1/     \
              18            0"

        assert removed_line not in written
        assert os.path.isfile("InitialModel/job009/RELION_JOB_EXIT_SUCCESS")

    def test_mark_as_finished_class3d_continue(self):
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_cl3d_pipeline.star"),
            self.test_dir,
        )
        assert os.path.isfile("short_cl3d_pipeline.star")

        dirs = [
            "Class3D/job010",
            "InitialModel/job009",
            "Extract/job007",
        ]

        for fdir in dirs:
            os.system("mkdir -p " + fdir)
            assert os.path.isdir(fdir)

        os.symlink(
            os.path.abspath("Class3D/job010"),
            os.path.join(self.test_dir, "Class3D/first_exhaustive"),
        )
        assert os.path.islink("Class3D/first_exhaustive")

        cl3_files = [
            "_data.star",
            "_model.star",
            "_optimiser.star",
            "_class001.mrc",
            "_class002.mrc",
            "_class003.mrc",
            "_class004.mrc",
        ]
        for i in range(0, 13):
            for f in cl3_files:
                ff = "Class3D/job010/run_it{0:03d}{1}".format(i, f)
                os.system("touch " + ff)
                assert os.path.isfile(ff), ff
        for i in range(12, 20):
            for f in cl3_files:
                ff = "Class3D/job010/run_ct12_it{0:03d}{1}".format(i, f)
                os.system("touch " + ff)
                assert os.path.isfile(ff), ff
        in_files = [
            "InitialModel/job009/run_it150_class001.star",
            "Extract/job007/particles.star",
        ]
        for f in in_files:
            os.system("touch " + f)
            assert os.path.isfile(f)

        pipeline = ProjectGraph(name="short_cl3d")
        pipeline.read()

        fin_proc = pipeline.process_list[9]

        pipeline.mark_as_finished(fin_proc, False, False)

        with open("short_cl3d_pipeline.star") as written_pipe:
            written = written_pipe.read()

        newlines = [
            "Class3D/job010/ Class3D/first_exhaustive/            9            2",
            "Class3D/job010/run_ct12_it019_optimiser.star            9",
            "Class3D/job010/run_ct12_it019_data.star            3",
            "Class3D/job010/run_ct12_it019_model.star            8",
            "Class3D/job010/ Class3D/job010/run_ct12_it019_optimiser.star",
            "Class3D/job010/ Class3D/job010/run_ct12_it019_model.star",
            "Class3D/job010/ Class3D/job010/run_ct12_it019_class001.mrc",
            "Class3D/job010/ Class3D/job010/run_ct12_it019_class002.mrc",
            "Class3D/job010/ Class3D/job010/run_ct12_it019_class003.mrc",
            "Class3D/job010/ Class3D/job010/run_ct12_it019_class004.mrc",
            "Class3D/job010/ Class3D/job010/run_ct12_it019_data.star",
        ]
        for line in newlines:
            assert line in written, line

        removed_line = "Class3D/job010/ Class3D/first_exhaustive/      \
              9            0"
        assert removed_line not in written
        assert os.path.isfile("Class3D/job010/RELION_JOB_EXIT_SUCCESS")

    def test_mark_as_finished_ref3d_continue(self):
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_ref3d_pipeline.star"),
            self.test_dir,
        )
        assert os.path.isfile("short_ref3d_pipeline.star")

        dirs = [
            "Refine3D/job011",
            "Class3D/job010",
            "Extract/job007",
            "InitialModel/job008",
        ]

        for fdir in dirs:
            os.system("mkdir -p " + fdir)
            assert os.path.isdir(fdir)

        os.symlink(
            os.path.abspath("Refine3D/job011"),
            os.path.join(self.test_dir, "Refine3D/first3dref"),
        )
        os.symlink(
            os.path.abspath("Class3D/job010"),
            os.path.join(self.test_dir, "Class3D/first_exhaustive"),
        )

        assert os.path.islink("Refine3D/first3dref")

        in_files = [
            "InitialModel/job008/run_it150_class001.star",
            "Extract/job007/particles.star",
            "Class3D/job010/run_it025_class001.mrc",
            "Class3D/job010/run_it025_class002.mrc",
            "Class3D/job010/run_it025_class003.mrc",
            "Class3D/job010/run_it025_class004.mrc",
        ]
        for f in in_files:
            os.system("touch " + f)
            assert os.path.isfile(f), f

        r3d_files = [
            "_data.star",
            "_model.star",
            "_optimiser.star",
            "_half1_class001.mrc",
            "_half2_class001.mrc",
        ]
        for i in range(0, 18):
            for f in r3d_files:
                ff = "Refine3D/job011/run_it{0:03d}{1}".format(i, f)
                os.system("touch " + ff)
                assert os.path.isfile(ff), ff

        pipeline = ProjectGraph(name="short_ref3d")
        pipeline.read()

        fin_proc = pipeline.process_list[10]

        pipeline.mark_as_finished(fin_proc, False, False)

        with open("short_ref3d_pipeline.star") as written_pipe:
            written = written_pipe.read()

        newlines = [
            "Refine3D/job011/ Refine3D/first3dref/           10            2",
            "Refine3D/job011/run_it017_optimiser.star            9",
            "Refine3D/job011/run_it017_data.star            3",
            "Refine3D/job011/run_it017__half1model.star            8",
            "Extract/job007/particles.star Refine3D/job011/",
            "InitialModel/job009/run_it150_class001.mrc Refine3D/job011/",
            "Refine3D/job011/ Refine3D/job011/run_it017_optimiser.star",
            "Refine3D/job011/ Refine3D/job011/run_it017_data.star",
        ]
        for line in newlines:
            assert line in written, line

        removed_line = "Refine3D/job011/ Refine3D/first3dref/      \
             10             0"
        assert removed_line not in written
        assert os.path.isfile("Refine3D/job011/RELION_JOB_EXIT_SUCCESS")

    def test_mark_as_finished_class2d_aborted(self):
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_cl2d_abort_pipeline.star"),
            self.test_dir,
        )
        assert os.path.isfile("short_cl2d_abort_pipeline.star")

        fdir = "Class2D/job008"
        os.system("mkdir -p " + fdir)
        os.symlink(
            os.path.abspath(fdir), os.path.join(self.test_dir, "Class2D/LoG_based")
        )
        assert os.path.islink("Class2D/LoG_based")

        files = [
            "_data.star",
            "_model.star",
            "_optimiser.star",
        ]
        for i in range(0, 6):
            for f in files:
                ff = "Class2D/job008/run_it{0:03d}{1}".format(i, f)
                os.system("touch " + ff)
                assert os.path.isfile(ff), ff

        pipeline = ProjectGraph(name="short_cl2d_abort")
        pipeline.read()

        fin_proc = pipeline.process_list[7]

        assert pipeline.mark_as_finished(fin_proc, False, False)

        with open("short_cl2d_abort_pipeline.star") as written_pipe:
            written = written_pipe.read()
        newlines = [
            "Class2D/job008/ Class2D/LoG_based/            8            2",
            "Class2D/job008/run_it005_optimiser.star            9",
            "Class2D/job008/run_it005_data.star            3",
            "Class2D/job008/run_it005_model.star            8",
            "Class2D/job008/ Class2D/job008/run_it005_optimiser.star",
            "Class2D/job008/ Class2D/job008/run_it005_data.star",
            "Class2D/job008/ Class2D/job008/run_it005_model.star",
        ]
        for line in newlines:
            assert line in written, line

        removed_line = "Class2D/job008/ Class2D/LoG_based/            8            4"
        assert removed_line not in written
        assert os.path.isfile("Class2D/job008/RELION_JOB_EXIT_SUCCESS")

    def test_mark_failed_job_aborted_error(self):
        """ Take a job that is currently failed and try to mark it aborted
        should raise error"""
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_cl2d_fail_pipeline.star"),
            self.test_dir,
        )
        assert os.path.isfile("short_cl2d_fail_pipeline.star")

        pipeline = ProjectGraph(name="short_cl2d_fail")
        pipeline.read()

        fin_proc = pipeline.process_list[7]

        with self.assertRaises(ValueError):
            pipeline.mark_as_finished(fin_proc, False, True)

    def test_mark_as_finished_class2d_failed(self):
        """ Take a job that is currently failed and mark it as finished"""
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_cl2d_fail_pipeline.star"),
            self.test_dir,
        )
        assert os.path.isfile("short_cl2d_fail_pipeline.star")

        fdir = "Class2D/job008"
        os.system("mkdir -p " + fdir)
        os.symlink(
            os.path.abspath(fdir), os.path.join(self.test_dir, "Class2D/LoG_based")
        )
        assert os.path.islink("Class2D/LoG_based")

        files = [
            "_data.star",
            "_model.star",
            "_optimiser.star",
        ]
        for i in range(0, 6):
            for f in files:
                ff = "Class2D/job008/run_it{0:03d}{1}".format(i, f)
                os.system("touch " + ff)
                assert os.path.isfile(ff), ff

        pipeline = ProjectGraph(name="short_cl2d_fail")
        pipeline.read()

        fin_proc = pipeline.process_list[7]

        assert pipeline.mark_as_finished(fin_proc, False, False)

        with open("short_cl2d_fail_pipeline.star") as written_pipe:
            written = written_pipe.read()
        newlines = [
            "Class2D/job008/ Class2D/LoG_based/            8            2",
            "Class2D/job008/run_it005_optimiser.star            9",
            "Class2D/job008/run_it005_data.star            3",
            "Class2D/job008/run_it005_model.star            8",
            "Class2D/job008/ Class2D/job008/run_it005_optimiser.star",
            "Class2D/job008/ Class2D/job008/run_it005_data.star",
            "Class2D/job008/ Class2D/job008/run_it005_model.star",
        ]
        for line in newlines:
            assert line in written, line

        removed_line = "Class2D/job008/ Class2D/LoG_based/            8            4"
        assert removed_line not in written
        assert os.path.isfile("Class2D/job008/RELION_JOB_EXIT_SUCCESS")

    def test_mark_as_finished_class2d_mark_aborted_as_failed(self):
        """ Take an aborted job and mark it as failed"""
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_cl2d_abort_pipeline.star"),
            self.test_dir,
        )
        assert os.path.isfile("short_cl2d_abort_pipeline.star")

        fdir = "Class2D/job008"
        os.system("mkdir -p " + fdir)
        os.symlink(
            os.path.abspath(fdir), os.path.join(self.test_dir, "Class2D/LoG_based")
        )
        assert os.path.islink("Class2D/LoG_based")

        files = [
            "_data.star",
            "_model.star",
            "_optimiser.star",
        ]
        for i in range(0, 6):
            for f in files:
                ff = "Class2D/job008/run_it{0:03d}{1}".format(i, f)
                os.system("touch " + ff)
                assert os.path.isfile(ff), ff

        pipeline = ProjectGraph(name="short_cl2d_abort")
        pipeline.read()

        fin_proc = pipeline.process_list[7]

        assert pipeline.mark_as_finished(fin_proc, True, False)

        with open("short_cl2d_abort_pipeline.star") as written_pipe:
            written = written_pipe.read()
        newlines = [
            "Class2D/job008/ Class2D/LoG_based/            8            3",
            "Class2D/job008/run_it005_optimiser.star            9",
            "Class2D/job008/run_it005_data.star            3",
            "Class2D/job008/run_it005_model.star            8",
            "Class2D/job008/ Class2D/job008/run_it005_optimiser.star",
            "Class2D/job008/ Class2D/job008/run_it005_data.star",
            "Class2D/job008/ Class2D/job008/run_it005_model.star",
        ]
        for line in newlines:
            assert line in written, line

        removed_line = "Class2D/job008/ Class2D/LoG_based/            8            4"
        assert removed_line not in written
        assert os.path.isfile("Class2D/job008/RELION_JOB_EXIT_FAILED")
        assert not os.path.isfile("Class2D/job008/RELION_JOB_EXIT_ABORTED")

    def test_mark_as_finished_class2d_mark_as_aborted(self):
        """ Take a job marked as running and mark it aborted"""
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_cl2d_pipeline.star"),
            self.test_dir,
        )
        assert os.path.isfile("short_cl2d_pipeline.star")

        fdir = "Class2D/job008"
        os.system("mkdir -p " + fdir)
        os.symlink(
            os.path.abspath(fdir), os.path.join(self.test_dir, "Class2D/LoG_based")
        )
        assert os.path.islink("Class2D/LoG_based")

        files = [
            "_data.star",
            "_model.star",
            "_optimiser.star",
        ]
        for i in range(0, 6):
            for f in files:
                ff = "Class2D/job008/run_it{0:03d}{1}".format(i, f)
                os.system("touch " + ff)
                assert os.path.isfile(ff), ff

        pipeline = ProjectGraph(name="short_cl2d")
        pipeline.read()

        fin_proc = pipeline.process_list[7]

        assert pipeline.mark_as_finished(fin_proc, False, True)

        with open("short_cl2d_pipeline.star") as written_pipe:
            written = written_pipe.read()
        newlines = [
            "Class2D/job008/ Class2D/LoG_based/            8            4",
            "Class2D/job008/run_it005_optimiser.star            9",
            "Class2D/job008/run_it005_data.star            3",
            "Class2D/job008/run_it005_model.star            8",
            "Class2D/job008/ Class2D/job008/run_it005_optimiser.star",
            "Class2D/job008/ Class2D/job008/run_it005_data.star",
            "Class2D/job008/ Class2D/job008/run_it005_model.star",
        ]
        for line in newlines:
            assert line in written, line

        removed_line = "Class2D/job008/ Class2D/LoG_based/            8            0"
        assert removed_line not in written
        assert os.path.isfile("Class2D/job008/RELION_JOB_EXIT_ABORTED")

    def test_delete_job(self):
        # opy over files
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_cl2d_del_pipeline.star"),
            self.test_dir,
        )
        assert os.path.isfile("short_cl2d_del_pipeline.star")

        # make the files and their symlinks for aliases
        fdirs = {
            "Class2D/job008": "Class2D/LoG_based",
            "Extract/job007": "Extract/LoG_based",
        }
        for fdir in fdirs:
            os.system("mkdir -p " + fdir)
            os.symlink(os.path.abspath(fdir), os.path.join(self.test_dir, fdirs[fdir]))
            assert os.path.isdir(fdir)
            assert os.path.islink(fdirs[fdir])

        cl2d_files = [
            "_data.star",
            "_model.star",
            "_optimiser.star",
        ]
        file_list = list()
        for i in range(0, 26):
            for f in cl2d_files:
                ff = "Class2D/job008/run_it{0:03d}{1}".format(i, f)
                os.system("touch " + ff)
                assert os.path.isfile(ff), ff
                file_list.append(ff)

        cl2d_other_files = [
            "default_pipeline.star",
            "job_pipeline.star",
            "run.job",
            "RELION_JOB_EXIT_SUCCESS",
            "job.star",
            "note.txt",
            "run.err",
            "run.out",
        ]

        for f in cl2d_other_files:
            ff = "Class2D/job008/" + f
            os.system("touch " + ff)
            assert os.path.isfile(ff)
            file_list.append(ff)

        extract_files = [
            "default_pipeline.star",
            "job_pipeline.star",
            "particles.star",
            "run.job",
            "RELION_JOB_EXIT_SUCCESS",
            "job.star",
            "note.txt",
            "run.err",
            "run.out",
        ]

        for f in extract_files:
            ff = "Extract/job007/" + f
            os.system("touch " + ff)
            assert os.path.isfile(ff)
            file_list.append(ff)

        moviedir = "Extract/job007/Movies"
        os.system("mkdir " + moviedir)
        assert os.path.isdir("Extract/job007/Movies")

        for i in range(1, 11):
            f = moviedir + "/movie_parts{:03d}.mrcs".format(i)
            os.system("touch " + f)
            assert os.path.isfile(f)
            file_list.append(f)

        # make to .Nodes files
        nodes_files = [
            ".Nodes/3/Extract/job007/particles.star",
            ".Nodes/8/Class2D/job008/run_it025_model.star",
            ".Nodes/3/Class2D/job008/run_it025_data.star",
        ]
        for f in nodes_files:
            if not os.path.isdir(os.path.dirname(f)):
                subprocess.run(["mkdir", "-p", os.path.dirname(f)])
            subprocess.run(["touch", f])

        # read the pipeline
        pipeline = ProjectGraph(name="short_cl2d_del")
        pipeline.read()

        # get thr process to delete
        del_proc = pipeline.process_list[6]
        pipeline.delete_job(del_proc, True)

        # makesure the lines have been removed from the pipeline
        with open("short_cl2d_del_pipeline.star") as written_pipe:
            written = written_pipe.read()

        removed_lines = [
            "Extract/job007/ Extract/LoG_based/            5            2",
            "Class2D/job008/ Class2D/LoG_based/            8            2",
            "Extract/job007/particles.star            3",
            "Class2D/job008/run_it025_data.star        3",
            "Class2D/job008/run_it025_model.star            8",
            "Extract/job007/particles.star Class2D/job008/",
            "Extract/job007/ Extract/job007/particles.star",
            "Class2D/job008/ Class2D/job008/run_it025_model.star",
            "Class2D/job008/ Class2D/job008/run_it025_data.star",
        ]

        for removed_line in removed_lines:
            assert removed_line not in written, removed_line

        # make sure the files are gone
        for f in file_list:
            assert not os.path.isfile(f), f
            trashname = "Trash/" + f
            assert os.path.isfile(trashname), trashname

        # make sure the .Nodes entries are gone
        for f in nodes_files:
            assert not os.path.isfile(f), f
            dirname = os.path.dirname(f)
            assert not os.path.isdir(dirname), dirname

    def make_alias_file_structure(self, pipe_name, alias):
        shutil.copy(
            os.path.join(
                self.test_data, "Pipelines/{}_pipeline.star".format(pipe_name)
            ),
            self.test_dir,
        )

        assert os.path.isfile("{}_pipeline.star".format(pipe_name))

        fdir = "Class2D/job008"
        os.system("mkdir -p " + fdir)
        if alias is not None:
            os.symlink(
                os.path.abspath(fdir), os.path.join(self.test_dir, "Class2D/LoG_based")
            )
            assert os.path.islink("Class2D/LoG_based")

        real_files = [
            "Class2D/job008/run_it025_model.star",
            "Class2D/job008/run_it025_data.star",
        ]
        for f in real_files:
            os.system("touch " + f)

        outnodes = [NODES["Part data"], NODES["Model"]]
        if alias is None:
            alias = "job008"
        for node in outnodes:
            onode = "{}{}/Class2D/{}".format(NODES_DIR, node, alias)
            os.system("mkdir -p " + onode)
            assert os.path.isdir(onode)

        files = [
            "{}{}/Class2D/{}/run_it025_model.star".format(
                NODES_DIR, NODES["Model"], alias
            ),
            "{}{}/Class2D/{}/run_it025_data.star".format(
                NODES_DIR, NODES["Part data"], alias
            ),
        ]
        for f in files:
            os.system("touch " + f)
            assert os.path.isfile(f), f

    def test_change_job_alias(self):

        self.make_alias_file_structure("short_cl2d_finished", "LoG_based")

        pipeline = ProjectGraph(name="short_cl2d_finished")
        pipeline.read()

        change_proc = pipeline.process_list[7]
        pipeline.set_job_alias(change_proc, "pretty_new_one")

        assert os.path.islink(os.path.join(self.test_dir, "Class2D/pretty_new_one"))
        assert not os.path.islink(os.path.join(self.test_dir, "Class2D/LoG_based"))
        oldnodes = [
            str(NODES["Part data"]) + "/Class2D/LoG_based/run_it025_data.star",
            str(NODES["Model"]) + "/Class2D/LoG_based/run_it025_model.star",
        ]

        new_nodes = [
            str(NODES["Part data"]) + "/Class2D/pretty_new_one/run_it025_data.star",
            str(NODES["Model"]) + "/Class2D/pretty_new_one/run_it025_model.star",
        ]

        for n in oldnodes:
            assert not os.path.isfile(os.path.join(NODES_DIR, n)), n
        for n in new_nodes:
            assert os.path.isfile(os.path.join(NODES_DIR, n)), n

        with open(
            os.path.join(self.test_dir, "short_cl2d_finished_pipeline.star")
        ) as pipeline:
            pipe_data = pipeline.read()

        removed_line = "Class2D/job008/ Class2D/LoG_based/            8            2"
        new_line = "Class2D/job008/ Class2D/pretty_new_one/            8            2"

        assert removed_line not in pipe_data
        assert new_line in pipe_data

    def test_change_job_alias_to_none(self):

        self.make_alias_file_structure("short_cl2d_finished", "LoG_based")

        pipeline = ProjectGraph(name="short_cl2d_finished")
        pipeline.read()

        change_proc = pipeline.process_list[7]
        pipeline.set_job_alias(change_proc, "")

        assert not os.path.islink(os.path.join(self.test_dir, "Class2D/LoG_based"))
        oldnodes = [
            str(NODES["Part data"]) + "/Class2D/LoG_based/run_it025_data.star",
            str(NODES["Model"]) + "/Class2D/LoG_based/run_it025_model.star",
        ]

        new_nodes = [
            str(NODES["Part data"]) + "/Class2D/job008/run_it025_data.star",
            str(NODES["Model"]) + "/Class2D/job008/run_it025_model.star",
        ]

        for n in oldnodes:
            assert not os.path.isfile(os.path.join(NODES_DIR, n)), n
        for n in new_nodes:
            assert os.path.isfile(os.path.join(NODES_DIR, n)), n

        with open(
            os.path.join(self.test_dir, "short_cl2d_finished_pipeline.star")
        ) as pipeline:
            pipe_data = pipeline.read()

        removed_line = "Class2D/job008/ Class2D/LoG_based/            8            2"
        new_line = "Class2D/job008/       None            8            2"

        assert removed_line not in pipe_data, removed_line
        assert new_line in pipe_data, new_line

    def test_change_job_alias_from_none(self):

        self.make_alias_file_structure("short_cl2d_noalias", None)

        pipeline = ProjectGraph(name="short_cl2d_noalias")
        pipeline.read()

        change_proc = pipeline.process_list[7]
        pipeline.set_job_alias(change_proc, "from_none")

        new_nodes = [
            str(NODES["Part data"]) + "/Class2D/from_none/run_it025_data.star",
            str(NODES["Model"]) + "/Class2D/from_none/run_it025_model.star",
        ]

        old_nodes = [
            str(NODES["Part data"]) + "/Class2D/job008/run_it025_data.star",
            str(NODES["Model"]) + "/Class2D/job008/run_it025_model.star",
        ]

        for n in old_nodes:
            assert not os.path.isfile(os.path.join(NODES_DIR, n)), n
        for n in new_nodes:
            assert os.path.isfile(os.path.join(NODES_DIR, n)), n

        with open(
            os.path.join(self.test_dir, "short_cl2d_noalias_pipeline.star")
        ) as pipeline:
            pipe_data = pipeline.read()

        new_line = "Class2D/job008/ Class2D/from_none/            8            2"
        removed_line = "Class2D/job008/       None            8            2"

        assert removed_line not in pipe_data, removed_line
        assert new_line in pipe_data, new_line

    def test_job_alias_illegal_names(self):

        self.make_alias_file_structure("short_cl2d_noalias", None)

        pipeline = ProjectGraph(name="short_cl2d_noalias")
        pipeline.read()

        change_proc = pipeline.process_list[7]
        badnames = [
            "l",
            "JAH!!",
            "*nice*",
            "lala&",
            "(best",
            "worst)",
            "#HASH|",
            "pointy^^",
            "'quotes'",
            "'quotes'",
            "job420",
            "{left",
            "right}",
            ",comma",
            "100%",
            "any_more?",
            "\\slash",
            "otherslash/",
        ]
        for badname in badnames:
            with self.assertRaises(ValueError):
                pipeline.set_job_alias(change_proc, badname)

    def test_change_job_alias_not_unique(self):

        self.make_alias_file_structure("short_cl2d_finished", "LoG_based")

        pipeline = ProjectGraph(name="short_cl2d_finished")
        pipeline.read()

        change_proc = pipeline.process_list[7]
        with self.assertRaises(ValueError):
            pipeline.set_job_alias(change_proc, "LoG_based")

    def test_change_job_alias_not_unique_after_fixing_space(self):

        self.make_alias_file_structure("short_cl2d_finished", "LoG_based")

        pipeline = ProjectGraph(name="short_cl2d_finished")
        pipeline.read()

        change_proc = pipeline.process_list[7]
        with self.assertRaises(ValueError):
            pipeline.set_job_alias(change_proc, "LoG based")

    def test_change_job_alias_spaces_are_OK(self):

        self.make_alias_file_structure("short_cl2d_finished", "LoG_based")

        pipeline = ProjectGraph(name="short_cl2d_finished")
        pipeline.read()

        change_proc = pipeline.process_list[7]
        pipeline.set_job_alias(change_proc, "pretty new one")

        assert os.path.islink(os.path.join(self.test_dir, "Class2D/pretty_new_one"))
        assert not os.path.islink(os.path.join(self.test_dir, "Class2D/LoG_based"))
        oldnodes = [
            str(NODES["Part data"]) + "/Class2D/LoG_based/run_it025_data.star",
            str(NODES["Model"]) + "/Class2D/LoG_based/run_it025_model.star",
        ]

        new_nodes = [
            str(NODES["Part data"]) + "/Class2D/pretty_new_one/run_it025_data.star",
            str(NODES["Model"]) + "/Class2D/pretty_new_one/run_it025_model.star",
        ]

        for n in oldnodes:
            assert not os.path.isfile(os.path.join(NODES_DIR, n)), n
        for n in new_nodes:
            assert os.path.isfile(os.path.join(NODES_DIR, n)), n

        with open(
            os.path.join(self.test_dir, "short_cl2d_finished_pipeline.star")
        ) as pipeline:
            pipe_data = pipeline.read()

        removed_line = "Class2D/job008/ Class2D/LoG_based/            8            2"
        new_line = "Class2D/job008/ Class2D/pretty_new_one/            8            2"

        assert removed_line not in pipe_data
        assert new_line in pipe_data

    def make_undelete_file_structure(self):
        # make the directories needed
        dirs = [
            "Class2D/job008",
            "Extract/job007",
            "Trash",
        ]

        for d in dirs:
            os.system("mkdir -p " + d)
            assert os.path.isdir(d), d

        # make files common to all run types
        common_files = [
            "run.out",
            "run.err",
            "note.txt",
            "run.job",
            "default_pipeline.star",
            "RELION_JOB_EXIT_SUCCESS",
        ]

        outfiles = list()
        for d in dirs[:-1]:
            for f in common_files:
                os.system("touch " + d + "/" + f)
                assert os.path.isfile(d + "/" + f), d + "/" + f
                outfiles.append(d + "/" + f)

        # copy in the pipeline
        shutil.copy(
            os.path.join(
                self.test_data, "Pipelines/for_undelete_cl2d_job_pipeline.star"
            ),
            os.path.join(self.test_dir, "Class2D/job008/job_pipeline.star"),
        )
        # add the specific files for each run
        outfiles.append("Class2D/job008/job_pipeline.star")

        shutil.copy(
            os.path.join(
                self.test_data, "Pipelines/for_undelete_extract_job_pipeline.star"
            ),
            os.path.join(self.test_dir, "Extract/job007/job_pipeline.star"),
        )
        outfiles.append("Extract/job007/job_pipeline.star")

        os.system("touch Extract/job007/particles.star")
        assert os.path.isfile("Extract/job007/particles.star")
        outfiles.append("Extract/job007/particles.star")

        os.system("mkdir Extract/job007/Movies")
        assert os.path.isdir("Extract/job007/Movies")

        # make particles files
        for i in range(1, 11):
            f = "Extract/job007/Movies/movie_{:03d}.mrcs".format(i)
            os.system("touch " + f)
            assert os.path.isfile(f), f
            outfiles.append(f)

        # make class2d files
        cl2d_files = ["_data.star", "_model.star", "_optimiser.star"]
        for i in range(1, 26):
            for f in cl2d_files:
                ff = "Class2D/job008/run_it{:03d}{}".format(i, f)
                os.system("touch " + ff)
                assert os.path.isfile(ff)
                outfiles.append(ff)

        os.system("mv Class2D Trash/Class2D")
        os.system("mv Extract Trash/Extract")

        assert not os.path.isdir("Class2D")
        assert not os.path.isdir("Extract")
        assert os.path.isdir("Trash/Class2D")
        assert os.path.isdir("Trash/Extract")

        return outfiles

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_undelete_single(self):
        # make the file structure like jobs have been run
        outfiles = self.make_undelete_file_structure()

        # copy in the pipeline
        shutil.copy(
            os.path.join(
                self.test_data, "Pipelines/for_undelete_deleted_pipeline.star"
            ),
            self.test_dir,
        )

        # initialize the project
        pipeline = ProjectGraph(name="for_undelete_deleted")
        pipeline.read()

        # lines that should be restored
        restored_lines = [
            "Extract/job007/ Extract/LoG_based/            5            2",
            "CtfFind/job003/micrographs_ctf.star Extract/job007/",
            "AutoPick/job006/coords_suffix_autopick.star Extract/job007/",
            "Extract/job007/ Extract/job007/particles.star",
        ]

        # make sure the lines to be undelete are not in the pipeline
        with open("for_undelete_deleted_pipeline.star") as original_pipe:
            original = original_pipe.read()

        for line in restored_lines:
            assert line not in original, line

        # undelete the job
        pipeline.undelete_job("Extract/job007/")

        # make sure the undeleted lines are back in the pipeline
        with open("for_undelete_deleted_pipeline.star") as edited_pipe:
            wrote = edited_pipe.read()

        for line in restored_lines:
            assert line in wrote, line

        # make sure the files are back
        for f in outfiles:
            if "Extract" in f:
                assert os.path.isfile(f), f

        # make sure the .Nodes entries are back
        nodes_files = [
            ".Nodes/3/Extract/LoG_based/particles.star",
        ]
        for f in nodes_files:
            assert os.path.isfile(f), f

        # make sure the alias is restored
        assert os.path.islink("Extract/LoG_based")

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_undelete_single_no_alias(self):
        # set up file structure
        outfiles = self.make_undelete_file_structure()

        # get pipelines
        shutil.copy(
            os.path.join(
                self.test_data, "Pipelines/for_undelete_deleted_pipeline.star"
            ),
            self.test_dir,
        )

        shutil.copy(
            os.path.join(
                self.test_data, "Pipelines/for_undelete_noalias_job_pipeline.star"
            ),
            os.path.join(self.test_dir, "Trash/Extract/job007/job_pipeline.star"),
        )

        # load and read pipeline
        pipeline = ProjectGraph(name="for_undelete_deleted")
        pipeline.read()

        # lines to be restored
        restored_lines = [
            "Extract/job007/       None            5            2",
            "CtfFind/job003/micrographs_ctf.star Extract/job007/",
            "AutoPick/job006/coords_suffix_autopick.star Extract/job007/",
            "Extract/job007/ Extract/job007/particles.star",
        ]

        # make sure lines to be restored are not in the pipeline
        with open("for_undelete_deleted_pipeline.star") as original_pipe:
            original = original_pipe.read()

        for line in restored_lines:
            assert line not in original, line

        # undelete the extrat job
        pipeline.undelete_job("Extract/job007/")

        # make sure the lines have been restored to the pipeline
        with open("for_undelete_deleted_pipeline.star") as edited_pipe:
            wrote = edited_pipe.read()

        for line in restored_lines:
            assert line in wrote, line

        # make sure the files are back
        for f in outfiles:
            if "Extract" in f:
                assert os.path.isfile(f), f

        # make sure the .Nodes entries are back
        nodes_files = [
            ".Nodes/3/Extract/job007/particles.star",
        ]
        for f in nodes_files:
            assert os.path.isfile(f), f

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_undelete_single_alias_not_unique(self):
        #  make file structure
        outfiles = self.make_undelete_file_structure()

        # copy in the pipelines
        shutil.copy(
            os.path.join(
                self.test_data, "Pipelines/for_undelete_extra_alias_pipeline.star"
            ),
            self.test_dir,
        )

        shutil.copy(
            os.path.join(
                self.test_data, "Pipelines/for_undelete_extract_job_pipeline.star"
            ),
            os.path.join(self.test_dir, "Trash/Extract/job007/job_pipeline.star"),
        )

        # load and read pipeline
        pipeline = ProjectGraph(name="for_undelete_extra_alias")
        pipeline.read()

        #  lines to be restored
        restored_lines = [
            "Extract/job007/       None            5            2",
            "CtfFind/job003/micrographs_ctf.star Extract/job007/",
            "AutoPick/job006/coords_suffix_autopick.star Extract/job007/",
            "Extract/job007/ Extract/job007/particles.star",
        ]

        # make sure lines to be restored are not in pipeline
        with open("for_undelete_extra_alias_pipeline.star") as original_pipe:
            original = original_pipe.read()

        for line in restored_lines:
            assert line not in original, line

        # undelete the extract job
        pipeline.undelete_job("Extract/job007/")

        # make sure the lines are back in  the pipeline
        with open("for_undelete_extra_alias_pipeline.star") as edited_pipe:
            wrote = edited_pipe.read()

        for line in restored_lines:
            assert line in wrote, line

        # make sure the files are back
        for f in outfiles:
            if "Extract" in f:
                assert os.path.isfile(f), f

        # make sure the .Nodes entries are back
        nodes_files = [
            ".Nodes/3/Extract/job007/particles.star",
        ]
        for f in nodes_files:
            assert os.path.isfile(f), f

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_undelete_process_with_parents(self):
        outfiles = self.make_undelete_file_structure()

        shutil.copy(
            os.path.join(
                self.test_data, "Pipelines/for_undelete_deleted_pipeline.star"
            ),
            self.test_dir,
        )

        pipeline = ProjectGraph(name="for_undelete_deleted")
        pipeline.read()

        restored_lines = [
            "Extract/job007/ Extract/LoG_based/            5            2",
            "CtfFind/job003/micrographs_ctf.star Extract/job007/",
            "AutoPick/job006/coords_suffix_autopick.star Extract/job007/",
            "Extract/job007/ Extract/job007/particles.star",
            "Class2D/job008/run_it025_model.star            8",
            "Class2D/job008/run_it025_data.star            3",
            "Extract/job007/particles.star Class2D/job008/",
            "Class2D/job008/ Class2D/job008/run_it025_model.star",
            "Class2D/job008/ Class2D/job008/run_it025_data.star",
        ]

        with open("for_undelete_deleted_pipeline.star") as original_pipe:
            original = original_pipe.read()

        for line in restored_lines:
            assert line not in original, line

        pipeline.undelete_job("Class2D/job008/")

        with open("for_undelete_deleted_pipeline.star") as edited_pipe:
            wrote = edited_pipe.read()

        for line in restored_lines:
            assert line in wrote, line

        for f in outfiles:
            assert os.path.isfile(f), f

        assert os.path.islink("Extract/LoG_based")
        assert os.path.islink("Class2D/LoG_based")

    @unittest.skipUnless(do_full, "Slow test: only run in full unittest")
    def test_delete_job_then_undelete(self):
        # create the file structure - move things out of the trash
        # like they weren't deleted

        outfiles = self.make_undelete_file_structure()
        os.system("mv Trash/Class2D Class2D")
        os.system("mv Trash/Extract Extract")
        os.symlink("Extract/job007", "Extract/LoG_based")
        os.symlink("Class2D/job008", "Class2D/LoG_based")

        # make the .Nodes entries
        nodes_files = [
            ".Nodes/3/Extract/job007/particles.star",
            ".Nodes/8/Class2D/job008/run_it025_model.star",
            ".Nodes/3/Class2D/job008/run_it025_data.star",
        ]
        for f in nodes_files:
            nodedir = os.path.dirname(f)
            if not os.path.isfile(nodedir):
                subprocess.run(["mkdir", "-p", nodedir])
            subprocess.run(["touch", f])

        # copy in the pipeline
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/short_cl2d_del_pipeline.star"),
            self.test_dir,
        )

        # open and read the pipeline
        pipeline = ProjectGraph(name="short_cl2d_del")
        pipeline.read()

        with open("short_cl2d_del_pipeline.star") as original_pipe:
            original = original_pipe.read()

        # delete the process
        del_proc = pipeline.process_list[6]
        pipeline.delete_job(del_proc, True)

        # open the newly written pipeline
        with open("short_cl2d_del_pipeline.star") as written_pipe:
            written = written_pipe.read()

        #  lines that should be removed from the pipeline
        removed_lines = [
            "Extract/job007/ Extract/LoG_based/            5            2",
            "Class2D/job008/ Class2D/LoG_based/            8            2",
            "Extract/job007/particles.star            3",
            "Class2D/job008/run_it025_data.star            3",
            "Class2D/job008/run_it025_model.star            8",
            "Extract/job007/particles.star Class2D/job008/",
            "Extract/job007/ Extract/job007/particles.star",
            "Class2D/job008/ Class2D/job008/run_it025_model.star",
            "Class2D/job008/ Class2D/job008/run_it025_data.star",
        ]

        # make sure everything is deleted as expected
        for removed_line in removed_lines:
            assert removed_line in original, removed_line
        for removed_line in removed_lines:
            assert removed_line not in written, removed_line

        # makes sure the .Nodes entries are not there
        nodes_files = [
            ".Nodes/3/Extract/job007/particles.star",
            ".Nodes/8/Class2D/job008/run_it025_model.star",
            ".Nodes/3/Class2D/job008/run_it025_data.star",
        ]
        for f in nodes_files:
            assert not os.path.isfile(f), f

        # make sure the files are in the trash
        for f in outfiles:
            assert not os.path.isfile(f), f
            trashname = "Trash/" + f
            assert os.path.isfile(trashname), trashname

        # undelete the job that has a parent
        pipeline.undelete_job("Class2D/job008/")

        # make sure the lines are restored to tje pipeline
        with open("short_cl2d_del_pipeline.star") as restored_pipe:
            restored = restored_pipe.read()

        for removed_line in removed_lines:
            assert removed_line in restored, removed_line

        # make sure the files are back
        for f in outfiles:
            assert os.path.isfile(f), f

        # make sure the .Nodes entries are back
        nodes_files = [
            ".Nodes/3/Extract/LoG_based/particles.star",
            ".Nodes/8/Class2D/LoG_based/run_it025_model.star",
            ".Nodes/3/Class2D/LoG_based/run_it025_data.star",
        ]
        for f in nodes_files:
            assert os.path.isfile(f), f

    def test_check_pipeline_entries(self):
        """ Make sure a bug where input and output edges are duplicated
        is not occurring - any node that was used as an input to another
        process was duplicated in input and output edges """

        # copy in the map
        shutil.copy(os.path.join(self.test_data, "emd_3488.mrc"), self.test_dir)

        # Prepare a new pipeline and run the import job
        pipeline = JobRunner()
        map_job = job_factory.read_job(
            os.path.join(self.test_data, "import_map.job"), do_initialise=True
        )
        pipeline.run_job(map_job, None, False, False, False)

        # run the mask create job
        mask_job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/MaskCreate/maskcreate.job"),
            do_initialise=True,
        )
        pipeline.run_job(mask_job, None, False, False, False)
        time.sleep(0.5)

        # copy in the halfmaps
        halfmap_import_dir = "Halfmaps"
        os.makedirs(halfmap_import_dir)
        shutil.copy(
            os.path.join(self.test_data, "3488_run_half1_class001_unfil.mrc"),
            halfmap_import_dir,
        )
        shutil.copy(
            os.path.join(self.test_data, "3488_run_half2_class001_unfil.mrc"),
            halfmap_import_dir,
        )

        # run the postprocess job
        PP_job = job_factory.read_job(
            os.path.join(
                self.test_data, "JobFiles/PostProcess/postprocess_halfmapdir.job"
            ),
            do_initialise=True,
        )
        pipeline.run_job(PP_job, None, False, False, False)
        time.sleep(1)

        duplicated_lines = [
            "Import/job001/emd_3488.mrc MaskCreate/job002/ \n",
            "MaskCreate/job002/mask.mrc PostProcess/job003/ \n",
            "Import/job001/ Import/job001/emd_3488.mrc \n",
            "MaskCreate/job002/ MaskCreate/job002/mask.mrc \n",
        ]

        # make sure the duplicated nodes are not there
        dups = 0
        with open("default_pipeline.star") as pipe:
            pipe_data = pipe.readlines()
        for line in duplicated_lines:
            for pipe_line in pipe_data:
                if line in pipe_line:
                    dups += 1
            assert dups <= 1, line
            dups = 0

    def test_find_immediate_child_processes(self):
        #  copy in the pipeline
        shutil.copy(
            os.path.join(self.test_data, "Pipelines/tutorial_pipeline.star"),
            self.test_dir,
        )
        # open and read the pipeline
        pipeline = ProjectGraph(name="tutorial")
        pipeline.read()
        import_proc = pipeline.find_process("Import/job001/")
        import_children = pipeline.find_immediate_child_processes(import_proc)
        assert len(import_children) == 1


if __name__ == "__main__":
    unittest.main()
