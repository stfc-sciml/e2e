import unittest
import os
import shutil
import tempfile

from pipeliner.relion_jobs import job_factory
from pipeliner_tests import test_data
from pipeliner_tests import generic_tests
from pipeliner.data_structure import NODES


class MotionCorrTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_get_ctffind_env_var(self):
        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/MotionCorr/motioncorr_noexe.job")
        )
        assert (
            job.joboptions["fn_motioncor2_exe"].defaultvalue
            == "Enter path to MOTIONCOR2 executable"
        )

        os.environ["RELION_MOTIONCOR2_EXECUTABLE"] = os.path.join(
            self.test_data, "fake_motioncorr2.exe"
        )
        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/MotionCorr/motioncorr_noexe.job")
        )
        assert job.joboptions["fn_motioncor2_exe"].defaultvalue == os.path.join(
            self.test_data, "fake_motioncorr2.exe"
        )

    def test_get_command_own(self):
        generic_tests.general_get_command_test(
            self,
            "MotionCorr",
            "motioncorr_own.job",
            2,
            {"Import/job001/movies.star": NODES["Movies"]},
            {
                "corrected_micrographs.star": NODES["Mics"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "`which relion_run_motioncorr` --i Import/job001/movies.star --o"
            " MotionCorr/job002/ --first_frame_sum 1 --last_frame_sum 0 --use_own"
            " --j 24 --bin_factor 1 --bfactor 150 --dose_per_frame 1.277 "
            "--preexposure 0 --patch_x 5 --patch_y 5 --gainref Movies/gain.mrc"
            " --gain_rot 0 --gain_flip 0 --dose_weighting --grouping_for_ps 3"
            " --pipeline_control MotionCorr/job002/"
            " >> MotionCorr/job002/run.out 2>> MotionCorr/job002/run.err & ",
        )

    def test_get_command_own_jobstar(self):
        generic_tests.general_get_command_test(
            self,
            "MotionCorr",
            "motioncorr_own_job.star",
            2,
            {"Import/job001/movies.star": NODES["Movies"]},
            {
                "corrected_micrographs.star": NODES["Mics"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "`which relion_run_motioncorr` --i Import/job001/movies.star --o"
            " MotionCorr/job002/ --first_frame_sum 1 --last_frame_sum 0 --use_own"
            " --j 24 --bin_factor 1 --bfactor 150 --dose_per_frame 1.277 "
            "--preexposure 0 --patch_x 5 --patch_y 5 --group_frames 3"
            " --gainref Movies/gain.mrc"
            " --gain_rot 0 --gain_flip 0 --dose_weighting --grouping_for_ps 3"
            " --pipeline_control MotionCorr/job002/"
            " >> MotionCorr/job002/run.out 2>> MotionCorr/job002/run.err & ",
        )

    def test_get_command_own_continue(self):
        generic_tests.general_get_command_test(
            self,
            "MotionCorr",
            "motioncorr_own_continue.job",
            2,
            {"Import/job001/movies.star": NODES["Movies"]},
            {
                "corrected_micrographs.star": NODES["Mics"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "`which relion_run_motioncorr` --i Import/job001/movies.star --o"
            " MotionCorr/job002/ --first_frame_sum 1 --last_frame_sum 0 --use_own"
            " --j 24 --bin_factor 1 --bfactor 150 --dose_per_frame 1.277 "
            "--preexposure 0 --patch_x 5 --patch_y 5 --gainref Movies/gain.mrc"
            " --gain_rot 0 --gain_flip 0 --dose_weighting --grouping_for_ps 3"
            " --only_do_unfinished --pipeline_control MotionCorr/job002/"
            " >> MotionCorr/job002/run.out 2>> MotionCorr/job002/run.err & ",
        )

    def test_get_command_own_noDW(self):
        generic_tests.general_get_command_test(
            self,
            "MotionCorr",
            "motioncorr_own_noDW.job",
            2,
            {"Import/job001/movies.star": NODES["Movies"]},
            {
                "corrected_micrographs.star": NODES["Mics"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "`which relion_run_motioncorr` --i Import/job001/movies.star"
            " --o MotionCorr/job002/ --first_frame_sum 1 --last_frame_sum"
            " -1 --use_own --j 24 --bin_factor 1 --bfactor 150 --dose_per_frame 1"
            " --preexposure 0 --patch_x 5 --patch_y 5 --group_frames 3 --gainref"
            " Movies/gain.mrc --gain_rot 0 --gain_flip 0 --grouping_for_ps 4"
            " --pipeline_control MotionCorr/job002/"
            " >> MotionCorr/job002/run.out 2>> MotionCorr/job002/run.err & ",
        )

    def test_get_command_own_savenoDW(self):
        generic_tests.general_get_command_test(
            self,
            "MotionCorr",
            "motioncorr_own_save_noDW.job",
            2,
            {"Import/job001/movies.star": NODES["Movies"]},
            {
                "corrected_micrographs.star": NODES["Mics"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "`which relion_run_motioncorr` --i Import/job001/movies.star"
            " --o MotionCorr/job002/ --first_frame_sum 1 --last_frame_sum"
            " -1 --use_own --j 24 --bin_factor 1 --bfactor 150 --dose_per_frame 1"
            " --preexposure 0 --patch_x 5 --patch_y 5 --group_frames 3 --gainref"
            " Movies/gain.mrc --gain_rot 0 --gain_flip 0 --dose_weighting --save_noDW"
            " --pipeline_control MotionCorr/job002/ >> MotionCorr/job002/run.out 2>> "
            "MotionCorr/job002/run.err & ",
        )

    def test_get_command_mocorr(self):
        generic_tests.general_get_command_test(
            self,
            "MotionCorr",
            "motioncorr_mocorr.job",
            2,
            {"Import/job001/movies.star": NODES["Movies"]},
            {
                "corrected_micrographs.star": NODES["Mics"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 2 `which relion_run_motioncorr_mpi` --i "
            "Import/job001/movies.star --o MotionCorr/job002/ "
            "--first_frame_sum 1 --last_frame_sum -1 "
            "--use_motioncor2 --motioncor2_exe fake_motioncorr2.exe"
            ' --other_motioncor2_args " --mocorr_test_arg " --gpu "0:1"'
            " --bin_factor 1 --bfactor 150 --dose_per_frame 1.5 --preexposure 2"
            " --patch_x 5 --patch_y 5 --group_frames 3 --gainref Movies/gain.mrc"
            " --gain_rot 0 --gain_flip 0 --dose_weighting --save_noDW "
            "--pipeline_control MotionCorr/job002/ "
            ">> MotionCorr/job002/run.out 2>> MotionCorr/job002/run.err & ",
        )

    def test_get_command_mocorr_defectfile(self):
        generic_tests.general_get_command_test(
            self,
            "MotionCorr",
            "motioncorr_mocorr_defect.job",
            2,
            {"Import/job001/movies.star": NODES["Movies"]},
            {
                "corrected_micrographs.star": NODES["Mics"],
                "logfile.pdf": NODES["PdfLogfile"],
            },
            "mpirun -n 2 `which relion_run_motioncorr_mpi` --i "
            "Import/job001/movies.star --o MotionCorr/job002/"
            " --first_frame_sum 1 --last_frame_sum -1 "
            "--use_motioncor2 --motioncor2_exe fake_motioncorr2.exe"
            ' --other_motioncor2_args " --mocorr_test_arg " --gpu "0:1"'
            " --defect_file defect_file.mrc --bin_factor 1 --bfactor 150"
            " --dose_per_frame 1.5 --preexposure 2 --patch_x 5 --patch_y 5"
            " --group_frames 3 --gainref Movies/gain.mrc --gain_rot 0 --gain_flip"
            " 0 --dose_weighting --save_noDW --pipeline_control MotionCorr/job002/"
            " >> MotionCorr/job002/run.out 2>> MotionCorr/job002/run.err & ",
        )


if __name__ == "__main__":
    unittest.main()
