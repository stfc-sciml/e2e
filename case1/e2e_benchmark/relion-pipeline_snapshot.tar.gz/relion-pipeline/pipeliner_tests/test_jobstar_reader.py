import unittest
from pipeliner.jobstar_reader import JobStar, BodyFile, OutputNodeStar
import os
import tempfile
import shutil
from pipeliner_tests import test_data


class JobStarReaderTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories and get example file.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_reader(self):
        """make sure all the blocks are as expected"""
        jobdata = JobStar(
            os.path.join(self.test_data, "JobFiles/MaskCreate/maskcreate_job.star")
        )
        assert jobdata.count_blocks() == 2, jobdata.count_blocks()
        assert jobdata.count_pipeline() == 2, jobdata.count_pipeline()
        assert jobdata.count_jobopt() == 15, jobdata.count_jobopt()

    def test_return_option_pairs(self):
        """ return the job options and values """
        jobdata = JobStar(
            os.path.join(self.test_data, "JobFiles/MaskCreate/maskcreate_job.star")
        )
        options = jobdata.get_all_options()
        assert len(options) == 17, len(options)

    def test_read_bodyfile(self):
        """ Test reading a body file for multibody refinement """
        bildfile_data = BodyFile(
            os.path.join(self.test_data, "JobFiles/MultiBody/bodyfile.star")
        )
        assert bildfile_data.count_bodies() == 3

    def test_correcting_reserved_words_changed(self):
        """ Check reading a motioncorr file where the data labels
        have been changed to avoid using reserved words"""
        jobdata = JobStar(
            os.path.join(self.test_data, "StarFiles/motioncorr_changed.star")
        )
        jovals = jobdata.data.find_block("joboptions_values")
        joloop = jovals.find_loop("_rlnJobOptionVariable")
        assert list(joloop) == [
            "bfactor",
            "bin_factor",
            "do_dose_weighting",
            "do_own_motioncor",
            "do_queue",
            "dose_per_frame",
            "first_frame_sum",
            "fn_defect",
            "fn_gain_ref",
            "fn_motioncor2_exe",
            "gain_flip",
            "gain_rot",
            "gpu_ids",
            "group_for_ps",
            "group_frames",
            "input_star_mics",
            "last_frame_sum",
            "min_dedicated",
            "nr_mpi",
            "nr_threads",
            "other_args",
            "other_motioncor2_args",
            "patch_x",
            "patch_y",
            "pre_exposure",
            "qsub",
            "qsubscript",
            "noDW_save",
            "ps_save",
            "queuename",
        ]

    def test_correcting_reserved_words_quotated(self):
        """ Check read a files that contains reserved words as labels
         but they have been quotated """
        jobdata = JobStar(
            os.path.join(self.test_data, "StarFiles/motioncorr_quotated.star")
        )
        jovals = jobdata.data.find_block("joboptions_values")
        joloop = jovals.find_loop("_rlnJobOptionVariable")
        assert list(joloop) == [
            "bfactor",
            "bin_factor",
            "do_dose_weighting",
            "do_own_motioncor",
            "do_queue",
            "dose_per_frame",
            "first_frame_sum",
            "fn_defect",
            "fn_gain_ref",
            "fn_motioncor2_exe",
            "gain_flip",
            "gain_rot",
            "gpu_ids",
            "group_for_ps",
            "group_frames",
            "input_star_mics",
            "last_frame_sum",
            "min_dedicated",
            "nr_mpi",
            "nr_threads",
            "other_args",
            "other_motioncor2_args",
            "patch_x",
            "patch_y",
            "pre_exposure",
            "qsub",
            "qsubscript",
            '"save_noDW"',
            '"save_ps"',
            "queuename",
        ]

    def test_correcting_reserved_words_not_quotated(self):
        """ Test reading a file where reserved words are used for data labels
        make sure the correction runs as expected"""
        jobdata = JobStar(
            os.path.join(self.test_data, "StarFiles/motioncorr_not_quotated.star")
        )
        jovals = jobdata.data.find_block("joboptions_values")
        joloop = jovals.find_loop("_rlnJobOptionVariable")
        assert list(joloop) == [
            "bfactor",
            "bin_factor",
            "do_dose_weighting",
            "do_own_motioncor",
            "do_queue",
            "dose_per_frame",
            "first_frame_sum",
            "fn_defect",
            "fn_gain_ref",
            "fn_motioncor2_exe",
            "gain_flip",
            "gain_rot",
            "gpu_ids",
            "group_for_ps",
            "group_frames",
            "input_star_mics",
            "last_frame_sum",
            "min_dedicated",
            "nr_mpi",
            "nr_threads",
            "other_args",
            "other_motioncor2_args",
            "patch_x",
            "patch_y",
            "pre_exposure",
            "qsub",
            "qsubscript",
            '"save_noDW"',
            '"save_ps"',
            "queuename",
        ]

    def test_reading_outputnodes_star(self):
        """ Test reading a file containing output nodes"""
        on_star = OutputNodeStar(
            os.path.join(self.test_data, "StarFiles/RELION_OUTPUT_NODES.star")
        )
        outnodes = on_star.get_output_nodes()
        assert outnodes[0][0] == "MotionCorr/job002/corrected_micrographs.star"
        assert outnodes[0][1] == "1"
        assert outnodes[1][0] == "MotionCorr/job002/logfile.pdf"
        assert outnodes[1][1] == "13"
        assert outnodes[2][0] == "CtfFind/job003/micrographs_ctf.star"
        assert outnodes[2][1] == "1"
        assert outnodes[3][0] == "CtfFind/job003/logfile.pdf"
        assert outnodes[3][1] == "13"


if __name__ == "__main__":
    unittest.main()
