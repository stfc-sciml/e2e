import unittest
import os
import shutil
import tempfile

from pipeliner_tests import test_data
from pipeliner_tests.generic_tests import general_get_command_test
from pipeliner.data_structure import NODES


class JoinStarTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_join_parts(self):
        general_get_command_test(
            self,
            "JoinStar",
            "joinstar_parts.job",
            13,
            {
                "parts_file1.star": NODES["Part data"],
                "parts_file2.star": NODES["Part data"],
                "parts_file3.star": NODES["Part data"],
                "parts_file4.star": NODES["Part data"],
            },
            {"join_particles.star": NODES["Part data"]},
            '`which relion_star_handler` --combine --i " parts_file1.star '
            'parts_file2.star parts_file3.star parts_file4.star " --check_duplicates'
            " rlnImageName --o JoinStar/job013/join_particles.star"
            " --pipeline_control JoinStar/job013/"
            " >> JoinStar/job013/run.out 2>> JoinStar/job013/run.err & ",
        )

    def test_join_parts_jobstar(self):
        general_get_command_test(
            self,
            "JoinStar",
            "joinstar_parts_job.star",
            13,
            {
                "parts_file1.star": NODES["Part data"],
                "parts_file2.star": NODES["Part data"],
                "parts_file3.star": NODES["Part data"],
                "parts_file4.star": NODES["Part data"],
            },
            {"join_particles.star": NODES["Part data"]},
            '`which relion_star_handler` --combine --i " parts_file1.star '
            'parts_file2.star parts_file3.star parts_file4.star " --check_duplicates'
            " rlnImageName --o JoinStar/job013/join_particles.star"
            " --pipeline_control JoinStar/job013/"
            " >> JoinStar/job013/run.out 2>> JoinStar/job013/run.err & ",
        )

    def test_join_too_many_types(self):
        with self.assertRaises(ValueError):
            general_get_command_test(
                self,
                "JoinStar",
                "joinstar_toomany_types.job",
                13,
                {
                    "parts_file1.star": NODES["Part data"],
                    "parts_file2.star": NODES["Part data"],
                    "parts_file3.star": NODES["Part data"],
                    "parts_file4.star": NODES["Part data"],
                },
                {"join_particles.star": NODES["Part data"]},
                "",
            )

    def test_join_no_types(self):
        with self.assertRaises(ValueError):
            general_get_command_test(
                self,
                "JoinStar",
                "joinstar_no_types.job",
                13,
                {
                    "parts_file1.star": NODES["Part data"],
                    "parts_file2.star": NODES["Part data"],
                    "parts_file3.star": NODES["Part data"],
                    "parts_file4.star": NODES["Part data"],
                },
                {"join_particles.star": NODES["Part data"]},
                "",
            )

    def test_join_too_few_files(self):
        with self.assertRaises(ValueError):
            general_get_command_test(
                self,
                "JoinStar",
                "joinstar_too_few_files.job",
                13,
                {
                    "parts_file1.star": NODES["Part data"],
                    "parts_file2.star": NODES["Part data"],
                    "parts_file3.star": NODES["Part data"],
                    "parts_file4.star": NODES["Part data"],
                },
                {"join_particles.star": NODES["Part data"]},
                "",
            )

    def test_join_parts_1and2_missing(self):
        general_get_command_test(
            self,
            "JoinStar",
            "joinstar_parts_1and2_missing.job",
            13,
            {
                "parts_file3.star": NODES["Part data"],
                "parts_file4.star": NODES["Part data"],
            },
            {"join_particles.star": NODES["Part data"]},
            '`which relion_star_handler` --combine --i " '
            'parts_file3.star parts_file4.star " --check_duplicates'
            " rlnImageName --o JoinStar/job013/join_particles.star"
            " --pipeline_control JoinStar/job013/"
            " >> JoinStar/job013/run.out 2>> JoinStar/job013/run.err & ",
        )

    def test_join_mics(self):
        general_get_command_test(
            self,
            "JoinStar",
            "joinstar_mics.job",
            13,
            {
                "micrographs_file1.star": NODES["Mics"],
                "micrographs_file2.star": NODES["Mics"],
                "micrographs_file3.star": NODES["Mics"],
                "micrographs_file4.star": NODES["Mics"],
            },
            {"join_mics.star": NODES["Mics"]},
            '`which relion_star_handler` --combine --i " micrographs_file1.star '
            'micrographs_file2.star micrographs_file3.star micrographs_file4.star "'
            " --check_duplicates rlnMicrographName --o "
            "JoinStar/job013/join_mics.star --pipeline_control JoinStar/job013/"
            " >> JoinStar/job013/run.out 2>> JoinStar/job013/run.err & ",
        )

    def test_join_movies(self):
        general_get_command_test(
            self,
            "JoinStar",
            "joinstar_movies.job",
            13,
            {
                "movies_file1.star": NODES["Movies"],
                "movies_file2.star": NODES["Movies"],
                "movies_file3.star": NODES["Movies"],
                "movies_file4.star": NODES["Movies"],
            },
            {"join_movies.star": NODES["Movies"]},
            '`which relion_star_handler` --combine --i " movies_file1.star '
            'movies_file2.star movies_file3.star movies_file4.star "'
            " --check_duplicates rlnMicrographName --o "
            "JoinStar/job013/join_movies.star --pipeline_control JoinStar/job013/"
            " >> JoinStar/job013/run.out 2>> JoinStar/job013/run.err & ",
        )

    def test_join_movies_additional_args(self):
        general_get_command_test(
            self,
            "JoinStar",
            "joinstar_movies_extra_args.job",
            13,
            {
                "movies_file1.star": NODES["Movies"],
                "movies_file2.star": NODES["Movies"],
                "movies_file3.star": NODES["Movies"],
                "movies_file4.star": NODES["Movies"],
            },
            {"join_movies.star": NODES["Movies"]},
            '`which relion_star_handler` --combine --i " movies_file1.star '
            'movies_file2.star movies_file3.star movies_file4.star "'
            " --check_duplicates rlnMicrographName --o "
            "JoinStar/job013/join_movies.star --Here_are_the_extra_arguments Blah"
            " --pipeline_control JoinStar/job013/"
            " >> JoinStar/job013/run.out 2>> JoinStar/job013/run.err & ",
        )


if __name__ == "__main__":
    unittest.main()
