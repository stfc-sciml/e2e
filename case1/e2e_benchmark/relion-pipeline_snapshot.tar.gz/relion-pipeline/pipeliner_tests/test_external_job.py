import unittest
import os
import shutil
import tempfile

from pipeliner_tests import test_data
from pipeliner_tests import generic_tests
from pipeliner.data_structure import NODES


class ExternalJobTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)
        os.mkdir("CtfRefine")
        os.mkdir("CtfRefine/job018")

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_get_command_external_movies(self):
        generic_tests.general_get_command_test(
            self,
            "External",
            "external_movies.job",
            19,
            {"Import/job001/movies.star": NODES["Movies"]},
            {},
            "/path/to/external/here.exe --in_movies Import/job001/movies.star "
            "--o External/job019/ --test_param1 1001 --j 16 >> "
            "External/job019/run.out 2>> External/job019/run.err & ",
        )

    def test_get_command_external_parts(self):
        generic_tests.general_get_command_test(
            self,
            "External",
            "external_parts.job",
            19,
            {"Import/job001/particles.star": NODES["Part data"]},
            {},
            "/path/to/external/here.exe --in_parts Import/job001/particles.star "
            "--o External/job019/ --test_param1 1001 --j 16 >> "
            "External/job019/run.out 2>> External/job019/run.err & ",
        )

    def test_get_command_external_3dref(self):
        generic_tests.general_get_command_test(
            self,
            "External",
            "external_3dref.job",
            19,
            {"Import/job001/3dref.mrc": NODES["3D refs"]},
            {},
            "/path/to/external/here.exe --in_3Dref Import/job001/3dref.mrc "
            "--o External/job019/ --test_param1 1001 --j 16 >> "
            "External/job019/run.out 2>> External/job019/run.err & ",
        )

    def test_get_command_external_coords(self):
        generic_tests.general_get_command_test(
            self,
            "External",
            "external_coords.job",
            19,
            {"Import/job001/coords.star": NODES["Mic coords"]},
            {},
            "/path/to/external/here.exe --in_coords Import/job001/coords.star "
            "--o External/job019/ --test_param1 1001 --j 16 >> "
            "External/job019/run.out 2>> External/job019/run.err & ",
        )

    def test_get_command_external_mask(self):
        generic_tests.general_get_command_test(
            self,
            "External",
            "external_mask.job",
            19,
            {"Import/job001/mask.mrc": NODES["Mask"]},
            {},
            "/path/to/external/here.exe --in_mask Import/job001/mask.mrc "
            "--o External/job019/ --test_param1 1001 --j 16 >> "
            "External/job019/run.out 2>> External/job019/run.err & ",
        )

    def test_get_command_external_allin(self):
        generic_tests.general_get_command_test(
            self,
            "External",
            "external_allin.job",
            19,
            {
                "Import/job001/mics.star": NODES["Mics"],
                "Import/job001/movies.star": NODES["Movies"],
                "Import/job001/coords.star": NODES["Mic coords"],
                "Import/job001/parts.star": NODES["Part data"],
                "Import/job001/3dref.mrc": NODES["3D refs"],
            },
            {},
            "/path/to/external/here.exe --in_mics Import/job001/mics.star"
            " --in_movies Import/job001/movies.star --in_coords "
            "Import/job001/coords.star --in_parts Import/job001/parts.star"
            " --in_3Dref Import/job001/3dref.mrc "
            "--o External/job019/ --test_param1 1001 --j 16 >> "
            "External/job019/run.out 2>> External/job019/run.err & ",
        )

    def test_get_command_external_allparams(self):
        generic_tests.general_get_command_test(
            self,
            "External",
            "external_all_params.job",
            19,
            {"Import/job001/3dref.mrc": NODES["3D refs"]},
            {},
            "/path/to/external/here.exe --in_3Dref Import/job001/3dref.mrc "
            "--o External/job019/ --test_param1 1001"
            " --test_param2 2002 --test_param3 3003 --test_param4 4004"
            " --test_param5 5005 --test_param6 6006 --test_param7 7007"
            " --test_param8 8008 --test_param9 9009 --test_param10 1010 --j 16 >> "
            "External/job019/run.out 2>> External/job019/run.err & ",
        )

    def test_get_command_external_allparams_jobstar(self):
        generic_tests.general_get_command_test(
            self,
            "External",
            "external_job.star",
            19,
            {"Import/job001/3dref.mrc": NODES["3D refs"]},
            {},
            "/path/to/external/here.exe --in_3Dref Import/job001/3dref.mrc "
            "--o External/job019/ --test_param1 1001"
            " --test_param2 2002 --test_param3 3003 --test_param4 4004"
            " --test_param5 5005 --test_param6 6006 --test_param7 7007"
            " --test_param8 8008 --test_param9 9009 --test_param10 1010 --j 16 >> "
            "External/job019/run.out 2>> External/job019/run.err & ",
        )

    def test_get_command_external_parts_output(self):
        job = generic_tests.general_get_command_test(
            self,
            "External",
            "external_parts_out.job",
            19,
            {"Import/job001/particles.star": NODES["Part data"]},
            {"parts_out.star": NODES["Part data"]},
            "/path/to/external/here.exe --in_parts Import/job001/particles.star "
            "--o External/job019/ --test_param1 1001 --j 16 >> "
            "External/job019/run.out 2>> External/job019/run.err & ",
        )

        outnode = job.output_nodes[0]
        assert outnode.name == "External/job019/parts_out.star"
        assert outnode.type == 3

    def test_get_command_external_mask_output(self):
        job = generic_tests.general_get_command_test(
            self,
            "External",
            "external_mask_out.job",
            19,
            {"Import/job001/mask.mrc": NODES["Mask"]},
            {"mask_out.mrc": NODES["Mask"]},
            "/path/to/external/here.exe --in_mask Import/job001/mask.mrc "
            "--o External/job019/ --test_param1 1001 --j 16 >> "
            "External/job019/run.out 2>> External/job019/run.err & ",
        )

        outnode = job.output_nodes[0]
        assert outnode.name == "External/job019/mask_out.mrc"
        assert outnode.type == 7

    def test_get_command_external_3dref_output(self):
        job = generic_tests.general_get_command_test(
            self,
            "External",
            "external_3dref_out.job",
            19,
            {"Import/job001/3dref.mrc": NODES["3D refs"]},
            {"3dref_out.mrc": NODES["3D refs"]},
            "/path/to/external/here.exe --in_3Dref Import/job001/3dref.mrc "
            "--o External/job019/ --test_param1 1001 --j 16 >> "
            "External/job019/run.out 2>> External/job019/run.err & ",
        )

        outnode = job.output_nodes[0]
        assert outnode.name == "External/job019/3dref_out.mrc"
        assert outnode.type == 6

    def test_get_command_external_other_output(self):
        job = generic_tests.general_get_command_test(
            self,
            "External",
            "external_otherout.job",
            19,
            {"Import/job001/movies.star": NODES["Movies"]},
            {"strange_file.xyz": NODES["Other"]},
            "/path/to/external/here.exe --in_movies Import/job001/movies.star "
            "--o External/job019/ --test_param1 1001 --j 16 >> "
            "External/job019/run.out 2>> External/job019/run.err & ",
        )

        outnode = job.output_nodes[0]
        assert outnode.name == "External/job019/strange_file.xyz"
        assert outnode.type == 99

    def test_get_command_external_3dref_nothreads(self):
        generic_tests.general_get_command_test(
            self,
            "External",
            "external_3dref_nothreads.job",
            19,
            {"Import/job001/3dref.mrc": NODES["3D refs"]},
            {},
            "/path/to/external/here.exe --in_3Dref Import/job001/3dref.mrc "
            "--o External/job019/ --test_param1 1001 >> "
            "External/job019/run.out 2>> External/job019/run.err & ",
        )


if __name__ == "__main__":
    unittest.main()
