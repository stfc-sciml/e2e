import unittest
import os
import shutil
import tempfile

from pipeliner_tests import test_data
from pipeliner_tests import generic_tests
from pipeliner.data_structure import NODES


class CtfRefineTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)
        os.mkdir("CtfRefine")
        os.mkdir("CtfRefine/job018")

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_get_command_aniso(self):
        generic_tests.general_get_command_test(
            self,
            "CtfRefine",
            "ctfrefine.job",
            18,
            {
                "Refine3D/job600/run_data.star": NODES["Part data"],
                "PostProcess/job700/postprocess.star": NODES["Post"],
            },
            {
                "logfile.pdf": NODES["PdfLogfile"],
                "particles_ctf_refine.star": NODES["Part data"],
            },
            "mpirun -n 16 `which relion_ctf_refine_mpi` --i "
            "Refine3D/job600/run_data.star --f "
            "PostProcess/job700/postprocess.star --o CtfRefine/job018/"
            " --fit_aniso --kmin_mag 29 --j 8 --pipeline_control CtfRefine/job018/ "
            ">> CtfRefine/job018/run.out 2>> CtfRefine/job018/run.err & ",
        )

    def test_get_command_aniso_jobstar(self):
        generic_tests.general_get_command_test(
            self,
            "CtfRefine",
            "ctfrefine_job.star",
            18,
            {
                "Refine3D/job600/run_data.star": NODES["Part data"],
                "PostProcess/job700/postprocess.star": NODES["Post"],
            },
            {
                "logfile.pdf": NODES["PdfLogfile"],
                "particles_ctf_refine.star": NODES["Part data"],
            },
            "mpirun -n 16 `which relion_ctf_refine_mpi` --i "
            "Refine3D/job600/run_data.star --f "
            "PostProcess/job700/postprocess.star --o CtfRefine/job018/"
            " --fit_aniso --kmin_mag 29 --j 8 --pipeline_control CtfRefine/job018/ "
            ">> CtfRefine/job018/run.out 2>> CtfRefine/job018/run.err & ",
        )

    def test_get_command_no_options_error(self):
        with self.assertRaises(ValueError):
            generic_tests.general_get_command_test(
                self, "CtfRefine", "ctfrefine_nooptions_error.job", 18, 2, 2, ""
            )

    def test_get_command_ctfrefine_defocus(self):
        generic_tests.general_get_command_test(
            self,
            "CtfRefine",
            "ctfrefine_defocus.job",
            18,
            {
                "Refine3D/job600/run_data.star": NODES["Part data"],
                "PostProcess/job700/postprocess.star": NODES["Post"],
            },
            {
                "logfile.pdf": NODES["PdfLogfile"],
                "particles_ctf_refine.star": NODES["Part data"],
            },
            "mpirun -n 16 `which relion_ctf_refine_mpi` --i "
            "Refine3D/job600/run_data.star --f "
            "PostProcess/job700/postprocess.star --o CtfRefine/job018/"
            " --fit_defocus --kmin_defocus 29 --fit_mode fmfff --j 8 "
            "--pipeline_control CtfRefine/job018/ >> "
            "CtfRefine/job018/run.out 2>> CtfRefine/job018/run.err & ",
        )

    def test_get_command_ctfrefine_defocus_astig(self):
        generic_tests.general_get_command_test(
            self,
            "CtfRefine",
            "ctfrefine_defocus_astig.job",
            18,
            {
                "Refine3D/job600/run_data.star": NODES["Part data"],
                "PostProcess/job700/postprocess.star": NODES["Post"],
            },
            {
                "logfile.pdf": NODES["PdfLogfile"],
                "particles_ctf_refine.star": NODES["Part data"],
            },
            "mpirun -n 16 `which relion_ctf_refine_mpi` --i "
            "Refine3D/job600/run_data.star --f "
            "PostProcess/job700/postprocess.star --o CtfRefine/job018/"
            " --fit_defocus --kmin_defocus 29 --fit_mode fmmff --j 8"
            " --pipeline_control CtfRefine/job018/ >> "
            "CtfRefine/job018/run.out 2>> CtfRefine/job018/run.err & ",
        )

    def test_get_command_ctfrefine_focus_astig_bfact(self):
        generic_tests.general_get_command_test(
            self,
            "CtfRefine",
            "ctfrefine_defocus_astig_bf.job",
            18,
            {
                "Refine3D/job600/run_data.star": NODES["Part data"],
                "PostProcess/job700/postprocess.star": NODES["Post"],
            },
            {
                "logfile.pdf": NODES["PdfLogfile"],
                "particles_ctf_refine.star": NODES["Part data"],
            },
            "mpirun -n 16 `which relion_ctf_refine_mpi` --i "
            "Refine3D/job600/run_data.star --f "
            "PostProcess/job700/postprocess.star --o CtfRefine/job018/"
            " --fit_defocus --kmin_defocus 29 --fit_mode fppfp --j 8 "
            "--pipeline_control CtfRefine/job018/ >> "
            "CtfRefine/job018/run.out 2>> CtfRefine/job018/run.err & ",
        )

    def test_get_command_ctfrefine_focus_astig_bfact_phase(self):
        generic_tests.general_get_command_test(
            self,
            "CtfRefine",
            "ctfrefine_defocus_astig_bf_ps.job",
            18,
            {
                "Refine3D/job600/run_data.star": NODES["Part data"],
                "PostProcess/job700/postprocess.star": NODES["Post"],
            },
            {
                "logfile.pdf": NODES["PdfLogfile"],
                "particles_ctf_refine.star": NODES["Part data"],
            },
            "mpirun -n 16 `which relion_ctf_refine_mpi` --i "
            "Refine3D/job600/run_data.star --f "
            "PostProcess/job700/postprocess.star --o CtfRefine/job018/"
            " --fit_defocus --kmin_defocus 29 --fit_mode mppfp --j 8 "
            "--pipeline_control CtfRefine/job018/ >> "
            "CtfRefine/job018/run.out 2>> CtfRefine/job018/run.err & ",
        )

    def test_get_command_ctfrefine_no_ctf_params(self):
        with self.assertRaises(ValueError):
            generic_tests.general_get_command_test(
                self, "CtfRefine", "ctfrefine_no_ctf_params_error.job", 18, 2, 2, "",
            )

    def test_get_command_ctfrefine_cant_do_both(self):
        with self.assertRaises(ValueError):
            generic_tests.general_get_command_test(
                self,
                "CtfRefine",
                "ctfrefine_cantdo_both.job",
                18,
                {
                    "Refine3D/job600/run_data.star": NODES["Part data"],
                    "PostProcess/job700/postprocess.star": NODES["Post"],
                },
                {
                    "logfile.pdf": NODES["PdfLogfile"],
                    "particles_ctf_refine.star": NODES["Part data"],
                },
                "mpirun -n 16 `which relion_ctf_refine_mpi` --i "
                "Refine3D/job600/run_data.star --f "
                "PostProcess/job700/postprocess.star --o CtfRefine/job018/"
                " --fit_aniso --kmin_mag 29 --j 8 --pipeline_control "
                "CtfRefine/job018/ >> CtfRefine/job018/run.out 2>> "
                "CtfRefine/job018/run.err & ",
            )

    def test_get_command_ctfrefine_continue(self):
        generic_tests.general_get_command_test(
            self,
            "CtfRefine",
            "ctfrefine_continue.job",
            18,
            {
                "Refine3D/job600/run_data.star": NODES["Part data"],
                "PostProcess/job700/postprocess.star": NODES["Post"],
            },
            {
                "logfile.pdf": NODES["PdfLogfile"],
                "particles_ctf_refine.star": NODES["Part data"],
            },
            "mpirun -n 16 `which relion_ctf_refine_mpi` --i "
            "Refine3D/job600/run_data.star --f "
            "PostProcess/job700/postprocess.star --o CtfRefine/job018/"
            " --fit_aniso --kmin_mag 29 --only_do_unfinished --j 8 "
            "--pipeline_control CtfRefine/job018/ >>"
            " CtfRefine/job018/run.out 2>> CtfRefine/job018/run.err & ",
        )


if __name__ == "__main__":
    unittest.main()
