import unittest
import os
import shutil
import tempfile

from pipeliner_tests import test_data
from pipeliner_tests import generic_tests
from pipeliner.data_structure import NODES


class ExtractTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_get_command_basic(self):
        generic_tests.general_get_command_test(
            self,
            "Extract",
            "extract_basic.job",
            7,
            {
                "Select/job005/micrographs_selected.star": NODES["Mics"],
                "AutoPick/job006/coords_suffix_autopick.star": NODES["Mic coords"],
            },
            {"particles.star": NODES["Part data"]},
            "`which relion_preprocess` --i "
            "Select/job005/micrographs_selected.star --coord_dir "
            "AutoPick/job006/ --coord_suffix _autopick.star "
            "--part_star Extract/job007/particles.star --part_dir "
            "Extract/job007/ --extract --extract_size 256 --scale 64 "
            "--norm --bg_radius 25 --white_dust -1 --black_dust -1 "
            "--invert_contrast --pipeline_control Extract/job007/"
            " >> Extract/job007/run.out 2>> Extract/job007/run.err & ",
        )

    def test_get_command_jobstar(self):
        generic_tests.general_get_command_test(
            self,
            "Extract",
            "extract_job.star",
            7,
            {
                "Select/job005/micrographs_selected.star": NODES["Mics"],
                "AutoPick/job006/coords_suffix_autopick.star": NODES["Mic coords"],
            },
            {"particles.star": NODES["Part data"]},
            "`which relion_preprocess` --i "
            "Select/job005/micrographs_selected.star --coord_dir "
            "AutoPick/job006/ --coord_suffix _autopick.star "
            "--part_star Extract/job007/particles.star --part_dir "
            "Extract/job007/ --extract --extract_size 256 --scale 64 "
            "--norm --bg_radius 24 --white_dust -1 --black_dust -1 "
            "--invert_contrast --pipeline_control Extract/job007/"
            " >> Extract/job007/run.out 2>> Extract/job007/run.err & ",
        )

    def test_get_command_rextract_wrongfile(self):
        with self.assertRaises(ValueError):
            generic_tests.general_get_command_test(
                self, "Extract", "extract_rextract_wrongfile.job", 7, 2, 1, ""
            )

    def test_get_command_rextract(self):
        generic_tests.general_get_command_test(
            self,
            "Extract",
            "extract_rextract.job",
            7,
            {
                "Select/job005/micrographs_selected.star": NODES["Mics"],
                "Refine3D/job200/run_data.star": NODES["Part data"],
            },
            {
                "particles.star": NODES["Part data"],
                "coords_suffix_extract.star": NODES["Mic coords"],
            },
            "mpirun -n 16 `which relion_preprocess_mpi` --i "
            "Select/job005/micrographs_selected.star "
            "--reextract_data_star Refine3D/job200/run_data.star "
            "--part_star Extract/job007/particles.star --part_dir Extract/job007/"
            " --extract --extract_size 256 --scale 64 --norm --bg_radius 25"
            " --white_dust -1 --black_dust -1 --invert_contrast "
            "--rextract_on_this_one --pipeline_control Extract/job007/ >> "
            "Extract/job007/run.out 2>> Extract/job007/run.err &&"
            " echo Select/job005/micrographs_selected.star > "
            "Extract/job007/coords_suffix_extract.star & ",
        )

    def test_get_command_rextract_recenter(self):
        generic_tests.general_get_command_test(
            self,
            "Extract",
            "extract_rextract_recenter.job",
            7,
            {
                "Select/job005/micrographs_selected.star": NODES["Mics"],
                "Refine3D/job200/run_data.star": NODES["Part data"],
            },
            {
                "particles.star": NODES["Part data"],
                "coords_suffix_extract.star": NODES["Mic coords"],
            },
            "`which relion_preprocess` --i "
            "Select/job005/micrographs_selected.star "
            "--reextract_data_star Refine3D/job200/run_data.star "
            "--recenter --recenter_x 10 --recenter_y 20 --recenter_z 30 "
            "--part_star Extract/job007/particles.star --part_dir Extract/job007/"
            " --extract --extract_size 256 --norm --bg_radius 125"
            " --white_dust -1 --black_dust -1 --invert_contrast"
            " --pipeline_control Extract/job007/ >> "
            "Extract/job007/run.out 2>> Extract/job007/run.err &&"
            " echo Select/job005/micrographs_selected.star > "
            "Extract/job007/coords_suffix_extract.star & ",
        )

    def test_get_command_rextract_setbgdia(self):
        generic_tests.general_get_command_test(
            self,
            "Extract",
            "extract_rextract_set_bgdia.job",
            7,
            {
                "Select/job005/micrographs_selected.star": NODES["Mics"],
                "Refine3D/job200/run_data.star": NODES["Part data"],
            },
            {
                "particles.star": NODES["Part data"],
                "coords_suffix_extract.star": NODES["Mic coords"],
            },
            "`which relion_preprocess` --i "
            "Select/job005/micrographs_selected.star "
            "--reextract_data_star Refine3D/job200/run_data.star "
            "--part_star Extract/job007/particles.star --part_dir Extract/job007/"
            " --extract --extract_size 256 --scale 64 --norm --bg_radius 24"
            " --white_dust -1 --black_dust -1 --invert_contrast --pipeline_control"
            " Extract/job007/ >> Extract/job007/run.out 2>> Extract/job007/run.err &&"
            " echo Select/job005/micrographs_selected.star > "
            "Extract/job007/coords_suffix_extract.star & ",
        )

    def test_get_command_helical(self):
        generic_tests.general_get_command_test(
            self,
            "Extract",
            "extract_helical.job",
            7,
            {
                "Select/job005/micrographs_selected.star": NODES["Mics"],
                "AutoPick/job006/coords_suffix_autopick.star": NODES["Mic coords"],
            },
            {
                "particles.star": NODES["Part data"],
                "coords_suffix_extract.star": NODES["Mic coords"],
            },
            "`which relion_preprocess` --i "
            "Select/job005/micrographs_selected.star --coord_dir "
            "AutoPick/job006/ --coord_suffix _autopick.star "
            "--part_star Extract/job007/particles.star --part_dir "
            "Extract/job007/ --extract --extract_size 256 --scale 64 "
            "--norm --bg_radius 25 --white_dust -1 --black_dust -1 "
            "--invert_contrast --helix --helical_outer_diameter 200"
            " --helical_bimodal_angular_priors --helical_tubes "
            "--helical_cut_into_segments --helical_nr_asu 3 "
            "--helical_rise 2.34 --pipeline_control Extract/job007/"
            " >> Extract/job007/run.out 2>> Extract/job007/run.err && echo "
            "Select/job005/micrographs_selected.star > "
            "Extract/job007/coords_suffix_extract.star & ",
        )

    def test_get_command_helical_nosegs(self):
        generic_tests.general_get_command_test(
            self,
            "Extract",
            "extract_helical_nosegs.job",
            7,
            {
                "Select/job005/micrographs_selected.star": NODES["Mics"],
                "AutoPick/job006/coords_suffix_autopick.star": NODES["Mic coords"],
            },
            {"particles.star": NODES["Part data"]},
            "`which relion_preprocess` --i "
            "Select/job005/micrographs_selected.star --coord_dir "
            "AutoPick/job006/ --coord_suffix _autopick.star "
            "--part_star Extract/job007/particles.star --part_dir "
            "Extract/job007/ --extract --extract_size 256 --scale 64 "
            "--norm --bg_radius 25 --white_dust -1 --black_dust -1 "
            "--invert_contrast --helix --helical_outer_diameter 200"
            " --helical_bimodal_angular_priors --pipeline_control Extract/job007/ >> "
            "Extract/job007/run.out 2>> Extract/job007/run.err & ",
        )


if __name__ == "__main__":
    unittest.main()
