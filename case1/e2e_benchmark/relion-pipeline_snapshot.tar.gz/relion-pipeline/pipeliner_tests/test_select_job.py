import unittest
import os
import shutil
import tempfile
from pipeliner.relion_jobs import job_factory
from pipeliner_tests import test_data
from pipeliner_tests import generic_tests
from pipeliner.data_structure import NODES


class SelectTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def print_coms(self, commands, expected_commands):
        """Compare two commands and find the differences"""
        print("\n" + commands)
        print(expected_commands)
        compare = ""
        for i in range(len(commands)):
            try:
                if commands[i] == expected_commands[i]:
                    compare += " "
                else:
                    compare += "*"
            except IndexError:
                pass
        print(compare)

    def test_get_command_select_mics_on_val(self):
        generic_tests.general_get_command_test(
            self,
            "Select",
            "select_mics_by_val.job",
            10,
            {"CtfFind/job300/micrographs_ctf.star": NODES["Mics"]},
            {"micrographs.star": NODES["Mics"]},
            "`which relion_star_handler` --i CtfFind/job300/micrographs_ctf.star"
            " --o Select/job010/micrographs.star --select rlnCtfFigureOfMerit "
            "--minval 12345.0 --maxval 23456.0 --pipeline_control Select/job010/ "
            ">> Select/job010/run.out 2>> Select/job010/run.err & ",
        )

    def test_get_command_select_jobstar(self):
        generic_tests.general_get_command_test(
            self,
            "Select",
            "select_job.star",
            10,
            {"CtfFind/job300/micrographs_ctf.star": NODES["Mics"]},
            {"micrographs.star": NODES["Mics"]},
            "`which relion_star_handler` --i CtfFind/job300/micrographs_ctf.star"
            " --o Select/job010/micrographs.star --select rlnCtfFigureOfMerit "
            "--minval 12345.0 --maxval 23456.0 --pipeline_control Select/job010/ "
            ">> Select/job010/run.out 2>> Select/job010/run.err & ",
        )

    def test_get_command_discard_mics(self):
        generic_tests.general_get_command_test(
            self,
            "Select",
            "select_mics_discard.job",
            10,
            {"CtfFind/job300/micrographs_ctf.star": NODES["Mics"]},
            {"micrographs.star": NODES["Mics"]},
            "`which relion_star_handler` --i CtfFind/job300/micrographs_ctf.star"
            " --o Select/job010/micrographs.star --discard_on_stats --discard_label"
            " rlnCtfFigureOfMerit --discard_sigma 4 --pipeline_control Select/job010/"
            " >> Select/job010/run.out 2>> Select/job010/run.err & ",
        )

    def test_get_command_mics_regroup_error(self):
        """Ignore illegal regrouping of selected mics"""
        generic_tests.general_get_command_test(
            self,
            "Select",
            "select_mics_regroup_error.job",
            10,
            {"CtfFind/job300/micrographs_ctf.star": NODES["Mics"]},
            {"micrographs.star": NODES["Mics"]},
            "`which relion_star_handler` --i CtfFind/job300/micrographs_ctf.star --o "
            "Select/job010/micrographs.star --select rlnCtfFigureOfMerit --minval "
            "12345.0 --maxval 23456.0 --pipeline_control Select/job010/ >> "
            "Select/job010/run.out 2>> Select/job010/run.err & ",
        )

    def test_get_command_split_mics_defined_number(self):
        """ split micrographs into n groups """
        generic_tests.general_get_command_test(
            self,
            "Select",
            "select_mics_split_defined.job",
            10,
            {"CtfFind/job300/micrographs_ctf.star": NODES["Mics"]},
            {"micrographs_split1.star": NODES["Mics"]},
            "`which relion_star_handler` --i CtfFind/job300/micrographs_ctf.star"
            " --o Select/job010/micrographs.star --split  --size_split 100"
            " --pipeline_control Select/job010/"
            " >> Select/job010/run.out 2>> Select/job010/run.err & ",
        )

    def test_get_command_split_mics_nr_groups(self):
        """Split the micrograph into a defined number of groups"""
        generic_tests.general_get_command_test(
            self,
            "Select",
            "select_mics_split_nr.job",
            10,
            {"CtfFind/job300/micrographs_ctf.star": NODES["Mics"]},
            {
                "micrographs_split1.star": NODES["Mics"],
                "micrographs_split2.star": NODES["Mics"],
                "micrographs_split3.star": NODES["Mics"],
                "micrographs_split4.star": NODES["Mics"],
            },
            "`which relion_star_handler` --i CtfFind/job300/micrographs_ctf.star"
            " --o Select/job010/micrographs.star --split  --nr_split 4"
            " --pipeline_control Select/job010/"
            " >> Select/job010/run.out 2>> Select/job010/run.err & ",
        )

    def test_get_command_split_parts_nr_groups(self):
        generic_tests.general_get_command_test(
            self,
            "Select",
            "select_parts_split_nr.job",
            10,
            {"Extract/job300/particles.star": NODES["Part data"]},
            {
                "particles_split1.star": NODES["Part data"],
                "particles_split2.star": NODES["Part data"],
                "particles_split3.star": NODES["Part data"],
                "particles_split4.star": NODES["Part data"],
            },
            "`which relion_star_handler` --i Extract/job300/particles.star"
            " --o Select/job010/particles.star --split  --nr_split 4"
            " --pipeline_control Select/job010/"
            " >> Select/job010/run.out 2>> Select/job010/run.err & ",
        )

    def test_get_command_split_parts_defined_number(self):
        """split particles into n parts per subset"""
        generic_tests.general_get_command_test(
            self,
            "Select",
            "select_mics_split_defined.job",
            10,
            {"CtfFind/job300/micrographs_ctf.star": NODES["Mics"]},
            {"micrographs_split1.star": NODES["Mics"]},
            "`which relion_star_handler` --i CtfFind/job300/micrographs_ctf.star"
            " --o Select/job010/micrographs.star --split  --size_split 100"
            " --pipeline_control Select/job010/"
            " >> Select/job010/run.out 2>> Select/job010/run.err & ",
        )

    def test_get_command_remove_duplicates(self):
        """remove duplicate for particles"""
        generic_tests.general_get_command_test(
            self,
            "Select",
            "select_parts_remove_dups.job",
            10,
            {"Extract/job300/particles.star": NODES["Part data"]},
            {"particles.star": NODES["Part data"]},
            "`which relion_star_handler` --i Extract/job300/particles.star"
            " --o Select/job010/particles.star --remove_duplicates 30"
            " --pipeline_control Select/job010/"
            " >> Select/job010/run.out 2>> Select/job010/run.err & ",
        )

    def test_get_command_interactive_from_model(self):
        """ get particles from model file with regrouping and recentering"""
        generic_tests.general_get_command_test(
            self,
            "Select",
            "select_interactive_averages_job.star",
            8,
            {"Class2D/job006/run_it025_model.star": NODES["Model"]},
            {
                "particles.star": NODES["Part data"],
                "class_averages.star": NODES["2D refs"],
            },
            "`which relion_display` --gui --i Class2D/job006/run_it025_model.star"
            " --allow_save --fn_parts Select/job008/particles.star --fn_imgs "
            "Select/job008/class_averages.star --recenter --regroup 60 "
            "--pipeline_control Select/job008/"
            " >> Select/job008/run.out 2>> Select/job008/run.err & ",
        )

    def test_get_command_interactive_from_model_norecenter(self):
        """ get particles from model file with regrouping and no recentering"""
        generic_tests.general_get_command_test(
            self,
            "Select",
            "select_interactive_averages_norecenter_job.star",
            8,
            {"Class2D/job006/run_it025_model.star": NODES["Model"]},
            {
                "particles.star": NODES["Part data"],
                "class_averages.star": NODES["2D refs"],
            },
            "`which relion_display` --gui --i Class2D/job006/run_it025_model.star"
            " --allow_save --fn_parts Select/job008/particles.star --fn_imgs "
            "Select/job008/class_averages.star --regroup 60 "
            "--pipeline_control Select/job008/"
            " >> Select/job008/run.out 2>> Select/job008/run.err & ",
        )

    def test_get_command_interactive_from_model_class3d_norecenter(self):
        """ get particles from model file with regrouping and no recentering"""
        generic_tests.general_get_command_test(
            self,
            "Select",
            "select_interactive_averages_class3d_norecenter_job.star",
            8,
            {"Class3D/job006/run_it025_model.star": NODES["Model"]},
            {"particles.star": NODES["Part data"]},
            "`which relion_display` --gui --i Class3D/job006/run_it025_model.star"
            " --allow_save --fn_parts Select/job008/particles.star"
            " --regroup 60 --pipeline_control Select/job008/"
            " >> Select/job008/run.out 2>> Select/job008/run.err & ",
        )

    def test_get_command_interactive_from_model_norecenter_noregroup(self):
        """ get particles from model file with
        regrouping and no recentering or regrouping"""
        generic_tests.general_get_command_test(
            self,
            "Select",
            "select_interactive_averages_norecenter_noregroup_job.star",
            8,
            {"Class2D/job006/run_it025_model.star": NODES["Model"]},
            {
                "particles.star": NODES["Part data"],
                "class_averages.star": NODES["2D refs"],
            },
            "`which relion_display` --gui --i Class2D/job006/run_it025_model.star"
            " --allow_save --fn_parts Select/job008/particles.star --fn_imgs "
            "Select/job008/class_averages.star "
            "--pipeline_control Select/job008/"
            " >> Select/job008/run.out 2>> Select/job008/run.err & ",
        )

    def test_get_command_interactive_from_mics(self):
        """ get micrographs from mics file"""
        generic_tests.general_get_command_test(
            self,
            "Select",
            "select_interactive_micrographs_job.star",
            8,
            {"CtfFind/job001/micrographs_ctf.star": NODES["Mics"]},
            {"micrographs.star": NODES["Mics"]},
            "`which relion_display` --gui --i CtfFind/job001/micrographs_ctf.star"
            " --allow_save --fn_imgs Select/job008/micrographs.star"
            " --pipeline_control Select/job008/"
            " >> Select/job008/run.out 2>> Select/job008/run.err & ",
        )

    def test_get_command_interactive_from_mics_regroup(self):
        """ get micrographs from mics file ignoring illegal regrouping"""
        generic_tests.general_get_command_test(
            self,
            "Select",
            "select_interactive_micrographs_regroup_job.star",
            8,
            {"CtfFind/job001/micrographs_ctf.star": NODES["Mics"]},
            {"micrographs.star": NODES["Mics"]},
            "`which relion_display` --gui --i CtfFind/job001/micrographs_ctf.star"
            " --allow_save --fn_imgs Select/job008/micrographs.star"
            " --pipeline_control Select/job008/"
            " >> Select/job008/run.out 2>> Select/job008/run.err & ",
        )

    def test_get_command_interactive_from_parts(self):
        """ get particles from data file"""
        generic_tests.general_get_command_test(
            self,
            "Select",
            "select_interactive_parts_job.star",
            8,
            {"Refine3D/job010/run_data.star": NODES["Part data"]},
            {"particles.star": NODES["Part data"]},
            "`which relion_display` --gui --i Refine3D/job010/run_data.star"
            " --allow_save --fn_imgs Select/job008/particles.star"
            " --pipeline_control Select/job008/"
            " >> Select/job008/run.out 2>> Select/job008/run.err & ",
        )

    def test_get_command_interactive_from_parts_regroup(self):
        """ get particles from data file ignoring illegal regrouping"""
        generic_tests.general_get_command_test(
            self,
            "Select",
            "select_interactive_parts_regroup_job.star",
            8,
            {"Refine3D/job010/run_data.star": NODES["Part data"]},
            {"particles.star": NODES["Part data"]},
            "`which relion_display` --gui --i Refine3D/job010/run_data.star"
            " --allow_save --fn_imgs Select/job008/particles.star"
            " --pipeline_control Select/job008/"
            " >> Select/job008/run.out 2>> Select/job008/run.err & ",
        )

    def test_get_command_select_parts_by_class(self):
        """ get particles from data file by class"""
        generic_tests.general_get_command_test(
            self,
            "Select",
            "select_parts_by_class.job",
            8,
            {"Class3D/job002/run_it025_data.star": NODES["Part data"]},
            {"particles.star": NODES["Part data"]},
            "`which relion_star_handler` --i Class3D/job002/run_it025_data.star"
            " --o Select/job008/particles.star --select rlnCtfFigureOfMerit "
            "--minval 3.0 --maxval 3.0 --pipeline_control Select/job008/ >> "
            "Select/job008/run.out 2>> Select/job008/run.err & ",
        )

    def test_get_command_interactive_from_coords(self):
        """ get coords, checking reading .gui_manualpick_job.star"""
        # diagnositic tools
        show_coms = False
        show_inputnodes = False
        show_outputnodes = False

        # copy in the .gui_manualpick_job.star
        manpick_file = os.path.join(
            self.test_data, "JobFiles/ManualPick/manualpick_job.star"
        )
        shutil.copy(manpick_file, ".gui_manualpickjob.star")

        # make the Autopick dir and jobstar file
        os.makedirs("AutoPick/job004")
        ap_jobfile = os.path.join(
            self.test_data, "JobFiles/ManualPick/manualpick_job.star"
        )
        shutil.copy(ap_jobfile, "AutoPick/job004/job.star")

        # can't use generic test because some outputs are in a different dir
        jobnumber = 9
        input_nodes = [
            "CtfFind/job003/micrographs_ctf.star",
            "AutoPick/job004/coords_suffix_autopick.star",
        ]
        output_nodes = [
            "Select/job009/micrographs_selected.star",
            "AutoPick/job004/coords_suffix_autopick.star",
        ]
        expected_command = (
            "`which relion_manualpick` --i CtfFind/job003/micrographs_ctf.star"
            " --odir AutoPick/job004/ --pickname autopick"
            " --allow_save --selection Select/job009/micrographs_selected.star"
            " --scale 0.25 --sigma_contrast 3 --black 0 --white 0 --lowpass 20"
            " --ctf_scale 1 --particle_diameter 200 --pipeline_control"
            " Select/job009/ >> Select/job009/run.out 2>> Select/job009/run.err & "
        )

        # read the job
        jobfile_path = os.path.join(
            self.test_data, "JobFiles/Select/select_interactive_coords_job.star"
        )

        job = job_factory.read_job(jobfile_path, do_initialise=True)

        # check the command is as expected
        commands = job.get_commands("", False, jobnumber)
        expected_commands = expected_command
        assert commands == expected_commands, self.print_coms(
            commands, expected_commands,
        )

        def print_inputnodes(expected):
            print("\nINPUT NODES: ({}/{})".format(len(job.input_nodes), len(expected)))
            for i in job.input_nodes:
                print(i.name)

        def print_outputnodes(expected):
            print(
                "\nOUTPUT NODES: ({}/{})".format(len(job.output_nodes), len(expected))
            )
            for i in job.output_nodes:
                print(i.name)

        # make sure the expected nodes have been created
        actual_in_nodes = [x.name for x in job.input_nodes]
        actual_out_nodes = [x.name for x in job.output_nodes]

        # diagnostics
        if show_coms:
            self.print_coms(commands, expected_commands)
        if show_inputnodes:
            print_inputnodes(input_nodes)
        if show_outputnodes:
            print_outputnodes(output_nodes)

        for node in input_nodes:
            assert node in actual_in_nodes, node
        for node in output_nodes:
            assert node in actual_out_nodes, node

        # make sure no extra nodes have been produced
        for node in actual_in_nodes:
            assert node in input_nodes, "EXTRA NODE: " + node
        for node in output_nodes:
            assert node in output_nodes, "EXTRA NODE: " + node
        assert len(input_nodes) == len(actual_in_nodes)
        assert len(output_nodes) == len(actual_out_nodes)

    def test_get_command_interactive_from_coords_nosuffix(self):
        """ get coords, checking reading .gui_manualpick_job.star, when
        there is no suffix on the coords file"""
        # diagnositic tools
        show_coms = False
        show_inputnodes = False
        show_outputnodes = False

        # copy in the .gui_manualpick_job.star
        manpick_file = os.path.join(
            self.test_data, "JobFiles/ManualPick/manualpick_job.star"
        )
        shutil.copy(manpick_file, ".gui_manualpickjob.star")

        # make the Autopick dir and jobstar file
        os.makedirs("AutoPick/job004")
        ap_jobfile = os.path.join(
            self.test_data, "JobFiles/ManualPick/manualpick_job.star"
        )
        shutil.copy(ap_jobfile, "AutoPick/job004/job.star")

        # can't use generic test because some outputs are in a different dir
        jobnumber = 9
        input_nodes = [
            "CtfFind/job003/micrographs_ctf.star",
            "AutoPick/job004/coords_suffix.star",
        ]
        output_nodes = [
            "Select/job009/micrographs_selected.star",
            "AutoPick/job004/coords_suffix.star",
        ]
        expected_command = (
            "`which relion_manualpick` --i CtfFind/job003/micrographs_ctf.star"
            " --odir AutoPick/job004/"
            " --allow_save --selection Select/job009/micrographs_selected.star"
            " --scale 0.25 --sigma_contrast 3 --black 0 --white 0 --lowpass 20"
            " --ctf_scale 1 --particle_diameter 200 --pipeline_control"
            " Select/job009/ >> Select/job009/run.out 2>> Select/job009/run.err & "
        )

        # read the job
        jobfile_path = os.path.join(
            self.test_data,
            "JobFiles/Select/select_interactive_coords_nosuffix_job.star",
        )

        job = job_factory.read_job(jobfile_path, do_initialise=True)

        # check the command is as expected
        commands = job.get_commands("", False, jobnumber)
        expected_commands = expected_command
        assert commands == expected_commands, self.print_coms(
            commands, expected_commands,
        )

        def print_inputnodes(expected):
            print("\nINPUT NODES: ({}/{})".format(len(job.input_nodes), len(expected)))
            for i in job.input_nodes:
                print(i.name)

        def print_outputnodes(expected):
            print(
                "\nOUTPUT NODES: ({}/{})".format(len(job.output_nodes), len(expected))
            )
            for i in job.output_nodes:
                print(i.name)

        # make sure the expected nodes have been created
        actual_in_nodes = [x.name for x in job.input_nodes]
        actual_out_nodes = [x.name for x in job.output_nodes]

        # diagnostics
        if show_coms:
            self.print_coms(commands, expected_commands)
        if show_inputnodes:
            print_inputnodes(input_nodes)
        if show_outputnodes:
            print_outputnodes(output_nodes)

        for node in input_nodes:
            assert node in actual_in_nodes, node
        for node in output_nodes:
            assert node in actual_out_nodes, node

        # make sure no extra nodes have been produced
        for node in actual_in_nodes:
            assert node in input_nodes, "EXTRA NODE: " + node
        for node in output_nodes:
            assert node in output_nodes, "EXTRA NODE: " + node
        assert len(input_nodes) == len(actual_in_nodes)
        assert len(output_nodes) == len(actual_out_nodes)

    def test_get_command_interactive_from_coords_error_no_manpickparams(self):
        """ select coordinates raises error if there are no saved manpick
        parameters"""

        # .gui_manualpick_job.star is missing!!!

        # make the Autopick dir and jobstar file
        os.makedirs("Autopick/job004")
        ap_jobfile = os.path.join(
            self.test_data, "JobFiles/ManualPick/manualpick_job.star"
        )
        shutil.copy(ap_jobfile, "Autopick/job004/job.star")

        # need to set job number to run get command
        jobnumber = 9
        # read the job
        jobfile_path = os.path.join(
            self.test_data,
            "JobFiles/Select/select_interactive_coords_nosuffix_job.star",
        )

        job = job_factory.read_job(jobfile_path, do_initialise=True)

        # check the command is as expected
        with self.assertRaises(ValueError):
            job.get_commands("", False, jobnumber)

    def test_get_command_too_many_options(self):
        with self.assertRaises(ValueError):
            generic_tests.general_get_command_test(
                self, "Select", "select_too_many_options.job", 10, 1, 1, "",
            )

    def test_get_command_remove_dup_mics_error(self):
        with self.assertRaises(ValueError):
            generic_tests.general_get_command_test(
                self, "Select", "select_mics_remove_dup_error.job", 10, 1, 1, "",
            )


if __name__ == "__main__":
    unittest.main()
