import unittest
import os
import shutil
import tempfile

from pipeliner.relion_jobs import job_factory
from pipeliner_tests import test_data
from pipeliner_tests import generic_tests
from pipeliner.data_structure import NODES


class Class3DTest(unittest.TestCase):
    def setUp(self):
        """
        Setup test data and output directories.
        """
        self.test_data = os.path.dirname(test_data.__file__)
        self.test_dir = tempfile.mkdtemp(prefix="relion_")

        # Change to test directory
        self._orig_dir = os.getcwd()
        os.chdir(self.test_dir)

    def tearDown(self):
        os.chdir(self._orig_dir)
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)

    def test_get_scratch_env_var(self):
        # Ensure RELION_SCRATCH_DIR is unset to begin with
        os.environ["RELION_SCRATCH_DIR"] = ""

        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/Class3D/class3D.job")
        )
        assert job.joboptions["scratch_dir"].defaultvalue == ""

        os.environ["RELION_SCRATCH_DIR"] = os.path.join(
            self.test_data, "fake_SCRATCH_dir"
        )
        job = job_factory.read_job(
            os.path.join(self.test_data, "JobFiles/Class3D/class3D.job")
        )
        assert job.joboptions["scratch_dir"].defaultvalue == os.path.join(
            self.test_data, "fake_SCRATCH_dir"
        )

    def test_get_command_class3D_basic(self):
        generic_tests.general_get_command_test(
            self,
            "Class3D",
            "class3D.job",
            11,
            {
                "Select/job014/particles.star": NODES["Part data"],
                "InitialModel/job015/run_it150_class001_symD2.mrc": NODES["3D refs"],
            },
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
                "run_it025_class001.mrc": NODES["3D refs"],
                "run_it025_class002.mrc": NODES["3D refs"],
                "run_it025_class003.mrc": NODES["3D refs"],
                "run_it025_class004.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Select/job014/particles.star"
            " --o Class3D/job011/run --ref "
            "InitialModel/job015/run_it150_class001_symD2.mrc --ini_high 50.0"
            " --dont_combine_weights_via_disc --preread_images --pool 30 --pad 2"
            " --skip_gridding --ctf --ctf_corrected_ref --iter 25 --tau2_fudge 4"
            " --particle_diameter 200 --K 4 --flatten_solvent --zero_mask"
            " --oversampling 1 --healpix_order 2 --offset_range 5 --offset_step 2.0"
            ' --sym C1 --norm --scale --j 6 --gpu "4:5:6:7" '
            "--pipeline_control Class3D/job011/ "
            ">> Class3D/job011/run.out 2>> Class3D/job011/run.err & ",
        )

    def test_get_command_class3D_jobstar(self):
        generic_tests.general_get_command_test(
            self,
            "Class3D",
            "class3D_job.star",
            11,
            {
                "Select/job014/particles.star": NODES["Part data"],
                "InitialModel/job015/run_it150_class001_symD2.mrc": NODES["3D refs"],
            },
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
                "run_it025_class001.mrc": NODES["3D refs"],
                "run_it025_class002.mrc": NODES["3D refs"],
                "run_it025_class003.mrc": NODES["3D refs"],
                "run_it025_class004.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Select/job014/particles.star"
            " --o Class3D/job011/run --ref "
            "InitialModel/job015/run_it150_class001_symD2.mrc --ini_high 50.0"
            " --dont_combine_weights_via_disc --preread_images --pool 30 --pad 2"
            " --skip_gridding --ctf --ctf_corrected_ref --iter 25 --tau2_fudge 4"
            " --particle_diameter 200 --K 4 --flatten_solvent --zero_mask"
            " --oversampling 1 --healpix_order 2 --offset_range 5 --offset_step 2.0"
            ' --sym C1 --norm --scale --j 6 --gpu "4:5:6:7" '
            "--pipeline_control Class3D/job011/ "
            ">> Class3D/job011/run.out 2>> Class3D/job011/run.err & ",
        )

    def test_get_command_class3D_mask(self):
        generic_tests.general_get_command_test(
            self,
            "Class3D",
            "class3D_mask.job",
            11,
            {
                "Select/job014/particles.star": NODES["Part data"],
                "InitialModel/job015/run_it150_class001_symD2.mrc": NODES["3D refs"],
                "MaskCreate/job012/mask.mrc": NODES["Mask"],
            },
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
                "run_it025_class001.mrc": NODES["3D refs"],
                "run_it025_class002.mrc": NODES["3D refs"],
                "run_it025_class003.mrc": NODES["3D refs"],
                "run_it025_class004.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Select/job014/particles.star"
            " --o Class3D/job011/run --ref "
            "InitialModel/job015/run_it150_class001_symD2.mrc --ini_high 50.0"
            " --dont_combine_weights_via_disc --preread_images --pool 30 --pad 2"
            " --skip_gridding --ctf --ctf_corrected_ref --iter 25 --tau2_fudge 4"
            " --particle_diameter 200 --K 4 --flatten_solvent --zero_mask"
            " --solvent_mask MaskCreate/job012/mask.mrc"
            " --oversampling 1 --healpix_order 2 --offset_range 5 --offset_step 2.0"
            ' --sym C1 --norm --scale --j 6 --gpu "4:5:6:7" '
            "--pipeline_control Class3D/job011/ "
            ">> Class3D/job011/run.out 2>> Class3D/job011/run.err & ",
        )

    def test_get_command_class3D_2masks(self):
        generic_tests.general_get_command_test(
            self,
            "Class3D",
            "class3D_2masks.job",
            11,
            {
                "Select/job014/particles.star": NODES["Part data"],
                "InitialModel/job015/run_it150_class001_symD2.mrc": NODES["3D refs"],
                "MaskCreate/job012/mask.mrc": NODES["Mask"],
                "MaskCreate/job013/mask.mrc": NODES["Mask"],
            },
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
                "run_it025_class001.mrc": NODES["3D refs"],
                "run_it025_class002.mrc": NODES["3D refs"],
                "run_it025_class003.mrc": NODES["3D refs"],
                "run_it025_class004.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Select/job014/particles.star"
            " --o Class3D/job011/run --ref "
            "InitialModel/job015/run_it150_class001_symD2.mrc --ini_high 50.0"
            " --dont_combine_weights_via_disc --preread_images --pool 30 --pad 2"
            " --skip_gridding --ctf --ctf_corrected_ref --iter 25 --tau2_fudge 4"
            " --particle_diameter 200 --K 4 --flatten_solvent --zero_mask"
            " --solvent_mask MaskCreate/job012/mask.mrc"
            " --oversampling 1 --healpix_order 2 --offset_range 5 --offset_step 2.0"
            ' --sym C1 --norm --scale --j 6 --gpu "4:5:6:7" '
            "--solvent_mask2 MaskCreate/job013/mask.mrc "
            "--pipeline_control Class3D/job011/ "
            ">> Class3D/job011/run.out 2>> Class3D/job011/run.err & ",
        )

    def test_get_command_class3D_mask_absgrey(self):
        generic_tests.general_get_command_test(
            self,
            "Class3D",
            "class3D_mask_noabsgrey.job",
            11,
            {
                "Select/job014/particles.star": NODES["Part data"],
                "InitialModel/job015/run_it150_class001_symD2.mrc": NODES["3D refs"],
                "MaskCreate/job012/mask.mrc": NODES["Mask"],
            },
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
                "run_it025_class001.mrc": NODES["3D refs"],
                "run_it025_class002.mrc": NODES["3D refs"],
                "run_it025_class003.mrc": NODES["3D refs"],
                "run_it025_class004.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Select/job014/particles.star"
            " --o Class3D/job011/run --ref "
            "InitialModel/job015/run_it150_class001_symD2.mrc --firstiter_cc"
            " --ini_high 50.0 --dont_combine_weights_via_disc --preread_images --pool "
            "30 --pad 2 --skip_gridding --ctf --ctf_corrected_ref --iter 25 "
            "--tau2_fudge 4 --particle_diameter 200 --K 4 --flatten_solvent "
            "--zero_mask --solvent_mask MaskCreate/job012/mask.mrc"
            " --oversampling 1 --healpix_order 2 --offset_range 5 --offset_step 2.0"
            ' --sym C1 --norm --scale --j 6 --gpu "4:5:6:7" '
            "--pipeline_control Class3D/job011/ "
            ">> Class3D/job011/run.out 2>> Class3D/job011/run.err & ",
        )

    def test_get_command_class3D_noctfref(self):
        generic_tests.general_get_command_test(
            self,
            "Class3D",
            "class3D_noctfcorref.job",
            11,
            {
                "Select/job014/particles.star": NODES["Part data"],
                "InitialModel/job015/run_it150_class001_symD2.mrc": NODES["3D refs"],
            },
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
                "run_it025_class001.mrc": NODES["3D refs"],
                "run_it025_class002.mrc": NODES["3D refs"],
                "run_it025_class003.mrc": NODES["3D refs"],
                "run_it025_class004.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Select/job014/particles.star"
            " --o Class3D/job011/run --ref "
            "InitialModel/job015/run_it150_class001_symD2.mrc --ini_high 50.0"
            " --dont_combine_weights_via_disc --preread_images --pool 30 --pad 2"
            " --skip_gridding --ctf --iter 25 --tau2_fudge 4"
            " --particle_diameter 200 --K 4 --flatten_solvent --zero_mask"
            " --oversampling 1 --healpix_order 2 --offset_range 5 --offset_step 2.0"
            ' --sym C1 --norm --scale --j 6 --gpu "4:5:6:7" '
            "--pipeline_control Class3D/job011/ "
            ">> Class3D/job011/run.out 2>> Class3D/job011/run.err & ",
        )

    def test_get_command_class3D_ctfintact(self):
        generic_tests.general_get_command_test(
            self,
            "Class3D",
            "class3D_ctfintact.job",
            11,
            {
                "Select/job014/particles.star": NODES["Part data"],
                "InitialModel/job015/run_it150_class001_symD2.mrc": NODES["3D refs"],
            },
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
                "run_it025_class001.mrc": NODES["3D refs"],
                "run_it025_class002.mrc": NODES["3D refs"],
                "run_it025_class003.mrc": NODES["3D refs"],
                "run_it025_class004.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Select/job014/particles.star"
            " --o Class3D/job011/run --ref "
            "InitialModel/job015/run_it150_class001_symD2.mrc --ini_high 50.0"
            " --dont_combine_weights_via_disc --preread_images --pool 30 --pad 2"
            " --skip_gridding --ctf --ctf_corrected_ref --ctf_intact_first_peak"
            " --iter 25 --tau2_fudge 4 --particle_diameter 200 --K 4 "
            "--flatten_solvent --zero_mask --oversampling 1 --healpix_order 2"
            " --offset_range 5 --offset_step 2.0"
            ' --sym C1 --norm --scale --j 6 --gpu "4:5:6:7" '
            "--pipeline_control Class3D/job011/ "
            ">> Class3D/job011/run.out 2>> Class3D/job011/run.err & ",
        )

    def test_get_command_class3D_fastss(self):
        generic_tests.general_get_command_test(
            self,
            "Class3D",
            "class3D_fastss.job",
            11,
            {
                "Select/job014/particles.star": NODES["Part data"],
                "InitialModel/job015/run_it150_class001_symD2.mrc": NODES["3D refs"],
            },
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
                "run_it025_class001.mrc": NODES["3D refs"],
                "run_it025_class002.mrc": NODES["3D refs"],
                "run_it025_class003.mrc": NODES["3D refs"],
                "run_it025_class004.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Select/job014/particles.star"
            " --o Class3D/job011/run --ref "
            "InitialModel/job015/run_it150_class001_symD2.mrc --ini_high 50.0"
            " --dont_combine_weights_via_disc --preread_images --pool 30 --pad 2"
            " --skip_gridding --ctf --ctf_corrected_ref --iter 25 --tau2_fudge 4"
            " --particle_diameter 200 --fast_subsets --K 4 --flatten_solvent"
            " --zero_mask --oversampling 1 --healpix_order 2 --offset_range 5"
            ' --offset_step 2.0 --sym C1 --norm --scale --j 6 --gpu "4:5:6:7" '
            "--pipeline_control Class3D/job011/ "
            ">> Class3D/job011/run.out 2>> Class3D/job011/run.err & ",
        )

    def test_get_command_class3D_nozeromask(self):
        generic_tests.general_get_command_test(
            self,
            "Class3D",
            "class3D_nozero.job",
            11,
            {
                "Select/job014/particles.star": NODES["Part data"],
                "InitialModel/job015/run_it150_class001_symD2.mrc": NODES["3D refs"],
            },
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
                "run_it025_class001.mrc": NODES["3D refs"],
                "run_it025_class002.mrc": NODES["3D refs"],
                "run_it025_class003.mrc": NODES["3D refs"],
                "run_it025_class004.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Select/job014/particles.star"
            " --o Class3D/job011/run --ref "
            "InitialModel/job015/run_it150_class001_symD2.mrc --ini_high 50.0"
            " --dont_combine_weights_via_disc --preread_images --pool 30 --pad 2"
            " --skip_gridding --ctf --ctf_corrected_ref --iter 25 --tau2_fudge 4"
            " --particle_diameter 200 --K 4 --flatten_solvent"
            " --oversampling 1 --healpix_order 2 --offset_range 5 --offset_step 2.0"
            ' --sym C1 --norm --scale --j 6 --gpu "4:5:6:7" '
            "--pipeline_control Class3D/job011/ "
            ">> Class3D/job011/run.out 2>> Class3D/job011/run.err & ",
        )

    def test_get_command_class3D_hireslim(self):
        generic_tests.general_get_command_test(
            self,
            "Class3D",
            "class3D_hireslim.job",
            11,
            {
                "Select/job014/particles.star": NODES["Part data"],
                "InitialModel/job015/run_it150_class001_symD2.mrc": NODES["3D refs"],
            },
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
                "run_it025_class001.mrc": NODES["3D refs"],
                "run_it025_class002.mrc": NODES["3D refs"],
                "run_it025_class003.mrc": NODES["3D refs"],
                "run_it025_class004.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Select/job014/particles.star"
            " --o Class3D/job011/run --ref "
            "InitialModel/job015/run_it150_class001_symD2.mrc --ini_high 50.0"
            " --dont_combine_weights_via_disc --preread_images --pool 30 --pad 2"
            " --skip_gridding --ctf --ctf_corrected_ref --iter 25 --tau2_fudge 4"
            " --particle_diameter 200 --K 4 --flatten_solvent --zero_mask"
            " --strict_highres_exp 12.0 --oversampling 1 --healpix_order 2 "
            "--offset_range 5 --offset_step 2.0 --sym C1 --norm --scale --j 6 "
            '--gpu "4:5:6:7" --pipeline_control Class3D/job011/ '
            ">> Class3D/job011/run.out 2>> Class3D/job011/run.err & ",
        )

    def test_get_command_class3D_dfferent_sampling(self):
        generic_tests.general_get_command_test(
            self,
            "Class3D",
            "class3D_diffsamp.job",
            11,
            {
                "Select/job014/particles.star": NODES["Part data"],
                "InitialModel/job015/run_it150_class001_symD2.mrc": NODES["3D refs"],
            },
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
                "run_it025_class001.mrc": NODES["3D refs"],
                "run_it025_class002.mrc": NODES["3D refs"],
                "run_it025_class003.mrc": NODES["3D refs"],
                "run_it025_class004.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Select/job014/particles.star"
            " --o Class3D/job011/run --ref "
            "InitialModel/job015/run_it150_class001_symD2.mrc --ini_high 50.0"
            " --dont_combine_weights_via_disc --preread_images --pool 30 --pad 2"
            " --skip_gridding --ctf --ctf_corrected_ref --iter 25 --tau2_fudge 4"
            " --particle_diameter 200 --K 4 --flatten_solvent --zero_mask"
            " --oversampling 1 --healpix_order 3 --offset_range 5 --offset_step 2.0"
            ' --sym C1 --norm --scale --j 6 --gpu "4:5:6:7" '
            "--pipeline_control Class3D/job011/ "
            ">> Class3D/job011/run.out 2>> Class3D/job011/run.err & ",
        )

    def test_get_command_class3D_local(self):
        generic_tests.general_get_command_test(
            self,
            "Class3D",
            "class3D_local.job",
            11,
            {
                "Select/job014/particles.star": NODES["Part data"],
                "InitialModel/job015/run_it150_class001_symD2.mrc": NODES["3D refs"],
            },
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
                "run_it025_class001.mrc": NODES["3D refs"],
                "run_it025_class002.mrc": NODES["3D refs"],
                "run_it025_class003.mrc": NODES["3D refs"],
                "run_it025_class004.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Select/job014/particles.star"
            " --o Class3D/job011/run --ref "
            "InitialModel/job015/run_it150_class001_symD2.mrc --ini_high 50.0"
            " --dont_combine_weights_via_disc --preread_images --pool 30 --pad 2"
            " --skip_gridding --ctf --ctf_corrected_ref --iter 25 --tau2_fudge 4"
            " --particle_diameter 200 --K 4 --flatten_solvent --zero_mask"
            " --oversampling 1 --healpix_order 2 --sigma_ang 1.66667 "
            "--offset_range 5 --offset_step 2.0 --sym C1 --norm --scale --j "
            '6 --gpu "4:5:6:7" '
            "--pipeline_control Class3D/job011/ "
            ">> Class3D/job011/run.out 2>> Class3D/job011/run.err & ",
        )

    def test_get_command_class3D_coarse(self):
        generic_tests.general_get_command_test(
            self,
            "Class3D",
            "class3D_coarse.job",
            11,
            {
                "Select/job014/particles.star": NODES["Part data"],
                "InitialModel/job015/run_it150_class001_symD2.mrc": NODES["3D refs"],
            },
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
                "run_it025_class001.mrc": NODES["3D refs"],
                "run_it025_class002.mrc": NODES["3D refs"],
                "run_it025_class003.mrc": NODES["3D refs"],
                "run_it025_class004.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Select/job014/particles.star"
            " --o Class3D/job011/run --ref "
            "InitialModel/job015/run_it150_class001_symD2.mrc --ini_high 50.0"
            " --dont_combine_weights_via_disc --preread_images --pool 30 --pad 2"
            " --skip_gridding --ctf --ctf_corrected_ref --iter 25 --tau2_fudge 4"
            " --particle_diameter 200 --K 4 --flatten_solvent --zero_mask"
            " --oversampling 1 --healpix_order 2 --offset_range 5 --offset_step 2.0"
            ' --allow_coarser_sampling --sym C1 --norm --scale --j 6 --gpu "4:5:6:7" '
            "--pipeline_control Class3D/job011/ "
            ">> Class3D/job011/run.out 2>> Class3D/job011/run.err & ",
        )

    def test_get_command_class3D_helical(self):
        generic_tests.general_get_command_test(
            self,
            "Class3D",
            "class3D_helical.job",
            11,
            {
                "Select/job014/particles.star": NODES["Part data"],
                "InitialModel/job015/run_it150_class001_symD2.mrc": NODES["3D refs"],
            },
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
                "run_it025_class001.mrc": NODES["3D refs"],
                "run_it025_class002.mrc": NODES["3D refs"],
                "run_it025_class003.mrc": NODES["3D refs"],
                "run_it025_class004.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Select/job014/particles.star"
            " --o Class3D/job011/run --ref "
            "InitialModel/job015/run_it150_class001_symD2.mrc --ini_high 50.0"
            " --dont_combine_weights_via_disc --preread_images --pool 30 --pad 2"
            " --skip_gridding --ctf --ctf_corrected_ref --iter 25 --tau2_fudge 4"
            " --particle_diameter 200 --K 4 --flatten_solvent --zero_mask"
            " --oversampling 1 --healpix_order 2 --offset_range 5 --offset_step 2.0"
            " --sym C1 --norm --scale --helix --helical_inner_diameter 20"
            " --helical_outer_diameter 50 --helical_nr_asu 1"
            " --helical_twist_initial 0 --helical_rise_initial 0 "
            "--helical_z_percentage 0.3 --helical_keep_tilt_prior_fixed "
            "--sigma_tilt 5 --sigma_psi 3.33333 --sigma_rot 3.33333 --j "
            '6 --gpu "4:5:6:7" --pipeline_control Class3D/job011/ '
            ">> Class3D/job011/run.out 2>> Class3D/job011/run.err & ",
        )

    def test_get_command_class3D_helical_noTPF(self):
        generic_tests.general_get_command_test(
            self,
            "Class3D",
            "class3D_helical_noTPF.job",
            11,
            {
                "Select/job014/particles.star": NODES["Part data"],
                "InitialModel/job015/run_it150_class001_symD2.mrc": NODES["3D refs"],
            },
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
                "run_it025_class001.mrc": NODES["3D refs"],
                "run_it025_class002.mrc": NODES["3D refs"],
                "run_it025_class003.mrc": NODES["3D refs"],
                "run_it025_class004.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Select/job014/particles.star"
            " --o Class3D/job011/run --ref "
            "InitialModel/job015/run_it150_class001_symD2.mrc --ini_high 50.0"
            " --dont_combine_weights_via_disc --preread_images --pool 30 --pad 2"
            " --skip_gridding --ctf --ctf_corrected_ref --iter 25 --tau2_fudge 4"
            " --particle_diameter 200 --K 4 --flatten_solvent --zero_mask"
            " --oversampling 1 --healpix_order 2 --offset_range 5 --offset_step 2.0"
            " --sym C1 --norm --scale --helix --helical_inner_diameter 20"
            " --helical_outer_diameter 50 --helical_nr_asu 1"
            " --helical_twist_initial 0 --helical_rise_initial 0 "
            "--helical_z_percentage 0.3 "
            "--sigma_tilt 5 --sigma_psi 3.33333 --sigma_rot 3.33333 --j "
            '6 --gpu "4:5:6:7" --pipeline_control Class3D/job011/ '
            ">> Class3D/job011/run.out 2>> Class3D/job011/run.err & ",
        )

    def test_get_command_class3D_helical_nosym(self):
        generic_tests.general_get_command_test(
            self,
            "Class3D",
            "class3D_helical_nosym.job",
            11,
            {
                "Select/job014/particles.star": NODES["Part data"],
                "InitialModel/job015/run_it150_class001_symD2.mrc": NODES["3D refs"],
            },
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
                "run_it025_class001.mrc": NODES["3D refs"],
                "run_it025_class002.mrc": NODES["3D refs"],
                "run_it025_class003.mrc": NODES["3D refs"],
                "run_it025_class004.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Select/job014/particles.star"
            " --o Class3D/job011/run --ref "
            "InitialModel/job015/run_it150_class001_symD2.mrc --ini_high 50.0"
            " --dont_combine_weights_via_disc --preread_images --pool 30 --pad 2"
            " --skip_gridding --ctf --ctf_corrected_ref --iter 25 --tau2_fudge 4"
            " --particle_diameter 200 --K 4 --flatten_solvent --zero_mask"
            " --oversampling 1 --healpix_order 2 --offset_range 5 --offset_step 2.0"
            " --sym C1 --norm --scale --helix --helical_inner_diameter 20"
            " --helical_outer_diameter 50 --ignore_helical_symmetry "
            "--helical_keep_tilt_prior_fixed "
            "--sigma_tilt 5 --sigma_psi 3.33333 --sigma_rot 3.33333 --j "
            '6 --gpu "4:5:6:7" --pipeline_control Class3D/job011/ '
            ">> Class3D/job011/run.out 2>> Class3D/job011/run.err & ",
        )

    def test_get_command_class3D_helical_search(self):
        generic_tests.general_get_command_test(
            self,
            "Class3D",
            "class3D_helical_search.job",
            11,
            {
                "Select/job014/particles.star": NODES["Part data"],
                "InitialModel/job015/run_it150_class001_symD2.mrc": NODES["3D refs"],
            },
            {
                "run_it025_data.star": NODES["Part data"],
                "run_it025_model.star": NODES["Model"],
                "run_it025_class001.mrc": NODES["3D refs"],
                "run_it025_class002.mrc": NODES["3D refs"],
                "run_it025_class003.mrc": NODES["3D refs"],
                "run_it025_class004.mrc": NODES["3D refs"],
            },
            "mpirun -n 5 `which relion_refine_mpi` --i Select/job014/particles.star"
            " --o Class3D/job011/run --ref "
            "InitialModel/job015/run_it150_class001_symD2.mrc --ini_high 50.0"
            " --dont_combine_weights_via_disc --preread_images --pool 30 --pad 2"
            " --skip_gridding --ctf --ctf_corrected_ref --iter 25 --tau2_fudge 4"
            " --particle_diameter 200 --K 4 --flatten_solvent --zero_mask"
            " --oversampling 1 --healpix_order 2 --offset_range 5 --offset_step 2.0"
            " --sym C1 --norm --scale --helix --helical_inner_diameter 20"
            " --helical_outer_diameter 50 --helical_nr_asu 1"
            " --helical_twist_initial 0 --helical_rise_initial 0 "
            "--helical_z_percentage 0.3 --helical_symmetry_search "
            "--helical_twist_min 15 --helical_twist_max 30 "
            "--helical_twist_inistep 2 --helical_rise_min 10 "
            "--helical_rise_max 20 --helical_rise_inistep 1 "
            "--helical_keep_tilt_prior_fixed "
            "--sigma_tilt 5 --sigma_psi 3.33333 --sigma_rot 3.33333 --j "
            '6 --gpu "4:5:6:7" --pipeline_control Class3D/job011/ '
            ">> Class3D/job011/run.out 2>> Class3D/job011/run.err & ",
        )


if __name__ == "__main__":
    unittest.main()
